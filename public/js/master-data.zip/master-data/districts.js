// districts.js
window.masterDataV2 = window.masterDataV2 || {};
window.masterDataV2.districts = [
    { id: 303, text: "24 PARAGANAS NORTH" },
    { id: 304, text: "24 PARAGANAS SOUTH" },
    { id: 664, text: "Alipurduar" },
    { id: 305, text: "BANKURA" },
    { id: 307, text: "BIRBHUM" },
    { id: 308, text: "COOCHBEHAR" },
    { id: 309, text: "DARJEELING" },
    { id: 310, text: "DINAJPUR DAKSHIN" },
    { id: 311, text: "DINAJPUR UTTAR" },
    { id: 312, text: "HOOGHLY" },
    { id: 313, text: "HOWRAH" },
    { id: 314, text: "JALPAIGURI" },
    { id: 703, text: "Jhargram" },
    { id: 702, text: "KALIMPONG" },
    { id: 316, text: "MALDAH" },
    { id: 317, text: "MEDINIPUR EAST" },
    { id: 318, text: "MEDINIPUR WEST" },
    { id: 319, text: "MURSHIDABAD" },
    { id: 320, text: "NADIA" },
    { id: 704, text: "PASCHIM BARDHAMAN" },
    { id: 306, text: "PURBA BARDHAMAN" },
    { id: 321, text: "PURULIA" },
    { id: 315, text: "KMC" }
];

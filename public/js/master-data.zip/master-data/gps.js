window.masterDataV2 = window.masterDataV2 || {};

window.masterDataV2.gps= [
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110658,
            "text": "PADAMKANDI"
        },
        {
            "district_code": 317,
            "block_code": 2947,
            "id": 110005,
            "text": "GURGRAM"
        },
        {
            "district_code": 305,
            "block_code": 2793,
            "id": 108459,
            "text": "PURBA-NABASAN"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108900,
            "text": "BANAGRAM"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109556,
            "text": "BASANTAPUR"
        },
        {
            "district_code": 314,
            "block_code": 2921,
            "id": 109742,
            "text": "MAGURMARI-I"
        },
        {
            "district_code": 319,
            "block_code": 3009,
            "id": 110606,
            "text": "JURANPUR"
        },
        {
            "district_code": 307,
            "block_code": 2830,
            "id": 108784,
            "text": "BABUIJORE"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108974,
            "text": "KISHAMAT DASGRAM"
        },
        {
            "district_code": 306,
            "block_code": 2810,
            "id": 108612,
            "text": "SUDPUR"
        },
        {
            "district_code": 303,
            "block_code": 2728,
            "id": 107825,
            "text": "KAMPA-CHAKLA"
        },
        {
            "district_code": 321,
            "block_code": 3045,
            "id": 110964,
            "text": "MATHA"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109449,
            "text": "PYANTRA"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260981,
            "text": "SAMSING"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109954,
            "text": "BAKHRABAD"
        },
        {
            "district_code": 321,
            "block_code": 3050,
            "id": 111006,
            "text": "MUKUNDAPUR"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110918,
            "text": "KAMALPUR"
        },
        {
            "district_code": 704,
            "block_code": 2809,
            "id": 108598,
            "text": "BANKATI"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110827,
            "text": "MIRA-II"
        },
        {
            "district_code": 306,
            "block_code": 2797,
            "id": 108492,
            "text": "VEDIA"
        },
        {
            "district_code": 317,
            "block_code": 2952,
            "id": 110046,
            "text": "MARISHDA"
        },
        {
            "district_code": 306,
            "block_code": 2822,
            "id": 108713,
            "text": "JHAUDANGA"
        },
        {
            "district_code": 303,
            "block_code": 2728,
            "id": 107827,
            "text": "KOWGACHI-II"
        },
        {
            "district_code": 306,
            "block_code": 2818,
            "id": 108684,
            "text": "BARAPALASAN-II"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109345,
            "text": "SITGRAM"
        },
        {
            "district_code": 304,
            "block_code": 2767,
            "id": 108229,
            "text": "UTTAR LAKSHMINARAYANPUR"
        },
        {
            "district_code": 316,
            "block_code": 2941,
            "id": 109949,
            "text": "RATHBARI"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109188,
            "text": "DANGA"
        },
        {
            "district_code": 311,
            "block_code": 2884,
            "id": 109315,
            "text": "DHANKOIL"
        },
        {
            "district_code": 310,
            "block_code": 2873,
            "id": 109213,
            "text": "PUNDARI"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109336,
            "text": "BIRGHOI"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 243875,
            "text": "NATSHAL-II"
        },
        {
            "district_code": 303,
            "block_code": 2741,
            "id": 107950,
            "text": "RAJARHAT BISHNUPUR-II"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109571,
            "text": "JAYPUR"
        },
        {
            "district_code": 306,
            "block_code": 2821,
            "id": 108711,
            "text": "SAMUDRAGARH"
        },
        {
            "district_code": 305,
            "block_code": 2788,
            "id": 108414,
            "text": "DUNDAR"
        },
        {
            "district_code": 321,
            "block_code": 3047,
            "id": 110980,
            "text": "DHELATBAMU"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109902,
            "text": "SALAIDANGA"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109749,
            "text": "DEOGAON"
        },
        {
            "district_code": 321,
            "block_code": 3063,
            "id": 111119,
            "text": "RAMCHANDRAPUR-KOTALDI"
        },
        {
            "district_code": 305,
            "block_code": 2795,
            "id": 108472,
            "text": "BELSULIA"
        },
        {
            "district_code": 304,
            "block_code": 2747,
            "id": 108015,
            "text": "PRANGANJ"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110663,
            "text": "BILBORAKOPRA"
        },
        {
            "district_code": 317,
            "block_code": 2947,
            "id": 110006,
            "text": "KAJLAGARH"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109564,
            "text": "UDANG-I"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110889,
            "text": "BILLWAGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110490,
            "text": "NARAYANBARH"
        },
        {
            "district_code": 305,
            "block_code": 2787,
            "id": 108403,
            "text": "BALSI-II"
        },
        {
            "district_code": 303,
            "block_code": 2731,
            "id": 107852,
            "text": "RAJENDRAPUR"
        },
        {
            "district_code": 319,
            "block_code": 3009,
            "id": 110599,
            "text": "DHULAURI"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110294,
            "text": "RANICHAK"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108039,
            "text": "BAKHRAHAT"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110523,
            "text": "MAHULA-II"
        },
        {
            "district_code": 305,
            "block_code": 2793,
            "id": 108452,
            "text": "DHULAI"
        },
        {
            "district_code": 318,
            "block_code": 2976,
            "id": 110261,
            "text": "DANTAN-II"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110527,
            "text": "ANDULBARIA-I"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110919,
            "text": "MAJHERGRAM"
        },
        {
            "district_code": 309,
            "block_code": 2867,
            "id": 109164,
            "text": "UPPER BAGDOGRA"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108063,
            "text": "NORTH BAWALI"
        },
        {
            "district_code": 317,
            "block_code": 2950,
            "id": 110036,
            "text": "NAYAPUT"
        },
        {
            "district_code": 304,
            "block_code": 2754,
            "id": 108082,
            "text": "NARAYANPUR"
        },
        {
            "district_code": 313,
            "block_code": 2908,
            "id": 109590,
            "text": "ANTILA"
        },
        {
            "district_code": 319,
            "block_code": 3020,
            "id": 110711,
            "text": "LAKSHMIJOLA"
        },
        {
            "district_code": 317,
            "block_code": 2969,
            "id": 110196,
            "text": "BALLUK-I"
        },
        {
            "district_code": 320,
            "block_code": 3039,
            "id": 110904,
            "text": "KHISMA"
        },
        {
            "district_code": 305,
            "block_code": 2795,
            "id": 108476,
            "text": "MORAR"
        },
        {
            "district_code": 704,
            "block_code": 2809,
            "id": 108601,
            "text": "KANKSA"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109730,
            "text": "TATPARA-II"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110656,
            "text": "MAHISAR"
        },
        {
            "district_code": 303,
            "block_code": 2742,
            "id": 107952,
            "text": "BAYERMARI-II"
        },
        {
            "district_code": 317,
            "block_code": 2963,
            "id": 110146,
            "text": "BOYAL-II"
        },
        {
            "district_code": 314,
            "block_code": 2930,
            "id": 109841,
            "text": "CHAMPAGURI"
        },
        {
            "district_code": 307,
            "block_code": 2842,
            "id": 108890,
            "text": "BUDHIGRAM"
        },
        {
            "district_code": 305,
            "block_code": 2789,
            "id": 108426,
            "text": "RAJAKATA"
        },
        {
            "district_code": 703,
            "block_code": 3000,
            "id": 110506,
            "text": "DHANGHORI"
        },
        {
            "district_code": 303,
            "block_code": 2737,
            "id": 107914,
            "text": "HALIPUR"
        },
        {
            "district_code": 307,
            "block_code": 2841,
            "id": 108888,
            "text": "NARAYANPUR"
        },
        {
            "district_code": 311,
            "block_code": 2878,
            "id": 109252,
            "text": "HAPTIAGACHH"
        },
        {
            "district_code": 307,
            "block_code": 2827,
            "id": 108757,
            "text": "KANKALITALA"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109038,
            "text": "NATABARI-I"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110306,
            "text": "RADHAMOHANPUR-I"
        },
        {
            "district_code": 321,
            "block_code": 3057,
            "id": 111074,
            "text": "PARA"
        },
        {
            "district_code": 308,
            "block_code": 2852,
            "id": 108997,
            "text": "HAZRAHAT-I"
        },
        {
            "district_code": 306,
            "block_code": 2804,
            "id": 108552,
            "text": "KHANO"
        },
        {
            "district_code": 303,
            "block_code": 2723,
            "id": 107779,
            "text": "BERABERIA"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110584,
            "text": "BIPRASEKHAR"
        },
        {
            "district_code": 308,
            "block_code": 2851,
            "id": 108989,
            "text": "LATAPOTA"
        },
        {
            "district_code": 304,
            "block_code": 2767,
            "id": 108227,
            "text": "NALUA"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109328,
            "text": "LAHUTARA-II"
        },
        {
            "district_code": 308,
            "block_code": 2853,
            "id": 109008,
            "text": "JAMALDAHA"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260962,
            "text": "LODHOMA-II"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108825,
            "text": "DEUCHA"
        },
        {
            "district_code": 321,
            "block_code": 3046,
            "id": 110968,
            "text": "BALARAMPUR"
        },
        {
            "district_code": 318,
            "block_code": 2997,
            "id": 110472,
            "text": "GOBORDHANPUR"
        },
        {
            "district_code": 321,
            "block_code": 3051,
            "id": 111014,
            "text": "KALMA"
        },
        {
            "district_code": 308,
            "block_code": 2854,
            "id": 109015,
            "text": "CHAMTA"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260988,
            "text": "LOWER SONADA-II"
        },
        {
            "district_code": 303,
            "block_code": 2738,
            "id": 107925,
            "text": "MAKHALGACHHA"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107797,
            "text": "SAYESTANAGAR-I"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 261027,
            "text": "PEDON"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109338,
            "text": "JAGADISHPUR"
        },
        {
            "district_code": 311,
            "block_code": 2878,
            "id": 109250,
            "text": "DASPARA"
        },
        {
            "district_code": 305,
            "block_code": 2795,
            "id": 108470,
            "text": "AJODHYA"
        },
        {
            "district_code": 664,
            "block_code": 2926,
            "id": 109802,
            "text": "MADARIHAT"
        },
        {
            "district_code": 318,
            "block_code": 2992,
            "id": 110427,
            "text": "PAPARARA-II"
        },
        {
            "district_code": 312,
            "block_code": 2904,
            "id": 109543,
            "text": "ASHTARADATTAPUR"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109027,
            "text": "ANDARAN-FULBARI-II"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107791,
            "text": "JADURHATI UTTAR"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110669,
            "text": "MANIKCHAK"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110457,
            "text": "RANISARAI"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261011,
            "text": "SAMTHAR"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110383,
            "text": "NEDABAHARA"
        },
        {
            "district_code": 321,
            "block_code": 3058,
            "id": 111077,
            "text": "CHANDRA"
        },
        {
            "district_code": 321,
            "block_code": 3060,
            "id": 111101,
            "text": "PINDRA"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109660,
            "text": "RAGHUDEBBATI"
        },
        {
            "district_code": 304,
            "block_code": 2755,
            "id": 108089,
            "text": "HARINDANGA"
        },
        {
            "district_code": 321,
            "block_code": 3054,
            "id": 111047,
            "text": "DHANARAH"
        },
        {
            "district_code": 305,
            "block_code": 2789,
            "id": 108427,
            "text": "RANIBANDH"
        },
        {
            "district_code": 307,
            "block_code": 2830,
            "id": 108787,
            "text": "KENDGORE"
        },
        {
            "district_code": 317,
            "block_code": 2948,
            "id": 110019,
            "text": "MUGBERIA"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110806,
            "text": "MAYURHAT-I"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109636,
            "text": "SHIALDANGA"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108138,
            "text": "RAJAPUR KORABEG"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110220,
            "text": "PIPULBERIA-II"
        },
        {
            "district_code": 303,
            "block_code": 2729,
            "id": 107835,
            "text": "MOHANPUR"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109788,
            "text": "KHOARDANGA-I"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108956,
            "text": "DINHATA VILL-I"
        },
        {
            "district_code": 319,
            "block_code": 3017,
            "id": 110688,
            "text": "PANCHGRAM"
        },
        {
            "district_code": 313,
            "block_code": 2909,
            "id": 109601,
            "text": "DURGAPUR ABHAYNAGAR-II"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108198,
            "text": "DHAMUA UTTAR"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111035,
            "text": "KALIDAHA"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109346,
            "text": "ARANDI-I"
        },
        {
            "district_code": 318,
            "block_code": 2992,
            "id": 110421,
            "text": "CHANGUAL"
        },
        {
            "district_code": 309,
            "block_code": 2866,
            "id": 261048,
            "text": "DUPTIN"
        },
        {
            "district_code": 306,
            "block_code": 2804,
            "id": 108550,
            "text": "GALSI"
        },
        {
            "district_code": 317,
            "block_code": 2953,
            "id": 110057,
            "text": "JERTHAN"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108795,
            "text": "CHAUHATTA-MAHODARI-I"
        },
        {
            "district_code": 304,
            "block_code": 2748,
            "id": 108026,
            "text": "POLERHAT-II"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108254,
            "text": "DURBACHATI"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108387,
            "text": "CHINGANI"
        },
        {
            "district_code": 306,
            "block_code": 2812,
            "id": 108621,
            "text": "GANGATIKURI"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108252,
            "text": "DAKSHIN RAIPUR"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109207,
            "text": "SUKDEVPUR"
        },
        {
            "district_code": 316,
            "block_code": 2946,
            "id": 109998,
            "text": "PUKHURIA"
        },
        {
            "district_code": 319,
            "block_code": 3026,
            "id": 110759,
            "text": "AURANGABAD-II"
        },
        {
            "district_code": 312,
            "block_code": 2890,
            "id": 109391,
            "text": "PANCHGHORA"
        },
        {
            "district_code": 309,
            "block_code": 2863,
            "id": 109133,
            "text": "RANIGANJ-PANISHALI"
        },
        {
            "district_code": 321,
            "block_code": 3060,
            "id": 111098,
            "text": "GHONGA"
        },
        {
            "district_code": 319,
            "block_code": 3010,
            "id": 110613,
            "text": "BEWA-I"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110110,
            "text": "GOJINA"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109555,
            "text": "BALICHAK"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261063,
            "text": "TAKDAH"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109502,
            "text": "AMNAN"
        },
        {
            "district_code": 319,
            "block_code": 3011,
            "id": 110621,
            "text": "DHARAMPUR"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109333,
            "text": "BARUA"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109308,
            "text": "PATIRAJPUR"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108821,
            "text": "ANGARGARIA"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110531,
            "text": "KASHIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110659,
            "text": "PARULIA"
        },
        {
            "district_code": 319,
            "block_code": 3016,
            "id": 110678,
            "text": "NATUNGRAM"
        },
        {
            "district_code": 312,
            "block_code": 2889,
            "id": 109381,
            "text": "NABABPUR"
        },
        {
            "district_code": 306,
            "block_code": 2810,
            "id": 108611,
            "text": "SREEKHANDA"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110940,
            "text": "PATHARGHATA-I"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108933,
            "text": "PATLAKHAWA"
        },
        {
            "district_code": 321,
            "block_code": 3054,
            "id": 111045,
            "text": "BISRI"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110293,
            "text": "PALASHPAI"
        },
        {
            "district_code": 317,
            "block_code": 2962,
            "id": 110141,
            "text": "SONACHURA"
        },
        {
            "district_code": 304,
            "block_code": 2747,
            "id": 108014,
            "text": "NARAYANPUR"
        },
        {
            "district_code": 305,
            "block_code": 2787,
            "id": 108406,
            "text": "BIUR-BETUR"
        },
        {
            "district_code": 305,
            "block_code": 2780,
            "id": 108346,
            "text": "INDPUR"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109759,
            "text": "SHALKUMAR"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110651,
            "text": "INDRANI"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108236,
            "text": "KUMRAPARA"
        },
        {
            "district_code": 319,
            "block_code": 3011,
            "id": 110620,
            "text": "CHOA"
        },
        {
            "district_code": 319,
            "block_code": 3021,
            "id": 110720,
            "text": "LOCHANPUR"
        },
        {
            "district_code": 319,
            "block_code": 3018,
            "id": 110692,
            "text": "BALI-II"
        },
        {
            "district_code": 306,
            "block_code": 2807,
            "id": 108582,
            "text": "BADLA"
        },
        {
            "district_code": 319,
            "block_code": 3020,
            "id": 110712,
            "text": "MITIPUR"
        },
        {
            "district_code": 305,
            "block_code": 2787,
            "id": 108404,
            "text": "BELUT-RASULPUR"
        },
        {
            "district_code": 304,
            "block_code": 2754,
            "id": 108078,
            "text": "DEULI-I"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 110107,
            "text": "NATSHAL-I"
        },
        {
            "district_code": 317,
            "block_code": 2968,
            "id": 110192,
            "text": "KALINDI"
        },
        {
            "district_code": 320,
            "block_code": 3037,
            "id": 110877,
            "text": "BABLARI"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109721,
            "text": "BHATIBARI"
        },
        {
            "district_code": 304,
            "block_code": 2755,
            "id": 108092,
            "text": "NETRA"
        },
        {
            "district_code": 317,
            "block_code": 2962,
            "id": 110132,
            "text": "BHAKUTIA"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109372,
            "text": "SOMRA-II"
        },
        {
            "district_code": 305,
            "block_code": 2794,
            "id": 108467,
            "text": "SALTORA"
        },
        {
            "district_code": 313,
            "block_code": 2909,
            "id": 109603,
            "text": "NISCHINDA"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109623,
            "text": "BARAGACHHIA-I"
        },
        {
            "district_code": 305,
            "block_code": 2793,
            "id": 108456,
            "text": "MANIKBAZAR"
        },
        {
            "district_code": 318,
            "block_code": 2994,
            "id": 110441,
            "text": "SHIALSAI"
        },
        {
            "district_code": 305,
            "block_code": 2783,
            "id": 108371,
            "text": "KHATRAGRAM-I"
        },
        {
            "district_code": 304,
            "block_code": 2766,
            "id": 108216,
            "text": "JAGADISHPUR"
        },
        {
            "district_code": 319,
            "block_code": 3022,
            "id": 110724,
            "text": "KALINAGAR-II"
        },
        {
            "district_code": 317,
            "block_code": 2967,
            "id": 110182,
            "text": "HALDIA-I"
        },
        {
            "district_code": 303,
            "block_code": 2726,
            "id": 107810,
            "text": "DATTAPUKUR-II"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108971,
            "text": "BURIRHAT-II"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109609,
            "text": "DAKSHIN JHAPARDAHA"
        },
        {
            "district_code": 704,
            "block_code": 2819,
            "id": 108698,
            "text": "SREERAMPUR"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110794,
            "text": "MAHATPUR"
        },
        {
            "district_code": 307,
            "block_code": 2835,
            "id": 108838,
            "text": "PALSA"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109294,
            "text": "MATIKUNDA-II"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108136,
            "text": "KHAKURDAHA"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108654,
            "text": "MAJIGRAM"
        },
        {
            "district_code": 317,
            "block_code": 2968,
            "id": 110193,
            "text": "MAITHANA"
        },
        {
            "district_code": 312,
            "block_code": 2904,
            "id": 109550,
            "text": "PURBARAMNAGAR"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109467,
            "text": "KISHOREPUR-II"
        },
        {
            "district_code": 306,
            "block_code": 2810,
            "id": 108609,
            "text": "KOSHIGRAM"
        },
        {
            "district_code": 319,
            "block_code": 3016,
            "id": 110680,
            "text": "TENTULIA"
        },
        {
            "district_code": 320,
            "block_code": 3036,
            "id": 110870,
            "text": "BELPUKUR"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109760,
            "text": "ARABINDA"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110517,
            "text": "CHAITANYAPUR-I"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109483,
            "text": "RAJHATI-II"
        },
        {
            "district_code": 304,
            "block_code": 2769,
            "id": 108245,
            "text": "NAMKHANA"
        },
        {
            "district_code": 704,
            "block_code": 2819,
            "id": 108702,
            "text": "CHHORA"
        },
        {
            "district_code": 304,
            "block_code": 2766,
            "id": 108210,
            "text": "ANCHANA"
        },
        {
            "district_code": 303,
            "block_code": 2727,
            "id": 107818,
            "text": "DADPUR"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109610,
            "text": "DOMJUR"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261035,
            "text": "GAYABARI-III"
        },
        {
            "district_code": 306,
            "block_code": 2804,
            "id": 108549,
            "text": "BHUNRI"
        },
        {
            "district_code": 312,
            "block_code": 2891,
            "id": 109396,
            "text": "DIGSUIHOYERA"
        },
        {
            "district_code": 319,
            "block_code": 3005,
            "id": 110565,
            "text": "KUTHIRAMPUR"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110151,
            "text": "GHOSHPUR"
        },
        {
            "district_code": 321,
            "block_code": 3052,
            "id": 111022,
            "text": "CHEKYA"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 108001,
            "text": "FOOLMALANCHA"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110491,
            "text": "NAWGAON"
        },
        {
            "district_code": 303,
            "block_code": 2727,
            "id": 107817,
            "text": "CHANDIGARH-ROHANDA"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110782,
            "text": "TATLA-I"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108645,
            "text": "BHALUGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110284,
            "text": "DUDHKOMRA"
        },
        {
            "district_code": 704,
            "block_code": 2802,
            "id": 108533,
            "text": "GAURBAZAR"
        },
        {
            "district_code": 304,
            "block_code": 2755,
            "id": 108093,
            "text": "PARULIA"
        },
        {
            "district_code": 306,
            "block_code": 2818,
            "id": 108687,
            "text": "BOHAR-I"
        },
        {
            "district_code": 317,
            "block_code": 2951,
            "id": 110044,
            "text": "KUSUMPUR"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261008,
            "text": "PABRINGTAR"
        },
        {
            "district_code": 703,
            "block_code": 2986,
            "id": 110365,
            "text": "SHASHRHA"
        },
        {
            "district_code": 306,
            "block_code": 2808,
            "id": 108589,
            "text": "BAGHNAPARA"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109362,
            "text": "CHARKRISHNABATI"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110534,
            "text": "RAMPARA-II"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108754,
            "text": "SALANPUR"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109521,
            "text": "ANANDANAGAR"
        },
        {
            "district_code": 306,
            "block_code": 2803,
            "id": 108544,
            "text": "PARAJ"
        },
        {
            "district_code": 304,
            "block_code": 2767,
            "id": 108228,
            "text": "SHANKARPUR"
        },
        {
            "district_code": 312,
            "block_code": 2896,
            "id": 109452,
            "text": "DILAKASH"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109574,
            "text": "KALNA"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109909,
            "text": "JAJAIL"
        },
        {
            "district_code": 317,
            "block_code": 2965,
            "id": 110165,
            "text": "BARHAT"
        },
        {
            "district_code": 703,
            "block_code": 2972,
            "id": 110228,
            "text": "DAHIJURI"
        },
        {
            "district_code": 703,
            "block_code": 2987,
            "id": 110372,
            "text": "KAPGARI"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107873,
            "text": "CHAKLA"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261044,
            "text": "ST. MARRYS-III"
        },
        {
            "district_code": 303,
            "block_code": 2738,
            "id": 107926,
            "text": "MURARISHA"
        },
        {
            "district_code": 321,
            "block_code": 3044,
            "id": 110959,
            "text": "SIRKABAD"
        },
        {
            "district_code": 303,
            "block_code": 2736,
            "id": 107906,
            "text": "DIGHARA MALIKBERIA"
        },
        {
            "district_code": 703,
            "block_code": 3000,
            "id": 110511,
            "text": "RAGRAH"
        },
        {
            "district_code": 307,
            "block_code": 2838,
            "id": 108859,
            "text": "BARA-II"
        },
        {
            "district_code": 306,
            "block_code": 2803,
            "id": 108539,
            "text": "BUDBUD"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109880,
            "text": "JADUPUR-I"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 107997,
            "text": "BASANTI"
        },
        {
            "district_code": 304,
            "block_code": 2755,
            "id": 108086,
            "text": "BASULDANGA"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107886,
            "text": "DUMA"
        },
        {
            "district_code": 317,
            "block_code": 2951,
            "id": 110039,
            "text": "BHAJACHAULIA"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109472,
            "text": "TANTISAL"
        },
        {
            "district_code": 313,
            "block_code": 2917,
            "id": 109698,
            "text": "HEERAPUR"
        },
        {
            "district_code": 306,
            "block_code": 2817,
            "id": 108676,
            "text": "DALUIBAZAR-II"
        },
        {
            "district_code": 320,
            "block_code": 3041,
            "id": 110926,
            "text": "BABLA"
        },
        {
            "district_code": 305,
            "block_code": 2781,
            "id": 108353,
            "text": "INDAS-II"
        },
        {
            "district_code": 316,
            "block_code": 2944,
            "id": 109980,
            "text": "MAHISBATHANI"
        },
        {
            "district_code": 318,
            "block_code": 2993,
            "id": 110430,
            "text": "CHANDRA"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108313,
            "text": "ARRAH"
        },
        {
            "district_code": 319,
            "block_code": 3012,
            "id": 110631,
            "text": "FARIDPUR"
        },
        {
            "district_code": 303,
            "block_code": 2740,
            "id": 107941,
            "text": "DHUTURDAHA"
        },
        {
            "district_code": 304,
            "block_code": 2756,
            "id": 108097,
            "text": "KHORDA"
        },
        {
            "district_code": 307,
            "block_code": 2828,
            "id": 108772,
            "text": "PADUMA"
        },
        {
            "district_code": 317,
            "block_code": 2949,
            "id": 110021,
            "text": "BRAJALALCHAK"
        },
        {
            "district_code": 317,
            "block_code": 2954,
            "id": 110066,
            "text": "DUBDA"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109930,
            "text": "ALINAGAR"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109883,
            "text": "KOTWALI"
        },
        {
            "district_code": 316,
            "block_code": 2934,
            "id": 109875,
            "text": "KSHEMPUR"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109470,
            "text": "RAMMOHAN-I"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108104,
            "text": "BELSINGHA-I"
        },
        {
            "district_code": 307,
            "block_code": 2845,
            "id": 108921,
            "text": "KOMA"
        },
        {
            "district_code": 305,
            "block_code": 2790,
            "id": 108430,
            "text": "BAMUNTORE"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110649,
            "text": "BALIA"
        },
        {
            "district_code": 304,
            "block_code": 2748,
            "id": 108021,
            "text": "BHAGAWANPUR"
        },
        {
            "district_code": 305,
            "block_code": 2791,
            "id": 108443,
            "text": "SARENGA"
        },
        {
            "district_code": 320,
            "block_code": 3033,
            "id": 110843,
            "text": "DIGHAL KANDI"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110896,
            "text": "MAJHERGRAM"
        },
        {
            "district_code": 309,
            "block_code": 2865,
            "id": 109150,
            "text": "MATIGARA-I"
        },
        {
            "district_code": 316,
            "block_code": 2946,
            "id": 109996,
            "text": "PARANPUR"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110297,
            "text": "BHARATPUR"
        },
        {
            "district_code": 306,
            "block_code": 2817,
            "id": 108673,
            "text": "AMADPUR"
        },
        {
            "district_code": 703,
            "block_code": 3000,
            "id": 110509,
            "text": "LAUDAHA"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109469,
            "text": "POLE-II"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111036,
            "text": "KASHIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110516,
            "text": "BHABTA-II"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109496,
            "text": "PANDUA"
        },
        {
            "district_code": 317,
            "block_code": 2947,
            "id": 110003,
            "text": "BHAGWANPUR"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109614,
            "text": "MAHIYARI-II"
        },
        {
            "district_code": 305,
            "block_code": 2775,
            "id": 108298,
            "text": "MANKANALI"
        },
        {
            "district_code": 310,
            "block_code": 2873,
            "id": 109215,
            "text": "SHIRSHI"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110770,
            "text": "DEWLI"
        },
        {
            "district_code": 321,
            "block_code": 3048,
            "id": 110986,
            "text": "CHIRUDIH"
        },
        {
            "district_code": 319,
            "block_code": 3017,
            "id": 110685,
            "text": "MAHURUL"
        },
        {
            "district_code": 313,
            "block_code": 2915,
            "id": 109678,
            "text": "DIHIMONDALGHAT-II"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109193,
            "text": "VATPARA"
        },
        {
            "district_code": 307,
            "block_code": 2828,
            "id": 108774,
            "text": "SAHAPUR"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111030,
            "text": "BARRAH"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109629,
            "text": "JAGATBALLAVPUR-II"
        },
        {
            "district_code": 307,
            "block_code": 2829,
            "id": 108782,
            "text": "NANASOLE"
        },
        {
            "district_code": 305,
            "block_code": 2792,
            "id": 108448,
            "text": "MANDALGRAM"
        },
        {
            "district_code": 305,
            "block_code": 2795,
            "id": 108477,
            "text": "RADHANAGAR"
        },
        {
            "district_code": 306,
            "block_code": 2800,
            "id": 108519,
            "text": "KSHETIA"
        },
        {
            "district_code": 306,
            "block_code": 2811,
            "id": 108618,
            "text": "SINGI"
        },
        {
            "district_code": 307,
            "block_code": 2841,
            "id": 108880,
            "text": "AYAS"
        },
        {
            "district_code": 316,
            "block_code": 2932,
            "id": 109859,
            "text": "JAGDALA"
        },
        {
            "district_code": 309,
            "block_code": 2866,
            "id": 261049,
            "text": "PAHELIGAON SCHOOL DARA-I"
        },
        {
            "district_code": 321,
            "block_code": 3046,
            "id": 110969,
            "text": "BARAURMA"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110547,
            "text": "NAODAPANUR"
        },
        {
            "district_code": 317,
            "block_code": 2949,
            "id": 110024,
            "text": "CHAUKHALI"
        },
        {
            "district_code": 303,
            "block_code": 2729,
            "id": 107834,
            "text": "BILKANDA-II"
        },
        {
            "district_code": 306,
            "block_code": 2823,
            "id": 108727,
            "text": "PALSONA"
        },
        {
            "district_code": 319,
            "block_code": 3018,
            "id": 110697,
            "text": "NAODA"
        },
        {
            "district_code": 305,
            "block_code": 2779,
            "id": 108338,
            "text": "HIRBANDH"
        },
        {
            "district_code": 313,
            "block_code": 2908,
            "id": 109594,
            "text": "MUALYAN BENAPUR"
        },
        {
            "district_code": 316,
            "block_code": 2945,
            "id": 109985,
            "text": "BHADO"
        },
        {
            "district_code": 303,
            "block_code": 2744,
            "id": 107970,
            "text": "CHARGHAT"
        },
        {
            "district_code": 303,
            "block_code": 2738,
            "id": 107920,
            "text": "BARUNHAT RAMESWARPUR"
        },
        {
            "district_code": 321,
            "block_code": 3047,
            "id": 110982,
            "text": "SINDRI"
        },
        {
            "district_code": 318,
            "block_code": 2982,
            "id": 110327,
            "text": "MAKLI"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107883,
            "text": "CHANDPARA"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110158,
            "text": "PRATAPPUR-I"
        },
        {
            "district_code": 318,
            "block_code": 2977,
            "id": 110265,
            "text": "HARIPUR"
        },
        {
            "district_code": 316,
            "block_code": 2939,
            "id": 109928,
            "text": "SULTANNAGAR"
        },
        {
            "district_code": 307,
            "block_code": 2842,
            "id": 108897,
            "text": "SAHAPUR"
        },
        {
            "district_code": 704,
            "block_code": 2802,
            "id": 108538,
            "text": "PRATAPPUR"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109441,
            "text": "HARIPALKINGKARBATI"
        },
        {
            "district_code": 320,
            "block_code": 3036,
            "id": 110871,
            "text": "DHUBULIA-I"
        },
        {
            "district_code": 318,
            "block_code": 2974,
            "id": 110247,
            "text": "MANIKKUNDU"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109040,
            "text": "BAROKODALI-I"
        },
        {
            "district_code": 306,
            "block_code": 2800,
            "id": 108516,
            "text": "BAGHAR-II"
        },
        {
            "district_code": 305,
            "block_code": 2791,
            "id": 108442,
            "text": "NETURPUR"
        },
        {
            "district_code": 306,
            "block_code": 2821,
            "id": 108706,
            "text": "BOGPUR"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 110100,
            "text": "BETKUNDU"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108951,
            "text": "BARA ATIABARI-I"
        },
        {
            "district_code": 303,
            "block_code": 2731,
            "id": 107846,
            "text": "CHAMPAPUKUR"
        },
        {
            "district_code": 319,
            "block_code": 3009,
            "id": 110608,
            "text": "RAIPUR"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109489,
            "text": "ITACHUNAKHANYAN"
        },
        {
            "district_code": 317,
            "block_code": 2947,
            "id": 110007,
            "text": "KAKRA"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109526,
            "text": "BASUBATI"
        },
        {
            "district_code": 307,
            "block_code": 2842,
            "id": 108891,
            "text": "DUNIGRAM"
        },
        {
            "district_code": 310,
            "block_code": 2875,
            "id": 109222,
            "text": "BHOUR"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109683,
            "text": "DEBIPUR"
        },
        {
            "district_code": 305,
            "block_code": 2783,
            "id": 108372,
            "text": "KHATRAGRAM-II"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110408,
            "text": "KESHPUR"
        },
        {
            "district_code": 305,
            "block_code": 2791,
            "id": 108439,
            "text": "CHILTORE"
        },
        {
            "district_code": 319,
            "block_code": 3018,
            "id": 110696,
            "text": "MADHUPUR"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109885,
            "text": "MILKI"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107986,
            "text": "MADARAT"
        },
        {
            "district_code": 319,
            "block_code": 3018,
            "id": 110698,
            "text": "PATIKABARI"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109642,
            "text": "GANGADHARPUR"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109488,
            "text": "HARALDASPUR"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261039,
            "text": "SEETONG-II"
        },
        {
            "district_code": 307,
            "block_code": 2836,
            "id": 108845,
            "text": "NANDIGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110453,
            "text": "MOKRAMPUR"
        },
        {
            "district_code": 303,
            "block_code": 2736,
            "id": 107905,
            "text": "BHURKUNDA"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 108004,
            "text": "KANTHALBERIA"
        },
        {
            "district_code": 310,
            "block_code": 2876,
            "id": 109236,
            "text": "UDAYPUR"
        },
        {
            "district_code": 303,
            "block_code": 2739,
            "id": 107935,
            "text": "SAHEBKHALI"
        },
        {
            "district_code": 311,
            "block_code": 2884,
            "id": 109311,
            "text": "ANANTAPUR"
        },
        {
            "district_code": 318,
            "block_code": 2982,
            "id": 110326,
            "text": "JOGARDANGA"
        },
        {
            "district_code": 319,
            "block_code": 3011,
            "id": 110623,
            "text": "HUMAIPUR"
        },
        {
            "district_code": 316,
            "block_code": 2934,
            "id": 109870,
            "text": "BHAKRI"
        },
        {
            "district_code": 303,
            "block_code": 2725,
            "id": 107806,
            "text": "RANAGHAT"
        },
        {
            "district_code": 306,
            "block_code": 2804,
            "id": 108556,
            "text": "SATINANDI"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109303,
            "text": "GULANDAR-II"
        },
        {
            "district_code": 310,
            "block_code": 2871,
            "id": 109194,
            "text": "BRAJABALLAVPUR"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109652,
            "text": "DHULAGARI"
        },
        {
            "district_code": 309,
            "block_code": 2866,
            "id": 261050,
            "text": "PAHELIGAON SCHOOL DARA-II"
        },
        {
            "district_code": 317,
            "block_code": 2965,
            "id": 110170,
            "text": "GOPALPUR"
        },
        {
            "district_code": 304,
            "block_code": 2753,
            "id": 108076,
            "text": "TALDI"
        },
        {
            "district_code": 316,
            "block_code": 2945,
            "id": 109990,
            "text": "KAHALA"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260971,
            "text": "SIRIKHOLA-DARAGAON"
        },
        {
            "district_code": 303,
            "block_code": 2736,
            "id": 107903,
            "text": "BANSPOLE"
        },
        {
            "district_code": 303,
            "block_code": 2735,
            "id": 107896,
            "text": "BARGOOM-I"
        },
        {
            "district_code": 303,
            "block_code": 2726,
            "id": 107814,
            "text": "KOTRA"
        },
        {
            "district_code": 316,
            "block_code": 2938,
            "id": 109918,
            "text": "MAHENDRAPUR"
        },
        {
            "district_code": 306,
            "block_code": 2797,
            "id": 108488,
            "text": "ERAL"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109049,
            "text": "SALBARI-I"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108116,
            "text": "BALI-I"
        },
        {
            "district_code": 317,
            "block_code": 2968,
            "id": 110188,
            "text": "BADALPUR"
        },
        {
            "district_code": 307,
            "block_code": 2836,
            "id": 108844,
            "text": "MITRAPUR"
        },
        {
            "district_code": 307,
            "block_code": 2829,
            "id": 108783,
            "text": "SIRSHA"
        },
        {
            "district_code": 318,
            "block_code": 2997,
            "id": 110478,
            "text": "KUSUMDA"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110087,
            "text": "BAISHNABCHAK"
        },
        {
            "district_code": 303,
            "block_code": 2744,
            "id": 107967,
            "text": "BALTI NITYANANDAKATI"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108118,
            "text": "BIPRADASPUR"
        },
        {
            "district_code": 319,
            "block_code": 3013,
            "id": 110646,
            "text": "MAHALANDI-I"
        },
        {
            "district_code": 320,
            "block_code": 3043,
            "id": 110947,
            "text": "HANSPUKURIA"
        },
        {
            "district_code": 704,
            "block_code": 2806,
            "id": 108577,
            "text": "PARASIA"
        },
        {
            "district_code": 316,
            "block_code": 2941,
            "id": 109945,
            "text": "GANGAPRASAD"
        },
        {
            "district_code": 313,
            "block_code": 2918,
            "id": 109702,
            "text": "BANIBAN"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261010,
            "text": "SAMALBONG"
        },
        {
            "district_code": 702,
            "block_code": 7354,
            "id": 261020,
            "text": "GITABLING"
        },
        {
            "district_code": 305,
            "block_code": 2778,
            "id": 108329,
            "text": "GANGAJALGHATI"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109299,
            "text": "CHHAYGHARA"
        },
        {
            "district_code": 305,
            "block_code": 2774,
            "id": 108294,
            "text": "KENJAKURA"
        },
        {
            "district_code": 305,
            "block_code": 2787,
            "id": 108411,
            "text": "PATRASAYER"
        },
        {
            "district_code": 317,
            "block_code": 2954,
            "id": 110069,
            "text": "SARBODAYA"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109490,
            "text": "JAMNA"
        },
        {
            "district_code": 321,
            "block_code": 3051,
            "id": 111013,
            "text": "JHALDA-DARDA"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110378,
            "text": "CHANDRI"
        },
        {
            "district_code": 321,
            "block_code": 3057,
            "id": 111072,
            "text": "JABARRAH-JHAPRA-II"
        },
        {
            "district_code": 319,
            "block_code": 3020,
            "id": 110708,
            "text": "GIRIA"
        },
        {
            "district_code": 321,
            "block_code": 3058,
            "id": 111085,
            "text": "PUNCHA"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107787,
            "text": "BAJITPUR"
        },
        {
            "district_code": 319,
            "block_code": 3018,
            "id": 110699,
            "text": "RAIPUR"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108113,
            "text": "MALLIKPUR"
        },
        {
            "district_code": 303,
            "block_code": 2725,
            "id": 107800,
            "text": "BAGDA"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108669,
            "text": "PIPALAN"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 244953,
            "text": "CHAPRA-I"
        },
        {
            "district_code": 307,
            "block_code": 2838,
            "id": 108863,
            "text": "SHITALGRAM"
        },
        {
            "district_code": 321,
            "block_code": 3055,
            "id": 111052,
            "text": "ANKROBARAKADAM"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108967,
            "text": "BAMANHAT-I"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108957,
            "text": "DINHATA VILL-II"
        },
        {
            "district_code": 304,
            "block_code": 2754,
            "id": 108079,
            "text": "DEULI-II"
        },
        {
            "district_code": 317,
            "block_code": 2953,
            "id": 110055,
            "text": "BARIDA"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111040,
            "text": "SONAIJURI"
        },
        {
            "district_code": 319,
            "block_code": 3026,
            "id": 110766,
            "text": "MAHESAIL-II"
        },
        {
            "district_code": 321,
            "block_code": 3047,
            "id": 110981,
            "text": "LATPADA"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108139,
            "text": "SRIPUR"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108158,
            "text": "SRI SRI RAMKRISHNA"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108941,
            "text": "GHUGHUMARI"
        },
        {
            "district_code": 316,
            "block_code": 2933,
            "id": 109868,
            "text": "MAKDAMPUR"
        },
        {
            "district_code": 318,
            "block_code": 2982,
            "id": 110324,
            "text": "GOHALDANGA"
        },
        {
            "district_code": 321,
            "block_code": 3052,
            "id": 111020,
            "text": "BAMNIYA-BELYADIH"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109268,
            "text": "DHARAMPUR-II"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107888,
            "text": "ICHAPUR-I"
        },
        {
            "district_code": 320,
            "block_code": 3034,
            "id": 110851,
            "text": "BHAJANGHAT TUNGI"
        },
        {
            "district_code": 321,
            "block_code": 3060,
            "id": 111095,
            "text": "BELMA"
        },
        {
            "district_code": 305,
            "block_code": 2792,
            "id": 108445,
            "text": "DUBRAJPUR"
        },
        {
            "district_code": 321,
            "block_code": 3057,
            "id": 111075,
            "text": "UDAYPUR-JOYNAGAR"
        },
        {
            "district_code": 305,
            "block_code": 2783,
            "id": 108368,
            "text": "DAHALA"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109825,
            "text": "CHURABHANDAR"
        },
        {
            "district_code": 664,
            "block_code": 2926,
            "id": 109798,
            "text": "BIRPARA-II"
        },
        {
            "district_code": 703,
            "block_code": 2986,
            "id": 110364,
            "text": "SATMA"
        },
        {
            "district_code": 304,
            "block_code": 2763,
            "id": 108179,
            "text": "JALABERIA-I"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109355,
            "text": "MALAYPUR-II"
        },
        {
            "district_code": 703,
            "block_code": 2972,
            "id": 110229,
            "text": "DHARAMPUR"
        },
        {
            "district_code": 704,
            "block_code": 2819,
            "id": 108696,
            "text": "MADANPUR"
        },
        {
            "district_code": 304,
            "block_code": 2763,
            "id": 108184,
            "text": "MERIGANJ-II"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110350,
            "text": "MONOHARPUR-II"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108197,
            "text": "DHAMUA DAKSHIN"
        },
        {
            "district_code": 306,
            "block_code": 2814,
            "id": 108638,
            "text": "KHANDAGHOSH"
        },
        {
            "district_code": 320,
            "block_code": 3033,
            "id": 110846,
            "text": "NARAYANPUR-I"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107859,
            "text": "DHARAM PUKURIA"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108032,
            "text": "JULPIA"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260993,
            "text": "POKHRIABONG-II"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110533,
            "text": "RAMPARA-I"
        },
        {
            "district_code": 321,
            "block_code": 3044,
            "id": 110955,
            "text": "HENSLA"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109934,
            "text": "GAYESHBARI"
        },
        {
            "district_code": 319,
            "block_code": 3013,
            "id": 110647,
            "text": "MAHALANDI-II"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109291,
            "text": "ISLAMPUR"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109793,
            "text": "TURTURIKHANDA"
        },
        {
            "district_code": 304,
            "block_code": 2756,
            "id": 108095,
            "text": "KALATALAHAT"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109473,
            "text": "THAKURANICHAK"
        },
        {
            "district_code": 312,
            "block_code": 2889,
            "id": 109379,
            "text": "KUMIRMORE"
        },
        {
            "district_code": 321,
            "block_code": 3050,
            "id": 111004,
            "text": "GHAGRA"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109471,
            "text": "RAMMOHAN-II"
        },
        {
            "district_code": 304,
            "block_code": 2769,
            "id": 108247,
            "text": "SHIBRAMPUR"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110519,
            "text": "DEBKUNDU"
        },
        {
            "district_code": 321,
            "block_code": 3054,
            "id": 111046,
            "text": "CHANDRA-PAIRACHALI"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108864,
            "text": "BARASAOTA"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109358,
            "text": "SALEPUR-I"
        },
        {
            "district_code": 306,
            "block_code": 2797,
            "id": 108490,
            "text": "RAMNAGAR"
        },
        {
            "district_code": 321,
            "block_code": 3048,
            "id": 110987,
            "text": "DHADKA"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110829,
            "text": "PANIGHATA"
        },
        {
            "district_code": 320,
            "block_code": 3043,
            "id": 110951,
            "text": "SAHEBNAGAR"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110779,
            "text": "SILINDA-I"
        },
        {
            "district_code": 318,
            "block_code": 2982,
            "id": 110328,
            "text": "PATHARPARA"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108948,
            "text": "PATCHHARA"
        },
        {
            "district_code": 320,
            "block_code": 3043,
            "id": 110949,
            "text": "PALSUNDA-I"
        },
        {
            "district_code": 703,
            "block_code": 2987,
            "id": 110366,
            "text": "CHILKIGARH"
        },
        {
            "district_code": 309,
            "block_code": 2867,
            "id": 109161,
            "text": "LOWER BAGDOGRA"
        },
        {
            "district_code": 306,
            "block_code": 2822,
            "id": 108714,
            "text": "KALEKHANTALA-I"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109932,
            "text": "ALIPUR-II"
        },
        {
            "district_code": 317,
            "block_code": 2947,
            "id": 110009,
            "text": "MAHAMMADPUR-I"
        },
        {
            "district_code": 321,
            "block_code": 3059,
            "id": 111089,
            "text": "DURKU"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107867,
            "text": "PALLA"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110091,
            "text": "GOPALNAGAR"
        },
        {
            "district_code": 312,
            "block_code": 2904,
            "id": 109549,
            "text": "NAITAMALPAHARPUR"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109491,
            "text": "JAMNAGARMONDALAII"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109279,
            "text": "SAHAPUR-I"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110305,
            "text": "MALIGHATI"
        },
        {
            "district_code": 319,
            "block_code": 3009,
            "id": 110603,
            "text": "GHORAMARA"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108964,
            "text": "PETLA"
        },
        {
            "district_code": 321,
            "block_code": 3060,
            "id": 111094,
            "text": "AGOYA-NARRA"
        },
        {
            "district_code": 321,
            "block_code": 3057,
            "id": 111071,
            "text": "JABARRAH-JHAPRA-I"
        },
        {
            "district_code": 303,
            "block_code": 2739,
            "id": 107928,
            "text": "BISHPUR"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109882,
            "text": "KAJIGRAM"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261037,
            "text": "PANDU"
        },
        {
            "district_code": 318,
            "block_code": 2994,
            "id": 110438,
            "text": "MOHANPUR"
        },
        {
            "district_code": 303,
            "block_code": 2741,
            "id": 107949,
            "text": "RAJARHAT BISHNUPUR-I"
        },
        {
            "district_code": 312,
            "block_code": 2891,
            "id": 109400,
            "text": "MOGRA-II"
        },
        {
            "district_code": 702,
            "block_code": 7355,
            "id": 261022,
            "text": "KASHYONG"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109824,
            "text": "BARNIS"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110160,
            "text": "PURUSOTTAMPUR"
        },
        {
            "district_code": 704,
            "block_code": 2809,
            "id": 108600,
            "text": "GOPALPUR"
        },
        {
            "district_code": 319,
            "block_code": 3006,
            "id": 110571,
            "text": "BHARATPUR"
        },
        {
            "district_code": 320,
            "block_code": 3032,
            "id": 110834,
            "text": "HOGOLBERIA"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108505,
            "text": "BARABELOON-I"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109357,
            "text": "MAYAPUR-II"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 110106,
            "text": "LAKSHYA-II"
        },
        {
            "district_code": 303,
            "block_code": 2727,
            "id": 107820,
            "text": "KEMIA KHAMARPARA"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110212,
            "text": "ANANTAPUR-I"
        },
        {
            "district_code": 321,
            "block_code": 3061,
            "id": 111105,
            "text": "BERO"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108512,
            "text": "NITYANANDAPUR"
        },
        {
            "district_code": 307,
            "block_code": 2828,
            "id": 108765,
            "text": "BALIJURI"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260961,
            "text": "LODHOMA-I"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109340,
            "text": "KAMALABARI-II"
        },
        {
            "district_code": 303,
            "block_code": 2731,
            "id": 107848,
            "text": "DHANYAKURIA"
        },
        {
            "district_code": 317,
            "block_code": 2949,
            "id": 110029,
            "text": "NANDAPURBARAGHUNI"
        },
        {
            "district_code": 309,
            "block_code": 2866,
            "id": 261052,
            "text": "SOURENI-II"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108904,
            "text": "HATORA"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109658,
            "text": "NALPUR"
        },
        {
            "district_code": 318,
            "block_code": 2983,
            "id": 110337,
            "text": "SATBANKURA"
        },
        {
            "district_code": 316,
            "block_code": 2933,
            "id": 109863,
            "text": "BHAGABANPUR"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109505,
            "text": "GOSWAMIMALIPARA"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260950,
            "text": "BIJANBARI-PULBAZAR"
        },
        {
            "district_code": 321,
            "block_code": 3045,
            "id": 110962,
            "text": "BEERGRAM"
        },
        {
            "district_code": 308,
            "block_code": 2851,
            "id": 108990,
            "text": "NISHIGANJ-I"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110535,
            "text": "SHAKTIPUR"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109854,
            "text": "SIKARPUR"
        },
        {
            "district_code": 312,
            "block_code": 2889,
            "id": 109374,
            "text": "AINYA"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109339,
            "text": "KAMALABARI-I"
        },
        {
            "district_code": 319,
            "block_code": 3011,
            "id": 110622,
            "text": "HARIHARPARA"
        },
        {
            "district_code": 304,
            "block_code": 2754,
            "id": 108085,
            "text": "TAMBULDAHA-II"
        },
        {
            "district_code": 306,
            "block_code": 2800,
            "id": 108517,
            "text": "BANDUL-I"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110320,
            "text": "SANDHIPUR"
        },
        {
            "district_code": 321,
            "block_code": 3052,
            "id": 111026,
            "text": "NOWAHATU"
        },
        {
            "district_code": 306,
            "block_code": 2818,
            "id": 108690,
            "text": "SATGACHHIA-I"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108397,
            "text": "ONDA-II"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109290,
            "text": "GUNJARIA"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108275,
            "text": "KALIKAPUR-II"
        },
        {
            "district_code": 321,
            "block_code": 3061,
            "id": 111103,
            "text": "ARRAH"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108565,
            "text": "JOUGRAM"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108954,
            "text": "BHETAGURI-I"
        },
        {
            "district_code": 312,
            "block_code": 2903,
            "id": 109537,
            "text": "KANAIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110738,
            "text": "KABILPUR"
        },
        {
            "district_code": 306,
            "block_code": 2823,
            "id": 108725,
            "text": "NARUGRAM"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109617,
            "text": "NARNA"
        },
        {
            "district_code": 319,
            "block_code": 3012,
            "id": 110632,
            "text": "GHOSHPARA"
        },
        {
            "district_code": 308,
            "block_code": 2854,
            "id": 109017,
            "text": "SITAI-II"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110796,
            "text": "PIPRAGACHHI"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108321,
            "text": "JIRRAH"
        },
        {
            "district_code": 304,
            "block_code": 2769,
            "id": 108246,
            "text": "NARAYANPUR"
        },
        {
            "district_code": 306,
            "block_code": 2804,
            "id": 108548,
            "text": "ADRA"
        },
        {
            "district_code": 704,
            "block_code": 2806,
            "id": 108574,
            "text": "HIJALGARA"
        },
        {
            "district_code": 309,
            "block_code": 2868,
            "id": 109171,
            "text": "JALAS-NIJAMTARA"
        },
        {
            "district_code": 317,
            "block_code": 2967,
            "id": 110180,
            "text": "BASANTAPUR"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109264,
            "text": "SURJAPUR-I"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108060,
            "text": "KAMRABAD"
        },
        {
            "district_code": 318,
            "block_code": 2976,
            "id": 110260,
            "text": "DANTAN-I"
        },
        {
            "district_code": 305,
            "block_code": 2791,
            "id": 108438,
            "text": "BIKRAMPUR"
        },
        {
            "district_code": 307,
            "block_code": 2832,
            "id": 108813,
            "text": "TALOWAN"
        },
        {
            "district_code": 307,
            "block_code": 2829,
            "id": 108778,
            "text": "GHURISHA"
        },
        {
            "district_code": 317,
            "block_code": 2948,
            "id": 110016,
            "text": "GARBARI-II"
        },
        {
            "district_code": 320,
            "block_code": 3036,
            "id": 110872,
            "text": "DHUBULIA-II"
        },
        {
            "district_code": 313,
            "block_code": 2914,
            "id": 109666,
            "text": "BANESWARPUR-II"
        },
        {
            "district_code": 704,
            "block_code": 2798,
            "id": 108497,
            "text": "NUNI"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109350,
            "text": "GOURHATI-II"
        },
        {
            "district_code": 321,
            "block_code": 3047,
            "id": 110979,
            "text": "BHAGABANDH"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110670,
            "text": "NASHIPUR"
        },
        {
            "district_code": 321,
            "block_code": 3045,
            "id": 110965,
            "text": "SERENGDIH"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108658,
            "text": "SHIMULIA-I"
        },
        {
            "district_code": 317,
            "block_code": 2955,
            "id": 110074,
            "text": "DEULPOTA"
        },
        {
            "district_code": 317,
            "block_code": 2954,
            "id": 110068,
            "text": "PANIPARUL"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110801,
            "text": "BETNA GOBINDAPUR"
        },
        {
            "district_code": 306,
            "block_code": 2807,
            "id": 108583,
            "text": "BAIDYAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108105,
            "text": "BELSINGHA-II"
        },
        {
            "district_code": 321,
            "block_code": 3054,
            "id": 111048,
            "text": "GOPALNAGAR"
        },
        {
            "district_code": 320,
            "block_code": 7115,
            "id": 110776,
            "text": "MADANPUR-II"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108209,
            "text": "URELCHANDPUR"
        },
        {
            "district_code": 703,
            "block_code": 2973,
            "id": 110234,
            "text": "BANSPAHARI"
        },
        {
            "district_code": 703,
            "block_code": 2972,
            "id": 110231,
            "text": "NEPURA"
        },
        {
            "district_code": 305,
            "block_code": 2787,
            "id": 108408,
            "text": "JAMKURI"
        },
        {
            "district_code": 310,
            "block_code": 2873,
            "id": 109214,
            "text": "SAIYADPUR"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110449,
            "text": "KHURSI"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109265,
            "text": "SURJAPUR-II"
        },
        {
            "district_code": 305,
            "block_code": 2787,
            "id": 108407,
            "text": "HAMIRPUR"
        },
        {
            "district_code": 320,
            "block_code": 3041,
            "id": 110928,
            "text": "BELGORIA-I"
        },
        {
            "district_code": 321,
            "block_code": 3058,
            "id": 111076,
            "text": "BAGDA"
        },
        {
            "district_code": 305,
            "block_code": 2775,
            "id": 108299,
            "text": "NARRAH"
        },
        {
            "district_code": 313,
            "block_code": 2914,
            "id": 109670,
            "text": "KAMALPUR"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109259,
            "text": "KANKI"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109280,
            "text": "SAHAPUR-II"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 110108,
            "text": "SATISHSAMANTA"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109202,
            "text": "BELBARI-II"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109530,
            "text": "BORAIPAHALAMPUR"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109293,
            "text": "MATIKUNDA-I"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109731,
            "text": "TURTURI"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110913,
            "text": "BAIDYAPUR-I"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110155,
            "text": "KHANDAKHOLA"
        },
        {
            "district_code": 303,
            "block_code": 2725,
            "id": 107802,
            "text": "HELENCHA"
        },
        {
            "district_code": 317,
            "block_code": 2963,
            "id": 110147,
            "text": "KHODAMBARI-I"
        },
        {
            "district_code": 704,
            "block_code": 2819,
            "id": 108705,
            "text": "NABAGRAM"
        },
        {
            "district_code": 316,
            "block_code": 2932,
            "id": 109858,
            "text": "GOBINDAPUR-MAHESHPUR"
        },
        {
            "district_code": 312,
            "block_code": 2904,
            "id": 109548,
            "text": "KESABCHAK"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109484,
            "text": "SABALSINGHAPUR"
        },
        {
            "district_code": 318,
            "block_code": 2997,
            "id": 110476,
            "text": "KARKAI"
        },
        {
            "district_code": 313,
            "block_code": 2907,
            "id": 109586,
            "text": "HATURIA-II"
        },
        {
            "district_code": 305,
            "block_code": 2789,
            "id": 108422,
            "text": "AMBIKANAGAR"
        },
        {
            "district_code": 321,
            "block_code": 3052,
            "id": 111028,
            "text": "TATUARA"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109849,
            "text": "KUKURJAN"
        },
        {
            "district_code": 304,
            "block_code": 2760,
            "id": 108141,
            "text": "BAISHATA"
        },
        {
            "district_code": 318,
            "block_code": 2989,
            "id": 110391,
            "text": "GHRITAGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2983,
            "id": 110332,
            "text": "AMSOLE"
        },
        {
            "district_code": 312,
            "block_code": 2894,
            "id": 109434,
            "text": "PASCHIMPARA"
        },
        {
            "district_code": 306,
            "block_code": 2811,
            "id": 108614,
            "text": "GAZIPUR"
        },
        {
            "district_code": 306,
            "block_code": 2804,
            "id": 108551,
            "text": "GOHOGRAM"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109371,
            "text": "SOMRA-I"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260995,
            "text": "RANGBHANG GOPALDHARA"
        },
        {
            "district_code": 305,
            "block_code": 2790,
            "id": 108436,
            "text": "SALTORA"
        },
        {
            "district_code": 303,
            "block_code": 2730,
            "id": 107844,
            "text": "SANKCHURA BEGUNDI"
        },
        {
            "district_code": 319,
            "block_code": 3006,
            "id": 110569,
            "text": "ALUGRAM"
        },
        {
            "district_code": 304,
            "block_code": 2766,
            "id": 108218,
            "text": "KRISHNAPUR"
        },
        {
            "district_code": 704,
            "block_code": 2819,
            "id": 108699,
            "text": "UKHRA"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109855,
            "text": "SUKHANI"
        },
        {
            "district_code": 320,
            "block_code": 3033,
            "id": 110842,
            "text": "DHORADAHA-II"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109531,
            "text": "GOPALNAGAR"
        },
        {
            "district_code": 316,
            "block_code": 2946,
            "id": 109997,
            "text": "PEERGANJ"
        },
        {
            "district_code": 307,
            "block_code": 2828,
            "id": 108771,
            "text": "LOBA"
        },
        {
            "district_code": 312,
            "block_code": 2896,
            "id": 109455,
            "text": "KOTALPUR"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110551,
            "text": "RAJDHARPARA"
        },
        {
            "district_code": 306,
            "block_code": 2823,
            "id": 108729,
            "text": "SEHARA"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108865,
            "text": "CHANDIDASNANOOR"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109534,
            "text": "NASIBPUR"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109277,
            "text": "PANJIPARA"
        },
        {
            "district_code": 306,
            "block_code": 2818,
            "id": 108685,
            "text": "BIJUR-I"
        },
        {
            "district_code": 312,
            "block_code": 2894,
            "id": 109428,
            "text": "BADANGANJ-FALUI-II"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109503,
            "text": "BABNAN"
        },
        {
            "district_code": 319,
            "block_code": 3024,
            "id": 110747,
            "text": "GAJINAGAR MALANCHA"
        },
        {
            "district_code": 305,
            "block_code": 2788,
            "id": 108412,
            "text": "DHANARA"
        },
        {
            "district_code": 307,
            "block_code": 2828,
            "id": 108766,
            "text": "CHINPAI"
        },
        {
            "district_code": 307,
            "block_code": 2829,
            "id": 108781,
            "text": "MONGOLDIHI"
        },
        {
            "district_code": 304,
            "block_code": 2766,
            "id": 108219,
            "text": "NISAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2948,
            "id": 110014,
            "text": "BASUDEVBERIA"
        },
        {
            "district_code": 704,
            "block_code": 2798,
            "id": 108495,
            "text": "ITAPARA"
        },
        {
            "district_code": 314,
            "block_code": 2928,
            "id": 109818,
            "text": "BIDHANNAGAR"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109763,
            "text": "BELAKOBA"
        },
        {
            "district_code": 314,
            "block_code": 2921,
            "id": 109737,
            "text": "GADHEARKUTHI"
        },
        {
            "district_code": 321,
            "block_code": 3048,
            "id": 110990,
            "text": "KUILAPAL"
        },
        {
            "district_code": 305,
            "block_code": 2790,
            "id": 108435,
            "text": "SALMA"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109557,
            "text": "BHANDARGACHHA"
        },
        {
            "district_code": 307,
            "block_code": 2844,
            "id": 108915,
            "text": "NAGARI"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109899,
            "text": "RANIGANJ-I"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109273,
            "text": "JAINGAON"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109419,
            "text": "SOMASPUR-II"
        },
        {
            "district_code": 307,
            "block_code": 2840,
            "id": 108878,
            "text": "RAJNAGAR"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110153,
            "text": "HAUR"
        },
        {
            "district_code": 664,
            "block_code": 2926,
            "id": 109805,
            "text": "TOTOPARA BALLALGURI"
        },
        {
            "district_code": 307,
            "block_code": 2837,
            "id": 108850,
            "text": "BARLA"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110292,
            "text": "NISHCHINTAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110118,
            "text": "SRIKANTHA"
        },
        {
            "district_code": 307,
            "block_code": 2840,
            "id": 108879,
            "text": "TANTIPARA"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109901,
            "text": "SAHAJADPUR"
        },
        {
            "district_code": 307,
            "block_code": 2845,
            "id": 108918,
            "text": "BANSHANKA"
        },
        {
            "district_code": 314,
            "block_code": 2927,
            "id": 109809,
            "text": "DAMDIM"
        },
        {
            "district_code": 306,
            "block_code": 2810,
            "id": 108605,
            "text": "GIDHAGRAM"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110552,
            "text": "RANGAMATI CHANDPARA"
        },
        {
            "district_code": 319,
            "block_code": 3005,
            "id": 110562,
            "text": "HABASPUR"
        },
        {
            "district_code": 307,
            "block_code": 2842,
            "id": 108894,
            "text": "KALUHA"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107786,
            "text": "BAGJOLA"
        },
        {
            "district_code": 307,
            "block_code": 2833,
            "id": 108818,
            "text": "MAYURESWAR"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108398,
            "text": "PUNISOLE"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109971,
            "text": "GOPALPUR"
        },
        {
            "district_code": 704,
            "block_code": 2806,
            "id": 108571,
            "text": "CHINCHURIA"
        },
        {
            "district_code": 304,
            "block_code": 2763,
            "id": 108182,
            "text": "MAIPITH BAIKUNTHAPUR"
        },
        {
            "district_code": 319,
            "block_code": 3013,
            "id": 110643,
            "text": "JASHAHARI ANUKHA-I"
        },
        {
            "district_code": 308,
            "block_code": 2852,
            "id": 109000,
            "text": "KEDARHAT"
        },
        {
            "district_code": 704,
            "block_code": 2809,
            "id": 108602,
            "text": "MOLANDIGHI"
        },
        {
            "district_code": 318,
            "block_code": 2983,
            "id": 110335,
            "text": "NAYABASAT"
        },
        {
            "district_code": 664,
            "block_code": 2926,
            "id": 109803,
            "text": "RANGALIBAJNA"
        },
        {
            "district_code": 305,
            "block_code": 2785,
            "id": 108383,
            "text": "BANJORA"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108389,
            "text": "KALYANI"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108827,
            "text": "HINGLOW"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109511,
            "text": "SATITHAN"
        },
        {
            "district_code": 318,
            "block_code": 2999,
            "id": 110499,
            "text": "KARNAGARH"
        },
        {
            "district_code": 317,
            "block_code": 2953,
            "id": 110058,
            "text": "JUMKI"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109240,
            "text": "GOPHANAGAR"
        },
        {
            "district_code": 312,
            "block_code": 2890,
            "id": 109387,
            "text": "GARALGACHHA"
        },
        {
            "district_code": 319,
            "block_code": 3006,
            "id": 110573,
            "text": "GUNDIRIA"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110377,
            "text": "BANDHGORA"
        },
        {
            "district_code": 305,
            "block_code": 2778,
            "id": 108331,
            "text": "KAPISTA"
        },
        {
            "district_code": 703,
            "block_code": 2972,
            "id": 110230,
            "text": "LALGARH"
        },
        {
            "district_code": 306,
            "block_code": 2823,
            "id": 108728,
            "text": "RAYNA"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108157,
            "text": "RISHI BANKIMCHANDRA"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110916,
            "text": "DUTTAFULIA"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108132,
            "text": "DAKSHIN BARASAT"
        },
        {
            "district_code": 303,
            "block_code": 2735,
            "id": 107898,
            "text": "KUMRA"
        },
        {
            "district_code": 306,
            "block_code": 2813,
            "id": 108630,
            "text": "JYANDAS-KANDARA"
        },
        {
            "district_code": 313,
            "block_code": 2909,
            "id": 109604,
            "text": "SANPUIPARA BASUKATI"
        },
        {
            "district_code": 304,
            "block_code": 2763,
            "id": 108176,
            "text": "DEULBARI DEBIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3006,
            "id": 110570,
            "text": "AMLAI"
        },
        {
            "district_code": 314,
            "block_code": 2927,
            "id": 109811,
            "text": "KUMLAI"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109622,
            "text": "UTTAR JHAPARDAHA"
        },
        {
            "district_code": 306,
            "block_code": 2796,
            "id": 108481,
            "text": "BILWAGRAM"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260964,
            "text": "NAYANOR"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109524,
            "text": "BALARAMBATI"
        },
        {
            "district_code": 313,
            "block_code": 2908,
            "id": 109591,
            "text": "BANTUL-BAIDYANATHPUR"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109728,
            "text": "SHAMUKTALA"
        },
        {
            "district_code": 318,
            "block_code": 2978,
            "id": 110280,
            "text": "SARBERIA-I"
        },
        {
            "district_code": 306,
            "block_code": 2807,
            "id": 108585,
            "text": "KALYANPUR"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110218,
            "text": "PADUMPUR-II"
        },
        {
            "district_code": 303,
            "block_code": 2726,
            "id": 107811,
            "text": "ICHHAPUR-NILGANJ"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108871,
            "text": "KIRNAHAR-II"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110893,
            "text": "DHARMADA"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108187,
            "text": "KALIKAPOTA"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108202,
            "text": "HOTOR MORJADA"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109307,
            "text": "MARNAI"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109892,
            "text": "CHAKNAGAR"
        },
        {
            "district_code": 305,
            "block_code": 2778,
            "id": 108327,
            "text": "BARSHAL"
        },
        {
            "district_code": 312,
            "block_code": 2890,
            "id": 109386,
            "text": "CHANDITALA"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110898,
            "text": "NAKASHIPARA"
        },
        {
            "district_code": 321,
            "block_code": 3063,
            "id": 111117,
            "text": "GARSIKA"
        },
        {
            "district_code": 703,
            "block_code": 3000,
            "id": 110513,
            "text": "SANKRAIL"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110215,
            "text": "BISHNUBAR-II"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109710,
            "text": "BANCHUKAMARI"
        },
        {
            "district_code": 305,
            "block_code": 2779,
            "id": 108340,
            "text": "MOSHIARA"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108968,
            "text": "BAMANHAT-II"
        },
        {
            "district_code": 304,
            "block_code": 2769,
            "id": 108243,
            "text": "HARIPUR"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110795,
            "text": "MAHESHPUR"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108932,
            "text": "MARICHBARI-KHOLTA"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109480,
            "text": "PALASHPAI-I"
        },
        {
            "district_code": 321,
            "block_code": 3050,
            "id": 111009,
            "text": "UPANKAHAN"
        },
        {
            "district_code": 321,
            "block_code": 3049,
            "id": 111000,
            "text": "LAKHANPUR"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110545,
            "text": "MADANPUR"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110667,
            "text": "LALGOLA"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110286,
            "text": "GOURA"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110537,
            "text": "SOMEPARA-II"
        },
        {
            "district_code": 304,
            "block_code": 2754,
            "id": 108081,
            "text": "MATHERDIGHI"
        },
        {
            "district_code": 319,
            "block_code": 3017,
            "id": 110683,
            "text": "HAJBIBIDANGA"
        },
        {
            "district_code": 312,
            "block_code": 2891,
            "id": 109399,
            "text": "MOGRA-I"
        },
        {
            "district_code": 307,
            "block_code": 2841,
            "id": 108884,
            "text": "KASTHOGORA"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108230,
            "text": "DIGHIRPAR-BAKULTALA"
        },
        {
            "district_code": 303,
            "block_code": 2737,
            "id": 107913,
            "text": "GOPALPUR-II"
        },
        {
            "district_code": 309,
            "block_code": 2865,
            "id": 109149,
            "text": "CHAMPASARI"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109322,
            "text": "BAZARGAON-II"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108171,
            "text": "KULPI"
        },
        {
            "district_code": 307,
            "block_code": 2827,
            "id": 108759,
            "text": "RAIPUR-SUPUR"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108935,
            "text": "TAKAGACHH-RAJARHAT"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109306,
            "text": "KAPASIA"
        },
        {
            "district_code": 305,
            "block_code": 2785,
            "id": 108386,
            "text": "RAMCHANDRAPUR"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110783,
            "text": "TATLA-II"
        },
        {
            "district_code": 307,
            "block_code": 2830,
            "id": 108788,
            "text": "KHOYRASOLE"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109911,
            "text": "MANGALPUR"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110793,
            "text": "KALINGA"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109827,
            "text": "DOMOHONI-I"
        },
        {
            "district_code": 307,
            "block_code": 2842,
            "id": 108895,
            "text": "MARGRAM-I"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108065,
            "text": "SATGACHHIA"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108940,
            "text": "FALMARI"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108663,
            "text": "JAMNA"
        },
        {
            "district_code": 307,
            "block_code": 2829,
            "id": 108777,
            "text": "DHARAMPUR"
        },
        {
            "district_code": 305,
            "block_code": 2795,
            "id": 108478,
            "text": "ULIARA"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110488,
            "text": "DEBHOG"
        },
        {
            "district_code": 321,
            "block_code": 3044,
            "id": 110958,
            "text": "PUARA"
        },
        {
            "district_code": 307,
            "block_code": 2840,
            "id": 108877,
            "text": "GANGMURI-JOYPUR"
        },
        {
            "district_code": 307,
            "block_code": 2842,
            "id": 108896,
            "text": "MARGRAM-II"
        },
        {
            "district_code": 303,
            "block_code": 2739,
            "id": 107931,
            "text": "HINGALGANJ"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261002,
            "text": "DR. GRAHAMS HOMES"
        },
        {
            "district_code": 319,
            "block_code": 3016,
            "id": 110677,
            "text": "MUKUNDABAGH"
        },
        {
            "district_code": 318,
            "block_code": 2993,
            "id": 110436,
            "text": "SHIROMONI"
        },
        {
            "district_code": 314,
            "block_code": 2921,
            "id": 109743,
            "text": "MAGURMARI-II"
        },
        {
            "district_code": 314,
            "block_code": 2921,
            "id": 109738,
            "text": "GODONG-I"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108162,
            "text": "BABURMAHAL"
        },
        {
            "district_code": 664,
            "block_code": 2926,
            "id": 109796,
            "text": "BANDAPANI"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109256,
            "text": "BELON"
        },
        {
            "district_code": 304,
            "block_code": 2760,
            "id": 108148,
            "text": "MAYDA"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109688,
            "text": "KHILA"
        },
        {
            "district_code": 304,
            "block_code": 2751,
            "id": 108055,
            "text": "UTTAR RAIPUR"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110859,
            "text": "BHALUKA"
        },
        {
            "district_code": 310,
            "block_code": 2876,
            "id": 109235,
            "text": "MALIGAON"
        },
        {
            "district_code": 319,
            "block_code": 3026,
            "id": 110767,
            "text": "UMRAPUR"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109835,
            "text": "PADAMOTI-II"
        },
        {
            "district_code": 319,
            "block_code": 3020,
            "id": 110715,
            "text": "SEKENDRA"
        },
        {
            "district_code": 321,
            "block_code": 3047,
            "id": 110978,
            "text": "BERADA"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108154,
            "text": "PRATAPADITYANAGAR"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108659,
            "text": "SHIMULIA-II"
        },
        {
            "district_code": 321,
            "block_code": 3048,
            "id": 110988,
            "text": "GURUR"
        },
        {
            "district_code": 321,
            "block_code": 3056,
            "id": 111062,
            "text": "JANARDANDIH"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260958,
            "text": "KAIJALIA"
        },
        {
            "district_code": 320,
            "block_code": 3036,
            "id": 110874,
            "text": "NOAPARA-II"
        },
        {
            "district_code": 307,
            "block_code": 2840,
            "id": 108875,
            "text": "BHABANIPUR"
        },
        {
            "district_code": 314,
            "block_code": 2927,
            "id": 109817,
            "text": "TESIMALA"
        },
        {
            "district_code": 307,
            "block_code": 2836,
            "id": 108841,
            "text": "JAJIGRAM"
        },
        {
            "district_code": 306,
            "block_code": 2823,
            "id": 108723,
            "text": "HIJALNA"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110939,
            "text": "NATNA"
        },
        {
            "district_code": 308,
            "block_code": 2850,
            "id": 108984,
            "text": "UTTAR BARA HALDIBARI"
        },
        {
            "district_code": 305,
            "block_code": 2782,
            "id": 108364,
            "text": "SALDA"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109278,
            "text": "POKHARIA"
        },
        {
            "district_code": 704,
            "block_code": 2819,
            "id": 108692,
            "text": "ANDAL"
        },
        {
            "district_code": 321,
            "block_code": 3059,
            "id": 111086,
            "text": "BHANDARPUARA-CHIPIDA"
        },
        {
            "district_code": 704,
            "block_code": 2802,
            "id": 108536,
            "text": "JEMUA"
        },
        {
            "district_code": 307,
            "block_code": 2842,
            "id": 108892,
            "text": "HANSAN-I"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110780,
            "text": "SILINDA-II"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108115,
            "text": "AMTALI"
        },
        {
            "district_code": 702,
            "block_code": 7355,
            "id": 261030,
            "text": "SYAKIYONG"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110544,
            "text": "HATINAGAR"
        },
        {
            "district_code": 310,
            "block_code": 2876,
            "id": 109233,
            "text": "KARANJI"
        },
        {
            "district_code": 318,
            "block_code": 2999,
            "id": 110495,
            "text": "BHIMPUR"
        },
        {
            "district_code": 319,
            "block_code": 3024,
            "id": 110750,
            "text": "PRATAPGANJ"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261059,
            "text": "RONGCHONG"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110546,
            "text": "MANINDRANAGAR"
        },
        {
            "district_code": 303,
            "block_code": 2744,
            "id": 107974,
            "text": "SHARAPUL NIRMAN"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109938,
            "text": "KALIACHAK-II"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110302,
            "text": "GOLGRAM"
        },
        {
            "district_code": 305,
            "block_code": 2778,
            "id": 108328,
            "text": "BHAKTABUNDH"
        },
        {
            "district_code": 319,
            "block_code": 3019,
            "id": 110705,
            "text": "MIRJAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108029,
            "text": "ANDHAR MANIK"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110944,
            "text": "TEHATTA"
        },
        {
            "district_code": 313,
            "block_code": 2908,
            "id": 109592,
            "text": "CHANDRABHAG"
        },
        {
            "district_code": 320,
            "block_code": 3037,
            "id": 110882,
            "text": "MAYAPUR BAMANPUKUR-I"
        },
        {
            "district_code": 303,
            "block_code": 2730,
            "id": 107841,
            "text": "NIMDARIA KODALIA"
        },
        {
            "district_code": 312,
            "block_code": 2890,
            "id": 109389,
            "text": "KAPASARIA"
        },
        {
            "district_code": 306,
            "block_code": 2804,
            "id": 108555,
            "text": "SANKO"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109407,
            "text": "DASHGHARA-II"
        },
        {
            "district_code": 319,
            "block_code": 3009,
            "id": 110609,
            "text": "SARANGPUR"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109270,
            "text": "GOAGAON-II"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108508,
            "text": "BOLGONA"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108930,
            "text": "KHAPAIDANGA"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108568,
            "text": "PARATAL-I"
        },
        {
            "district_code": 319,
            "block_code": 3005,
            "id": 110568,
            "text": "SUNDARPUR"
        },
        {
            "district_code": 318,
            "block_code": 2989,
            "id": 110397,
            "text": "SANTRAPUR"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109044,
            "text": "FALIMARI"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109048,
            "text": "RAMPUR-II"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109960,
            "text": "GOLAPGANJ"
        },
        {
            "district_code": 311,
            "block_code": 2878,
            "id": 109248,
            "text": "CHOPRA"
        },
        {
            "district_code": 703,
            "block_code": 2987,
            "id": 110368,
            "text": "DHARSA"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109191,
            "text": "NAJIRPUR"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110349,
            "text": "MONOHARPUR-I"
        },
        {
            "district_code": 318,
            "block_code": 2992,
            "id": 110424,
            "text": "LACHHMAPUR"
        },
        {
            "district_code": 310,
            "block_code": 2874,
            "id": 109218,
            "text": "HILI"
        },
        {
            "district_code": 304,
            "block_code": 2769,
            "id": 108244,
            "text": "MAUSINI"
        },
        {
            "district_code": 310,
            "block_code": 2876,
            "id": 109230,
            "text": "BEROIL"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110344,
            "text": "DEWANCHAK-II"
        },
        {
            "district_code": 306,
            "block_code": 2813,
            "id": 108632,
            "text": "PALITA"
        },
        {
            "district_code": 312,
            "block_code": 2896,
            "id": 109451,
            "text": "ANTPUR"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110152,
            "text": "GOBINDANAGAR"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110493,
            "text": "SHARTA"
        },
        {
            "district_code": 313,
            "block_code": 2907,
            "id": 109583,
            "text": "BAKSIHAT"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108196,
            "text": "AMRATALA"
        },
        {
            "district_code": 321,
            "block_code": 3046,
            "id": 110970,
            "text": "BELA"
        },
        {
            "district_code": 307,
            "block_code": 2844,
            "id": 108910,
            "text": "ALUNDA"
        },
        {
            "district_code": 316,
            "block_code": 2946,
            "id": 109995,
            "text": "MAHARAJPUR"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108823,
            "text": "BHUTURA"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110296,
            "text": "BHABANIPUR"
        },
        {
            "district_code": 304,
            "block_code": 2754,
            "id": 108077,
            "text": "ATHAROBANKI"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108562,
            "text": "JAMALPUR-I"
        },
        {
            "district_code": 309,
            "block_code": 2867,
            "id": 109159,
            "text": "GOSSAIPUR"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109890,
            "text": "BAIRGACHHI-I"
        },
        {
            "district_code": 307,
            "block_code": 2827,
            "id": 108763,
            "text": "SIAN-MULUK"
        },
        {
            "district_code": 305,
            "block_code": 2792,
            "id": 108446,
            "text": "LAKSHMISAGAR"
        },
        {
            "district_code": 306,
            "block_code": 2822,
            "id": 108717,
            "text": "MERTALA"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110831,
            "text": "PLASSEY-II"
        },
        {
            "district_code": 318,
            "block_code": 2974,
            "id": 110248,
            "text": "MONOHARPUR-I"
        },
        {
            "district_code": 306,
            "block_code": 2812,
            "id": 108623,
            "text": "MAUGRAM"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108205,
            "text": "MAGRAHAT PURBA"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110458,
            "text": "TUTRANGA"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109578,
            "text": "TAJPUR"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260954,
            "text": "DARJEELING-II"
        },
        {
            "district_code": 319,
            "block_code": 3021,
            "id": 110719,
            "text": "ISLAMPURCHAK"
        },
        {
            "district_code": 703,
            "block_code": 3000,
            "id": 110507,
            "text": "KHUDMORAI"
        },
        {
            "district_code": 703,
            "block_code": 2972,
            "id": 110232,
            "text": "RAMGARH"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109447,
            "text": "NARAYANPURBAHIRKHANDA"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109475,
            "text": "DHANYAGORI"
        },
        {
            "district_code": 306,
            "block_code": 2801,
            "id": 108528,
            "text": "BARASUL-II"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260959,
            "text": "LEBONG VALLEY-I"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109192,
            "text": "PATRIRAM"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110318,
            "text": "KATRAUTTARBIL"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107985,
            "text": "KALYANPUR"
        },
        {
            "district_code": 318,
            "block_code": 2978,
            "id": 110273,
            "text": "DASPUR-I"
        },
        {
            "district_code": 704,
            "block_code": 2806,
            "id": 108573,
            "text": "DOBRANA"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110401,
            "text": "DHALHARA"
        },
        {
            "district_code": 321,
            "block_code": 3055,
            "id": 111056,
            "text": "BURIBANDH"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109247,
            "text": "TAPANCHANDIPUR"
        },
        {
            "district_code": 303,
            "block_code": 2723,
            "id": 107782,
            "text": "MARICHA"
        },
        {
            "district_code": 319,
            "block_code": 3018,
            "id": 110693,
            "text": "CHANDPUR"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108317,
            "text": "DHABAN"
        },
        {
            "district_code": 320,
            "block_code": 3032,
            "id": 110837,
            "text": "KARIMPUR-II"
        },
        {
            "district_code": 704,
            "block_code": 2798,
            "id": 108496,
            "text": "JAMGRAM"
        },
        {
            "district_code": 317,
            "block_code": 2967,
            "id": 110179,
            "text": "BADHIA"
        },
        {
            "district_code": 320,
            "block_code": 3033,
            "id": 110850,
            "text": "RAHAMATPUR"
        },
        {
            "district_code": 319,
            "block_code": 3024,
            "id": 110743,
            "text": "BHASAIPAIKAR"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110444,
            "text": "BELDA-I"
        },
        {
            "district_code": 316,
            "block_code": 2946,
            "id": 109999,
            "text": "SAMBALPUR"
        },
        {
            "district_code": 320,
            "block_code": 3030,
            "id": 110817,
            "text": "NAGARUKHRA-II"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109405,
            "text": "BHASTARA"
        },
        {
            "district_code": 305,
            "block_code": 2795,
            "id": 108474,
            "text": "DWARIKA-GOSSAINPUR"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110536,
            "text": "SOMEPARA-I"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109616,
            "text": "MAKARDAH-II"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108936,
            "text": "CHANDAMARI"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110892,
            "text": "DHANANJAYPUR"
        },
        {
            "district_code": 314,
            "block_code": 2921,
            "id": 109745,
            "text": "SAKOYAJHORA-II"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109269,
            "text": "GOAGAON-I"
        },
        {
            "district_code": 305,
            "block_code": 2775,
            "id": 108296,
            "text": "JUNBEDIA"
        },
        {
            "district_code": 313,
            "block_code": 2917,
            "id": 109701,
            "text": "TAPNA"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109349,
            "text": "GOURHATI-I"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108514,
            "text": "SAHEBGANJ-II"
        },
        {
            "district_code": 303,
            "block_code": 2736,
            "id": 107909,
            "text": "RAJIBPUR BIRA"
        },
        {
            "district_code": 303,
            "block_code": 2727,
            "id": 107823,
            "text": "SHASAN"
        },
        {
            "district_code": 305,
            "block_code": 2790,
            "id": 108434,
            "text": "PABRA"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110830,
            "text": "PLASSEY-I"
        },
        {
            "district_code": 304,
            "block_code": 2747,
            "id": 108009,
            "text": "BODRA"
        },
        {
            "district_code": 305,
            "block_code": 2788,
            "id": 108416,
            "text": "MANDALKULI"
        },
        {
            "district_code": 305,
            "block_code": 2784,
            "id": 108374,
            "text": "DESRA-KOALPARA"
        },
        {
            "district_code": 317,
            "block_code": 2952,
            "id": 110047,
            "text": "AMTALIA"
        },
        {
            "district_code": 313,
            "block_code": 2908,
            "id": 109595,
            "text": "ORPHOOLI"
        },
        {
            "district_code": 307,
            "block_code": 2833,
            "id": 108814,
            "text": "DASPALSA"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109637,
            "text": "BANHARISHPUR"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109907,
            "text": "DHUMPUR"
        },
        {
            "district_code": 310,
            "block_code": 2875,
            "id": 109225,
            "text": "MOHANA"
        },
        {
            "district_code": 305,
            "block_code": 2793,
            "id": 108454,
            "text": "HAMIRHATI"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110126,
            "text": "KALYANPUR"
        },
        {
            "district_code": 702,
            "block_code": 7354,
            "id": 261026,
            "text": "PAYONG"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108972,
            "text": "CHOWDHURIHAT"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261056,
            "text": "PUBANG-RAMPURIA"
        },
        {
            "district_code": 312,
            "block_code": 2894,
            "id": 109427,
            "text": "BADANGANJ-FALUI-I"
        },
        {
            "district_code": 321,
            "block_code": 3051,
            "id": 111017,
            "text": "NOYADIH"
        },
        {
            "district_code": 310,
            "block_code": 2874,
            "id": 109216,
            "text": "BINSHIRA"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 8888102,
            "text": "Kashyone"
        },
        {
            "district_code": 304,
            "block_code": 2753,
            "id": 108067,
            "text": "BANSRA"
        },
        {
            "district_code": 319,
            "block_code": 3025,
            "id": 110757,
            "text": "SADIKPUR"
        },
        {
            "district_code": 317,
            "block_code": 2970,
            "id": 110206,
            "text": "ASHADTALIA"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261036,
            "text": "MAHANADI"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109508,
            "text": "MAKALPUR"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109719,
            "text": "VIVEKANDA-I"
        },
        {
            "district_code": 312,
            "block_code": 2896,
            "id": 109454,
            "text": "JANGIPARA"
        },
        {
            "district_code": 318,
            "block_code": 2976,
            "id": 110262,
            "text": "MONOHARPUR"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109495,
            "text": "PANCHAGARA-TOREGRAM"
        },
        {
            "district_code": 703,
            "block_code": 2986,
            "id": 110363,
            "text": "SARIA"
        },
        {
            "district_code": 319,
            "block_code": 3019,
            "id": 110706,
            "text": "RANINAGAR"
        },
        {
            "district_code": 307,
            "block_code": 2833,
            "id": 108820,
            "text": "ULKUNDA"
        },
        {
            "district_code": 304,
            "block_code": 2767,
            "id": 108224,
            "text": "LALPUR"
        },
        {
            "district_code": 321,
            "block_code": 3054,
            "id": 111043,
            "text": "BARAMASYA-RAMNAGAR"
        },
        {
            "district_code": 312,
            "block_code": 2894,
            "id": 109435,
            "text": "SHYAMBAZAR"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108047,
            "text": "PANCHANAN"
        },
        {
            "district_code": 308,
            "block_code": 2850,
            "id": 108981,
            "text": "DEWANGANJ"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110317,
            "text": "GARHBETA"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109659,
            "text": "PANCHPARA"
        },
        {
            "district_code": 320,
            "block_code": 3030,
            "id": 110816,
            "text": "NAGARUKHRA-I"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109787,
            "text": "KAMAKHYAGURI-II"
        },
        {
            "district_code": 306,
            "block_code": 2814,
            "id": 108636,
            "text": "GOPALBERA"
        },
        {
            "district_code": 318,
            "block_code": 2978,
            "id": 110276,
            "text": "NANDANPUR-II"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110402,
            "text": "ENAYETPUR"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109974,
            "text": "MATHURAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2950,
            "id": 110031,
            "text": "BADALPUR"
        },
        {
            "district_code": 306,
            "block_code": 2817,
            "id": 108677,
            "text": "DEBIPUR"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108961,
            "text": "GOSANIMARI-II"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108041,
            "text": "CHANDI"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109621,
            "text": "SHALAP-II"
        },
        {
            "district_code": 318,
            "block_code": 2975,
            "id": 110252,
            "text": "BASANCHORA"
        },
        {
            "district_code": 307,
            "block_code": 2832,
            "id": 108810,
            "text": "KANACHI"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108927,
            "text": "DHANGDHINGURI"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109522,
            "text": "BAGDANGACHINAMORE"
        },
        {
            "district_code": 306,
            "block_code": 2800,
            "id": 108518,
            "text": "BELKASH"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260985,
            "text": "GORABARI MARGARETS HOPE"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109606,
            "text": "BANKRA-II"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109319,
            "text": "ALTAPUR-I"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110481,
            "text": "BALPAI"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110307,
            "text": "RADHAMOHANPUR-II"
        },
        {
            "district_code": 319,
            "block_code": 3018,
            "id": 110700,
            "text": "SARANGPUR"
        },
        {
            "district_code": 319,
            "block_code": 3004,
            "id": 110557,
            "text": "BALIGRAM"
        },
        {
            "district_code": 321,
            "block_code": 3056,
            "id": 111065,
            "text": "SARBARI"
        },
        {
            "district_code": 321,
            "block_code": 3051,
            "id": 111019,
            "text": "TULIN"
        },
        {
            "district_code": 704,
            "block_code": 2798,
            "id": 108499,
            "text": "PANURIA"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 110104,
            "text": "KISMATNAIKUNDI"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108153,
            "text": "NETAJI"
        },
        {
            "district_code": 319,
            "block_code": 3013,
            "id": 110644,
            "text": "JASHAHARI ANUKHA-II"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109640,
            "text": "CHARA-PANCHLA"
        },
        {
            "district_code": 319,
            "block_code": 3024,
            "id": 110744,
            "text": "BOGDADNAGAR"
        },
        {
            "district_code": 303,
            "block_code": 2741,
            "id": 107946,
            "text": "JANGRAHATIARA-II"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108310,
            "text": "MALIARA"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109893,
            "text": "DEOTALA"
        },
        {
            "district_code": 310,
            "block_code": 2874,
            "id": 109220,
            "text": "PANJUL"
        },
        {
            "district_code": 304,
            "block_code": 2753,
            "id": 108075,
            "text": "NIKARIGHATA"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109826,
            "text": "DHARMAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108133,
            "text": "DHOSA CHANDANESWAR"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110937,
            "text": "CHHITKA"
        },
        {
            "district_code": 318,
            "block_code": 2977,
            "id": 110268,
            "text": "SABRA"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260994,
            "text": "POKHRIABONG-III"
        },
        {
            "district_code": 308,
            "block_code": 2853,
            "id": 109005,
            "text": "BAGDOGRA-FULKADABRI"
        },
        {
            "district_code": 312,
            "block_code": 2904,
            "id": 109552,
            "text": "TALPUR"
        },
        {
            "district_code": 303,
            "block_code": 2740,
            "id": 107938,
            "text": "BAMANPUKUR"
        },
        {
            "district_code": 317,
            "block_code": 2970,
            "id": 110210,
            "text": "JOYNAGAR"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110890,
            "text": "BIRPUR-I"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109476,
            "text": "JAGATPUR"
        },
        {
            "district_code": 312,
            "block_code": 2893,
            "id": 109423,
            "text": "KUMARSA"
        },
        {
            "district_code": 303,
            "block_code": 2743,
            "id": 107962,
            "text": "JELIAKHALI"
        },
        {
            "district_code": 318,
            "block_code": 2994,
            "id": 110440,
            "text": "SAUTIA"
        },
        {
            "district_code": 307,
            "block_code": 2837,
            "id": 108854,
            "text": "KAITHA-II"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110785,
            "text": "ALFA"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109645,
            "text": "PANCHLA"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108747,
            "text": "BASUDEVPURJEMARI"
        },
        {
            "district_code": 320,
            "block_code": 3041,
            "id": 110927,
            "text": "BAGANCHRA"
        },
        {
            "district_code": 318,
            "block_code": 2999,
            "id": 110500,
            "text": "KASHIJORA"
        },
        {
            "district_code": 317,
            "block_code": 2957,
            "id": 110081,
            "text": "BARATALA"
        },
        {
            "district_code": 320,
            "block_code": 3043,
            "id": 110948,
            "text": "PALASIPARA"
        },
        {
            "district_code": 317,
            "block_code": 2969,
            "id": 110204,
            "text": "SHANTIPUR-I"
        },
        {
            "district_code": 306,
            "block_code": 2808,
            "id": 108596,
            "text": "SULTANPUR"
        },
        {
            "district_code": 305,
            "block_code": 2782,
            "id": 108363,
            "text": "ROUTHKHANDA"
        },
        {
            "district_code": 319,
            "block_code": 3010,
            "id": 110611,
            "text": "BAHADURPUR"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108653,
            "text": "LAKHURIA"
        },
        {
            "district_code": 321,
            "block_code": 3045,
            "id": 110960,
            "text": "AJODHYA"
        },
        {
            "district_code": 318,
            "block_code": 2982,
            "id": 110322,
            "text": "AMLASULI"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108109,
            "text": "FATEPUR"
        },
        {
            "district_code": 306,
            "block_code": 2818,
            "id": 108683,
            "text": "BARAPALASAN-I"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107890,
            "text": "JALESWAR-I"
        },
        {
            "district_code": 306,
            "block_code": 2803,
            "id": 108546,
            "text": "SERORAI"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110282,
            "text": "BENAI"
        },
        {
            "district_code": 307,
            "block_code": 2832,
            "id": 108808,
            "text": "DAKSHINGRAM"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109261,
            "text": "NIJAMPUR-II"
        },
        {
            "district_code": 704,
            "block_code": 2806,
            "id": 108576,
            "text": "MADANTOR"
        },
        {
            "district_code": 306,
            "block_code": 2801,
            "id": 108527,
            "text": "BARASUL-I"
        },
        {
            "district_code": 313,
            "block_code": 2914,
            "id": 109667,
            "text": "BELARI"
        },
        {
            "district_code": 308,
            "block_code": 2855,
            "id": 109023,
            "text": "KHALISAMARI"
        },
        {
            "district_code": 320,
            "block_code": 7115,
            "id": 110769,
            "text": "CHANDURIA-II"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108958,
            "text": "GITALDAHA-I"
        },
        {
            "district_code": 321,
            "block_code": 3051,
            "id": 111015,
            "text": "MARUMOSINA"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109411,
            "text": "GOPINATHPUR-II"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109438,
            "text": "BANDIPUR"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109966,
            "text": "SAHABANCHAK"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109661,
            "text": "SANKRAIL"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110522,
            "text": "MAHULA-I"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108898,
            "text": "AHMEDPUR"
        },
        {
            "district_code": 308,
            "block_code": 2850,
            "id": 108980,
            "text": "DAKSHIN BARA HALDIBARI"
        },
        {
            "district_code": 318,
            "block_code": 2983,
            "id": 110336,
            "text": "RASKUNDA"
        },
        {
            "district_code": 318,
            "block_code": 2978,
            "id": 110274,
            "text": "DASPUR-II"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109208,
            "text": "JAHANGIRPUR"
        },
        {
            "district_code": 319,
            "block_code": 3007,
            "id": 110583,
            "text": "TENYA-BAIDYAPUR"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108388,
            "text": "CHURAMONIPUR"
        },
        {
            "district_code": 321,
            "block_code": 3062,
            "id": 111111,
            "text": "CHELIAMA"
        },
        {
            "district_code": 317,
            "block_code": 2955,
            "id": 110071,
            "text": "BARUTTARHINGLI"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109039,
            "text": "NATABARI-II"
        },
        {
            "district_code": 704,
            "block_code": 2820,
            "id": 108704,
            "text": "KENDRA"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110308,
            "text": "SATYAPUR"
        },
        {
            "district_code": 306,
            "block_code": 2808,
            "id": 108590,
            "text": "BEGPUR"
        },
        {
            "district_code": 321,
            "block_code": 3060,
            "id": 111102,
            "text": "RAGHABPUR"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108256,
            "text": "GOPALNAGAR"
        },
        {
            "district_code": 303,
            "block_code": 2727,
            "id": 107821,
            "text": "KIRITIPUR-II"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109635,
            "text": "SHANKARHATI-II"
        },
        {
            "district_code": 321,
            "block_code": 3054,
            "id": 111050,
            "text": "KAMTAJANGIDIRI"
        },
        {
            "district_code": 303,
            "block_code": 2738,
            "id": 107922,
            "text": "BHABANIPUR-II"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110290,
            "text": "KHEPUTDAKSHNIBARH"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108923,
            "text": "AMBARI"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109913,
            "text": "SREERAMPUR"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107882,
            "text": "SOHAI-SHETPUR"
        },
        {
            "district_code": 703,
            "block_code": 2987,
            "id": 110370,
            "text": "GIDHNI"
        },
        {
            "district_code": 317,
            "block_code": 2967,
            "id": 110183,
            "text": "HALDIA-II"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108173,
            "text": "RAMKISHORE"
        },
        {
            "district_code": 316,
            "block_code": 2939,
            "id": 109929,
            "text": "VALUKA"
        },
        {
            "district_code": 313,
            "block_code": 2915,
            "id": 109677,
            "text": "DIHIMONDALGHAT-I"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109347,
            "text": "ARANDI-II"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109242,
            "text": "HARSURA"
        },
        {
            "district_code": 320,
            "block_code": 3039,
            "id": 110903,
            "text": "KALINARAYANPUR PAHARPUR"
        },
        {
            "district_code": 303,
            "block_code": 2726,
            "id": 107813,
            "text": "KASHIMPUR"
        },
        {
            "district_code": 305,
            "block_code": 2781,
            "id": 108355,
            "text": "MONGALPUR"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 107998,
            "text": "BHARATGARH"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109274,
            "text": "KHAGORE"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110917,
            "text": "JUGALKISHORE"
        },
        {
            "district_code": 313,
            "block_code": 2915,
            "id": 109679,
            "text": "KHARUBERIA"
        },
        {
            "district_code": 308,
            "block_code": 2850,
            "id": 108982,
            "text": "HEMKUMARI"
        },
        {
            "district_code": 703,
            "block_code": 2973,
            "id": 110238,
            "text": "ERGODA"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109894,
            "text": "GAZOLE-I"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108953,
            "text": "BARA SOULMARI"
        },
        {
            "district_code": 313,
            "block_code": 2917,
            "id": 109694,
            "text": "CHANDIPUR"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108797,
            "text": "DWARAKA"
        },
        {
            "district_code": 316,
            "block_code": 2944,
            "id": 109978,
            "text": "BHABUK"
        },
        {
            "district_code": 319,
            "block_code": 3005,
            "id": 110566,
            "text": "MAHAMMADPUR"
        },
        {
            "district_code": 320,
            "block_code": 3033,
            "id": 110848,
            "text": "NATIDANGA-I"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110799,
            "text": "BATKULLA-I"
        },
        {
            "district_code": 321,
            "block_code": 3049,
            "id": 110999,
            "text": "LADHURKA"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108975,
            "text": "NAJIRHAT-I"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108563,
            "text": "JAMALPUR-II"
        },
        {
            "district_code": 307,
            "block_code": 2841,
            "id": 108881,
            "text": "BARSHAL"
        },
        {
            "district_code": 317,
            "block_code": 2950,
            "id": 110038,
            "text": "SABAJPUT"
        },
        {
            "district_code": 318,
            "block_code": 2999,
            "id": 110503,
            "text": "SHATPATI"
        },
        {
            "district_code": 318,
            "block_code": 2992,
            "id": 110423,
            "text": "KALIARA-II"
        },
        {
            "district_code": 321,
            "block_code": 3055,
            "id": 111053,
            "text": "BARGORIA-JAMTORIA"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108203,
            "text": "JUGDIA"
        },
        {
            "district_code": 303,
            "block_code": 2739,
            "id": 107933,
            "text": "KALITALA"
        },
        {
            "district_code": 306,
            "block_code": 2804,
            "id": 108553,
            "text": "KURKUBA"
        },
        {
            "district_code": 313,
            "block_code": 2915,
            "id": 109676,
            "text": "BARGRAM"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109478,
            "text": "NATIBPUR-I"
        },
        {
            "district_code": 307,
            "block_code": 2835,
            "id": 108837,
            "text": "MURARAI"
        },
        {
            "district_code": 317,
            "block_code": 2969,
            "id": 110198,
            "text": "DHALHARA"
        },
        {
            "district_code": 310,
            "block_code": 2875,
            "id": 109224,
            "text": "JAKIRPUR"
        },
        {
            "district_code": 305,
            "block_code": 2780,
            "id": 108344,
            "text": "GOURBAZAR"
        },
        {
            "district_code": 317,
            "block_code": 2951,
            "id": 110045,
            "text": "LAUDA"
        },
        {
            "district_code": 316,
            "block_code": 2933,
            "id": 109867,
            "text": "MAHANANDAPUR"
        },
        {
            "district_code": 308,
            "block_code": 2852,
            "id": 108995,
            "text": "BAIRAGIRHAT"
        },
        {
            "district_code": 319,
            "block_code": 3022,
            "id": 110729,
            "text": "RAJAPUR"
        },
        {
            "district_code": 303,
            "block_code": 2742,
            "id": 107958,
            "text": "SEHERA RADHNAGAR"
        },
        {
            "district_code": 319,
            "block_code": 3007,
            "id": 110579,
            "text": "SALAR"
        },
        {
            "district_code": 306,
            "block_code": 2818,
            "id": 108691,
            "text": "SATGACHHIA-II"
        },
        {
            "district_code": 318,
            "block_code": 2991,
            "id": 110415,
            "text": "GOPALI"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109898,
            "text": "PANDUA"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107871,
            "text": "BERACHAMPA-I"
        },
        {
            "district_code": 321,
            "block_code": 3058,
            "id": 111082,
            "text": "NAPARA"
        },
        {
            "district_code": 321,
            "block_code": 3058,
            "id": 111084,
            "text": "PIRRAH"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109412,
            "text": "GUDUBARI-I"
        },
        {
            "district_code": 305,
            "block_code": 2775,
            "id": 108301,
            "text": "SANBANDHA"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107993,
            "text": "SHIKHARBALI-I"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109186,
            "text": "CHAKVRIGU"
        },
        {
            "district_code": 312,
            "block_code": 2903,
            "id": 109541,
            "text": "RAJYADHARPUR"
        },
        {
            "district_code": 316,
            "block_code": 2945,
            "id": 109984,
            "text": "BAHARAL"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108868,
            "text": "DASKALGRAM-KAREYA-II"
        },
        {
            "district_code": 303,
            "block_code": 2735,
            "id": 107901,
            "text": "PRITHIBA"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110113,
            "text": "MOYNA-II"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110111,
            "text": "GOKULNAGAR"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109329,
            "text": "RANIGANJ"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109444,
            "text": "KAIKALA"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109403,
            "text": "BHANDARHATI-I"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110912,
            "text": "BAHIRGACHI"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109895,
            "text": "GAZOLE-II"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107990,
            "text": "RAMNAGAR-II"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110820,
            "text": "FARIDPUR"
        },
        {
            "district_code": 312,
            "block_code": 2893,
            "id": 109424,
            "text": "NAKUNDA"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110483,
            "text": "BISHNUPUR"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110594,
            "text": "SABALPUR"
        },
        {
            "district_code": 321,
            "block_code": 3050,
            "id": 111008,
            "text": "SIDHI-JAMRA"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109888,
            "text": "ALAL"
        },
        {
            "district_code": 703,
            "block_code": 2986,
            "id": 110362,
            "text": "KENDUGARI"
        },
        {
            "district_code": 307,
            "block_code": 2830,
            "id": 108792,
            "text": "PARSUNDI"
        },
        {
            "district_code": 703,
            "block_code": 2973,
            "id": 110242,
            "text": "SHILDA"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110541,
            "text": "DAULATABAD"
        },
        {
            "district_code": 317,
            "block_code": 2957,
            "id": 110084,
            "text": "KHEJURI"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110867,
            "text": "JOANIA"
        },
        {
            "district_code": 319,
            "block_code": 3025,
            "id": 110754,
            "text": "BANSABATI"
        },
        {
            "district_code": 313,
            "block_code": 2918,
            "id": 109707,
            "text": "TEHATTA-KANTABERIA-I"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260967,
            "text": "RELLING"
        },
        {
            "district_code": 308,
            "block_code": 2853,
            "id": 109007,
            "text": "CHANGRABANDHA"
        },
        {
            "district_code": 306,
            "block_code": 2817,
            "id": 108680,
            "text": "GOP-GANTAR-II"
        },
        {
            "district_code": 305,
            "block_code": 2788,
            "id": 108417,
            "text": "MELERA"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109481,
            "text": "PALASHPAI-II"
        },
        {
            "district_code": 304,
            "block_code": 2760,
            "id": 108150,
            "text": "SAHAJADAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2773,
            "id": 108283,
            "text": "ASUTI-I"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109795,
            "text": "VALKA BARABISA-II"
        },
        {
            "district_code": 306,
            "block_code": 2800,
            "id": 108522,
            "text": "RAYAN-II"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108831,
            "text": "RAMPUR"
        },
        {
            "district_code": 312,
            "block_code": 2896,
            "id": 109458,
            "text": "RAJBALHAT-I"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109779,
            "text": "KALCHINI"
        },
        {
            "district_code": 320,
            "block_code": 3030,
            "id": 244952,
            "text": "KASTODANGA-I"
        },
        {
            "district_code": 306,
            "block_code": 2822,
            "id": 108721,
            "text": "PILLA"
        },
        {
            "district_code": 317,
            "block_code": 2963,
            "id": 110148,
            "text": "KHODAMBARI-II"
        },
        {
            "district_code": 317,
            "block_code": 2948,
            "id": 110020,
            "text": "RADHAPUR"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109780,
            "text": "LATABARI"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108928,
            "text": "GOPALPUR"
        },
        {
            "district_code": 308,
            "block_code": 2855,
            "id": 109018,
            "text": "BAROKAIMARI"
        },
        {
            "district_code": 307,
            "block_code": 2833,
            "id": 108817,
            "text": "KUNDOLA"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109497,
            "text": "RAMESWARPUR-GOPALNAGAR"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108272,
            "text": "BANGOOGHLY-I"
        },
        {
            "district_code": 303,
            "block_code": 2739,
            "id": 107934,
            "text": "RUPAMARI"
        },
        {
            "district_code": 306,
            "block_code": 2813,
            "id": 108627,
            "text": "AGARDANGA"
        },
        {
            "district_code": 305,
            "block_code": 2793,
            "id": 108455,
            "text": "KOCHDIHI"
        },
        {
            "district_code": 305,
            "block_code": 2781,
            "id": 108354,
            "text": "KARISUNDA"
        },
        {
            "district_code": 312,
            "block_code": 2889,
            "id": 109382,
            "text": "SHIYAKHALA"
        },
        {
            "district_code": 320,
            "block_code": 3030,
            "id": 110814,
            "text": "KASTODANGA-II"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108828,
            "text": "KAPISTA"
        },
        {
            "district_code": 304,
            "block_code": 2769,
            "id": 108242,
            "text": "FREZARGANJ"
        },
        {
            "district_code": 320,
            "block_code": 3037,
            "id": 110879,
            "text": "FAKIRDANGA GHOLAPARA"
        },
        {
            "district_code": 313,
            "block_code": 2907,
            "id": 109589,
            "text": "SABSIT"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260972,
            "text": "AAHALEY"
        },
        {
            "district_code": 316,
            "block_code": 2934,
            "id": 109874,
            "text": "JALALPUR"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107789,
            "text": "CHHATRA"
        },
        {
            "district_code": 306,
            "block_code": 2803,
            "id": 108547,
            "text": "UCHCHAGRAM"
        },
        {
            "district_code": 306,
            "block_code": 2803,
            "id": 108542,
            "text": "LOARAMGOPALPUR"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108273,
            "text": "BANHOOGHLY-II"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110661,
            "text": "AIRMARI KRISHNAPUR"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109632,
            "text": "PANTIHAL"
        },
        {
            "district_code": 317,
            "block_code": 2949,
            "id": 110026,
            "text": "ISWARPUR"
        },
        {
            "district_code": 307,
            "block_code": 2844,
            "id": 108914,
            "text": "MALLICKPUR"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108234,
            "text": "KAUTALA"
        },
        {
            "district_code": 320,
            "block_code": 3032,
            "id": 110833,
            "text": "HAREKRISHNAPUR"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110524,
            "text": "MIRJAPUR-I"
        },
        {
            "district_code": 311,
            "block_code": 2884,
            "id": 109313,
            "text": "BHANDAR"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108130,
            "text": "BAMANGACHHI"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110446,
            "text": "GRAMRAJ"
        },
        {
            "district_code": 317,
            "block_code": 2952,
            "id": 110048,
            "text": "AURAI"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110387,
            "text": "SARDIHA"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108661,
            "text": "BAMUNPARA"
        },
        {
            "district_code": 303,
            "block_code": 2727,
            "id": 107822,
            "text": "KIRTIPUR-I"
        },
        {
            "district_code": 303,
            "block_code": 2742,
            "id": 107953,
            "text": "HATGACHHI"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109684,
            "text": "GARBHABANIPUR-SONATALA"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108304,
            "text": "BRINDABANPUR"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110789,
            "text": "HATISALA-I"
        },
        {
            "district_code": 318,
            "block_code": 2982,
            "id": 110329,
            "text": "PINGBANI"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110482,
            "text": "BHEMUA"
        },
        {
            "district_code": 303,
            "block_code": 2742,
            "id": 107957,
            "text": "SARBERIA AGARHATI"
        },
        {
            "district_code": 313,
            "block_code": 2918,
            "id": 109703,
            "text": "BASUDEVPUR"
        },
        {
            "district_code": 319,
            "block_code": 3019,
            "id": 110701,
            "text": "DAFARPUR"
        },
        {
            "district_code": 303,
            "block_code": 2743,
            "id": 107965,
            "text": "MANIPUR"
        },
        {
            "district_code": 316,
            "block_code": 2939,
            "id": 109922,
            "text": "DOULATNAGAR"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109450,
            "text": "SRIPATIPURILIPUR"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107792,
            "text": "JAGANNATHPUR"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108501,
            "text": "AMARUN-I"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 107999,
            "text": "CHARABIDYA"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110792,
            "text": "HRIDAYPUR"
        },
        {
            "district_code": 317,
            "block_code": 2969,
            "id": 110199,
            "text": "KAKHARDA"
        },
        {
            "district_code": 303,
            "block_code": 2728,
            "id": 107826,
            "text": "KOWGACHI-I"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110923,
            "text": "SHYAMNAGAR"
        },
        {
            "district_code": 312,
            "block_code": 2903,
            "id": 109542,
            "text": "RISHRA"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110652,
            "text": "JAIPUR"
        },
        {
            "district_code": 318,
            "block_code": 2992,
            "id": 110422,
            "text": "KALIARA-I"
        },
        {
            "district_code": 321,
            "block_code": 3046,
            "id": 110973,
            "text": "GHATBERA-KEROWA"
        },
        {
            "district_code": 321,
            "block_code": 3050,
            "id": 111003,
            "text": "BARAGRAM"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109559,
            "text": "KANPUR"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109263,
            "text": "SAHAPUR-II"
        },
        {
            "district_code": 321,
            "block_code": 3061,
            "id": 111108,
            "text": "NUTANDI"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 261029,
            "text": "SHANTUK"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107994,
            "text": "SHIKHARBALI-II"
        },
        {
            "district_code": 319,
            "block_code": 3012,
            "id": 110634,
            "text": "KATABARI"
        },
        {
            "district_code": 305,
            "block_code": 2774,
            "id": 108290,
            "text": "ANDARTHOLE"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108662,
            "text": "DENUR"
        },
        {
            "district_code": 312,
            "block_code": 2901,
            "id": 109516,
            "text": "KELEPARA"
        },
        {
            "district_code": 306,
            "block_code": 2821,
            "id": 108708,
            "text": "JAHANNAGAR"
        },
        {
            "district_code": 317,
            "block_code": 2957,
            "id": 110082,
            "text": "HALUDBARI"
        },
        {
            "district_code": 321,
            "block_code": 3047,
            "id": 110983,
            "text": "SUKURHUTU"
        },
        {
            "district_code": 306,
            "block_code": 2807,
            "id": 108581,
            "text": "ANUKHAL"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109567,
            "text": "BHATORA"
        },
        {
            "district_code": 308,
            "block_code": 2855,
            "id": 109021,
            "text": "GOLENOWHATI"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109626,
            "text": "HANTAL ANANTABATI"
        },
        {
            "district_code": 321,
            "block_code": 3044,
            "id": 110956,
            "text": "HETGUGUI"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108255,
            "text": "G PLOT"
        },
        {
            "district_code": 321,
            "block_code": 3051,
            "id": 111010,
            "text": "HENSAHATU"
        },
        {
            "district_code": 704,
            "block_code": 2825,
            "id": 108739,
            "text": "AMRASOTA"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108030,
            "text": "BHANDARIA KASTEKUMARI"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109246,
            "text": "RAMPARA CHENCHRA"
        },
        {
            "district_code": 305,
            "block_code": 2778,
            "id": 108326,
            "text": "BANASHURIA"
        },
        {
            "district_code": 307,
            "block_code": 2827,
            "id": 108761,
            "text": "SARPALEHANA-ALBANDHA"
        },
        {
            "district_code": 306,
            "block_code": 2811,
            "id": 108617,
            "text": "PALSONA"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108660,
            "text": "BAGHSAN"
        },
        {
            "district_code": 304,
            "block_code": 2763,
            "id": 108180,
            "text": "JALABERIA-II"
        },
        {
            "district_code": 318,
            "block_code": 2978,
            "id": 110281,
            "text": "SARBERIA-II"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109618,
            "text": "PARBATIPUR"
        },
        {
            "district_code": 703,
            "block_code": 2972,
            "id": 110227,
            "text": "BINPUR"
        },
        {
            "district_code": 303,
            "block_code": 2741,
            "id": 107945,
            "text": "CHANDPUR"
        },
        {
            "district_code": 304,
            "block_code": 2766,
            "id": 108213,
            "text": "DHANURHAT"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108207,
            "text": "MULTI"
        },
        {
            "district_code": 303,
            "block_code": 2738,
            "id": 107921,
            "text": "BHABANIPUR-I"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109266,
            "text": "TORIYAL"
        },
        {
            "district_code": 307,
            "block_code": 2836,
            "id": 108848,
            "text": "RUDRANAGAR"
        },
        {
            "district_code": 305,
            "block_code": 2781,
            "id": 108352,
            "text": "INDAS-I"
        },
        {
            "district_code": 312,
            "block_code": 2893,
            "id": 109426,
            "text": "SAORA"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109565,
            "text": "UDANG-II"
        },
        {
            "district_code": 305,
            "block_code": 2793,
            "id": 108460,
            "text": "RADHAMOHANPUR"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109209,
            "text": "UDAY"
        },
        {
            "district_code": 306,
            "block_code": 2822,
            "id": 108722,
            "text": "PURBASTHALI"
        },
        {
            "district_code": 319,
            "block_code": 3018,
            "id": 110694,
            "text": "KEDARCHANDPUR-I"
        },
        {
            "district_code": 313,
            "block_code": 2917,
            "id": 109699,
            "text": "KALINAGAR"
        },
        {
            "district_code": 306,
            "block_code": 2812,
            "id": 108626,
            "text": "SITAHATI"
        },
        {
            "district_code": 306,
            "block_code": 2814,
            "id": 108642,
            "text": "SHANKARI-II"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108232,
            "text": "KANKANDIGHI"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110466,
            "text": "JAMIRAPAL"
        },
        {
            "district_code": 306,
            "block_code": 2814,
            "id": 108643,
            "text": "SHASHANGA"
        },
        {
            "district_code": 307,
            "block_code": 2837,
            "id": 108853,
            "text": "KAITHA-I"
        },
        {
            "district_code": 317,
            "block_code": 2969,
            "id": 110197,
            "text": "BALLUK-II"
        },
        {
            "district_code": 305,
            "block_code": 2793,
            "id": 108453,
            "text": "DIHIPARA"
        },
        {
            "district_code": 305,
            "block_code": 2784,
            "id": 108377,
            "text": "LEGO"
        },
        {
            "district_code": 305,
            "block_code": 2782,
            "id": 108360,
            "text": "JAGANNATHPUR"
        },
        {
            "district_code": 321,
            "block_code": 3055,
            "id": 111055,
            "text": "BOROJARAGARA"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109364,
            "text": "DUMURDAHANITYANANDAPUR-II"
        },
        {
            "district_code": 317,
            "block_code": 2950,
            "id": 110035,
            "text": "MAJILAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108119,
            "text": "CHHOTA MOLLAKHALI"
        },
        {
            "district_code": 321,
            "block_code": 3060,
            "id": 111099,
            "text": "GOLAMARA"
        },
        {
            "district_code": 318,
            "block_code": 2989,
            "id": 110394,
            "text": "KUSUMPUR"
        },
        {
            "district_code": 303,
            "block_code": 2743,
            "id": 107964,
            "text": "KORAKATI"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110410,
            "text": "SARISHAKHOLA"
        },
        {
            "district_code": 303,
            "block_code": 2725,
            "id": 107804,
            "text": "KONIARA-II"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109657,
            "text": "MASHILA"
        },
        {
            "district_code": 305,
            "block_code": 2782,
            "id": 108366,
            "text": "UTTARBARH"
        },
        {
            "district_code": 316,
            "block_code": 2944,
            "id": 109981,
            "text": "MANGALBARI"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261012,
            "text": "SEOKBIR"
        },
        {
            "district_code": 316,
            "block_code": 2944,
            "id": 109979,
            "text": "JATRADANGA"
        },
        {
            "district_code": 307,
            "block_code": 2832,
            "id": 108806,
            "text": "BARATURIGRAM"
        },
        {
            "district_code": 306,
            "block_code": 2812,
            "id": 108624,
            "text": "NABAGRAM"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108233,
            "text": "KASINAGAR"
        },
        {
            "district_code": 317,
            "block_code": 2952,
            "id": 110052,
            "text": "DARIYAPUR"
        },
        {
            "district_code": 308,
            "block_code": 2851,
            "id": 108994,
            "text": "UNISHBISHA"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108955,
            "text": "BHETAGURI-II"
        },
        {
            "district_code": 318,
            "block_code": 2989,
            "id": 110393,
            "text": "KHAJRA"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109406,
            "text": "DASHGHARA-I"
        },
        {
            "district_code": 305,
            "block_code": 2790,
            "id": 108433,
            "text": "KANURI"
        },
        {
            "district_code": 319,
            "block_code": 3011,
            "id": 110626,
            "text": "RAIPUR"
        },
        {
            "district_code": 305,
            "block_code": 2789,
            "id": 108428,
            "text": "ROUTORA"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110316,
            "text": "GARANGA"
        },
        {
            "district_code": 318,
            "block_code": 2991,
            "id": 110414,
            "text": "BARKOLA"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109570,
            "text": "GHORABERIA CHITNAN"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109782,
            "text": "MENDABARI"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110790,
            "text": "HATISALA-II"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110590,
            "text": "KULI"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108174,
            "text": "RAMKRISHNAPUR"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110443,
            "text": "BAKHRABAD"
        },
        {
            "district_code": 317,
            "block_code": 2969,
            "id": 110200,
            "text": "KHARUI-I"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109956,
            "text": "BEERNAGAR-I"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110804,
            "text": "GAJNA"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110470,
            "text": "PATINA"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110554,
            "text": "SATUI CHAURIGACHHA"
        },
        {
            "district_code": 306,
            "block_code": 2796,
            "id": 108483,
            "text": "DIGNAGAR-II"
        },
        {
            "district_code": 316,
            "block_code": 2945,
            "id": 109993,
            "text": "SAMSI"
        },
        {
            "district_code": 316,
            "block_code": 2939,
            "id": 109921,
            "text": "DAULATPUR"
        },
        {
            "district_code": 319,
            "block_code": 3007,
            "id": 110577,
            "text": "KAGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110341,
            "text": "AJABNAGAR-II"
        },
        {
            "district_code": 318,
            "block_code": 2982,
            "id": 110331,
            "text": "SARBOTH"
        },
        {
            "district_code": 304,
            "block_code": 2766,
            "id": 108211,
            "text": "CHANDPUR"
        },
        {
            "district_code": 304,
            "block_code": 2751,
            "id": 108054,
            "text": "RAJIBPUR"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109493,
            "text": "KSHIRKUNDI-NAMAJGRAM-NIYASA"
        },
        {
            "district_code": 319,
            "block_code": 3010,
            "id": 110612,
            "text": "BENIAGRAM"
        },
        {
            "district_code": 321,
            "block_code": 3057,
            "id": 111068,
            "text": "BOWRIDIH"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108564,
            "text": "JARAGRAM"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109968,
            "text": "DAKSHIN CHANDIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3006,
            "id": 110576,
            "text": "TALGRAM"
        },
        {
            "district_code": 317,
            "block_code": 2966,
            "id": 110177,
            "text": "SOUTH KHANDA"
        },
        {
            "district_code": 309,
            "block_code": 2867,
            "id": 109160,
            "text": "HATIGHISA"
        },
        {
            "district_code": 303,
            "block_code": 2730,
            "id": 107838,
            "text": "GOCHHA AKHARPUR"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108170,
            "text": "KEORATALA"
        },
        {
            "district_code": 306,
            "block_code": 2807,
            "id": 108584,
            "text": "BARADHAMAS"
        },
        {
            "district_code": 318,
            "block_code": 2999,
            "id": 110501,
            "text": "LALGERIA"
        },
        {
            "district_code": 303,
            "block_code": 2723,
            "id": 107784,
            "text": "TARABERIA"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110469,
            "text": "NAYAGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110299,
            "text": "DEBRA-II"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108396,
            "text": "ONDA-I"
        },
        {
            "district_code": 317,
            "block_code": 2968,
            "id": 110189,
            "text": "BALISAI"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110347,
            "text": "MANSUKA-II"
        },
        {
            "district_code": 316,
            "block_code": 2945,
            "id": 109992,
            "text": "RATUA"
        },
        {
            "district_code": 316,
            "block_code": 2939,
            "id": 109926,
            "text": "MASHALDAHA"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110121,
            "text": "BASUDEVPUR"
        },
        {
            "district_code": 704,
            "block_code": 2806,
            "id": 108570,
            "text": "BAHADURPUR"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110214,
            "text": "BISHNUBAR-I"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109352,
            "text": "HARINKHOLA-II"
        },
        {
            "district_code": 321,
            "block_code": 3045,
            "id": 110963,
            "text": "BURDA-KALIMATI"
        },
        {
            "district_code": 306,
            "block_code": 2801,
            "id": 108531,
            "text": "NABASTHA-I"
        },
        {
            "district_code": 319,
            "block_code": 3007,
            "id": 110578,
            "text": "MALIHATI"
        },
        {
            "district_code": 321,
            "block_code": 3047,
            "id": 110976,
            "text": "BANSBERA"
        },
        {
            "district_code": 313,
            "block_code": 2914,
            "id": 109669,
            "text": "DINGAKHOLA"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109789,
            "text": "KHOARDANGA-II"
        },
        {
            "district_code": 304,
            "block_code": 2754,
            "id": 108080,
            "text": "KALIKATALA"
        },
        {
            "district_code": 308,
            "block_code": 2855,
            "id": 109022,
            "text": "GOSAIRHAT"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109613,
            "text": "MAHIYARI-I"
        },
        {
            "district_code": 304,
            "block_code": 2756,
            "id": 108096,
            "text": "KAMARPOLE"
        },
        {
            "district_code": 320,
            "block_code": 3041,
            "id": 110932,
            "text": "HARIPUR"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109256,
            "text": "BELON"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109847,
            "text": "FULBARI-I"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110122,
            "text": "BYABATTARHATPASCHIM"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109959,
            "text": "CHARIANANTAPUR"
        },
        {
            "district_code": 307,
            "block_code": 2841,
            "id": 108885,
            "text": "KHARUN"
        },
        {
            "district_code": 321,
            "block_code": 3059,
            "id": 111092,
            "text": "MANARA"
        },
        {
            "district_code": 702,
            "block_code": 7354,
            "id": 261028,
            "text": "SHANGSE"
        },
        {
            "district_code": 304,
            "block_code": 2769,
            "id": 108241,
            "text": "BUDHAKHALI"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108112,
            "text": "HARINDANGA-II"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109646,
            "text": "SAHAPUR"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108752,
            "text": "KULBERIABOLKUNDA"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109036,
            "text": "MARUGANJ"
        },
        {
            "district_code": 306,
            "block_code": 2817,
            "id": 108678,
            "text": "DURGAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2760,
            "id": 108147,
            "text": "MAYAHAURI"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110454,
            "text": "NARAYANGARH"
        },
        {
            "district_code": 317,
            "block_code": 2949,
            "id": 110022,
            "text": "BRINDABANPUR-I"
        },
        {
            "district_code": 319,
            "block_code": 3019,
            "id": 110704,
            "text": "KANUPUR"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 108006,
            "text": "NAFARGANJ"
        },
        {
            "district_code": 317,
            "block_code": 2962,
            "id": 110136,
            "text": "KALICHARANPUR"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109777,
            "text": "JAIGAON-I"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107854,
            "text": "AKAIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110588,
            "text": "KALYANPUR-II"
        },
        {
            "district_code": 312,
            "block_code": 2890,
            "id": 109384,
            "text": "BARIJHATI"
        },
        {
            "district_code": 310,
            "block_code": 2875,
            "id": 109226,
            "text": "RAMKRISHNAPUR"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110460,
            "text": "BALIGERIA"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109906,
            "text": "BULBULCHANDI"
        },
        {
            "district_code": 311,
            "block_code": 2881,
            "id": 109281,
            "text": "BANGALBARI"
        },
        {
            "district_code": 316,
            "block_code": 2932,
            "id": 109856,
            "text": "BAMONGOLA"
        },
        {
            "district_code": 317,
            "block_code": 2953,
            "id": 110062,
            "text": "SAHARA"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108160,
            "text": "SURYANAGAR"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108560,
            "text": "BERUGRAM"
        },
        {
            "district_code": 703,
            "block_code": 2973,
            "id": 110237,
            "text": "BHULAVEDA"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109933,
            "text": "BAMONGRAM-MASHIMPUR"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110532,
            "text": "RAMNAGAR BACHARA"
        },
        {
            "district_code": 318,
            "block_code": 2997,
            "id": 110473,
            "text": "JALCHAK-I"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109479,
            "text": "NATIBPUR-II"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 108008,
            "text": "UTTAR MOKAMBERIA"
        },
        {
            "district_code": 318,
            "block_code": 2994,
            "id": 110439,
            "text": "NEELDA"
        },
        {
            "district_code": 319,
            "block_code": 3013,
            "id": 110645,
            "text": "KUMARSANDA"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110459,
            "text": "ARA"
        },
        {
            "district_code": 319,
            "block_code": 3016,
            "id": 110674,
            "text": "DAHAPARA"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108824,
            "text": "CHARICHA"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109973,
            "text": "MANIKCHAK"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110095,
            "text": "PULSHITA"
        },
        {
            "district_code": 316,
            "block_code": 2941,
            "id": 109951,
            "text": "UTTAR PACHANANDAPUR-II"
        },
        {
            "district_code": 312,
            "block_code": 2901,
            "id": 109517,
            "text": "PURSURAH-I"
        },
        {
            "district_code": 321,
            "block_code": 3062,
            "id": 111115,
            "text": "NUTANDIH"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109523,
            "text": "BAINCHIPOTA"
        },
        {
            "district_code": 316,
            "block_code": 2945,
            "id": 109986,
            "text": "BILAIMARI"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108943,
            "text": "GURIAHATI-II"
        },
        {
            "district_code": 303,
            "block_code": 2731,
            "id": 107849,
            "text": "GHORARASH KULINGRAM"
        },
        {
            "district_code": 306,
            "block_code": 2796,
            "id": 108484,
            "text": "GUSKARA-II"
        },
        {
            "district_code": 318,
            "block_code": 2975,
            "id": 110250,
            "text": "BANDIPUR-I"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260990,
            "text": "PERMAGURITAMSANG"
        },
        {
            "district_code": 320,
            "block_code": 3041,
            "id": 110931,
            "text": "GAYESHPUR"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109962,
            "text": "KUMBHIRA"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110343,
            "text": "DEWANCHAK-I"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108318,
            "text": "GHOSERGRAM"
        },
        {
            "district_code": 305,
            "block_code": 2781,
            "id": 108356,
            "text": "ROL"
        },
        {
            "district_code": 309,
            "block_code": 2866,
            "id": 261051,
            "text": "SOURENI-I"
        },
        {
            "district_code": 303,
            "block_code": 2740,
            "id": 107943,
            "text": "MINAKHAN"
        },
        {
            "district_code": 321,
            "block_code": 3054,
            "id": 111051,
            "text": "MANBAZAR"
        },
        {
            "district_code": 320,
            "block_code": 3034,
            "id": 110857,
            "text": "TALDAH MAJDIA"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261034,
            "text": "GAYABARI-II"
        },
        {
            "district_code": 307,
            "block_code": 2844,
            "id": 108911,
            "text": "BHURKUNA"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109648,
            "text": "ANDUL"
        },
        {
            "district_code": 308,
            "block_code": 2853,
            "id": 109012,
            "text": "UCHALPUKURI"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109784,
            "text": "SATALI"
        },
        {
            "district_code": 320,
            "block_code": 3033,
            "id": 110845,
            "text": "NANDANPUR"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109437,
            "text": "ALIPURKASHIPUR"
        },
        {
            "district_code": 312,
            "block_code": 2890,
            "id": 109385,
            "text": "BEGUMPUR"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261013,
            "text": "SINDEPONG"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107788,
            "text": "CHANDIPUR"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109367,
            "text": "GUPTIPARA-II"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110486,
            "text": "DANRRA"
        },
        {
            "district_code": 305,
            "block_code": 2780,
            "id": 108342,
            "text": "BRAHMANDIHA"
        },
        {
            "district_code": 320,
            "block_code": 3041,
            "id": 110929,
            "text": "BELGORIA-II"
        },
        {
            "district_code": 317,
            "block_code": 2962,
            "id": 110135,
            "text": "HARIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3018,
            "id": 110691,
            "text": "BALI-I"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108308,
            "text": "HAT-ASURIA"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110157,
            "text": "PANSKURA-I"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110540,
            "text": "CHHAIGHARI"
        },
        {
            "district_code": 317,
            "block_code": 2968,
            "id": 110195,
            "text": "SATILAPUR"
        },
        {
            "district_code": 303,
            "block_code": 2738,
            "id": 107919,
            "text": "AMLANI"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110825,
            "text": "MATIARI"
        },
        {
            "district_code": 702,
            "block_code": 7355,
            "id": 261024,
            "text": "LINGSEYKHA"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108869,
            "text": "JALUNDI"
        },
        {
            "district_code": 305,
            "block_code": 2778,
            "id": 108333,
            "text": "LATIABONI"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110376,
            "text": "AGUIBONI"
        },
        {
            "district_code": 306,
            "block_code": 2817,
            "id": 108674,
            "text": "BAGILA"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108822,
            "text": "BHARKATA"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109656,
            "text": "MANIKPUR"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109321,
            "text": "BAZARGAON-I"
        },
        {
            "district_code": 312,
            "block_code": 2893,
            "id": 109425,
            "text": "RAGHUBATI"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109287,
            "text": "GAISAL-I"
        },
        {
            "district_code": 312,
            "block_code": 2901,
            "id": 109520,
            "text": "SREERAMPUR"
        },
        {
            "district_code": 317,
            "block_code": 2950,
            "id": 110032,
            "text": "DULALPUR"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109185,
            "text": "BOLLA"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108931,
            "text": "MADHUPUR"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110737,
            "text": "GOBORDHANDANGA"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109931,
            "text": "ALIPUR-I"
        },
        {
            "district_code": 305,
            "block_code": 2787,
            "id": 108409,
            "text": "KUSHADWIP"
        },
        {
            "district_code": 319,
            "block_code": 3020,
            "id": 110709,
            "text": "JOTKAMAL"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108963,
            "text": "OKRABARI"
        },
        {
            "district_code": 306,
            "block_code": 2814,
            "id": 108641,
            "text": "SHANKARI-I"
        },
        {
            "district_code": 304,
            "block_code": 2747,
            "id": 108012,
            "text": "DURGAPUR"
        },
        {
            "district_code": 318,
            "block_code": 2993,
            "id": 110433,
            "text": "PANCHKHURI-I"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110345,
            "text": "IRHPALA"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107885,
            "text": "DHARMAPUR-II"
        },
        {
            "district_code": 317,
            "block_code": 2953,
            "id": 110061,
            "text": "RISHIBANKIMCHANDRA"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108235,
            "text": "KHARI"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108046,
            "text": "NAHAJARI"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110221,
            "text": "SREERAMPUR-I"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109482,
            "text": "RAJHATI-I"
        },
        {
            "district_code": 307,
            "block_code": 2832,
            "id": 108805,
            "text": "BAJITPUR"
        },
        {
            "district_code": 303,
            "block_code": 2723,
            "id": 107777,
            "text": "ADHATA"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107858,
            "text": "CHHAIGHORIA"
        },
        {
            "district_code": 303,
            "block_code": 2726,
            "id": 107809,
            "text": "DATTAPUKUR-I"
        },
        {
            "district_code": 317,
            "block_code": 2962,
            "id": 110133,
            "text": "DAUDPUR"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107980,
            "text": "CHAMPAHATI"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110526,
            "text": "SUJAPUR-KUMARPUR"
        },
        {
            "district_code": 703,
            "block_code": 2987,
            "id": 110371,
            "text": "JAMBONI"
        },
        {
            "district_code": 318,
            "block_code": 2977,
            "id": 110266,
            "text": "JENKAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110150,
            "text": "CHAITANYAPUR-II"
        },
        {
            "district_code": 317,
            "block_code": 2952,
            "id": 110049,
            "text": "BAMUNIA"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109344,
            "text": "SERPUR"
        },
        {
            "district_code": 321,
            "block_code": 3056,
            "id": 111064,
            "text": "SALTORE"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109686,
            "text": "HARISHPUR"
        },
        {
            "district_code": 703,
            "block_code": 2987,
            "id": 110375,
            "text": "PARIHATI"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110403,
            "text": "GOLAR"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261054,
            "text": "LAMAHATTA"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109494,
            "text": "LCHHOBADASPUR"
        },
        {
            "district_code": 307,
            "block_code": 2836,
            "id": 108843,
            "text": "KUSHMORE-II"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109365,
            "text": "EKTARPUR"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108391,
            "text": "LODNA"
        },
        {
            "district_code": 318,
            "block_code": 2983,
            "id": 110338,
            "text": "SHANKARKANTA"
        },
        {
            "district_code": 308,
            "block_code": 2853,
            "id": 109010,
            "text": "NIZTAROF"
        },
        {
            "district_code": 304,
            "block_code": 2760,
            "id": 108149,
            "text": "NALGORA"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110289,
            "text": "KHANJAPUR"
        },
        {
            "district_code": 704,
            "block_code": 2820,
            "id": 108702,
            "text": "CHHORA"
        },
        {
            "district_code": 703,
            "block_code": 2986,
            "id": 110360,
            "text": "AMARDA"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110156,
            "text": "MYSORA"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109410,
            "text": "GOPINATHPUR-I"
        },
        {
            "district_code": 318,
            "block_code": 2993,
            "id": 110437,
            "text": "TANTIGERIA"
        },
        {
            "district_code": 304,
            "block_code": 2771,
            "id": 108266,
            "text": "GANGASAGAR"
        },
        {
            "district_code": 303,
            "block_code": 2740,
            "id": 107944,
            "text": "MOHANPUR"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261000,
            "text": "BHALUKHOP"
        },
        {
            "district_code": 308,
            "block_code": 2851,
            "id": 108992,
            "text": "PREMERDANGA"
        },
        {
            "district_code": 304,
            "block_code": 2767,
            "id": 108225,
            "text": "MATHURAPUR PASCHIM"
        },
        {
            "district_code": 305,
            "block_code": 2781,
            "id": 108348,
            "text": "AKUI-I"
        },
        {
            "district_code": 307,
            "block_code": 2832,
            "id": 108807,
            "text": "DABUK"
        },
        {
            "district_code": 306,
            "block_code": 2824,
            "id": 108732,
            "text": "BARABAINAN"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110412,
            "text": "TEGHARI"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109965,
            "text": "SAHABAJPUR"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111034,
            "text": "HADALDA-UPARRAH"
        },
        {
            "district_code": 304,
            "block_code": 2755,
            "id": 108088,
            "text": "DERAK"
        },
        {
            "district_code": 316,
            "block_code": 2939,
            "id": 109925,
            "text": "MALIOR-II"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261006,
            "text": "LOWER ECHHAY"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108253,
            "text": "DIGAMBARPUR"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107881,
            "text": "NURNAGAR"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109778,
            "text": "JAIGAON-II"
        },
        {
            "district_code": 305,
            "block_code": 2781,
            "id": 108349,
            "text": "AKUI-II"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109572,
            "text": "JHAMTIA"
        },
        {
            "district_code": 304,
            "block_code": 2766,
            "id": 108212,
            "text": "DAKSHIN BISHNUPUR"
        },
        {
            "district_code": 309,
            "block_code": 2867,
            "id": 109163,
            "text": "NAKSHALBARI"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108163,
            "text": "BELPUKUR"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109529,
            "text": "BORA"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108188,
            "text": "LAKSHMIKANTAPUR"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260986,
            "text": "LINGIAMARAYBONG"
        },
        {
            "district_code": 703,
            "block_code": 2973,
            "id": 110236,
            "text": "BHELAIDIHA"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109486,
            "text": "BELOONDHAMASIN"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110123,
            "text": "BYABATTARHATPURBA"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110553,
            "text": "SAHAJADPUR"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110520,
            "text": "KAPASDANGA"
        },
        {
            "district_code": 319,
            "block_code": 3026,
            "id": 110758,
            "text": "AURANGABAD-I"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109689,
            "text": "KURCHI SHIBPUR"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110657,
            "text": "MARGRAM"
        },
        {
            "district_code": 321,
            "block_code": 3058,
            "id": 111079,
            "text": "JAMBAD"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108277,
            "text": "KHEYADAHA-I"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109369,
            "text": "MOHIPALPUR"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109716,
            "text": "SHALKUMAR-I"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108314,
            "text": "CHHATNA-I"
        },
        {
            "district_code": 319,
            "block_code": 3012,
            "id": 110638,
            "text": "SAHEBNAGAR"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110863,
            "text": "CHAKDIGNAGAR"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109851,
            "text": "MANTADARI"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108199,
            "text": "DHANPOTA"
        },
        {
            "district_code": 309,
            "block_code": 2865,
            "id": 109152,
            "text": "PATHARGHATA"
        },
        {
            "district_code": 307,
            "block_code": 2832,
            "id": 108812,
            "text": "MOLLARPUR-II"
        },
        {
            "district_code": 321,
            "block_code": 3055,
            "id": 111057,
            "text": "DIGHI"
        },
        {
            "district_code": 311,
            "block_code": 2884,
            "id": 109312,
            "text": "BARUNA"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110885,
            "text": "BETHUADAHARI-I"
        },
        {
            "district_code": 312,
            "block_code": 2893,
            "id": 109421,
            "text": "BHADUR"
        },
        {
            "district_code": 317,
            "block_code": 2963,
            "id": 110143,
            "text": "AMDABAD-II"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110468,
            "text": "MALAM"
        },
        {
            "district_code": 702,
            "block_code": 7354,
            "id": 261019,
            "text": "DALAPCHAND"
        },
        {
            "district_code": 307,
            "block_code": 2830,
            "id": 108793,
            "text": "RUPUSPUR"
        },
        {
            "district_code": 308,
            "block_code": 2851,
            "id": 108987,
            "text": "FULBARI"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108750,
            "text": "JITPUR-UTTARRAMPUR"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109239,
            "text": "DWIPKHANDA"
        },
        {
            "district_code": 321,
            "block_code": 3047,
            "id": 110984,
            "text": "TUMRASOLE"
        },
        {
            "district_code": 318,
            "block_code": 2999,
            "id": 110494,
            "text": "BANKIBANDH"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260983,
            "text": "DHOOTRIA KALEJ VALLEY"
        },
        {
            "district_code": 704,
            "block_code": 2809,
            "id": 108603,
            "text": "TRILOKCHANDRAPUR"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110464,
            "text": "CHANDABILLA"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110671,
            "text": "PAIKAPARA"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110887,
            "text": "BIKRAMPUR"
        },
        {
            "district_code": 305,
            "block_code": 2774,
            "id": 108292,
            "text": "JAGADALLA-II"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261007,
            "text": "NEEMBONG"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109878,
            "text": "BINODPUR"
        },
        {
            "district_code": 317,
            "block_code": 2956,
            "id": 110080,
            "text": "TIKASHI"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108950,
            "text": "SUTKABARI"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108166,
            "text": "GAJIPUR"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108279,
            "text": "LANGALBERIA"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109772,
            "text": "PATKATA"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110404,
            "text": "JAGANNATHPUR"
        },
        {
            "district_code": 313,
            "block_code": 2914,
            "id": 109673,
            "text": "SYAMPUR"
        },
        {
            "district_code": 321,
            "block_code": 3047,
            "id": 110975,
            "text": "BANJORA"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109649,
            "text": "BANPUR-I"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108801,
            "text": "KURUNNAHAR"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109769,
            "text": "MONDALGHAT"
        },
        {
            "district_code": 313,
            "block_code": 2907,
            "id": 109581,
            "text": "BAGNAN-II"
        },
        {
            "district_code": 316,
            "block_code": 2934,
            "id": 109876,
            "text": "MALATIPUR"
        },
        {
            "district_code": 303,
            "block_code": 2736,
            "id": 107907,
            "text": "GUMA-I"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107795,
            "text": "RAGHUNATHPUR"
        },
        {
            "district_code": 703,
            "block_code": 2973,
            "id": 110241,
            "text": "SANDAPARA"
        },
        {
            "district_code": 308,
            "block_code": 2853,
            "id": 109006,
            "text": "BHOTBARI"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108899,
            "text": "AMARPUR"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109043,
            "text": "BHANUKUMARI-II"
        },
        {
            "district_code": 317,
            "block_code": 2951,
            "id": 110042,
            "text": "KANAIDIGHI"
        },
        {
            "district_code": 320,
            "block_code": 3036,
            "id": 110875,
            "text": "SADHANPARA-I"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108937,
            "text": "CHILKIRHAT"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107987,
            "text": "MALLIKPUR"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109905,
            "text": "BAIDYAPUR"
        },
        {
            "district_code": 307,
            "block_code": 2841,
            "id": 108886,
            "text": "KUSUMBA"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109370,
            "text": "SIJAKAMALPUR"
        },
        {
            "district_code": 320,
            "block_code": 3043,
            "id": 110950,
            "text": "PALSUNDA-II"
        },
        {
            "district_code": 310,
            "block_code": 2873,
            "id": 109211,
            "text": "BAIRHATTA"
        },
        {
            "district_code": 303,
            "block_code": 2739,
            "id": 107929,
            "text": "DULDULI"
        },
        {
            "district_code": 318,
            "block_code": 2975,
            "id": 110253,
            "text": "BHAGABANTAPUR-I"
        },
        {
            "district_code": 304,
            "block_code": 2771,
            "id": 108271,
            "text": "RUDRANAGAR"
        },
        {
            "district_code": 303,
            "block_code": 2742,
            "id": 107954,
            "text": "KALINAGAR"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110089,
            "text": "BRINDABANCHAK"
        },
        {
            "district_code": 304,
            "block_code": 2767,
            "id": 108222,
            "text": "DEBIPUR"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110489,
            "text": "MOHAR"
        },
        {
            "district_code": 321,
            "block_code": 3063,
            "id": 111121,
            "text": "TARABARI"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109615,
            "text": "MAKARDAH-I"
        },
        {
            "district_code": 306,
            "block_code": 2824,
            "id": 108736,
            "text": "PAINTA-I"
        },
        {
            "district_code": 312,
            "block_code": 2904,
            "id": 109547,
            "text": "CHAMPADANGA"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109722,
            "text": "CHAPORER PAR-I"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110315,
            "text": "DHADIKA"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110530,
            "text": "KAMNAGAR"
        },
        {
            "district_code": 316,
            "block_code": 2933,
            "id": 109864,
            "text": "CHANCHOL"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109041,
            "text": "BAROKODALI-II"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108970,
            "text": "BURIRHAT-I"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109200,
            "text": "BASURIA"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110786,
            "text": "BAGBERIA"
        },
        {
            "district_code": 316,
            "block_code": 2946,
            "id": 109994,
            "text": "ARAIDANGA"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108058,
            "text": "DONGARIA RAIPUR"
        },
        {
            "district_code": 311,
            "block_code": 2881,
            "id": 109285,
            "text": "NAODA"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108128,
            "text": "SHAMBHUNAGAR"
        },
        {
            "district_code": 704,
            "block_code": 2825,
            "id": 108740,
            "text": "BALLAVPUR"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109201,
            "text": "BELBARI-I"
        },
        {
            "district_code": 306,
            "block_code": 2814,
            "id": 108639,
            "text": "LODNA"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110732,
            "text": "BALIA"
        },
        {
            "district_code": 703,
            "block_code": 2987,
            "id": 110374,
            "text": "LALBANDH"
        },
        {
            "district_code": 318,
            "block_code": 2991,
            "id": 110416,
            "text": "HARIATORA"
        },
        {
            "district_code": 306,
            "block_code": 2796,
            "id": 108485,
            "text": "UKTA"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108127,
            "text": "SATJELIA"
        },
        {
            "district_code": 308,
            "block_code": 2852,
            "id": 108996,
            "text": "GOPALPUR"
        },
        {
            "district_code": 319,
            "block_code": 3013,
            "id": 110639,
            "text": "ANDULIA"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109940,
            "text": "NAODA-JADUPUR"
        },
        {
            "district_code": 704,
            "block_code": 2825,
            "id": 108744,
            "text": "TIRAT"
        },
        {
            "district_code": 314,
            "block_code": 2921,
            "id": 109741,
            "text": "JHARALTAGRAM-II"
        },
        {
            "district_code": 317,
            "block_code": 2962,
            "id": 110140,
            "text": "SAMSABAD"
        },
        {
            "district_code": 704,
            "block_code": 2819,
            "id": 108694,
            "text": "KAJORA"
        },
        {
            "district_code": 304,
            "block_code": 2753,
            "id": 108068,
            "text": "DARIA"
        },
        {
            "district_code": 307,
            "block_code": 2845,
            "id": 108922,
            "text": "PURANDARPUR"
        },
        {
            "district_code": 317,
            "block_code": 2951,
            "id": 110040,
            "text": "DEBENDRA"
        },
        {
            "district_code": 311,
            "block_code": 2878,
            "id": 109251,
            "text": "GHIRNIGAON"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109896,
            "text": "KARKACH"
        },
        {
            "district_code": 304,
            "block_code": 2766,
            "id": 108215,
            "text": "GHATESWAR"
        },
        {
            "district_code": 306,
            "block_code": 2797,
            "id": 108487,
            "text": "DEBSHALA"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110824,
            "text": "KALIGANJ"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111032,
            "text": "GAGNABAD"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108131,
            "text": "CHALTABERIA"
        },
        {
            "district_code": 703,
            "block_code": 2973,
            "id": 110239,
            "text": "HARDA"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108172,
            "text": "RAJARAMPUR"
        },
        {
            "district_code": 320,
            "block_code": 3033,
            "id": 110841,
            "text": "DHORADAHA-I"
        },
        {
            "district_code": 321,
            "block_code": 3058,
            "id": 111080,
            "text": "KENDA"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108830,
            "text": "PURANAGRAM"
        },
        {
            "district_code": 307,
            "block_code": 2832,
            "id": 108809,
            "text": "JHIKODDA"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109245,
            "text": "RAMCHANDRAPUR"
        },
        {
            "district_code": 319,
            "block_code": 3010,
            "id": 110615,
            "text": "IMAMNAGAR"
        },
        {
            "district_code": 320,
            "block_code": 3039,
            "id": 110907,
            "text": "RAMNAGAR-I"
        },
        {
            "district_code": 321,
            "block_code": 3051,
            "id": 111018,
            "text": "PUSTI"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108103,
            "text": "BANGANAGAR-II"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109342,
            "text": "MARAIKURA"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107872,
            "text": "BERACHAMPA-II"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109563,
            "text": "SIRAJBATI"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108161,
            "text": "SWAMI BIBEKANANDA"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109466,
            "text": "KISHOREPUR-I"
        },
        {
            "district_code": 312,
            "block_code": 2891,
            "id": 109395,
            "text": "DEBANANDAPUR"
        },
        {
            "district_code": 319,
            "block_code": 3022,
            "id": 110728,
            "text": "MALIBARI-II"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109462,
            "text": "BALIPUR"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260952,
            "text": "DADAIPANI"
        },
        {
            "district_code": 304,
            "block_code": 2753,
            "id": 108070,
            "text": "GOPALPUR"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110159,
            "text": "PRATAPPUR-II"
        },
        {
            "district_code": 303,
            "block_code": 2743,
            "id": 107960,
            "text": "BERMAJUR-II"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110447,
            "text": "HEMCHANDRA"
        },
        {
            "district_code": 306,
            "block_code": 2810,
            "id": 108610,
            "text": "SARGRAM"
        },
        {
            "district_code": 307,
            "block_code": 2845,
            "id": 108917,
            "text": "ABINASHPUR"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109330,
            "text": "RASAKHOWA-I"
        },
        {
            "district_code": 318,
            "block_code": 2974,
            "id": 110245,
            "text": "LAKSHMIPUR"
        },
        {
            "district_code": 305,
            "block_code": 2785,
            "id": 108384,
            "text": "KUSHTORE"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108259,
            "text": "PATHARPRATIMA"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110287,
            "text": "JYOTGHANASHYAM"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108561,
            "text": "CHAKDIGHI"
        },
        {
            "district_code": 305,
            "block_code": 2785,
            "id": 108385,
            "text": "MEJHIA"
        },
        {
            "district_code": 321,
            "block_code": 3056,
            "id": 111060,
            "text": "DIGHA"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110869,
            "text": "RUIPUKUR."
        },
        {
            "district_code": 703,
            "block_code": 3000,
            "id": 110508,
            "text": "KULTIKRI"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109536,
            "text": "SINGUR-II"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110342,
            "text": "BEERSINGHA"
        },
        {
            "district_code": 306,
            "block_code": 2797,
            "id": 108491,
            "text": "VALKI"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108952,
            "text": "BARA ATIABARI-II"
        },
        {
            "district_code": 305,
            "block_code": 2779,
            "id": 108337,
            "text": "GOPALPUR"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109961,
            "text": "KRISHNAPUR"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261043,
            "text": "ST. MARRYS-II"
        },
        {
            "district_code": 303,
            "block_code": 2730,
            "id": 107840,
            "text": "ITINDA PANITORE"
        },
        {
            "district_code": 321,
            "block_code": 3058,
            "id": 111078,
            "text": "CHIRUDIHI"
        },
        {
            "district_code": 304,
            "block_code": 2771,
            "id": 108269,
            "text": "MURIGANGA-II"
        },
        {
            "district_code": 306,
            "block_code": 2818,
            "id": 108689,
            "text": "KUCHUT"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110861,
            "text": "BHATJUNGLA"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261033,
            "text": "GAYABARI-I"
        },
        {
            "district_code": 305,
            "block_code": 2788,
            "id": 108419,
            "text": "RAIPUR"
        },
        {
            "district_code": 308,
            "block_code": 2855,
            "id": 109020,
            "text": "CHHOTOSALBARI"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108826,
            "text": "GONPUR"
        },
        {
            "district_code": 306,
            "block_code": 2811,
            "id": 108616,
            "text": "KARUI"
        },
        {
            "district_code": 312,
            "block_code": 2904,
            "id": 109544,
            "text": "BALIGORI-I"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108315,
            "text": "CHHATNA-II"
        },
        {
            "district_code": 306,
            "block_code": 2813,
            "id": 108628,
            "text": "ANKHONA"
        },
        {
            "district_code": 664,
            "block_code": 2926,
            "id": 109797,
            "text": "BIRPARA-I"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109468,
            "text": "POLE-I"
        },
        {
            "district_code": 312,
            "block_code": 2894,
            "id": 109429,
            "text": "BENGAI"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261001,
            "text": "BONG"
        },
        {
            "district_code": 319,
            "block_code": 3009,
            "id": 110598,
            "text": "BHAGIRATHPUR"
        },
        {
            "district_code": 311,
            "block_code": 2884,
            "id": 109317,
            "text": "MUSTAFANAGAR"
        },
        {
            "district_code": 318,
            "block_code": 2978,
            "id": 110272,
            "text": "BASUDEVPUR"
        },
        {
            "district_code": 318,
            "block_code": 2993,
            "id": 110431,
            "text": "DHERUA"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110593,
            "text": "SABALDAHA"
        },
        {
            "district_code": 318,
            "block_code": 2993,
            "id": 110435,
            "text": "PATHRA"
        },
        {
            "district_code": 306,
            "block_code": 2807,
            "id": 108586,
            "text": "PINDIRA"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110492,
            "text": "SABANG"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109028,
            "text": "BALABHUT"
        },
        {
            "district_code": 307,
            "block_code": 2842,
            "id": 108893,
            "text": "HANSAN-II"
        },
        {
            "district_code": 317,
            "block_code": 2962,
            "id": 110139,
            "text": "NANDIGRAM"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260975,
            "text": "GARUBATHAN-II"
        },
        {
            "district_code": 320,
            "block_code": 3039,
            "id": 110900,
            "text": "ANULIA"
        },
        {
            "district_code": 304,
            "block_code": 2760,
            "id": 108145,
            "text": "GARDOANI"
        },
        {
            "district_code": 320,
            "block_code": 7115,
            "id": 110774,
            "text": "KANCHARAPARA"
        },
        {
            "district_code": 305,
            "block_code": 2783,
            "id": 108369,
            "text": "DHANARA"
        },
        {
            "district_code": 306,
            "block_code": 2810,
            "id": 108606,
            "text": "GOAI"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261016,
            "text": "UPPER ECHHAY"
        },
        {
            "district_code": 311,
            "block_code": 2878,
            "id": 109249,
            "text": "CHUTIAKHORE"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110514,
            "text": "BEGUNBARI"
        },
        {
            "district_code": 703,
            "block_code": 3000,
            "id": 110510,
            "text": "PATHRA"
        },
        {
            "district_code": 317,
            "block_code": 2968,
            "id": 110194,
            "text": "PALDHUI"
        },
        {
            "district_code": 318,
            "block_code": 2977,
            "id": 110267,
            "text": "POROLDA"
        },
        {
            "district_code": 307,
            "block_code": 2835,
            "id": 108834,
            "text": "DUMURGRAM"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110538,
            "text": "BHAKURI-I"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109955,
            "text": "BEDRABAD"
        },
        {
            "district_code": 317,
            "block_code": 2952,
            "id": 110053,
            "text": "DHOBABERIA"
        },
        {
            "district_code": 321,
            "block_code": 3061,
            "id": 111106,
            "text": "CHORPAHARI"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109638,
            "text": "BELDUBI"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110114,
            "text": "NAICHANPUR-I"
        },
        {
            "district_code": 304,
            "block_code": 2760,
            "id": 108144,
            "text": "FUTIGODA"
        },
        {
            "district_code": 317,
            "block_code": 2948,
            "id": 110012,
            "text": "ARJUNNAGAR"
        },
        {
            "district_code": 305,
            "block_code": 2782,
            "id": 108365,
            "text": "SHYAMNAGAR"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110161,
            "text": "RADHABALLAVCHAK"
        },
        {
            "district_code": 664,
            "block_code": 2926,
            "id": 109799,
            "text": "HANTAPARA"
        },
        {
            "district_code": 305,
            "block_code": 2794,
            "id": 108464,
            "text": "HARMASRA"
        },
        {
            "district_code": 306,
            "block_code": 2801,
            "id": 108525,
            "text": "BAIKUNTHAPUR-II"
        },
        {
            "district_code": 318,
            "block_code": 2982,
            "id": 110330,
            "text": "PIYASALA"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109204,
            "text": "DAMDAMA"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109682,
            "text": "BHABANIPUR BIDHICHANDRAPUR"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109356,
            "text": "MAYAPUR-I"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109535,
            "text": "SINGUR-I"
        },
        {
            "district_code": 313,
            "block_code": 2917,
            "id": 109695,
            "text": "DHULASIMLA"
        },
        {
            "district_code": 317,
            "block_code": 2968,
            "id": 110190,
            "text": "DEPAL"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108108,
            "text": "FALTA"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111037,
            "text": "MANIHARA"
        },
        {
            "district_code": 317,
            "block_code": 2965,
            "id": 110164,
            "text": "AMARSHI-II"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109532,
            "text": "KAMARKUNDUGOPALNAGARDALUIGACHHA"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108934,
            "text": "PUNDIBARI"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260997,
            "text": "SUKHIA-SIMANA"
        },
        {
            "district_code": 703,
            "block_code": 2986,
            "id": 110359,
            "text": "ALAMPUR"
        },
        {
            "district_code": 313,
            "block_code": 2918,
            "id": 109706,
            "text": "RAGHUDEVPUR"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 261024,
            "text": "LINGSEYKHA"
        },
        {
            "district_code": 312,
            "block_code": 2889,
            "id": 109375,
            "text": "BHAGABATIPUR"
        },
        {
            "district_code": 314,
            "block_code": 2927,
            "id": 109814,
            "text": "ODLABARI"
        },
        {
            "district_code": 311,
            "block_code": 2878,
            "id": 109253,
            "text": "LAKHIPUR"
        },
        {
            "district_code": 320,
            "block_code": 3041,
            "id": 110930,
            "text": "FULIA TOWNSHIP"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108559,
            "text": "AJHAPUR"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110398,
            "text": "AMANPUR"
        },
        {
            "district_code": 304,
            "block_code": 2751,
            "id": 108053,
            "text": "NISCHINTAPUR"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108872,
            "text": "NAWANAGAR-KADDA"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110162,
            "text": "RAGHUNATHBARI"
        },
        {
            "district_code": 305,
            "block_code": 2787,
            "id": 108402,
            "text": "BALSI-I"
        },
        {
            "district_code": 312,
            "block_code": 2894,
            "id": 109433,
            "text": "MANDARAN"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108320,
            "text": "JHUNJKA"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107870,
            "text": "AMULIA"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109720,
            "text": "VIVEKANDA-II"
        },
        {
            "district_code": 311,
            "block_code": 2881,
            "id": 109284,
            "text": "HEMTABAD"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261053,
            "text": "LABDAH"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108504,
            "text": "BANPASH"
        },
        {
            "district_code": 306,
            "block_code": 2824,
            "id": 108737,
            "text": "PAINTA-II"
        },
        {
            "district_code": 316,
            "block_code": 2932,
            "id": 109860,
            "text": "MADNABATI"
        },
        {
            "district_code": 305,
            "block_code": 2774,
            "id": 108293,
            "text": "KALPATHAR"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109292,
            "text": "KAMALGAON-SUJALI"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109183,
            "text": "AMRITAKHAND"
        },
        {
            "district_code": 303,
            "block_code": 2737,
            "id": 107911,
            "text": "BAKJURI"
        },
        {
            "district_code": 316,
            "block_code": 2933,
            "id": 109869,
            "text": "MOTIHARPUR"
        },
        {
            "district_code": 313,
            "block_code": 2907,
            "id": 109580,
            "text": "BAGNAN-I"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109836,
            "text": "RAMSHAI"
        },
        {
            "district_code": 321,
            "block_code": 3052,
            "id": 111027,
            "text": "RIGID"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109026,
            "text": "ANDARAN-FULBARI-I"
        },
        {
            "district_code": 318,
            "block_code": 2989,
            "id": 110395,
            "text": "LALUA"
        },
        {
            "district_code": 307,
            "block_code": 2840,
            "id": 108876,
            "text": "CHANDRAPUR"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109712,
            "text": "MATHURA"
        },
        {
            "district_code": 305,
            "block_code": 2790,
            "id": 108432,
            "text": "GOGRA"
        },
        {
            "district_code": 305,
            "block_code": 2790,
            "id": 108431,
            "text": "DHEKIA"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110295,
            "text": "SAHACHAK"
        },
        {
            "district_code": 321,
            "block_code": 3059,
            "id": 111093,
            "text": "SONAIJURI"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108044,
            "text": "KHAGRAMURI"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109937,
            "text": "KALIACHAK-I"
        },
        {
            "district_code": 317,
            "block_code": 2967,
            "id": 110184,
            "text": "PADIMA-I"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107981,
            "text": "DHAPDHAPI-I"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109756,
            "text": "JATESWAR-II"
        },
        {
            "district_code": 304,
            "block_code": 2773,
            "id": 108285,
            "text": "CHATTA"
        },
        {
            "district_code": 310,
            "block_code": 2871,
            "id": 109196,
            "text": "GANGURIA"
        },
        {
            "district_code": 313,
            "block_code": 2917,
            "id": 109697,
            "text": "HATGACHHA-II"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108167,
            "text": "ISWARIPUR"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260969,
            "text": "RISHIRHATBLOOM FIELD"
        },
        {
            "district_code": 318,
            "block_code": 2989,
            "id": 110389,
            "text": "BAGHASTHI"
        },
        {
            "district_code": 306,
            "block_code": 2821,
            "id": 108707,
            "text": "DOGACHHIA"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108666,
            "text": "MAMUDPUR-I"
        },
        {
            "district_code": 321,
            "block_code": 3061,
            "id": 111107,
            "text": "KHAJURA"
        },
        {
            "district_code": 318,
            "block_code": 2977,
            "id": 110270,
            "text": "TALDA"
        },
        {
            "district_code": 317,
            "block_code": 2949,
            "id": 110028,
            "text": "KULBARI"
        },
        {
            "district_code": 321,
            "block_code": 3052,
            "id": 111025,
            "text": "MAJHIDIH"
        },
        {
            "district_code": 305,
            "block_code": 2783,
            "id": 108367,
            "text": "BAIDYANATHPUR"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110595,
            "text": "SAHORA"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109187,
            "text": "CHINGISHPUR"
        },
        {
            "district_code": 304,
            "block_code": 2771,
            "id": 108264,
            "text": "DHASPARA SUMATINAGAR-I"
        },
        {
            "district_code": 304,
            "block_code": 2753,
            "id": 108074,
            "text": "MATLA-II"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110895,
            "text": "HARANAGAR"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109267,
            "text": "DHARAMPUR-I"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260992,
            "text": "POKHRIABONG-I"
        },
        {
            "district_code": 320,
            "block_code": 3034,
            "id": 110853,
            "text": "JOYGHATA"
        },
        {
            "district_code": 306,
            "block_code": 2813,
            "id": 108634,
            "text": "RAJUR"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108311,
            "text": "PAKHANNA"
        },
        {
            "district_code": 321,
            "block_code": 3063,
            "id": 111116,
            "text": "BALITORA"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 261030,
            "text": "SYAKIYONG"
        },
        {
            "district_code": 319,
            "block_code": 3010,
            "id": 110614,
            "text": "BEWA-II"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109373,
            "text": "SRIPUR-BALAGARH"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109612,
            "text": "KOLORA-II"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108049,
            "text": "RAMKRISHNAPUR BORHANPUR"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108102,
            "text": "BANGANAGAR-I"
        },
        {
            "district_code": 309,
            "block_code": 2867,
            "id": 109162,
            "text": "MANIRAM"
        },
        {
            "district_code": 321,
            "block_code": 3044,
            "id": 110953,
            "text": "BELDIH"
        },
        {
            "district_code": 317,
            "block_code": 2966,
            "id": 110173,
            "text": "KHAR"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110112,
            "text": "MOYNA-I"
        },
        {
            "district_code": 310,
            "block_code": 2873,
            "id": 109212,
            "text": "GOKARNA"
        },
        {
            "district_code": 314,
            "block_code": 2930,
            "id": 109840,
            "text": "ANGRABHASA-II"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110891,
            "text": "BIRPUR-II"
        },
        {
            "district_code": 318,
            "block_code": 2989,
            "id": 110390,
            "text": "GAGANESWAR"
        },
        {
            "district_code": 303,
            "block_code": 2740,
            "id": 107942,
            "text": "KUMARJOLE"
        },
        {
            "district_code": 312,
            "block_code": 2890,
            "id": 109388,
            "text": "JANAI"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107991,
            "text": "SHANKARPUR-I"
        },
        {
            "district_code": 304,
            "block_code": 2756,
            "id": 108098,
            "text": "MATHUR"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 261025,
            "text": "LOLE"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108906,
            "text": "MATHPALSA"
        },
        {
            "district_code": 303,
            "block_code": 2728,
            "id": 107828,
            "text": "MAJHIPARA-PALASI"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109904,
            "text": "AKTAIL"
        },
        {
            "district_code": 319,
            "block_code": 3010,
            "id": 110616,
            "text": "MAHADEBNAGAR"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110380,
            "text": "DUDHKUNDI"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110914,
            "text": "BAIDYAPUR-II"
        },
        {
            "district_code": 307,
            "block_code": 2830,
            "id": 108785,
            "text": "BARRAH"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108322,
            "text": "METYALA"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108165,
            "text": "DHOLA"
        },
        {
            "district_code": 318,
            "block_code": 2975,
            "id": 110255,
            "text": "KUAPUR"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261014,
            "text": "TASHIDING"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109448,
            "text": "PASCHIMGOPINATHPUR"
        },
        {
            "district_code": 320,
            "block_code": 3034,
            "id": 110856,
            "text": "SHIBNIBAS"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109650,
            "text": "BANPUR-II"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110862,
            "text": "BHIMPUR"
        },
        {
            "district_code": 317,
            "block_code": 2951,
            "id": 110043,
            "text": "KUMIRDA"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109690,
            "text": "PANCHARUL"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109199,
            "text": "ASHOKEGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2976,
            "id": 110263,
            "text": "SALIKOTHA"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109762,
            "text": "BAROPATIA NUTANBOS"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108803,
            "text": "LABPUR-II"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107989,
            "text": "RAMNAGAR-I"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109244,
            "text": "MALANCHA"
        },
        {
            "district_code": 312,
            "block_code": 2896,
            "id": 109453,
            "text": "FURFURA"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110773,
            "text": "HINGARA"
        },
        {
            "district_code": 321,
            "block_code": 3057,
            "id": 111066,
            "text": "ANARA"
        },
        {
            "district_code": 303,
            "block_code": 2731,
            "id": 107853,
            "text": "SHRINAGAR METIA"
        },
        {
            "district_code": 303,
            "block_code": 2731,
            "id": 107845,
            "text": "BEGUMPUR BIBIPUR"
        },
        {
            "district_code": 312,
            "block_code": 2903,
            "id": 109538,
            "text": "NABAGRAM"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110802,
            "text": "DAKSHINPARA-I"
        },
        {
            "district_code": 319,
            "block_code": 3020,
            "id": 110707,
            "text": "BARASIMUL DAYARAMPUR"
        },
        {
            "district_code": 303,
            "block_code": 2743,
            "id": 107966,
            "text": "SANDESHKHALI"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108671,
            "text": "SHUSHUNIA"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261017,
            "text": "YANGMAKUM"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109794,
            "text": "VALKA BARABISA-I"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109445,
            "text": "NALIKULPASCHIM"
        },
        {
            "district_code": 319,
            "block_code": 3018,
            "id": 110695,
            "text": "KEDARCHANDPUR-II"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109302,
            "text": "GULANDAR-I"
        },
        {
            "district_code": 318,
            "block_code": 2983,
            "id": 110333,
            "text": "KARSA"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 110105,
            "text": "LAKSHYA-I"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108305,
            "text": "CHHANDAR"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109323,
            "text": "DALKHOLA-I"
        },
        {
            "district_code": 317,
            "block_code": 2954,
            "id": 110070,
            "text": "VIVEKANANDA"
        },
        {
            "district_code": 312,
            "block_code": 2894,
            "id": 109430,
            "text": "HAZIPUR"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110313,
            "text": "BARAMURA"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109045,
            "text": "MAHISKHUCHI-II"
        },
        {
            "district_code": 305,
            "block_code": 2780,
            "id": 108347,
            "text": "RAGHUNATHPUR"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108802,
            "text": "LABPUR-I"
        },
        {
            "district_code": 309,
            "block_code": 2868,
            "id": 109169,
            "text": "GHOSPUKUR"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109351,
            "text": "HARINKHOLA-I"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108506,
            "text": "BARABELOON-II"
        },
        {
            "district_code": 307,
            "block_code": 2828,
            "id": 108770,
            "text": "LAXMI-NARAYANPUR"
        },
        {
            "district_code": 318,
            "block_code": 2999,
            "id": 110502,
            "text": "SHALBONI"
        },
        {
            "district_code": 319,
            "block_code": 3022,
            "id": 110725,
            "text": "KATLAMARI-I"
        },
        {
            "district_code": 305,
            "block_code": 2781,
            "id": 108351,
            "text": "DIGHALGRAM"
        },
        {
            "district_code": 317,
            "block_code": 2962,
            "id": 110137,
            "text": "KENDUMARIJALPAI"
        },
        {
            "district_code": 704,
            "block_code": 2806,
            "id": 108575,
            "text": "KENDA"
        },
        {
            "district_code": 303,
            "block_code": 2736,
            "id": 107908,
            "text": "GUMA-II"
        },
        {
            "district_code": 307,
            "block_code": 2844,
            "id": 108913,
            "text": "KHATANGA"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260984,
            "text": "GHUM KHASMAHAL"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109643,
            "text": "JALABISWANATHPUR"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109498,
            "text": "SARAI-TINNA"
        },
        {
            "district_code": 306,
            "block_code": 2796,
            "id": 108480,
            "text": "BERENDA"
        },
        {
            "district_code": 320,
            "block_code": 3033,
            "id": 110849,
            "text": "NATIDANGA-II"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109463,
            "text": "GHOSHPUR"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108510,
            "text": "MAHACHANDA"
        },
        {
            "district_code": 321,
            "block_code": 3058,
            "id": 111081,
            "text": "LAKHRA"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108121,
            "text": "KACHUKHALI"
        },
        {
            "district_code": 313,
            "block_code": 2909,
            "id": 109602,
            "text": "JAGADISHPUR"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110921,
            "text": "RAGHUNATHPUR HIJULI-I"
        },
        {
            "district_code": 303,
            "block_code": 2735,
            "id": 107899,
            "text": "MACHHLANDAPUR-I"
        },
        {
            "district_code": 321,
            "block_code": 3048,
            "id": 110991,
            "text": "KUMRA"
        },
        {
            "district_code": 321,
            "block_code": 3056,
            "id": 111059,
            "text": "BHAMURIA"
        },
        {
            "district_code": 306,
            "block_code": 2814,
            "id": 108644,
            "text": "UKHRID"
        },
        {
            "district_code": 316,
            "block_code": 2945,
            "id": 109989,
            "text": "DEBIPUR"
        },
        {
            "district_code": 316,
            "block_code": 2933,
            "id": 109865,
            "text": "KALIGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110288,
            "text": "KAMALPUR"
        },
        {
            "district_code": 312,
            "block_code": 2901,
            "id": 109515,
            "text": "DIHIBADPUR"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108966,
            "text": "PUTIMARI-II"
        },
        {
            "district_code": 306,
            "block_code": 2801,
            "id": 108529,
            "text": "GOBINDAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108036,
            "text": "PASCHIM BISHNUPUR"
        },
        {
            "district_code": 317,
            "block_code": 2969,
            "id": 110201,
            "text": "KHARUI-II"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109500,
            "text": "SIMLAGARHVITASIN"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109436,
            "text": "HARIPALASHUTOSH"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107865,
            "text": "GOPALNAGAR-II"
        },
        {
            "district_code": 321,
            "block_code": 3048,
            "id": 110992,
            "text": "SUPUDIH"
        },
        {
            "district_code": 312,
            "block_code": 2903,
            "id": 109540,
            "text": "RAGHUNATHPUR"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261005,
            "text": "KALIMPONG"
        },
        {
            "district_code": 303,
            "block_code": 2723,
            "id": 107778,
            "text": "AMDANGA"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110858,
            "text": "ASSANNAGAR"
        },
        {
            "district_code": 704,
            "block_code": 2820,
            "id": 108705,
            "text": "NABAGRAM"
        },
        {
            "district_code": 306,
            "block_code": 2808,
            "id": 108593,
            "text": "KANKURIA"
        },
        {
            "district_code": 313,
            "block_code": 2907,
            "id": 109588,
            "text": "KHALORE"
        },
        {
            "district_code": 303,
            "block_code": 2738,
            "id": 107924,
            "text": "HASNABAD"
        },
        {
            "district_code": 313,
            "block_code": 2907,
            "id": 109582,
            "text": "BAINAN"
        },
        {
            "district_code": 321,
            "block_code": 3059,
            "id": 111088,
            "text": "DIMDIHA"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110119,
            "text": "TILKHOJA"
        },
        {
            "district_code": 304,
            "block_code": 2756,
            "id": 108101,
            "text": "SARISA"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109846,
            "text": "DABGRAM-II"
        },
        {
            "district_code": 316,
            "block_code": 2932,
            "id": 109861,
            "text": "PAKUAHAT"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110860,
            "text": "BHANDARKHOLA"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108307,
            "text": "GODARDIHI"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107796,
            "text": "RAMCHANDRAPUR UDAY"
        },
        {
            "district_code": 304,
            "block_code": 2755,
            "id": 108091,
            "text": "MASHAT"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109687,
            "text": "KANUPAT MANSUKA"
        },
        {
            "district_code": 305,
            "block_code": 2784,
            "id": 108378,
            "text": "LOWGRAM"
        },
        {
            "district_code": 321,
            "block_code": 3054,
            "id": 111042,
            "text": "BAMNIMAJHIHIRA"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110769,
            "text": "CHANDURIA-II"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110899,
            "text": "PATIKABARI"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261015,
            "text": "TISTA"
        },
        {
            "district_code": 318,
            "block_code": 2989,
            "id": 110392,
            "text": "KESHIARI"
        },
        {
            "district_code": 321,
            "block_code": 3044,
            "id": 110952,
            "text": "ARSHA"
        },
        {
            "district_code": 308,
            "block_code": 2851,
            "id": 108986,
            "text": "BARASOULMARI"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109029,
            "text": "BALARAMPUR-I"
        },
        {
            "district_code": 304,
            "block_code": 2763,
            "id": 108183,
            "text": "MERIGANJ-I"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260951,
            "text": "CHUNGTONG"
        },
        {
            "district_code": 314,
            "block_code": 2930,
            "id": 109839,
            "text": "ANGRABHASA-I"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108261,
            "text": "SRIDHARNAGAR"
        },
        {
            "district_code": 314,
            "block_code": 2921,
            "id": 109739,
            "text": "GODONG-II"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108251,
            "text": "DAKSHIN GANGADHARPUR"
        },
        {
            "district_code": 321,
            "block_code": 3062,
            "id": 111110,
            "text": "BARRAH"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110399,
            "text": "AMRAKUCHI"
        },
        {
            "district_code": 318,
            "block_code": 2992,
            "id": 110428,
            "text": "SANKOA"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107860,
            "text": "DIGHARI"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110936,
            "text": "CHANDERGHAT"
        },
        {
            "district_code": 309,
            "block_code": 2863,
            "id": 109132,
            "text": "KHARIBARI-PANISHALI"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110596,
            "text": "SUNDARPUR"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108257,
            "text": "HERAMBAGOPALPUR"
        },
        {
            "district_code": 311,
            "block_code": 2884,
            "id": 109316,
            "text": "MALGAON"
        },
        {
            "district_code": 305,
            "block_code": 2790,
            "id": 108437,
            "text": "TILURI"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108924,
            "text": "BANESWAR"
        },
        {
            "district_code": 318,
            "block_code": 2976,
            "id": 110264,
            "text": "TARURUI"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110283,
            "text": "CHAIPAT"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108395,
            "text": "NIKUNJAPUR"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109296,
            "text": "PANDITPOTA-II"
        },
        {
            "district_code": 664,
            "block_code": 2926,
            "id": 109801,
            "text": "LANKAPARA"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110311,
            "text": "AMKOPA"
        },
        {
            "district_code": 317,
            "block_code": 2969,
            "id": 110202,
            "text": "RAGHUNATHPUR-I"
        },
        {
            "district_code": 310,
            "block_code": 2875,
            "id": 109228,
            "text": "SAMJIA"
        },
        {
            "district_code": 316,
            "block_code": 2933,
            "id": 109862,
            "text": "ALIHANDA"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110943,
            "text": "SHYAMNAGAR"
        },
        {
            "district_code": 303,
            "block_code": 2744,
            "id": 107972,
            "text": "KAIJURI"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108649,
            "text": "JHILU-II"
        },
        {
            "district_code": 304,
            "block_code": 2754,
            "id": 108083,
            "text": "SARENGABAD"
        },
        {
            "district_code": 319,
            "block_code": 3010,
            "id": 110618,
            "text": "NAYANSUKH"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 110102,
            "text": "RAMANI MOHAN MAITY"
        },
        {
            "district_code": 303,
            "block_code": 2725,
            "id": 107801,
            "text": "BAYRA"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110864,
            "text": "DEYPARA"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109837,
            "text": "SAPTIBARI-I"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261042,
            "text": "ST. MARRYS-I"
        },
        {
            "district_code": 306,
            "block_code": 2814,
            "id": 108637,
            "text": "KAIARH"
        },
        {
            "district_code": 319,
            "block_code": 3004,
            "id": 110558,
            "text": "KHARIBONA"
        },
        {
            "district_code": 318,
            "block_code": 2993,
            "id": 110434,
            "text": "PANCHKHURI-II"
        },
        {
            "district_code": 320,
            "block_code": 7115,
            "id": 110777,
            "text": "SAGUNA"
        },
        {
            "district_code": 303,
            "block_code": 2744,
            "id": 107971,
            "text": "GOBINDAPUR"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109889,
            "text": "BABUPUR"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108237,
            "text": "NAGENDRAPUR"
        },
        {
            "district_code": 313,
            "block_code": 2915,
            "id": 109681,
            "text": "SHASHATI"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108061,
            "text": "KASIPUR ALAMPUR"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261004,
            "text": "KAFER KANKE BONG"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107893,
            "text": "RAMNAGAR"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110823,
            "text": "JURANPUR"
        },
        {
            "district_code": 307,
            "block_code": 2837,
            "id": 108849,
            "text": "BANIOR"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110097,
            "text": "SIDDHA-I"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260955,
            "text": "GOKE-I"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108280,
            "text": "POLEGHAT"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108925,
            "text": "BARARANGRAS"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108035,
            "text": "PANAKUA"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108748,
            "text": "DENDUA"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110485,
            "text": "CHAULKURI"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110521,
            "text": "MADDA"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108866,
            "text": "CHARKALGRAM"
        },
        {
            "district_code": 319,
            "block_code": 3020,
            "id": 110713,
            "text": "SAMMATINAGAR"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261058,
            "text": "RESSEP"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108124,
            "text": "PATHANKHALI"
        },
        {
            "district_code": 318,
            "block_code": 2997,
            "id": 110471,
            "text": "DHANESWARPUR"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109238,
            "text": "AUTINA"
        },
        {
            "district_code": 312,
            "block_code": 2901,
            "id": 109513,
            "text": "BHANGAMORA"
        },
        {
            "district_code": 317,
            "block_code": 2947,
            "id": 110002,
            "text": "BENUDIA"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109625,
            "text": "GOBINDAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2763,
            "id": 108177,
            "text": "GOPALGANJ"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108135,
            "text": "JANGALIA"
        },
        {
            "district_code": 308,
            "block_code": 2851,
            "id": 108993,
            "text": "RUIDANGA"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109757,
            "text": "MAIRADANGA"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110149,
            "text": "CHAITANYAPUR-I"
        },
        {
            "district_code": 313,
            "block_code": 2907,
            "id": 109587,
            "text": "KALYANPUR"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109569,
            "text": "GAZIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3025,
            "id": 110752,
            "text": "AHIRAN"
        },
        {
            "district_code": 304,
            "block_code": 2756,
            "id": 108099,
            "text": "NURPUR"
        },
        {
            "district_code": 307,
            "block_code": 2828,
            "id": 108769,
            "text": "JASHPUR"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108509,
            "text": "ERUAR"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 8888100,
            "text": "Lingsey"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110735,
            "text": "BOKHARA-I"
        },
        {
            "district_code": 304,
            "block_code": 2755,
            "id": 108090,
            "text": "KANPUR DHANABERIA"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110309,
            "text": "SNARPUR-LOYADA"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108186,
            "text": "HARIHARPUR"
        },
        {
            "district_code": 321,
            "block_code": 3051,
            "id": 111016,
            "text": "MATHARI-KHAMAR"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109969,
            "text": "DHARAMPUR"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109970,
            "text": "ENAYETPUR"
        },
        {
            "district_code": 313,
            "block_code": 2917,
            "id": 109693,
            "text": "BAHIRA"
        },
        {
            "district_code": 307,
            "block_code": 2827,
            "id": 108762,
            "text": "SATTORE"
        },
        {
            "district_code": 320,
            "block_code": 3032,
            "id": 110840,
            "text": "SHIKARPUR"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109506,
            "text": "HARIT"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108106,
            "text": "CHALUARI"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107988,
            "text": "NABAGRAM"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108168,
            "text": "KAMARCHAK"
        },
        {
            "district_code": 307,
            "block_code": 2836,
            "id": 108842,
            "text": "KUSHMORE-I"
        },
        {
            "district_code": 319,
            "block_code": 3022,
            "id": 110730,
            "text": "RANINAGAR-I"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107880,
            "text": "KOLSUR"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108040,
            "text": "CHAK ENAYETNAGAR"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109568,
            "text": "BINLA KRISHNABATI"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109335,
            "text": "BINDOLE"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107884,
            "text": "DHARMAPUR-I"
        },
        {
            "district_code": 307,
            "block_code": 2835,
            "id": 108835,
            "text": "GORSHA"
        },
        {
            "district_code": 321,
            "block_code": 3060,
            "id": 111100,
            "text": "HUTMURA"
        },
        {
            "district_code": 321,
            "block_code": 3050,
            "id": 111005,
            "text": "JOYPUR"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109301,
            "text": "DURLOVPUR"
        },
        {
            "district_code": 317,
            "block_code": 2947,
            "id": 110011,
            "text": "SIMULIA"
        },
        {
            "district_code": 308,
            "block_code": 2852,
            "id": 109001,
            "text": "KURSAMARI"
        },
        {
            "district_code": 319,
            "block_code": 3005,
            "id": 110564,
            "text": "KANTANAGAR"
        },
        {
            "district_code": 320,
            "block_code": 3039,
            "id": 110905,
            "text": "NAWPARA MASUNDA"
        },
        {
            "district_code": 306,
            "block_code": 2796,
            "id": 108479,
            "text": "AUSGRAM"
        },
        {
            "district_code": 312,
            "block_code": 2891,
            "id": 109393,
            "text": "CHANDRAHATI-I"
        },
        {
            "district_code": 308,
            "block_code": 2851,
            "id": 108991,
            "text": "NISHIGANJ-II"
        },
        {
            "district_code": 307,
            "block_code": 2836,
            "id": 108840,
            "text": "AMDOLE"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109527,
            "text": "BERABERI"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108117,
            "text": "BALI-II"
        },
        {
            "district_code": 318,
            "block_code": 2974,
            "id": 110249,
            "text": "MONOHARPUR-II"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108249,
            "text": "BANASHYAMNAGAR"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108195,
            "text": "YEARPUR"
        },
        {
            "district_code": 308,
            "block_code": 2850,
            "id": 108983,
            "text": "PER-MEKHLIGANJ"
        },
        {
            "district_code": 316,
            "block_code": 2934,
            "id": 109873,
            "text": "GOURHANDA"
        },
        {
            "district_code": 317,
            "block_code": 2953,
            "id": 110060,
            "text": "PANCHROL"
        },
        {
            "district_code": 303,
            "block_code": 2730,
            "id": 107843,
            "text": "SANGRAMPUR SHIBHATI"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108401,
            "text": "SANTORE"
        },
        {
            "district_code": 317,
            "block_code": 2970,
            "id": 110209,
            "text": "HORKHALI"
        },
        {
            "district_code": 319,
            "block_code": 3019,
            "id": 110702,
            "text": "JAMUAR"
        },
        {
            "district_code": 305,
            "block_code": 2782,
            "id": 108359,
            "text": "HETIA"
        },
        {
            "district_code": 321,
            "block_code": 3060,
            "id": 111097,
            "text": "CHHARRADUMDUMI"
        },
        {
            "district_code": 305,
            "block_code": 2791,
            "id": 108441,
            "text": "GOALBARI"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110450,
            "text": "KUNARPUR"
        },
        {
            "district_code": 704,
            "block_code": 2798,
            "id": 108500,
            "text": "PUNCHRAH"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111029,
            "text": "AGARDI-CHITRA"
        },
        {
            "district_code": 320,
            "block_code": 3030,
            "id": 110809,
            "text": "BIROHI-I"
        },
        {
            "district_code": 305,
            "block_code": 2794,
            "id": 108466,
            "text": "PANCHMURA"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110771,
            "text": "DUBRA"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109958,
            "text": "BHAGABANPUR"
        },
        {
            "district_code": 307,
            "block_code": 2830,
            "id": 108786,
            "text": "HAZRATPUR"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110672,
            "text": "RAMCHANDRAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2957,
            "id": 110085,
            "text": "NIJKASBA"
        },
        {
            "district_code": 319,
            "block_code": 3017,
            "id": 110689,
            "text": "RASULPUR"
        },
        {
            "district_code": 303,
            "block_code": 2739,
            "id": 107936,
            "text": "SANDELERBIL"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109761,
            "text": "BAHADUR"
        },
        {
            "district_code": 308,
            "block_code": 2852,
            "id": 108999,
            "text": "JORPATKI"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108392,
            "text": "MAJDIHA"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110788,
            "text": "CHAPRA-II"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109305,
            "text": "JOYHAT"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109439,
            "text": "CHANDANPUR"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108042,
            "text": "GOBINDAPUR KALICHARANPUR"
        },
        {
            "district_code": 319,
            "block_code": 3021,
            "id": 110718,
            "text": "HURSHI"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109633,
            "text": "POLEGUSTIA"
        },
        {
            "district_code": 319,
            "block_code": 3009,
            "id": 110607,
            "text": "MADHURKUL"
        },
        {
            "district_code": 304,
            "block_code": 2755,
            "id": 108087,
            "text": "BOLSIDDHI KALINAGAR"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110092,
            "text": "KHANGDIHI"
        },
        {
            "district_code": 317,
            "block_code": 2956,
            "id": 110076,
            "text": "HARIA"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109402,
            "text": "BELMURI"
        },
        {
            "district_code": 316,
            "block_code": 2941,
            "id": 109948,
            "text": "RAJNAGAR"
        },
        {
            "district_code": 305,
            "block_code": 2792,
            "id": 108444,
            "text": "BIKRAMPUR"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110591,
            "text": "KURUNNORUN"
        },
        {
            "district_code": 703,
            "block_code": 2973,
            "id": 110240,
            "text": "KANKO"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111041,
            "text": "SONATHALI"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108200,
            "text": "DIHIKALAS"
        },
        {
            "district_code": 308,
            "block_code": 2850,
            "id": 108979,
            "text": "BOXIGANJ"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110733,
            "text": "BANNYESWAR"
        },
        {
            "district_code": 307,
            "block_code": 2837,
            "id": 108855,
            "text": "KALITHA"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110797,
            "text": "BAGULA-I"
        },
        {
            "district_code": 321,
            "block_code": 3049,
            "id": 111001,
            "text": "MAGURIA-LALPUR"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108942,
            "text": "GURIAHATI-I"
        },
        {
            "district_code": 316,
            "block_code": 2934,
            "id": 109872,
            "text": "DHANGARA-BISHANPUR"
        },
        {
            "district_code": 317,
            "block_code": 2966,
            "id": 110175,
            "text": "PANCHET"
        },
        {
            "district_code": 303,
            "block_code": 2726,
            "id": 107812,
            "text": "KADAMBAGACHHI"
        },
        {
            "district_code": 321,
            "block_code": 3063,
            "id": 111120,
            "text": "SANTURI"
        },
        {
            "district_code": 312,
            "block_code": 2893,
            "id": 109420,
            "text": "BALI"
        },
        {
            "district_code": 321,
            "block_code": 3057,
            "id": 111073,
            "text": "NADIHASURULIA"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108400,
            "text": "RATANPUR"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108939,
            "text": "DEOANHAT"
        },
        {
            "district_code": 303,
            "block_code": 2737,
            "id": 107916,
            "text": "KHASBALANDA"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110310,
            "text": "AGRA"
        },
        {
            "district_code": 310,
            "block_code": 2875,
            "id": 109227,
            "text": "SAFANAGAR"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108111,
            "text": "HARINDANGA-I"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108062,
            "text": "NASKARPUR"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109237,
            "text": "AJMATPUR"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110463,
            "text": "BERAJAL"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110529,
            "text": "DADPUR"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109573,
            "text": "JHIKIRA"
        },
        {
            "district_code": 321,
            "block_code": 3056,
            "id": 111063,
            "text": "RAIBANDH"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110130,
            "text": "SEORABERIAJALPAI-II"
        },
        {
            "district_code": 307,
            "block_code": 2832,
            "id": 108811,
            "text": "MOLLARPUR-I"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108566,
            "text": "JYOTSREERAM"
        },
        {
            "district_code": 305,
            "block_code": 2775,
            "id": 108300,
            "text": "PURANDARPUR"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108123,
            "text": "LAHIRIPUR"
        },
        {
            "district_code": 316,
            "block_code": 2944,
            "id": 109983,
            "text": "SAHAPUR"
        },
        {
            "district_code": 314,
            "block_code": 2927,
            "id": 109816,
            "text": "RANGAMATI"
        },
        {
            "district_code": 303,
            "block_code": 2729,
            "id": 107832,
            "text": "BANDIPUR"
        },
        {
            "district_code": 304,
            "block_code": 2753,
            "id": 108073,
            "text": "MATLA-I"
        },
        {
            "district_code": 303,
            "block_code": 2737,
            "id": 107918,
            "text": "SONAPUKUR SANKARPUR"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110915,
            "text": "DEBAGRAM"
        },
        {
            "district_code": 319,
            "block_code": 3017,
            "id": 110686,
            "text": "NABAGRAM"
        },
        {
            "district_code": 317,
            "block_code": 2969,
            "id": 110205,
            "text": "SHANTIPUR-II"
        },
        {
            "district_code": 316,
            "block_code": 2939,
            "id": 109924,
            "text": "MALIOR-I"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109607,
            "text": "BANKRA-III"
        },
        {
            "district_code": 317,
            "block_code": 2950,
            "id": 110037,
            "text": "RAIPUR-PASCHIMBARH"
        },
        {
            "district_code": 317,
            "block_code": 2949,
            "id": 110027,
            "text": "JALPAI"
        },
        {
            "district_code": 317,
            "block_code": 2967,
            "id": 110181,
            "text": "GOBRA"
        },
        {
            "district_code": 318,
            "block_code": 2978,
            "id": 110275,
            "text": "NANDANPUR-I"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108159,
            "text": "SRINAGAR"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110406,
            "text": "JORAKEUDI-SOLIDIHA"
        },
        {
            "district_code": 321,
            "block_code": 3049,
            "id": 111002,
            "text": "RAKHERA-BISPURIA"
        },
        {
            "district_code": 305,
            "block_code": 2778,
            "id": 108334,
            "text": "NITYANANDAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110128,
            "text": "KUMARCHAK"
        },
        {
            "district_code": 304,
            "block_code": 2771,
            "id": 108267,
            "text": "GHORAMARA"
        },
        {
            "district_code": 319,
            "block_code": 3006,
            "id": 110575,
            "text": "SIJGRAM"
        },
        {
            "district_code": 303,
            "block_code": 2737,
            "id": 107915,
            "text": "HAROA"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108258,
            "text": "LAKSMIJANARDANPUR"
        },
        {
            "district_code": 306,
            "block_code": 2811,
            "id": 108619,
            "text": "SREEBATI"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260976,
            "text": "KUMAI"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110832,
            "text": "RAJARMPUR GHORAIKHETRA"
        },
        {
            "district_code": 319,
            "block_code": 3011,
            "id": 110628,
            "text": "SWARUPPUR"
        },
        {
            "district_code": 321,
            "block_code": 3062,
            "id": 111112,
            "text": "JORADIH"
        },
        {
            "district_code": 304,
            "block_code": 2748,
            "id": 108022,
            "text": "BHOGALI-I"
        },
        {
            "district_code": 312,
            "block_code": 2894,
            "id": 109431,
            "text": "KAMARPUKUR"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110484,
            "text": "BURAL"
        },
        {
            "district_code": 309,
            "block_code": 2866,
            "id": 261047,
            "text": "CHENGA PANIGHATA"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108250,
            "text": "BRAJABALLAVPUR"
        },
        {
            "district_code": 704,
            "block_code": 2820,
            "id": 108701,
            "text": "BEHULA"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109533,
            "text": "MIRZAPURBANKIPUR"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110094,
            "text": "KOLA-II"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109320,
            "text": "ALTAPUR-II"
        },
        {
            "district_code": 320,
            "block_code": 3032,
            "id": 110838,
            "text": "MADHUGARI"
        },
        {
            "district_code": 316,
            "block_code": 2938,
            "id": 109914,
            "text": "BARUI"
        },
        {
            "district_code": 317,
            "block_code": 2954,
            "id": 110063,
            "text": "BASUDEVPUR"
        },
        {
            "district_code": 317,
            "block_code": 2963,
            "id": 110144,
            "text": "BIRULIA"
        },
        {
            "district_code": 319,
            "block_code": 3005,
            "id": 110567,
            "text": "MAHISASTHALI"
        },
        {
            "district_code": 321,
            "block_code": 3045,
            "id": 110966,
            "text": "SINDRI"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260989,
            "text": "MUNDA KOTHI"
        },
        {
            "district_code": 702,
            "block_code": 7355,
            "id": 261027,
            "text": "PEDON"
        },
        {
            "district_code": 321,
            "block_code": 3062,
            "id": 111114,
            "text": "NILDIH"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110098,
            "text": "SIDHHA-II"
        },
        {
            "district_code": 312,
            "block_code": 2901,
            "id": 109518,
            "text": "PURSURAH-II"
        },
        {
            "district_code": 318,
            "block_code": 2976,
            "id": 110257,
            "text": "ALIKOSHA"
        },
        {
            "district_code": 305,
            "block_code": 2788,
            "id": 108421,
            "text": "SONAGARA"
        },
        {
            "district_code": 305,
            "block_code": 2784,
            "id": 108379,
            "text": "MADANMOHANPUR"
        },
        {
            "district_code": 319,
            "block_code": 3012,
            "id": 110637,
            "text": "SAGARPARA"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109781,
            "text": "MALANGI"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109325,
            "text": "KARANDIGHI-I"
        },
        {
            "district_code": 305,
            "block_code": 2778,
            "id": 108335,
            "text": "PIRRABONI"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109943,
            "text": "SUJAPUR"
        },
        {
            "district_code": 312,
            "block_code": 2889,
            "id": 109376,
            "text": "GANGADHARPUR"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109464,
            "text": "KHANAKUL-I"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109576,
            "text": "KUSBERIA"
        },
        {
            "district_code": 319,
            "block_code": 3024,
            "id": 110745,
            "text": "CHACHANDA"
        },
        {
            "district_code": 303,
            "block_code": 2731,
            "id": 107847,
            "text": "CHITA"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108874,
            "text": "UCHKARAN"
        },
        {
            "district_code": 702,
            "block_code": 7355,
            "id": 261021,
            "text": "KAGE"
        },
        {
            "district_code": 305,
            "block_code": 2774,
            "id": 108289,
            "text": "ANCHURI"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109884,
            "text": "MAHADIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3013,
            "id": 110640,
            "text": "GOKARNA-I"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110866,
            "text": "DOGACHI"
        },
        {
            "district_code": 303,
            "block_code": 2725,
            "id": 107805,
            "text": "MALIPOTA"
        },
        {
            "district_code": 703,
            "block_code": 2985,
            "id": 110356,
            "text": "NOTA"
        },
        {
            "district_code": 311,
            "block_code": 2881,
            "id": 109283,
            "text": "CHAINAGAR"
        },
        {
            "district_code": 319,
            "block_code": 3025,
            "id": 110756,
            "text": "NURPUR"
        },
        {
            "district_code": 307,
            "block_code": 2830,
            "id": 108791,
            "text": "PANCHRA"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108155,
            "text": "RABINDRA"
        },
        {
            "district_code": 313,
            "block_code": 2918,
            "id": 109704,
            "text": "JOYARGORI"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109776,
            "text": "GAROPARA"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108038,
            "text": "RASKHALI"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 108007,
            "text": "RAMCHANDRAKHALI"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107995,
            "text": "SOUTH GARIA"
        },
        {
            "district_code": 303,
            "block_code": 2740,
            "id": 107939,
            "text": "CHAITAL"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110587,
            "text": "KALYANPUR-I"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107875,
            "text": "CHAURASI"
        },
        {
            "district_code": 703,
            "block_code": 2987,
            "id": 110369,
            "text": "DUBRA"
        },
        {
            "district_code": 307,
            "block_code": 2829,
            "id": 108776,
            "text": "BELATI"
        },
        {
            "district_code": 303,
            "block_code": 2723,
            "id": 107783,
            "text": "SADHANPUR"
        },
        {
            "district_code": 664,
            "block_code": 2926,
            "id": 109804,
            "text": "SHISHUJHUMRA"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108048,
            "text": "PATHARBERIA JAYCHANDIPUR"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110386,
            "text": "SAPDHARA"
        },
        {
            "district_code": 307,
            "block_code": 2837,
            "id": 108856,
            "text": "KURUMGRAM"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109035,
            "text": "DHALPAL-II"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108646,
            "text": "CHANAK"
        },
        {
            "district_code": 319,
            "block_code": 3002,
            "id": 110528,
            "text": "ANDULBARIA-II"
        },
        {
            "district_code": 321,
            "block_code": 3054,
            "id": 111049,
            "text": "JITUJURI"
        },
        {
            "district_code": 303,
            "block_code": 2737,
            "id": 107912,
            "text": "GOPALPUR-I"
        },
        {
            "district_code": 319,
            "block_code": 3016,
            "id": 110679,
            "text": "PRASADPUR"
        },
        {
            "district_code": 307,
            "block_code": 2841,
            "id": 108882,
            "text": "BONHAT"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260970,
            "text": "SINGTAMN SOOM"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108873,
            "text": "THUPSARA"
        },
        {
            "district_code": 703,
            "block_code": 2972,
            "id": 110225,
            "text": "BAITA"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109833,
            "text": "MAYNAGURI"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110653,
            "text": "JHILLI"
        },
        {
            "district_code": 305,
            "block_code": 2784,
            "id": 108381,
            "text": "SIHAR"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109957,
            "text": "BEERNAGAR-II"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108569,
            "text": "PARATAL-II"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109485,
            "text": "BANTIKABAINCHI"
        },
        {
            "district_code": 309,
            "block_code": 2868,
            "id": 109170,
            "text": "HETMURI SINGHIJHORA"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108056,
            "text": "BURUL"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110384,
            "text": "PATASHIMUL"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110467,
            "text": "KHARIKAMATHANI"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108657,
            "text": "PALIGRAM"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110826,
            "text": "MIRA-I"
        },
        {
            "district_code": 306,
            "block_code": 2822,
            "id": 108720,
            "text": "PATULI"
        },
        {
            "district_code": 314,
            "block_code": 2927,
            "id": 109806,
            "text": "BAGRAKOT"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109257,
            "text": "BIDYANANDAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107982,
            "text": "DHAPDHAPI-II"
        },
        {
            "district_code": 305,
            "block_code": 2784,
            "id": 108380,
            "text": "MIRZAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2955,
            "id": 110073,
            "text": "DEBHOG"
        },
        {
            "district_code": 306,
            "block_code": 2824,
            "id": 108734,
            "text": "KAITI"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108059,
            "text": "GAJA POYALI"
        },
        {
            "district_code": 318,
            "block_code": 2976,
            "id": 110256,
            "text": "AINKOLA"
        },
        {
            "district_code": 319,
            "block_code": 3011,
            "id": 110627,
            "text": "RUKUNPUR"
        },
        {
            "district_code": 304,
            "block_code": 2773,
            "id": 108288,
            "text": "RASAPUNJA"
        },
        {
            "district_code": 318,
            "block_code": 2974,
            "id": 110246,
            "text": "MANGRUL"
        },
        {
            "district_code": 306,
            "block_code": 2821,
            "id": 108710,
            "text": "NASRATPUR"
        },
        {
            "district_code": 306,
            "block_code": 2818,
            "id": 108686,
            "text": "BIJUR-II"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109353,
            "text": "MADHABPUR"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111039,
            "text": "SIMLA-DHANARA"
        },
        {
            "district_code": 310,
            "block_code": 2875,
            "id": 109223,
            "text": "DEOR"
        },
        {
            "district_code": 318,
            "block_code": 2977,
            "id": 110271,
            "text": "TURKA"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107979,
            "text": "BRINDAKHALI"
        },
        {
            "district_code": 319,
            "block_code": 3004,
            "id": 110555,
            "text": "AKHERIGANJ"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260953,
            "text": "DARJEELING-I"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110589,
            "text": "KHARJUNA"
        },
        {
            "district_code": 319,
            "block_code": 3013,
            "id": 110642,
            "text": "HIZOLE"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109298,
            "text": "RAMGANJ-II"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109288,
            "text": "GAISAL-II"
        },
        {
            "district_code": 306,
            "block_code": 2810,
            "id": 108607,
            "text": "KARAJGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2975,
            "id": 110254,
            "text": "BHAGABANTAPUR-II"
        },
        {
            "district_code": 312,
            "block_code": 2896,
            "id": 109459,
            "text": "RAJBALHAT-II"
        },
        {
            "district_code": 306,
            "block_code": 2824,
            "id": 108733,
            "text": "GOTAN"
        },
        {
            "district_code": 305,
            "block_code": 2794,
            "id": 108462,
            "text": "BIBARDA"
        },
        {
            "district_code": 703,
            "block_code": 3000,
            "id": 110505,
            "text": "CHHATRI"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108114,
            "text": "NOYAPUKURIA"
        },
        {
            "district_code": 303,
            "block_code": 2735,
            "id": 107900,
            "text": "MACHHLANDAPUR-II"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108189,
            "text": "RANGILBAD"
        },
        {
            "district_code": 305,
            "block_code": 2788,
            "id": 108418,
            "text": "MOTGODA"
        },
        {
            "district_code": 305,
            "block_code": 2780,
            "id": 108341,
            "text": "BHEDUASOLE"
        },
        {
            "district_code": 303,
            "block_code": 2727,
            "id": 107819,
            "text": "FALTI BELIAGHATA"
        },
        {
            "district_code": 306,
            "block_code": 2810,
            "id": 108604,
            "text": "ALAMPUR"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109956,
            "text": "BEERNAGAR-I"
        },
        {
            "district_code": 305,
            "block_code": 2792,
            "id": 108447,
            "text": "MACHATORA"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109627,
            "text": "ISLAMPUR"
        },
        {
            "district_code": 303,
            "block_code": 2725,
            "id": 107803,
            "text": "KONIARA-I"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109823,
            "text": "AMGURI"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108978,
            "text": "SUKARUKUTHI"
        },
        {
            "district_code": 304,
            "block_code": 2767,
            "id": 108226,
            "text": "MATHURAPUR PURBA"
        },
        {
            "district_code": 306,
            "block_code": 2808,
            "id": 108595,
            "text": "NANDAI"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108832,
            "text": "SEKEDDA"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109341,
            "text": "MAHIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110592,
            "text": "PANCHTHUPI"
        },
        {
            "district_code": 317,
            "block_code": 2951,
            "id": 110046,
            "text": "MARISHDA"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109295,
            "text": "PANDITPOTA-I"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109848,
            "text": "FULBARI-II"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110405,
            "text": "JHENTLA"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110116,
            "text": "PARAMANANDAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2756,
            "id": 108100,
            "text": "PATRA"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109790,
            "text": "KUMARGRAM"
        },
        {
            "district_code": 307,
            "block_code": 2838,
            "id": 108862,
            "text": "NOAPARA"
        },
        {
            "district_code": 304,
            "block_code": 2760,
            "id": 108146,
            "text": "MANIRTAT"
        },
        {
            "district_code": 312,
            "block_code": 2904,
            "id": 109551,
            "text": "SANTOSHPUR"
        },
        {
            "district_code": 319,
            "block_code": 3009,
            "id": 110601,
            "text": "GARAIMARI"
        },
        {
            "district_code": 304,
            "block_code": 2767,
            "id": 108221,
            "text": "DAKSHIN LAKSHMINARAYANPUR"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110086,
            "text": "AMALHANDA"
        },
        {
            "district_code": 703,
            "block_code": 2972,
            "id": 110226,
            "text": "BELATIKRI"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110291,
            "text": "KHUKURDAHA"
        },
        {
            "district_code": 305,
            "block_code": 2787,
            "id": 108405,
            "text": "BIRSINGHA"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109647,
            "text": "SUVARARA"
        },
        {
            "district_code": 303,
            "block_code": 2729,
            "id": 107833,
            "text": "BILKANDA-I"
        },
        {
            "district_code": 319,
            "block_code": 3013,
            "id": 110648,
            "text": "PURANDARPUR"
        },
        {
            "district_code": 308,
            "block_code": 2853,
            "id": 109011,
            "text": "RANIRHAT"
        },
        {
            "district_code": 306,
            "block_code": 2803,
            "id": 108541,
            "text": "LOAPURKRISHNARAMPUR"
        },
        {
            "district_code": 303,
            "block_code": 2740,
            "id": 107940,
            "text": "CHAMPALI"
        },
        {
            "district_code": 321,
            "block_code": 3062,
            "id": 111113,
            "text": "MANGALDA-MAUTORE"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108316,
            "text": "CHINABARI"
        },
        {
            "district_code": 320,
            "block_code": 3037,
            "id": 110878,
            "text": "CHARMAJDIA CHARBRAHMANAGAR"
        },
        {
            "district_code": 306,
            "block_code": 2822,
            "id": 108719,
            "text": "NIMDAHA"
        },
        {
            "district_code": 321,
            "block_code": 3045,
            "id": 110967,
            "text": "TUNTURI-SUISA"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110934,
            "text": "BATAI-I"
        },
        {
            "district_code": 303,
            "block_code": 2728,
            "id": 107831,
            "text": "SHIBDASPUR"
        },
        {
            "district_code": 306,
            "block_code": 2800,
            "id": 108515,
            "text": "BAGHAR-I"
        },
        {
            "district_code": 319,
            "block_code": 3004,
            "id": 110556,
            "text": "AMDAHARA"
        },
        {
            "district_code": 308,
            "block_code": 2855,
            "id": 109025,
            "text": "SITALKUCHI"
        },
        {
            "district_code": 303,
            "block_code": 2723,
            "id": 107781,
            "text": "CHANDIGARH"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110462,
            "text": "BARANEGUI"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109241,
            "text": "GURAIL"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 107996,
            "text": "AMJHARA"
        },
        {
            "district_code": 303,
            "block_code": 2744,
            "id": 107973,
            "text": "SAGUNA"
        },
        {
            "district_code": 318,
            "block_code": 2997,
            "id": 110479,
            "text": "MALIGRAM"
        },
        {
            "district_code": 319,
            "block_code": 3013,
            "id": 110641,
            "text": "GOKARNA-II"
        },
        {
            "district_code": 304,
            "block_code": 2748,
            "id": 108023,
            "text": "BHOGALI-II"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109725,
            "text": "MAHAKALGURI"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110131,
            "text": "SHITALPURPASCHIM"
        },
        {
            "district_code": 319,
            "block_code": 3017,
            "id": 110687,
            "text": "NARAYANPUR"
        },
        {
            "district_code": 316,
            "block_code": 2941,
            "id": 109944,
            "text": "BANGITOLA"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108169,
            "text": "KARANJALI"
        },
        {
            "district_code": 312,
            "block_code": 2894,
            "id": 109432,
            "text": "KUMARGANJ"
        },
        {
            "district_code": 306,
            "block_code": 2817,
            "id": 108682,
            "text": "NIMO-II"
        },
        {
            "district_code": 303,
            "block_code": 2726,
            "id": 107815,
            "text": "PASCHIM KHILKAPUR"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109189,
            "text": "GOPALBATI"
        },
        {
            "district_code": 305,
            "block_code": 2775,
            "id": 108295,
            "text": "BIKNA"
        },
        {
            "district_code": 305,
            "block_code": 2774,
            "id": 108291,
            "text": "JAGADALLA-I"
        },
        {
            "district_code": 321,
            "block_code": 3063,
            "id": 111118,
            "text": "MURADI"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107891,
            "text": "JALESWAR-II"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108502,
            "text": "AMARUN-II"
        },
        {
            "district_code": 306,
            "block_code": 2808,
            "id": 108592,
            "text": "HATKALNA"
        },
        {
            "district_code": 319,
            "block_code": 3007,
            "id": 110580,
            "text": "SALU"
        },
        {
            "district_code": 307,
            "block_code": 2837,
            "id": 108852,
            "text": "HARIDASPUR"
        },
        {
            "district_code": 305,
            "block_code": 2789,
            "id": 108429,
            "text": "RUDRA"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109334,
            "text": "BHATUN"
        },
        {
            "district_code": 321,
            "block_code": 3061,
            "id": 111109,
            "text": "SANKA"
        },
        {
            "district_code": 321,
            "block_code": 3049,
            "id": 110994,
            "text": "DALDALI"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109348,
            "text": "BATANAL"
        },
        {
            "district_code": 316,
            "block_code": 2941,
            "id": 109950,
            "text": "UTTAR LAKSHMIPUR"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107877,
            "text": "DEGANGA-II"
        },
        {
            "district_code": 319,
            "block_code": 3022,
            "id": 110727,
            "text": "MALIBARI-I"
        },
        {
            "district_code": 318,
            "block_code": 2999,
            "id": 110496,
            "text": "BISHNUPUR"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109477,
            "text": "MAROKHANA"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108190,
            "text": "SHERPUR"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111031,
            "text": "BEKO"
        },
        {
            "district_code": 704,
            "block_code": 2798,
            "id": 108493,
            "text": "BARABONI"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110548,
            "text": "NIYALLISPARA GOALJAN"
        },
        {
            "district_code": 319,
            "block_code": 3012,
            "id": 110633,
            "text": "JALANGI"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108670,
            "text": "PUTSURI"
        },
        {
            "district_code": 307,
            "block_code": 2837,
            "id": 108851,
            "text": "BAUTIA"
        },
        {
            "district_code": 316,
            "block_code": 2932,
            "id": 109857,
            "text": "CHANDPUR"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109561,
            "text": "KHOSALPUR"
        },
        {
            "district_code": 303,
            "block_code": 2738,
            "id": 107923,
            "text": "BHEBIA"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109651,
            "text": "DAKSHIN SANKRAIL"
        },
        {
            "district_code": 317,
            "block_code": 2956,
            "id": 110079,
            "text": "LAKSHI"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109877,
            "text": "AMRITI"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110784,
            "text": "RAUTARI"
        },
        {
            "district_code": 318,
            "block_code": 2977,
            "id": 110269,
            "text": "SAURIKOTBAR"
        },
        {
            "district_code": 318,
            "block_code": 2999,
            "id": 110498,
            "text": "GARHMAL"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110351,
            "text": "SULTANPUR"
        },
        {
            "district_code": 318,
            "block_code": 2982,
            "id": 110323,
            "text": "GOALTOR"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109691,
            "text": "RAMPUR-DIHIBHUSUT ASANDA"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108066,
            "text": "SOUTH BAWALI"
        },
        {
            "district_code": 703,
            "block_code": 2987,
            "id": 110367,
            "text": "CHINCHRA"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108938,
            "text": "DAUAGURI"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110124,
            "text": "CHAKSHIMULIA"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109030,
            "text": "BALARAMPUR-II"
        },
        {
            "district_code": 307,
            "block_code": 2827,
            "id": 108758,
            "text": "KASBA"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108191,
            "text": "SHRICHANDA"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107876,
            "text": "DEGANGA-I"
        },
        {
            "district_code": 304,
            "block_code": 2771,
            "id": 108263,
            "text": "DHABLAT"
        },
        {
            "district_code": 321,
            "block_code": 3057,
            "id": 111067,
            "text": "BAHARA"
        },
        {
            "district_code": 313,
            "block_code": 2917,
            "id": 109696,
            "text": "HATGACHHA-I"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108399,
            "text": "RAMSAGAR"
        },
        {
            "district_code": 310,
            "block_code": 2875,
            "id": 109221,
            "text": "BATUN"
        },
        {
            "district_code": 308,
            "block_code": 2852,
            "id": 108998,
            "text": "HAZRAHAT-II"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108122,
            "text": "KUMIRMARI"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109360,
            "text": "TIROLE"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260991,
            "text": "PLUNGDUNG"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108959,
            "text": "GITALDAHA-II"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109414,
            "text": "GURAP"
        },
        {
            "district_code": 309,
            "block_code": 2865,
            "id": 109151,
            "text": "MATIGARA-II"
        },
        {
            "district_code": 303,
            "block_code": 2743,
            "id": 107959,
            "text": "BERMAJUR-I"
        },
        {
            "district_code": 313,
            "block_code": 2907,
            "id": 109585,
            "text": "HATURIA-I"
        },
        {
            "district_code": 321,
            "block_code": 3049,
            "id": 110995,
            "text": "HURA"
        },
        {
            "district_code": 317,
            "block_code": 2948,
            "id": 110017,
            "text": "ITABERIA"
        },
        {
            "district_code": 319,
            "block_code": 3010,
            "id": 110610,
            "text": "ARJUNPUR"
        },
        {
            "district_code": 303,
            "block_code": 2728,
            "id": 107830,
            "text": "PANPUR-KEUTIA"
        },
        {
            "district_code": 313,
            "block_code": 2914,
            "id": 109664,
            "text": "BALICHATURI"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110668,
            "text": "MAIYA"
        },
        {
            "district_code": 320,
            "block_code": 3032,
            "id": 110839,
            "text": "PIPULBARIA"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107864,
            "text": "GOPALNAGAR-I"
        },
        {
            "district_code": 311,
            "block_code": 2884,
            "id": 109318,
            "text": "RADHIKAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2747,
            "id": 108017,
            "text": "TARDA"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109729,
            "text": "TATPARA-I"
        },
        {
            "district_code": 306,
            "block_code": 2807,
            "id": 108587,
            "text": "SATGACHHI"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109465,
            "text": "KHANAKUL-II"
        },
        {
            "district_code": 704,
            "block_code": 2819,
            "id": 108693,
            "text": "DAKSHINKHANDA"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109881,
            "text": "JADUPUR-II"
        },
        {
            "district_code": 312,
            "block_code": 2891,
            "id": 109401,
            "text": "SAPTAGRAM"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107984,
            "text": "HARIHARPUR"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109879,
            "text": "FULBARIA"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110662,
            "text": "BAHADURPUR"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109964,
            "text": "PARDEONAPUR-SOVAPUR"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108302,
            "text": "BARJORA"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110911,
            "text": "ARANGHATA"
        },
        {
            "district_code": 304,
            "block_code": 2748,
            "id": 108027,
            "text": "SHANPUKUR"
        },
        {
            "district_code": 316,
            "block_code": 2938,
            "id": 109915,
            "text": "BHINGOLE"
        },
        {
            "district_code": 318,
            "block_code": 2992,
            "id": 110426,
            "text": "PAPARARA-I"
        },
        {
            "district_code": 305,
            "block_code": 2789,
            "id": 108425,
            "text": "PUDDI"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110451,
            "text": "KUSHBASAN"
        },
        {
            "district_code": 319,
            "block_code": 3026,
            "id": 110760,
            "text": "BAJITPUR"
        },
        {
            "district_code": 306,
            "block_code": 2803,
            "id": 108543,
            "text": "MANKAR"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108667,
            "text": "MAMUDPUR-II"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108037,
            "text": "PURBA BISHNUPUR"
        },
        {
            "district_code": 318,
            "block_code": 2982,
            "id": 110325,
            "text": "JEERAPARA"
        },
        {
            "district_code": 304,
            "block_code": 2747,
            "id": 108016,
            "text": "SHANKSAHAR"
        },
        {
            "district_code": 321,
            "block_code": 3056,
            "id": 111061,
            "text": "GUNIARA"
        },
        {
            "district_code": 319,
            "block_code": 3025,
            "id": 110753,
            "text": "BAHUTALI"
        },
        {
            "district_code": 320,
            "block_code": 7115,
            "id": 110781,
            "text": "SIMURALI"
        },
        {
            "district_code": 308,
            "block_code": 2852,
            "id": 109004,
            "text": "SHIKARPUR"
        },
        {
            "district_code": 312,
            "block_code": 2897,
            "id": 109461,
            "text": "ARUNDA"
        },
        {
            "district_code": 310,
            "block_code": 2876,
            "id": 109234,
            "text": "KUSHMANDI"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107785,
            "text": "ATURIA"
        },
        {
            "district_code": 308,
            "block_code": 2853,
            "id": 109009,
            "text": "KUCHLIBARI"
        },
        {
            "district_code": 317,
            "block_code": 2948,
            "id": 110018,
            "text": "JUKHIA"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110868,
            "text": "PORAGACHHA"
        },
        {
            "district_code": 306,
            "block_code": 2807,
            "id": 108580,
            "text": "AKALPAUS"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109258,
            "text": "CHAKULIA"
        },
        {
            "district_code": 320,
            "block_code": 3034,
            "id": 110852,
            "text": "GOBINDAPUR"
        },
        {
            "district_code": 313,
            "block_code": 2915,
            "id": 109675,
            "text": "BACHHRI"
        },
        {
            "district_code": 321,
            "block_code": 3054,
            "id": 111044,
            "text": "BHALUBASA"
        },
        {
            "district_code": 318,
            "block_code": 2991,
            "id": 110417,
            "text": "KALAIKUNDA"
        },
        {
            "district_code": 310,
            "block_code": 2871,
            "id": 109197,
            "text": "MAHABARI"
        },
        {
            "district_code": 306,
            "block_code": 2797,
            "id": 108489,
            "text": "KOTA"
        },
        {
            "district_code": 307,
            "block_code": 2844,
            "id": 108916,
            "text": "TILPARA"
        },
        {
            "district_code": 318,
            "block_code": 2992,
            "id": 110420,
            "text": "CHAKMAKAMPUR"
        },
        {
            "district_code": 305,
            "block_code": 2779,
            "id": 108336,
            "text": "BAHARAMURI"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109903,
            "text": "AIHO"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109558,
            "text": "CHANDRAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108185,
            "text": "EKTARA"
        },
        {
            "district_code": 317,
            "block_code": 2956,
            "id": 110077,
            "text": "KALAGECHHIA"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108796,
            "text": "CHAUHATTA-MAHODARI-II"
        },
        {
            "district_code": 320,
            "block_code": 3036,
            "id": 110876,
            "text": "SADHANPARA-II"
        },
        {
            "district_code": 317,
            "block_code": 2955,
            "id": 110072,
            "text": "CHAKDWIPA"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108323,
            "text": "SALDIHA"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110938,
            "text": "KANAINAGAR"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108503,
            "text": "BAMUNARA"
        },
        {
            "district_code": 317,
            "block_code": 2970,
            "id": 110207,
            "text": "CHAITANYAPUR"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110348,
            "text": "MOHANPUR"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110822,
            "text": "HATGACHHA"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109575,
            "text": "KASMOLI"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108929,
            "text": "KHAGRABARI"
        },
        {
            "district_code": 319,
            "block_code": 3020,
            "id": 110710,
            "text": "KASIADANGA"
        },
        {
            "district_code": 319,
            "block_code": 3004,
            "id": 110559,
            "text": "NASHIPUR"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109935,
            "text": "JALALPUR"
        },
        {
            "district_code": 318,
            "block_code": 2974,
            "id": 110244,
            "text": "JARA"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109324,
            "text": "DOMOHONA"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108513,
            "text": "SAHEBGANJ-I"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109628,
            "text": "JAGATBALLAVPUR-I"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109726,
            "text": "MAJHERDABRI"
        },
        {
            "district_code": 317,
            "block_code": 2966,
            "id": 110178,
            "text": "SREERAMPUR"
        },
        {
            "district_code": 319,
            "block_code": 3026,
            "id": 110765,
            "text": "MAHESAIL-I"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110542,
            "text": "GURUDASPUR"
        },
        {
            "district_code": 319,
            "block_code": 3016,
            "id": 110673,
            "text": "BAHADURPUR"
        },
        {
            "district_code": 704,
            "block_code": 2809,
            "id": 108599,
            "text": "BIDBEHAR"
        },
        {
            "district_code": 316,
            "block_code": 2938,
            "id": 109920,
            "text": "TULSIHATTA"
        },
        {
            "district_code": 320,
            "block_code": 3039,
            "id": 110902,
            "text": "BARASAT"
        },
        {
            "district_code": 319,
            "block_code": 3017,
            "id": 110684,
            "text": "KIRITESWARI"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107863,
            "text": "GHATBOUR"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108303,
            "text": "BELIATORE"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109768,
            "text": "KHARIJA-BERUBARI-II"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111033,
            "text": "GORANDIH"
        },
        {
            "district_code": 305,
            "block_code": 2784,
            "id": 108375,
            "text": "GOPINATHPUR"
        },
        {
            "district_code": 307,
            "block_code": 2845,
            "id": 108920,
            "text": "KENDUA"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110821,
            "text": "GOBRA"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109773,
            "text": "SOUTH BERUBARI"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108274,
            "text": "KALIKAPUR-I"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108567,
            "text": "PANCHRAH"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108206,
            "text": "MOHANPUR"
        },
        {
            "district_code": 321,
            "block_code": 3051,
            "id": 111012,
            "text": "ILU-JARGO"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108262,
            "text": "SRINARAYANPUR  PURNACHANDRAPUR"
        },
        {
            "district_code": 303,
            "block_code": 2728,
            "id": 107824,
            "text": "JETHIA"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110586,
            "text": "BURWAN-II"
        },
        {
            "district_code": 320,
            "block_code": 3039,
            "id": 110901,
            "text": "HABIBPUR"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110222,
            "text": "SREERAMPUR-II"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 8888101,
            "text": "Paiyong"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109972,
            "text": "HEERANANDAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2953,
            "id": 110059,
            "text": "KASBA-EGRA"
        },
        {
            "district_code": 317,
            "block_code": 2952,
            "id": 110051,
            "text": "CHALTI"
        },
        {
            "district_code": 317,
            "block_code": 2968,
            "id": 110191,
            "text": "KADUA"
        },
        {
            "district_code": 320,
            "block_code": 3041,
            "id": 110925,
            "text": "ARBANDI-II"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108672,
            "text": "VAGRAMULGRAM"
        },
        {
            "district_code": 317,
            "block_code": 2966,
            "id": 110172,
            "text": "ARGOAL"
        },
        {
            "district_code": 317,
            "block_code": 2949,
            "id": 110023,
            "text": "BRINDABANPUR-II"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109408,
            "text": "DHANEKHALI-I"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109662,
            "text": "SARENGA"
        },
        {
            "district_code": 308,
            "block_code": 2854,
            "id": 109014,
            "text": "BRAHMOTTAR-CHATRA"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109766,
            "text": "KHARIA"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108134,
            "text": "HARINARAYANPUR"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108151,
            "text": "BAPUJI"
        },
        {
            "district_code": 305,
            "block_code": 2780,
            "id": 108343,
            "text": "BRAJARAJPUR"
        },
        {
            "district_code": 305,
            "block_code": 2792,
            "id": 108450,
            "text": "SIMLAPAL"
        },
        {
            "district_code": 306,
            "block_code": 2813,
            "id": 108631,
            "text": "MURGRAM-GOPALPUR"
        },
        {
            "district_code": 306,
            "block_code": 2801,
            "id": 108530,
            "text": "KURMUN-II"
        },
        {
            "district_code": 307,
            "block_code": 2836,
            "id": 108847,
            "text": "PAIKAR-II"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109415,
            "text": "KHAJUDAHAMILKI"
        },
        {
            "district_code": 304,
            "block_code": 2747,
            "id": 108013,
            "text": "JAGULGACHHI"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109033,
            "text": "DEOCHARAI"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261045,
            "text": "SUKNA"
        },
        {
            "district_code": 309,
            "block_code": 2868,
            "id": 109166,
            "text": "BIDHANNAGAR-II"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108665,
            "text": "MAJHERGRAM"
        },
        {
            "district_code": 317,
            "block_code": 2965,
            "id": 110166,
            "text": "BRAJALALPUR"
        },
        {
            "district_code": 306,
            "block_code": 2822,
            "id": 108718,
            "text": "MUKSIMPARA"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108557,
            "text": "ABUJHATI-I"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108306,
            "text": "GHUTGORIA"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110448,
            "text": "KASHIPUR"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109975,
            "text": "NAZEERPUR"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108064,
            "text": "RANIA"
        },
        {
            "district_code": 306,
            "block_code": 2812,
            "id": 108622,
            "text": "KETUGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2993,
            "id": 110432,
            "text": "MONIDAHA"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110664,
            "text": "DEWANSARAI"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109366,
            "text": "GUPTIPARA-I"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110665,
            "text": "JASAITALA"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110550,
            "text": "RADHARGHAT-II"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 108005,
            "text": "MASZIDBATI"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109034,
            "text": "DHALPAL-I"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109487,
            "text": "BERELAKONCHMALI"
        },
        {
            "district_code": 319,
            "block_code": 3015,
            "id": 110666,
            "text": "KALMEGHA"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109783,
            "text": "RAJABHATKHAWA"
        },
        {
            "district_code": 319,
            "block_code": 3016,
            "id": 110675,
            "text": "DANGAPARA"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108651,
            "text": "KAICHAR-II"
        },
        {
            "district_code": 313,
            "block_code": 2907,
            "id": 109584,
            "text": "BANGALPUR"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261061,
            "text": "TACKLING-I"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 110103,
            "text": "ITAMOGRA-II"
        },
        {
            "district_code": 307,
            "block_code": 2833,
            "id": 108816,
            "text": "KALESWAR"
        },
        {
            "district_code": 317,
            "block_code": 2962,
            "id": 110138,
            "text": "MAHAMMADPUR"
        },
        {
            "district_code": 317,
            "block_code": 2951,
            "id": 110041,
            "text": "DURMUTH"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109727,
            "text": "PAROKATA"
        },
        {
            "district_code": 307,
            "block_code": 2838,
            "id": 108860,
            "text": "BHADRAPUR-I"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109416,
            "text": "MANDRA"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110411,
            "text": "SHIRSHA"
        },
        {
            "district_code": 317,
            "block_code": 2965,
            "id": 110169,
            "text": "GOKULPUR"
        },
        {
            "district_code": 306,
            "block_code": 2817,
            "id": 108675,
            "text": "DALUIBAZAR-I"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108647,
            "text": "GOTISTHA"
        },
        {
            "district_code": 303,
            "block_code": 2731,
            "id": 107850,
            "text": "KACHUA"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107978,
            "text": "BELEGACHHIA"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108194,
            "text": "UTTARKUSUM"
        },
        {
            "district_code": 704,
            "block_code": 2802,
            "id": 108534,
            "text": "GOGLA"
        },
        {
            "district_code": 318,
            "block_code": 2983,
            "id": 110334,
            "text": "NALBONA"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108652,
            "text": "KSHIRGRAM"
        },
        {
            "district_code": 303,
            "block_code": 2736,
            "id": 107904,
            "text": "BERABERI"
        },
        {
            "district_code": 319,
            "block_code": 3017,
            "id": 110690,
            "text": "SHIBPUR"
        },
        {
            "district_code": 304,
            "block_code": 2756,
            "id": 108094,
            "text": "BHADURA HARIDAS"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110772,
            "text": "GHETUGACHHI"
        },
        {
            "district_code": 317,
            "block_code": 2948,
            "id": 110015,
            "text": "GARBARI-I"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260998,
            "text": "UPPER SONADA"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108867,
            "text": "DASKALGRAM-KAREYA-I"
        },
        {
            "district_code": 321,
            "block_code": 3059,
            "id": 111090,
            "text": "GARAFUSRA"
        },
        {
            "district_code": 305,
            "block_code": 2788,
            "id": 108420,
            "text": "SHYAMSUNDARPUR"
        },
        {
            "district_code": 308,
            "block_code": 2851,
            "id": 108985,
            "text": "ANGARKATA-PARDUBI"
        },
        {
            "district_code": 305,
            "block_code": 2789,
            "id": 108423,
            "text": "BARIKUL"
        },
        {
            "district_code": 303,
            "block_code": 2735,
            "id": 107897,
            "text": "BARGUM-II"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261057,
            "text": "RANGLI"
        },
        {
            "district_code": 304,
            "block_code": 2747,
            "id": 108011,
            "text": "CHANDANESWAR-II"
        },
        {
            "district_code": 312,
            "block_code": 2896,
            "id": 109456,
            "text": "MUNDALIKA"
        },
        {
            "district_code": 319,
            "block_code": 3026,
            "id": 110762,
            "text": "JAGTAI-II"
        },
        {
            "district_code": 318,
            "block_code": 2997,
            "id": 110480,
            "text": "PINDURUI"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108156,
            "text": "RAMGOPALPUR"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109910,
            "text": "KANTURKA"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108175,
            "text": "RAMNAGAR-GAZIPUR"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110455,
            "text": "NARMA"
        },
        {
            "district_code": 313,
            "block_code": 2917,
            "id": 109700,
            "text": "MAHESHPUR"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110381,
            "text": "LODHASULI"
        },
        {
            "district_code": 307,
            "block_code": 2836,
            "id": 108846,
            "text": "PAIKAR-I"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108907,
            "text": "PANRUI"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110321,
            "text": "SHYAMNAGAR"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109509,
            "text": "POLBA"
        },
        {
            "district_code": 321,
            "block_code": 3052,
            "id": 111021,
            "text": "BEGUNKODAR"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107862,
            "text": "GANGRAPOTA"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109499,
            "text": "SHIKHIRACHANPTA"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110942,
            "text": "RAGHUNATHPUR"
        },
        {
            "district_code": 321,
            "block_code": 3048,
            "id": 110985,
            "text": "BANDWAN"
        },
        {
            "district_code": 312,
            "block_code": 2896,
            "id": 109460,
            "text": "RASIDPUR"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108028,
            "text": "AMGACHHIA"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108648,
            "text": "JHILU-I"
        },
        {
            "district_code": 303,
            "block_code": 2729,
            "id": 107837,
            "text": "SEWLI"
        },
        {
            "district_code": 303,
            "block_code": 2726,
            "id": 107816,
            "text": "PURBA KHILKAPUR"
        },
        {
            "district_code": 312,
            "block_code": 2889,
            "id": 109377,
            "text": "HARIPUR"
        },
        {
            "district_code": 319,
            "block_code": 3022,
            "id": 110723,
            "text": "KALINAGAR-I"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108324,
            "text": "SUSUNIA"
        },
        {
            "district_code": 307,
            "block_code": 2827,
            "id": 108756,
            "text": "BAHIRI-PANCHSHOWA"
        },
        {
            "district_code": 304,
            "block_code": 2748,
            "id": 108025,
            "text": "POLERHAT-I"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110803,
            "text": "DAKSHINPARA-II"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109887,
            "text": "SOVANAGAR"
        },
        {
            "district_code": 313,
            "block_code": 2918,
            "id": 109705,
            "text": "KHALISANI"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108745,
            "text": "ACHHRA"
        },
        {
            "district_code": 304,
            "block_code": 2751,
            "id": 108050,
            "text": "BUTA"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108798,
            "text": "HATIA"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109409,
            "text": "DHANEKHALI-II"
        },
        {
            "district_code": 305,
            "block_code": 2789,
            "id": 108424,
            "text": "HALUDKANALI"
        },
        {
            "district_code": 310,
            "block_code": 2876,
            "id": 109232,
            "text": "KALIKAMORA"
        },
        {
            "district_code": 319,
            "block_code": 3024,
            "id": 110746,
            "text": "DOGACHHI NAPARA"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110941,
            "text": "PATHATGHATA-II"
        },
        {
            "district_code": 304,
            "block_code": 2760,
            "id": 108143,
            "text": "CHUPRIJHARA"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107793,
            "text": "JASIKATI ATGHARA"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109758,
            "text": "PARANGERPAR"
        },
        {
            "district_code": 305,
            "block_code": 2788,
            "id": 108413,
            "text": "DHEKO"
        },
        {
            "district_code": 314,
            "block_code": 2921,
            "id": 109734,
            "text": "BAROGHARIA"
        },
        {
            "district_code": 305,
            "block_code": 2791,
            "id": 108440,
            "text": "GARGARIA"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108945,
            "text": "JIRANPUR"
        },
        {
            "district_code": 316,
            "block_code": 2941,
            "id": 109952,
            "text": "UTTAR PANCHANANDAPUR-I"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107992,
            "text": "SHANKARPUR-II"
        },
        {
            "district_code": 307,
            "block_code": 2835,
            "id": 108833,
            "text": "CHATRA"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 261020,
            "text": "GITABLING"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109300,
            "text": "DURGAPUR"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 261021,
            "text": "KAGE"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108755,
            "text": "SAMDI"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110115,
            "text": "NAICHANPUR-II"
        },
        {
            "district_code": 319,
            "block_code": 3019,
            "id": 110703,
            "text": "JARUR"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109510,
            "text": "RAJHAT"
        },
        {
            "district_code": 306,
            "block_code": 2824,
            "id": 108731,
            "text": "ARUI"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110543,
            "text": "HARIDASMATI"
        },
        {
            "district_code": 320,
            "block_code": 3033,
            "id": 110844,
            "text": "MURUTIA"
        },
        {
            "district_code": 704,
            "block_code": 2820,
            "id": 108700,
            "text": "BAIDYANATHPUR"
        },
        {
            "district_code": 319,
            "block_code": 3026,
            "id": 110764,
            "text": "LAXMIPUR"
        },
        {
            "district_code": 304,
            "block_code": 2771,
            "id": 108270,
            "text": "RAMKARCHAR"
        },
        {
            "district_code": 321,
            "block_code": 3059,
            "id": 111091,
            "text": "LAGDA"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109900,
            "text": "RANIGANJ-II"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 108002,
            "text": "JHARKHALI"
        },
        {
            "district_code": 319,
            "block_code": 3005,
            "id": 110561,
            "text": "BHAGAWANGOLA"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109032,
            "text": "CHILKHANA-II"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109206,
            "text": "NANDANPUR"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260968,
            "text": "RIMBIK"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110736,
            "text": "BOKHARA-II"
        },
        {
            "district_code": 319,
            "block_code": 3021,
            "id": 110717,
            "text": "HERAMPUR"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108947,
            "text": "PANISALA"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110910,
            "text": "ANISHMALI"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110088,
            "text": "BHOGPUR"
        },
        {
            "district_code": 312,
            "block_code": 2893,
            "id": 109422,
            "text": "GOGHAT"
        },
        {
            "district_code": 309,
            "block_code": 2868,
            "id": 109167,
            "text": "CHATHAT-BANSGAON"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261060,
            "text": "SINGRIMATAM"
        },
        {
            "district_code": 306,
            "block_code": 2801,
            "id": 108532,
            "text": "NABASTHA-II"
        },
        {
            "district_code": 310,
            "block_code": 2874,
            "id": 109217,
            "text": "DHALPARA"
        },
        {
            "district_code": 318,
            "block_code": 2991,
            "id": 110413,
            "text": "ARJUNI"
        },
        {
            "district_code": 312,
            "block_code": 2890,
            "id": 109390,
            "text": "NAITI"
        },
        {
            "district_code": 305,
            "block_code": 2783,
            "id": 108370,
            "text": "GORABARI"
        },
        {
            "district_code": 704,
            "block_code": 2819,
            "id": 108697,
            "text": "RAMPRASADPUR"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109775,
            "text": "DALSING PARA"
        },
        {
            "district_code": 320,
            "block_code": 3034,
            "id": 110855,
            "text": "MAITIARY BANPUR"
        },
        {
            "district_code": 316,
            "block_code": 2935,
            "id": 109886,
            "text": "NARHATTA"
        },
        {
            "district_code": 317,
            "block_code": 2965,
            "id": 110167,
            "text": "CHISTIPUR-I"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109630,
            "text": "LASKARPUR"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107895,
            "text": "SUTIA"
        },
        {
            "district_code": 306,
            "block_code": 2813,
            "id": 108633,
            "text": "PANDUGRAM"
        },
        {
            "district_code": 306,
            "block_code": 2808,
            "id": 108591,
            "text": "DHATRIGRAM"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108668,
            "text": "MANTESWAR"
        },
        {
            "district_code": 305,
            "block_code": 2785,
            "id": 108382,
            "text": "ARDHAGRAM"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110888,
            "text": "BILKUMARI"
        },
        {
            "district_code": 703,
            "block_code": 2973,
            "id": 110235,
            "text": "BELPAHARI"
        },
        {
            "district_code": 306,
            "block_code": 2821,
            "id": 108709,
            "text": "NADANGHAT"
        },
        {
            "district_code": 318,
            "block_code": 2992,
            "id": 110425,
            "text": "PALSYA"
        },
        {
            "district_code": 314,
            "block_code": 2928,
            "id": 109819,
            "text": "INDONG-MATIALI"
        },
        {
            "district_code": 702,
            "block_code": 7354,
            "id": 261029,
            "text": "SHANTUK"
        },
        {
            "district_code": 320,
            "block_code": 3041,
            "id": 110924,
            "text": "ARBANDI-I"
        },
        {
            "district_code": 317,
            "block_code": 2967,
            "id": 110187,
            "text": "TALGACHHARI-II"
        },
        {
            "district_code": 321,
            "block_code": 3046,
            "id": 110974,
            "text": "TENTLOW"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109639,
            "text": "BIKIHAKOLA"
        },
        {
            "district_code": 306,
            "block_code": 2814,
            "id": 108635,
            "text": "BERUGRAM"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109755,
            "text": "JATESWAR-I"
        },
        {
            "district_code": 317,
            "block_code": 2965,
            "id": 110168,
            "text": "CHISTIPUR-II"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110400,
            "text": "ANANDAPUR"
        },
        {
            "district_code": 319,
            "block_code": 3017,
            "id": 110682,
            "text": "GURAPASHLA"
        },
        {
            "district_code": 303,
            "block_code": 2736,
            "id": 107910,
            "text": "SRIKRISHNAPUR"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261032,
            "text": "CHIMNEY-DEORALI"
        },
        {
            "district_code": 308,
            "block_code": 2846,
            "id": 108926,
            "text": "CHAKCHAKA"
        },
        {
            "district_code": 321,
            "block_code": 3058,
            "id": 111083,
            "text": "PANIPATHAR"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108208,
            "text": "NAINAN"
        },
        {
            "district_code": 319,
            "block_code": 3016,
            "id": 110676,
            "text": "KAPASDANGA"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108656,
            "text": "NIGAN"
        },
        {
            "district_code": 303,
            "block_code": 2725,
            "id": 107807,
            "text": "SINDRANI"
        },
        {
            "district_code": 319,
            "block_code": 3017,
            "id": 110681,
            "text": "AMARKUNDU"
        },
        {
            "district_code": 308,
            "block_code": 2855,
            "id": 109024,
            "text": "LALBAZAR"
        },
        {
            "district_code": 306,
            "block_code": 2803,
            "id": 108540,
            "text": "CHAKTENTUL"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109605,
            "text": "BANKRA-I"
        },
        {
            "district_code": 320,
            "block_code": 3039,
            "id": 110906,
            "text": "PAYRADANGA"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260980,
            "text": "RONGO"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109327,
            "text": "LAHUTARA-I"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108278,
            "text": "KHEYADAHA-II"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110379,
            "text": "CHUBKA"
        },
        {
            "district_code": 318,
            "block_code": 2997,
            "id": 110475,
            "text": "JAMNA"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107868,
            "text": "SUNDARPUR"
        },
        {
            "district_code": 305,
            "block_code": 2778,
            "id": 108332,
            "text": "LACHHMANPUR"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109368,
            "text": "JIRAT"
        },
        {
            "district_code": 316,
            "block_code": 2938,
            "id": 109916,
            "text": "HARISHCHANDRAPUR"
        },
        {
            "district_code": 305,
            "block_code": 2782,
            "id": 108361,
            "text": "KUCHIAKOLE"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108126,
            "text": "RANGABELIA"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107794,
            "text": "NAYABASTIA MILANI"
        },
        {
            "district_code": 313,
            "block_code": 2914,
            "id": 109665,
            "text": "BANESWARPUR-I"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109442,
            "text": "HARIPALSAHADEV"
        },
        {
            "district_code": 320,
            "block_code": 3041,
            "id": 110933,
            "text": "NABLA"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109711,
            "text": "CHAKOWAKHETI"
        },
        {
            "district_code": 303,
            "block_code": 2730,
            "id": 107842,
            "text": "PIFA"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109713,
            "text": "PARORPAR"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108753,
            "text": "RUPNARAYANPUR"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109967,
            "text": "CHOWKI MIRDADPUR"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260987,
            "text": "LOWER SONADA-I"
        },
        {
            "district_code": 306,
            "block_code": 2804,
            "id": 108554,
            "text": "MASZIDPUR"
        },
        {
            "district_code": 304,
            "block_code": 2754,
            "id": 108084,
            "text": "TAMBULDAHA-I"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108276,
            "text": "KAMRABAD"
        },
        {
            "district_code": 305,
            "block_code": 2793,
            "id": 108457,
            "text": "PANCHAL"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109654,
            "text": "JORHAT"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109942,
            "text": "SILAMPUR-II"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110213,
            "text": "ANANTAPUR-II"
        },
        {
            "district_code": 303,
            "block_code": 2726,
            "id": 107808,
            "text": "CHHOTO JAGULIA"
        },
        {
            "district_code": 320,
            "block_code": 3037,
            "id": 110884,
            "text": "SWARUPGANJ"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109785,
            "text": "CHENGAMARI"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 261023,
            "text": "LAVA-GITABEONG"
        },
        {
            "district_code": 307,
            "block_code": 2835,
            "id": 108836,
            "text": "MAHURAPUR"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108110,
            "text": "GOPALPUR"
        },
        {
            "district_code": 307,
            "block_code": 2829,
            "id": 108780,
            "text": "JOYDEV-KENDULI"
        },
        {
            "district_code": 304,
            "block_code": 2748,
            "id": 108024,
            "text": "CHALTABERIA"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109418,
            "text": "SOMASPUR-I"
        },
        {
            "district_code": 319,
            "block_code": 3009,
            "id": 110602,
            "text": "GARIBPUR"
        },
        {
            "district_code": 317,
            "block_code": 2948,
            "id": 110013,
            "text": "BAROJ"
        },
        {
            "district_code": 316,
            "block_code": 2946,
            "id": 110000,
            "text": "SREEPUR-I"
        },
        {
            "district_code": 704,
            "block_code": 2798,
            "id": 108498,
            "text": "PANCHGECHHIA"
        },
        {
            "district_code": 314,
            "block_code": 2928,
            "id": 109821,
            "text": "MATIALI-BATABARI-I"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110739,
            "text": "MONIGRAM"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110798,
            "text": "BAGULA-II"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110096,
            "text": "SAGARBARH"
        },
        {
            "district_code": 306,
            "block_code": 2812,
            "id": 108620,
            "text": "BILLESWAR"
        },
        {
            "district_code": 321,
            "block_code": 3051,
            "id": 111011,
            "text": "ICHAG"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110219,
            "text": "PIPULBERIA-I"
        },
        {
            "district_code": 310,
            "block_code": 2873,
            "id": 109210,
            "text": "BAGICHAPUR"
        },
        {
            "district_code": 316,
            "block_code": 2945,
            "id": 109987,
            "text": "CHANDMONI-I"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108969,
            "text": "BARASAKDAL"
        },
        {
            "district_code": 704,
            "block_code": 2806,
            "id": 108572,
            "text": "CHURULIA"
        },
        {
            "district_code": 316,
            "block_code": 2946,
            "id": 110001,
            "text": "SREEPUR-II"
        },
        {
            "district_code": 320,
            "block_code": 3042,
            "id": 110935,
            "text": "BETAI-II"
        },
        {
            "district_code": 303,
            "block_code": 2725,
            "id": 107799,
            "text": "ASHARU"
        },
        {
            "district_code": 307,
            "block_code": 2841,
            "id": 108883,
            "text": "DAKHALBATI"
        },
        {
            "district_code": 306,
            "block_code": 2810,
            "id": 108608,
            "text": "KHAJURDIHI"
        },
        {
            "district_code": 703,
            "block_code": 2985,
            "id": 110352,
            "text": "BELIABERA"
        },
        {
            "district_code": 306,
            "block_code": 2817,
            "id": 108679,
            "text": "GOP-GANTAR-I"
        },
        {
            "district_code": 319,
            "block_code": 3020,
            "id": 110714,
            "text": "SEKALIPUR"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108201,
            "text": "GOKARNI"
        },
        {
            "district_code": 304,
            "block_code": 2771,
            "id": 108268,
            "text": "MURIGANGA-I"
        },
        {
            "district_code": 312,
            "block_code": 2891,
            "id": 109397,
            "text": "KODALIA-I"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108908,
            "text": "SANGRA"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110741,
            "text": "PATKELDANGA"
        },
        {
            "district_code": 321,
            "block_code": 3052,
            "id": 111024,
            "text": "HIRAPURADARDIH"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110452,
            "text": "MANYA"
        },
        {
            "district_code": 704,
            "block_code": 2798,
            "id": 108494,
            "text": "DOMOHANI"
        },
        {
            "district_code": 321,
            "block_code": 3057,
            "id": 111070,
            "text": "DUBRA"
        },
        {
            "district_code": 304,
            "block_code": 2766,
            "id": 108214,
            "text": "GABBERIA"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108751,
            "text": "KALYA"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110346,
            "text": "MANSUKA-I"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108140,
            "text": "UTTAR DURGAPUR"
        },
        {
            "district_code": 321,
            "block_code": 3044,
            "id": 110957,
            "text": "MANKIARY"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109714,
            "text": "PATLAKHAWA"
        },
        {
            "district_code": 303,
            "block_code": 2739,
            "id": 107932,
            "text": "JOGESHGANJ"
        },
        {
            "district_code": 304,
            "block_code": 2767,
            "id": 108220,
            "text": "ABAD BHAGAWANPUR"
        },
        {
            "district_code": 321,
            "block_code": 3046,
            "id": 110972,
            "text": "GENRUA"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108655,
            "text": "MONGALKOT"
        },
        {
            "district_code": 306,
            "block_code": 2808,
            "id": 108594,
            "text": "KRISHNADEVPUR"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109566,
            "text": "AMRAGORI"
        },
        {
            "district_code": 320,
            "block_code": 3037,
            "id": 110883,
            "text": "MAYAPUR BAMANPUKUR-II"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108746,
            "text": "ALLADI"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107878,
            "text": "HADIPUR JHIKRA-I"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110740,
            "text": "MOREGRAM"
        },
        {
            "district_code": 318,
            "block_code": 2983,
            "id": 110339,
            "text": "URIASAI"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110314,
            "text": "BENACHAPRA"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109834,
            "text": "PADAMOTI-I"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109850,
            "text": "MAJHIALI"
        },
        {
            "district_code": 305,
            "block_code": 2788,
            "id": 108415,
            "text": "FULKUSMA"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260973,
            "text": "DALIM"
        },
        {
            "district_code": 306,
            "block_code": 2811,
            "id": 108615,
            "text": "JAGADANANDSPUR"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107790,
            "text": "JADURHATI DAKSHIN"
        },
        {
            "district_code": 312,
            "block_code": 2889,
            "id": 109378,
            "text": "KRISHNARAMPUR"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108137,
            "text": "NARAYANITALA"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109631,
            "text": "MAJU"
        },
        {
            "district_code": 313,
            "block_code": 2908,
            "id": 109596,
            "text": "SARATCHANDRA"
        },
        {
            "district_code": 309,
            "block_code": 2863,
            "id": 109131,
            "text": "BURAGANJ"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110525,
            "text": "MIRJAPUR-II"
        },
        {
            "district_code": 305,
            "block_code": 2782,
            "id": 108358,
            "text": "GELIA"
        },
        {
            "district_code": 304,
            "block_code": 2752,
            "id": 108057,
            "text": "CHAKMANIK"
        },
        {
            "district_code": 319,
            "block_code": 3026,
            "id": 110761,
            "text": "JAGTAI-I"
        },
        {
            "district_code": 318,
            "block_code": 2998,
            "id": 110487,
            "text": "DASHGRAM"
        },
        {
            "district_code": 319,
            "block_code": 3012,
            "id": 110636,
            "text": "SADIKHANDERAH"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110800,
            "text": "BATKULLA-II"
        },
        {
            "district_code": 703,
            "block_code": 2987,
            "id": 110373,
            "text": "KENDADANGRI"
        },
        {
            "district_code": 319,
            "block_code": 3011,
            "id": 110625,
            "text": "MALOPARA"
        },
        {
            "district_code": 317,
            "block_code": 2954,
            "id": 110065,
            "text": "DESHBANDHU"
        },
        {
            "district_code": 318,
            "block_code": 2989,
            "id": 110396,
            "text": "NACHIPUR"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109832,
            "text": "MADHABDANGA-II"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109891,
            "text": "BAIRGACHHI-II"
        },
        {
            "district_code": 310,
            "block_code": 2876,
            "id": 109231,
            "text": "DEUL"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108393,
            "text": "MEDNIPUR"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108193,
            "text": "USTHI"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110303,
            "text": "JALIMANDA"
        },
        {
            "district_code": 317,
            "block_code": 2947,
            "id": 110010,
            "text": "MAHAMMADPUR-II"
        },
        {
            "district_code": 319,
            "block_code": 3026,
            "id": 110763,
            "text": "KASIMNAGAR"
        },
        {
            "district_code": 313,
            "block_code": 2918,
            "id": 109709,
            "text": "TULSIBERIA"
        },
        {
            "district_code": 307,
            "block_code": 2845,
            "id": 108919,
            "text": "DOMDAMA"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260982,
            "text": "TODEYTANGTA"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260957,
            "text": "JHEPI"
        },
        {
            "district_code": 304,
            "block_code": 2748,
            "id": 108018,
            "text": "BAMANGHATA"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260956,
            "text": "GOKE-II"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109753,
            "text": "FALAKATA-II"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109692,
            "text": "SINGTI"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109553,
            "text": "AMTA"
        },
        {
            "district_code": 319,
            "block_code": 3006,
            "id": 110574,
            "text": "JAJAN"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109286,
            "text": "AGDIMTI-KHANTI"
        },
        {
            "district_code": 306,
            "block_code": 2803,
            "id": 108545,
            "text": "POTNA-PURSA"
        },
        {
            "district_code": 321,
            "block_code": 3046,
            "id": 110971,
            "text": "DARDA"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110818,
            "text": "BARACHANDGHAR"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107874,
            "text": "CHAMPATALA"
        },
        {
            "district_code": 319,
            "block_code": 3008,
            "id": 110585,
            "text": "BURWAN-I"
        },
        {
            "district_code": 320,
            "block_code": 3036,
            "id": 110873,
            "text": "NOAPARA-I"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109976,
            "text": "NURPUR"
        },
        {
            "district_code": 305,
            "block_code": 2784,
            "id": 108376,
            "text": "KOTULPUR"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109504,
            "text": "DADPUR"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109262,
            "text": "SAHAPUR-I"
        },
        {
            "district_code": 319,
            "block_code": 3024,
            "id": 110748,
            "text": "KANCHANTALA"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109853,
            "text": "SANNYASIKATA"
        },
        {
            "district_code": 316,
            "block_code": 2933,
            "id": 109866,
            "text": "KHARBA"
        },
        {
            "district_code": 320,
            "block_code": 3037,
            "id": 110880,
            "text": "MAHISURA"
        },
        {
            "district_code": 321,
            "block_code": 3049,
            "id": 110998,
            "text": "KESHERGARH"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109750,
            "text": "DHANIRAMPUR-I"
        },
        {
            "district_code": 304,
            "block_code": 2753,
            "id": 108071,
            "text": "HATPUKURIA"
        },
        {
            "district_code": 320,
            "block_code": 3030,
            "id": 110810,
            "text": "BIROHI-II"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260977,
            "text": "NIM"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109786,
            "text": "KAMAKHYAGURI-I"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109363,
            "text": "DUMURDAHANITYANANDAPUR-I"
        },
        {
            "district_code": 305,
            "block_code": 2778,
            "id": 108330,
            "text": "GOBINDADHAM"
        },
        {
            "district_code": 321,
            "block_code": 3050,
            "id": 111007,
            "text": "ROPO"
        },
        {
            "district_code": 307,
            "block_code": 2829,
            "id": 108775,
            "text": "BATIKAR"
        },
        {
            "district_code": 321,
            "block_code": 3055,
            "id": 111058,
            "text": "KUMARI"
        },
        {
            "district_code": 316,
            "block_code": 2939,
            "id": 109923,
            "text": "ISLAMPUR"
        },
        {
            "district_code": 314,
            "block_code": 2930,
            "id": 109843,
            "text": "SULKAPARA"
        },
        {
            "district_code": 306,
            "block_code": 2823,
            "id": 108730,
            "text": "SHYAMSUNDAR"
        },
        {
            "district_code": 316,
            "block_code": 2941,
            "id": 109947,
            "text": "MOTHABARI"
        },
        {
            "district_code": 321,
            "block_code": 3049,
            "id": 110993,
            "text": "CHATUMADAR"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110920,
            "text": "NOKARI"
        },
        {
            "district_code": 317,
            "block_code": 2970,
            "id": 110211,
            "text": "KUKRAHATI"
        },
        {
            "district_code": 304,
            "block_code": 2761,
            "id": 108152,
            "text": "MADHUSUDANPUR"
        },
        {
            "district_code": 304,
            "block_code": 2753,
            "id": 108069,
            "text": "DIGHIRPAR"
        },
        {
            "district_code": 308,
            "block_code": 2852,
            "id": 109003,
            "text": "PACHAGARH"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110301,
            "text": "DUAN-II"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108800,
            "text": "JAMNA"
        },
        {
            "district_code": 303,
            "block_code": 2744,
            "id": 107969,
            "text": "BITHARI HAKIMPUR"
        },
        {
            "district_code": 321,
            "block_code": 3059,
            "id": 111087,
            "text": "CHAKALTORE"
        },
        {
            "district_code": 319,
            "block_code": 3022,
            "id": 110731,
            "text": "RANINAGAR-II"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109830,
            "text": "KHAGRABARI-II"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109512,
            "text": "SUGANDHA"
        },
        {
            "district_code": 303,
            "block_code": 2739,
            "id": 107930,
            "text": "GOBINDAKATI"
        },
        {
            "district_code": 317,
            "block_code": 2954,
            "id": 110064,
            "text": "BATHUARY"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109271,
            "text": "GOALPOKHAR"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108946,
            "text": "MOYAMARI"
        },
        {
            "district_code": 317,
            "block_code": 2965,
            "id": 110171,
            "text": "NAIPUR"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109413,
            "text": "GUDUBARI-II"
        },
        {
            "district_code": 320,
            "block_code": 3043,
            "id": 110945,
            "text": "BARNIA"
        },
        {
            "district_code": 703,
            "block_code": 2985,
            "id": 110358,
            "text": "TAPSHIA"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260960,
            "text": "LEBONG VALLEY-II"
        },
        {
            "district_code": 319,
            "block_code": 3012,
            "id": 110630,
            "text": "DEBIPUR"
        },
        {
            "district_code": 303,
            "block_code": 2731,
            "id": 107851,
            "text": "KHOLAPOTA"
        },
        {
            "district_code": 312,
            "block_code": 2891,
            "id": 109398,
            "text": "KODALIA-II"
        },
        {
            "district_code": 317,
            "block_code": 2950,
            "id": 110034,
            "text": "MAHISAGOT"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261009,
            "text": "PUDUNG"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108034,
            "text": "KULERDARI"
        },
        {
            "district_code": 320,
            "block_code": 3032,
            "id": 110836,
            "text": "KARIMPUR-I"
        },
        {
            "district_code": 306,
            "block_code": 2811,
            "id": 108613,
            "text": "AGRADWIP"
        },
        {
            "district_code": 317,
            "block_code": 2963,
            "id": 110142,
            "text": "AMDABAD-I"
        },
        {
            "district_code": 306,
            "block_code": 2816,
            "id": 108664,
            "text": "KUSUMGRAM"
        },
        {
            "district_code": 664,
            "block_code": 2924,
            "id": 109774,
            "text": "CHUAPARA"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109608,
            "text": "BEGARI"
        },
        {
            "district_code": 317,
            "block_code": 2947,
            "id": 110008,
            "text": "KOTBARH"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109525,
            "text": "BARUIPARAPALTAGARH"
        },
        {
            "district_code": 319,
            "block_code": 3022,
            "id": 110726,
            "text": "KATLAMARI-II"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110549,
            "text": "RADHARGHAT-I"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109031,
            "text": "CHILKHANA-I"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108031,
            "text": "DAKSHIN GAURIPUR CHAKDHIR"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109941,
            "text": "SILAMPUR-I"
        },
        {
            "district_code": 310,
            "block_code": 2871,
            "id": 109195,
            "text": "ELLAHABAD"
        },
        {
            "district_code": 307,
            "block_code": 2838,
            "id": 108861,
            "text": "BHADRAPUR-II"
        },
        {
            "district_code": 307,
            "block_code": 2841,
            "id": 108887,
            "text": "MASHRA"
        },
        {
            "district_code": 305,
            "block_code": 2793,
            "id": 108451,
            "text": "DHANSIMLA"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108905,
            "text": "HORISARA"
        },
        {
            "district_code": 307,
            "block_code": 2827,
            "id": 108764,
            "text": "SINGHEE"
        },
        {
            "district_code": 318,
            "block_code": 2984,
            "id": 110340,
            "text": "AJABNAGAR-I"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261038,
            "text": "SEETONG-I"
        },
        {
            "district_code": 313,
            "block_code": 2914,
            "id": 109672,
            "text": "RADHAPUR"
        },
        {
            "district_code": 307,
            "block_code": 2829,
            "id": 108779,
            "text": "ILLAMBAZAR"
        },
        {
            "district_code": 321,
            "block_code": 3045,
            "id": 110961,
            "text": "BAGHMUNDI"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107856,
            "text": "CHAWBERIA-I"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110217,
            "text": "PADUMPUR-I"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109443,
            "text": "JEJUR"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109337,
            "text": "GOURI"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108231,
            "text": "GILARCHHAT"
        },
        {
            "district_code": 318,
            "block_code": 2991,
            "id": 110419,
            "text": "VETIA"
        },
        {
            "district_code": 307,
            "block_code": 2842,
            "id": 108889,
            "text": "BISHNUPUR"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108312,
            "text": "SAHAJORA"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109764,
            "text": "BOALMARI-NANDANPUR"
        },
        {
            "district_code": 305,
            "block_code": 2780,
            "id": 108345,
            "text": "HATAGRAM"
        },
        {
            "district_code": 313,
            "block_code": 2918,
            "id": 109708,
            "text": "TEHATTA-KANTABERIA-II"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109655,
            "text": "KANDUA"
        },
        {
            "district_code": 307,
            "block_code": 2828,
            "id": 108773,
            "text": "PARULIA"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108944,
            "text": "HARIBHANGA"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110298,
            "text": "DEBRA-I"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109939,
            "text": "MOZAMPUR"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109577,
            "text": "NOYAPARA"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109272,
            "text": "GOTI"
        },
        {
            "district_code": 307,
            "block_code": 2828,
            "id": 108767,
            "text": "GOHALIARA"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109359,
            "text": "SALEPUR-II"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108281,
            "text": "PRATAPNAGAR"
        },
        {
            "district_code": 321,
            "block_code": 3057,
            "id": 111069,
            "text": "DEOLI"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110461,
            "text": "BARAKHAKRI"
        },
        {
            "district_code": 314,
            "block_code": 2928,
            "id": 109820,
            "text": "MATIALI HAT"
        },
        {
            "district_code": 318,
            "block_code": 2975,
            "id": 110251,
            "text": "BANDIPUR-II"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260979,
            "text": "POKHREYBONG"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110807,
            "text": "MAYURHAT-II"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109831,
            "text": "MADHABDANGA-I"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107869,
            "text": "TENGRA"
        },
        {
            "district_code": 319,
            "block_code": 3007,
            "id": 110581,
            "text": "SIMULIA"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109852,
            "text": "PANIKAURI"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109184,
            "text": "BOALDAR"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110518,
            "text": "CHAITANYAPUR-II"
        },
        {
            "district_code": 307,
            "block_code": 2839,
            "id": 108870,
            "text": "KIRNAHAR-I"
        },
        {
            "district_code": 305,
            "block_code": 2794,
            "id": 108465,
            "text": "KHALGRAM"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108804,
            "text": "THIBA"
        },
        {
            "district_code": 317,
            "block_code": 2949,
            "id": 110025,
            "text": "DIBAKARPUR"
        },
        {
            "district_code": 320,
            "block_code": 3030,
            "id": 110811,
            "text": "FATEPUR"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108960,
            "text": "GOSANIMARI-I"
        },
        {
            "district_code": 313,
            "block_code": 2914,
            "id": 109671,
            "text": "NABAGRAM"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109276,
            "text": "MAHUA"
        },
        {
            "district_code": 704,
            "block_code": 2802,
            "id": 108535,
            "text": "ICHHAPUR"
        },
        {
            "district_code": 307,
            "block_code": 2833,
            "id": 108815,
            "text": "DHEKA"
        },
        {
            "district_code": 312,
            "block_code": 2898,
            "id": 109474,
            "text": "CHINGRA"
        },
        {
            "district_code": 317,
            "block_code": 2963,
            "id": 110145,
            "text": "BOYAL-I"
        },
        {
            "district_code": 318,
            "block_code": 2978,
            "id": 110279,
            "text": "RAJNAGAR"
        },
        {
            "district_code": 317,
            "block_code": 2964,
            "id": 110154,
            "text": "KESHAPAT"
        },
        {
            "district_code": 312,
            "block_code": 2903,
            "id": 109539,
            "text": "PAYARAPUR"
        },
        {
            "district_code": 664,
            "block_code": 2926,
            "id": 109800,
            "text": "KHAYARBARI"
        },
        {
            "district_code": 305,
            "block_code": 2779,
            "id": 108339,
            "text": "MOLIAN"
        },
        {
            "district_code": 304,
            "block_code": 2766,
            "id": 108217,
            "text": "KECHARKUR"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261055,
            "text": "MANEYDARA"
        },
        {
            "district_code": 320,
            "block_code": 3034,
            "id": 110854,
            "text": "KRISHNAGANJ"
        },
        {
            "district_code": 309,
            "block_code": 2860,
            "id": 260996,
            "text": "RANGBUL"
        },
        {
            "district_code": 305,
            "block_code": 2787,
            "id": 108410,
            "text": "NARAYANPUR"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107857,
            "text": "CHAWBERIA-II"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108799,
            "text": "INDUS"
        },
        {
            "district_code": 320,
            "block_code": 3040,
            "id": 110922,
            "text": "RAGHUNATHPUR HIJULI-II"
        },
        {
            "district_code": 310,
            "block_code": 2874,
            "id": 109219,
            "text": "JAMALPUR"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108909,
            "text": "SREENIDHIPUR"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107861,
            "text": "GANGANANDAPUR"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109620,
            "text": "SHALAP-I"
        },
        {
            "district_code": 319,
            "block_code": 3004,
            "id": 110560,
            "text": "SARALPUR"
        },
        {
            "district_code": 316,
            "block_code": 2944,
            "id": 109982,
            "text": "MUCHIA"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107889,
            "text": "ICHAPUR-II"
        },
        {
            "district_code": 312,
            "block_code": 2887,
            "id": 109354,
            "text": "MALAYPUR-I"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260949,
            "text": "BADAMTAM"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109289,
            "text": "GOBINDAPUR"
        },
        {
            "district_code": 703,
            "block_code": 2973,
            "id": 110243,
            "text": "SHIMULPAL"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108260,
            "text": "RAMGANGA"
        },
        {
            "district_code": 321,
            "block_code": 3052,
            "id": 111023,
            "text": "CHITMU"
        },
        {
            "district_code": 317,
            "block_code": 2947,
            "id": 110004,
            "text": "BIBHISANPUR"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110120,
            "text": "BARGODAGODAR"
        },
        {
            "district_code": 307,
            "block_code": 2837,
            "id": 108857,
            "text": "PAIKPARA"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109771,
            "text": "PAHARPUR"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109723,
            "text": "CHAPORER PAR-II"
        },
        {
            "district_code": 304,
            "block_code": 2751,
            "id": 108052,
            "text": "MAYAPUR"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109653,
            "text": "DUILA"
        },
        {
            "district_code": 318,
            "block_code": 2993,
            "id": 110429,
            "text": "BANPURA"
        },
        {
            "district_code": 309,
            "block_code": 2868,
            "id": 109165,
            "text": "BIDHANNAGAR-I"
        },
        {
            "district_code": 312,
            "block_code": 2888,
            "id": 109361,
            "text": "BAKLIADHOBAPARA"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108976,
            "text": "NIJIRHAT-II"
        },
        {
            "district_code": 303,
            "block_code": 2730,
            "id": 107839,
            "text": "GOTRA"
        },
        {
            "district_code": 313,
            "block_code": 2915,
            "id": 109674,
            "text": "AMARDAHA"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109838,
            "text": "SAPTIBARI-II"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108240,
            "text": "RAIDIGHI"
        },
        {
            "district_code": 703,
            "block_code": 2972,
            "id": 110233,
            "text": "SIJUA"
        },
        {
            "district_code": 312,
            "block_code": 2904,
            "id": 109546,
            "text": "BHANJIPUR"
        },
        {
            "district_code": 703,
            "block_code": 2972,
            "id": 110224,
            "text": "ANDHARIA"
        },
        {
            "district_code": 317,
            "block_code": 2952,
            "id": 110050,
            "text": "BASANTIA"
        },
        {
            "district_code": 318,
            "block_code": 2979,
            "id": 110285,
            "text": "GOCHHATI"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110117,
            "text": "RAMCHAK"
        },
        {
            "district_code": 318,
            "block_code": 2978,
            "id": 110278,
            "text": "PANCHBERIA"
        },
        {
            "district_code": 321,
            "block_code": 3055,
            "id": 111054,
            "text": "BARI-JAGDA"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260963,
            "text": "MAZUWA"
        },
        {
            "district_code": 317,
            "block_code": 2960,
            "id": 110109,
            "text": "BAKCHA"
        },
        {
            "district_code": 306,
            "block_code": 2812,
            "id": 108625,
            "text": "NIROL"
        },
        {
            "district_code": 704,
            "block_code": 2826,
            "id": 108749,
            "text": "ETHORA"
        },
        {
            "district_code": 319,
            "block_code": 3005,
            "id": 110563,
            "text": "HANUMANTANAGAR"
        },
        {
            "district_code": 314,
            "block_code": 2930,
            "id": 109842,
            "text": "LUKSAN"
        },
        {
            "district_code": 303,
            "block_code": 2723,
            "id": 107780,
            "text": "BODAI"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109404,
            "text": "BHANDARHATI-II"
        },
        {
            "district_code": 316,
            "block_code": 2938,
            "id": 109919,
            "text": "RASHIDABAD"
        },
        {
            "district_code": 306,
            "block_code": 2822,
            "id": 108715,
            "text": "KALEKHANTALA-II"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110655,
            "text": "KIRTIPUR"
        },
        {
            "district_code": 304,
            "block_code": 2765,
            "id": 108204,
            "text": "MAGRAHAT PASCHIM"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109554,
            "text": "ANULIA"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109304,
            "text": "ITAHAR"
        },
        {
            "district_code": 304,
            "block_code": 2753,
            "id": 108072,
            "text": "ITKHOLA"
        },
        {
            "district_code": 305,
            "block_code": 2794,
            "id": 108461,
            "text": "AMDANGRA"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110456,
            "text": "PAKURSENI"
        },
        {
            "district_code": 321,
            "block_code": 3047,
            "id": 110977,
            "text": "BARABAZAR"
        },
        {
            "district_code": 319,
            "block_code": 3011,
            "id": 110624,
            "text": "KHIDIRPUR"
        },
        {
            "district_code": 704,
            "block_code": 2806,
            "id": 108578,
            "text": "SHYAMLA"
        },
        {
            "district_code": 316,
            "block_code": 2941,
            "id": 109946,
            "text": "HAMIDPUR"
        },
        {
            "district_code": 306,
            "block_code": 2797,
            "id": 108486,
            "text": "AMARPUR"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110385,
            "text": "RADHANAGAR"
        },
        {
            "district_code": 309,
            "block_code": 2869,
            "id": 261062,
            "text": "TACKLING-II"
        },
        {
            "district_code": 304,
            "block_code": 2764,
            "id": 108192,
            "text": "SIRAKOL"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109310,
            "text": "SURUN-II"
        },
        {
            "district_code": 304,
            "block_code": 2771,
            "id": 108265,
            "text": "DHASPARA SUMATINAGAR-II"
        },
        {
            "district_code": 304,
            "block_code": 2751,
            "id": 108051,
            "text": "CHINGRIPOTA"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108394,
            "text": "NAKAIJURI"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108045,
            "text": "MAUKHALI"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 261028,
            "text": "SHANGSE"
        },
        {
            "district_code": 320,
            "block_code": 3039,
            "id": 110909,
            "text": "TARAPUR"
        },
        {
            "district_code": 311,
            "block_code": 2884,
            "id": 109314,
            "text": "BOCHADANGA"
        },
        {
            "district_code": 306,
            "block_code": 2796,
            "id": 108482,
            "text": "DIGNAGAR-I"
        },
        {
            "district_code": 306,
            "block_code": 2815,
            "id": 108650,
            "text": "KAICHAR-I"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109963,
            "text": "LAKSHMIPUR"
        },
        {
            "district_code": 704,
            "block_code": 2806,
            "id": 108579,
            "text": "TAPSI"
        },
        {
            "district_code": 304,
            "block_code": 2763,
            "id": 108181,
            "text": "KUNDAKHALI GODABAR"
        },
        {
            "district_code": 319,
            "block_code": 3024,
            "id": 110749,
            "text": "NIMTITA"
        },
        {
            "district_code": 304,
            "block_code": 2773,
            "id": 108284,
            "text": "ASUTI-II"
        },
        {
            "district_code": 311,
            "block_code": 2882,
            "id": 109297,
            "text": "RAMGANJ-I"
        },
        {
            "district_code": 702,
            "block_code": 7354,
            "id": 261025,
            "text": "LOLE"
        },
        {
            "district_code": 321,
            "block_code": 3049,
            "id": 110996,
            "text": "JABARRAH"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 110099,
            "text": "AMRITABERIA"
        },
        {
            "district_code": 321,
            "block_code": 3049,
            "id": 110997,
            "text": "KALABANI"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110409,
            "text": "MUGBASAN"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110319,
            "text": "KHARKUSMA"
        },
        {
            "district_code": 317,
            "block_code": 2966,
            "id": 110176,
            "text": "PATASPUR"
        },
        {
            "district_code": 303,
            "block_code": 2743,
            "id": 107963,
            "text": "KHULNA"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109205,
            "text": "GANGARAMPUR"
        },
        {
            "district_code": 312,
            "block_code": 2902,
            "id": 109528,
            "text": "BIGHATI"
        },
        {
            "district_code": 312,
            "block_code": 2901,
            "id": 109514,
            "text": "CHILADANGI"
        },
        {
            "district_code": 319,
            "block_code": 3003,
            "id": 110539,
            "text": "BHAKURI-II"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109644,
            "text": "JUJARSAHA"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109845,
            "text": "DABGRAM-I"
        },
        {
            "district_code": 320,
            "block_code": 3037,
            "id": 110881,
            "text": "MAJDIA PANSILA"
        },
        {
            "district_code": 317,
            "block_code": 2966,
            "id": 110174,
            "text": "MATHURA"
        },
        {
            "district_code": 305,
            "block_code": 2795,
            "id": 108473,
            "text": "BHARA"
        },
        {
            "district_code": 313,
            "block_code": 2913,
            "id": 109663,
            "text": "THANAMAKUA"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109912,
            "text": "RISHIPUR"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109326,
            "text": "KARANDIGHI-II"
        },
        {
            "district_code": 307,
            "block_code": 2834,
            "id": 108829,
            "text": "MAHAMADBAZAR"
        },
        {
            "district_code": 303,
            "block_code": 2742,
            "id": 107955,
            "text": "NAZAT-I"
        },
        {
            "district_code": 703,
            "block_code": 3000,
            "id": 110504,
            "text": "ANDHARI"
        },
        {
            "district_code": 308,
            "block_code": 2855,
            "id": 109019,
            "text": "BHAWERTHANA"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108507,
            "text": "BHATAR"
        },
        {
            "district_code": 313,
            "block_code": 2916,
            "id": 109685,
            "text": "HARALI UDAYNARAYANPUR"
        },
        {
            "district_code": 316,
            "block_code": 2937,
            "id": 109908,
            "text": "HABIBPUR"
        },
        {
            "district_code": 312,
            "block_code": 2891,
            "id": 109392,
            "text": "BANDEL"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109752,
            "text": "FALAKATA-I"
        },
        {
            "district_code": 305,
            "block_code": 2794,
            "id": 108463,
            "text": "FULMATI"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109751,
            "text": "DHANIRAMPUR-II"
        },
        {
            "district_code": 305,
            "block_code": 2781,
            "id": 108350,
            "text": "AMRUL"
        },
        {
            "district_code": 305,
            "block_code": 2795,
            "id": 108471,
            "text": "BANKADAHA"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109754,
            "text": "GUABARNAGAR"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107892,
            "text": "JHAUDANGA"
        },
        {
            "district_code": 312,
            "block_code": 2896,
            "id": 109457,
            "text": "RADHANAGAR"
        },
        {
            "district_code": 321,
            "block_code": 3060,
            "id": 111096,
            "text": "BHANGRA"
        },
        {
            "district_code": 304,
            "block_code": 2748,
            "id": 108019,
            "text": "BEENTA-I"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 108000,
            "text": "CHUNAKHALI"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110791,
            "text": "HATKHOLA"
        },
        {
            "district_code": 318,
            "block_code": 2976,
            "id": 110258,
            "text": "ANGUA"
        },
        {
            "district_code": 704,
            "block_code": 2825,
            "id": 108741,
            "text": "EGRA"
        },
        {
            "district_code": 317,
            "block_code": 2967,
            "id": 110185,
            "text": "PADIMA-II"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110216,
            "text": "NILKUNTHIA"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110894,
            "text": "DOGACHHIA"
        },
        {
            "district_code": 704,
            "block_code": 2819,
            "id": 108695,
            "text": "KHANDARA"
        },
        {
            "district_code": 702,
            "block_code": 2862,
            "id": 261019,
            "text": "DALAPCHAND"
        },
        {
            "district_code": 303,
            "block_code": 2728,
            "id": 107829,
            "text": "MAMUDPUR"
        },
        {
            "district_code": 317,
            "block_code": 2969,
            "id": 110203,
            "text": "RAGHUNATHPUR-II"
        },
        {
            "district_code": 311,
            "block_code": 2885,
            "id": 109331,
            "text": "RASAKHOWA-II"
        },
        {
            "district_code": 303,
            "block_code": 2741,
            "id": 107948,
            "text": "PATHARGHATA"
        },
        {
            "district_code": 305,
            "block_code": 2781,
            "id": 108357,
            "text": "SAHASPUR"
        },
        {
            "district_code": 306,
            "block_code": 2808,
            "id": 108588,
            "text": "ATGHORIASIMLAN"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110897,
            "text": "MURAGACHHA"
        },
        {
            "district_code": 320,
            "block_code": 3043,
            "id": 110946,
            "text": "GOPINATHPUR"
        },
        {
            "district_code": 320,
            "block_code": 3027,
            "id": 110768,
            "text": "CHANDURIA-I"
        },
        {
            "district_code": 318,
            "block_code": 2981,
            "id": 110312,
            "text": "AMLAGORA"
        },
        {
            "district_code": 313,
            "block_code": 2914,
            "id": 109668,
            "text": "DHANDALI"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 244954,
            "text": "RAMNAGAR BARACHUPRIA-II"
        },
        {
            "district_code": 321,
            "block_code": 3048,
            "id": 110989,
            "text": "KUCHIA"
        },
        {
            "district_code": 307,
            "block_code": 2828,
            "id": 108768,
            "text": "HETAMPUR"
        },
        {
            "district_code": 304,
            "block_code": 2749,
            "id": 108033,
            "text": "KEORADANGA"
        },
        {
            "district_code": 320,
            "block_code": 3032,
            "id": 110835,
            "text": "JAMASHERPUR"
        },
        {
            "district_code": 303,
            "block_code": 2729,
            "id": 107836,
            "text": "PATULIA"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107887,
            "text": "FULSARA"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110805,
            "text": "MAMJOAN"
        },
        {
            "district_code": 317,
            "block_code": 2956,
            "id": 110078,
            "text": "KAMARDA"
        },
        {
            "district_code": 303,
            "block_code": 2742,
            "id": 107956,
            "text": "NAZAT-II"
        },
        {
            "district_code": 317,
            "block_code": 2957,
            "id": 110083,
            "text": "JANKA"
        },
        {
            "district_code": 318,
            "block_code": 2999,
            "id": 110497,
            "text": "DEBGRAM"
        },
        {
            "district_code": 319,
            "block_code": 3012,
            "id": 110635,
            "text": "KHAYRAMARI"
        },
        {
            "district_code": 307,
            "block_code": 2830,
            "id": 108789,
            "text": "LOKEPUR"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110129,
            "text": "SEORABERIAJALPAI-I"
        },
        {
            "district_code": 316,
            "block_code": 2943,
            "id": 109977,
            "text": "UTTAR CHANDIPUR"
        },
        {
            "district_code": 307,
            "block_code": 2827,
            "id": 108760,
            "text": "RUPPUR"
        },
        {
            "district_code": 316,
            "block_code": 2940,
            "id": 109936,
            "text": "JALUABADHAL"
        },
        {
            "district_code": 316,
            "block_code": 2945,
            "id": 109991,
            "text": "MAHANANDATOLA"
        },
        {
            "district_code": 304,
            "block_code": 2760,
            "id": 108142,
            "text": "BELEDURGANAGAR"
        },
        {
            "district_code": 317,
            "block_code": 2949,
            "id": 110030,
            "text": "OSMANPUR"
        },
        {
            "district_code": 304,
            "block_code": 2746,
            "id": 108003,
            "text": "JYOTISHPUR"
        },
        {
            "district_code": 311,
            "block_code": 2881,
            "id": 109282,
            "text": "BISHNUPUR"
        },
        {
            "district_code": 311,
            "block_code": 2880,
            "id": 109275,
            "text": "LODHAN"
        },
        {
            "district_code": 307,
            "block_code": 2831,
            "id": 108794,
            "text": "BIPRATIKURI"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109343,
            "text": "RAMPUR"
        },
        {
            "district_code": 304,
            "block_code": 2770,
            "id": 108248,
            "text": "ACHINTYANAGAR"
        },
        {
            "district_code": 319,
            "block_code": 3025,
            "id": 110755,
            "text": "HARUA"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108120,
            "text": "GOSABA"
        },
        {
            "district_code": 317,
            "block_code": 2956,
            "id": 110075,
            "text": "BIRBANDAR"
        },
        {
            "district_code": 321,
            "block_code": 3044,
            "id": 110954,
            "text": "CHATUHANSA"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109611,
            "text": "KOLORA-I"
        },
        {
            "district_code": 664,
            "block_code": 2922,
            "id": 109748,
            "text": "DALGAON"
        },
        {
            "district_code": 320,
            "block_code": 3038,
            "id": 110886,
            "text": "BETHUADAHARI-II"
        },
        {
            "district_code": 319,
            "block_code": 3024,
            "id": 110751,
            "text": "TINPUKURIA"
        },
        {
            "district_code": 313,
            "block_code": 2912,
            "id": 109641,
            "text": "DEULPUR"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110125,
            "text": "DAKSHINNARIKELDA"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109791,
            "text": "NEWLAND KUMARGRAM SANKOSH"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109829,
            "text": "KHAGRABARI-I"
        },
        {
            "district_code": 313,
            "block_code": 2906,
            "id": 109579,
            "text": "THALIA"
        },
        {
            "district_code": 305,
            "block_code": 2795,
            "id": 108475,
            "text": "LAYEKBANDH"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108239,
            "text": "RADHAKANTAPUR"
        },
        {
            "district_code": 703,
            "block_code": 2985,
            "id": 110357,
            "text": "PETBINDHI"
        },
        {
            "district_code": 309,
            "block_code": 2868,
            "id": 109168,
            "text": "PHANSIDEWA BANSGAON KISMAT"
        },
        {
            "district_code": 305,
            "block_code": 2775,
            "id": 108297,
            "text": "KOSTHIA"
        },
        {
            "district_code": 312,
            "block_code": 2904,
            "id": 109545,
            "text": "BALIGORI-II"
        },
        {
            "district_code": 306,
            "block_code": 2818,
            "id": 108688,
            "text": "BOHAR-II"
        },
        {
            "district_code": 321,
            "block_code": 3061,
            "id": 111104,
            "text": "BABUGRAM"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107983,
            "text": "HARDHAH"
        },
        {
            "district_code": 664,
            "block_code": 2920,
            "id": 109724,
            "text": "KOHINOOR"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110382,
            "text": "MANIKPARA"
        },
        {
            "district_code": 312,
            "block_code": 2890,
            "id": 109383,
            "text": "BAKSA"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108902,
            "text": "DERIAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2961,
            "id": 110127,
            "text": "KUMARARA"
        },
        {
            "district_code": 313,
            "block_code": 2908,
            "id": 109593,
            "text": "HALYAN"
        },
        {
            "district_code": 313,
            "block_code": 2909,
            "id": 109600,
            "text": "DURGAPUR ABHAYNAGAR-I"
        },
        {
            "district_code": 317,
            "block_code": 2953,
            "id": 110056,
            "text": "CHATRI"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110660,
            "text": "SADAL"
        },
        {
            "district_code": 703,
            "block_code": 2985,
            "id": 110353,
            "text": "CHORCHITA"
        },
        {
            "district_code": 316,
            "block_code": 2936,
            "id": 109897,
            "text": "MAJHRA"
        },
        {
            "district_code": 303,
            "block_code": 2733,
            "id": 107879,
            "text": "HADIPUR JHIKRA-II"
        },
        {
            "district_code": 306,
            "block_code": 2821,
            "id": 108712,
            "text": "SREERAMPUR"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109562,
            "text": "RASPUR"
        },
        {
            "district_code": 320,
            "block_code": 3035,
            "id": 110865,
            "text": "DIGNAGAR"
        },
        {
            "district_code": 318,
            "block_code": 2994,
            "id": 110442,
            "text": "TANUA"
        },
        {
            "district_code": 703,
            "block_code": 2985,
            "id": 110355,
            "text": "KULIANA"
        },
        {
            "district_code": 320,
            "block_code": 3039,
            "id": 110908,
            "text": "RAMNAGAR-II"
        },
        {
            "district_code": 306,
            "block_code": 2799,
            "id": 108511,
            "text": "MAHATA"
        },
        {
            "district_code": 317,
            "block_code": 2952,
            "id": 110054,
            "text": "SARADA"
        },
        {
            "district_code": 311,
            "block_code": 2886,
            "id": 109332,
            "text": "BAHIN"
        },
        {
            "district_code": 305,
            "block_code": 2783,
            "id": 108373,
            "text": "SUPUR"
        },
        {
            "district_code": 304,
            "block_code": 2747,
            "id": 108010,
            "text": "CHANDANESWAR-I"
        },
        {
            "district_code": 306,
            "block_code": 2814,
            "id": 108640,
            "text": "SAGRHAI"
        },
        {
            "district_code": 314,
            "block_code": 2921,
            "id": 109740,
            "text": "JHARALTAGRAM-I"
        },
        {
            "district_code": 316,
            "block_code": 2938,
            "id": 109917,
            "text": "KUSIDHA"
        },
        {
            "district_code": 306,
            "block_code": 2801,
            "id": 108524,
            "text": "BAIKUNTHAPUR-I"
        },
        {
            "district_code": 308,
            "block_code": 2854,
            "id": 109016,
            "text": "SITAI-I"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260965,
            "text": "RANGIT-I"
        },
        {
            "district_code": 703,
            "block_code": 2986,
            "id": 110361,
            "text": "GOPIBALLAVPUR"
        },
        {
            "district_code": 318,
            "block_code": 2997,
            "id": 110474,
            "text": "JALCHAK-II"
        },
        {
            "district_code": 308,
            "block_code": 2854,
            "id": 109013,
            "text": "ADABARI"
        },
        {
            "district_code": 317,
            "block_code": 2965,
            "id": 110163,
            "text": "AMARSHI-I"
        },
        {
            "district_code": 305,
            "block_code": 2793,
            "id": 108458,
            "text": "PEARBERA"
        },
        {
            "district_code": 313,
            "block_code": 2905,
            "id": 109560,
            "text": "KHARDAH"
        },
        {
            "district_code": 304,
            "block_code": 2759,
            "id": 108129,
            "text": "BAHARU KSHETRA"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109446,
            "text": "NALIKULPURBA"
        },
        {
            "district_code": 318,
            "block_code": 2990,
            "id": 110407,
            "text": "KALAGRAM"
        },
        {
            "district_code": 310,
            "block_code": 2877,
            "id": 109243,
            "text": "HAZRATPUR"
        },
        {
            "district_code": 311,
            "block_code": 2878,
            "id": 109255,
            "text": "SONAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110093,
            "text": "KOLA-I"
        },
        {
            "district_code": 304,
            "block_code": 2763,
            "id": 108178,
            "text": "GURGURIA BHUBANESWARI"
        },
        {
            "district_code": 319,
            "block_code": 3020,
            "id": 110716,
            "text": "TEGHARI-I"
        },
        {
            "district_code": 309,
            "block_code": 2863,
            "id": 109130,
            "text": "BINNABARI"
        },
        {
            "district_code": 316,
            "block_code": 2939,
            "id": 109927,
            "text": "SADLICHAK"
        },
        {
            "district_code": 306,
            "block_code": 2817,
            "id": 108681,
            "text": "NIMO-I"
        },
        {
            "district_code": 303,
            "block_code": 2743,
            "id": 107961,
            "text": "DURGAMANDOP"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110828,
            "text": "PALITBEGIA"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108901,
            "text": "BHROMORKOL"
        },
        {
            "district_code": 320,
            "block_code": 3030,
            "id": 110815,
            "text": "MOLLABELIA"
        },
        {
            "district_code": 303,
            "block_code": 2742,
            "id": 107951,
            "text": "BAYERMARI-I"
        },
        {
            "district_code": 319,
            "block_code": 3010,
            "id": 110617,
            "text": "MAHESHPUR"
        },
        {
            "district_code": 704,
            "block_code": 2820,
            "id": 108703,
            "text": "HARIPURA"
        },
        {
            "district_code": 312,
            "block_code": 2891,
            "id": 109394,
            "text": "CHANDRAHATI-II"
        },
        {
            "district_code": 304,
            "block_code": 2768,
            "id": 108238,
            "text": "NANDAKUMARPUR"
        },
        {
            "district_code": 314,
            "block_code": 2931,
            "id": 109844,
            "text": "BINNAGURI"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109046,
            "text": "MAHISKUCHI-I"
        },
        {
            "district_code": 317,
            "block_code": 2971,
            "id": 110223,
            "text": "UTTARSONAMUI"
        },
        {
            "district_code": 317,
            "block_code": 2970,
            "id": 110208,
            "text": "GUABERIA"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107866,
            "text": "KALUPUR"
        },
        {
            "district_code": 311,
            "block_code": 2879,
            "id": 109260,
            "text": "NIJAMPUR-I"
        },
        {
            "district_code": 306,
            "block_code": 2800,
            "id": 108523,
            "text": "SARAITIKAR"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260974,
            "text": "GARUBATHAN-I"
        },
        {
            "district_code": 305,
            "block_code": 2794,
            "id": 108468,
            "text": "SATMOULI"
        },
        {
            "district_code": 310,
            "block_code": 2872,
            "id": 109203,
            "text": "CHALOON"
        },
        {
            "district_code": 306,
            "block_code": 2805,
            "id": 108558,
            "text": "ABUJHATI-II"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109047,
            "text": "RAMPUR-I"
        },
        {
            "district_code": 306,
            "block_code": 2800,
            "id": 108520,
            "text": "KURMUN-I"
        },
        {
            "district_code": 318,
            "block_code": 2978,
            "id": 110277,
            "text": "NIZNARAJOL"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108319,
            "text": "JAMTORA"
        },
        {
            "district_code": 307,
            "block_code": 2833,
            "id": 108819,
            "text": "SATPALSA"
        },
        {
            "district_code": 303,
            "block_code": 2732,
            "id": 107855,
            "text": "BAIRAMPUR"
        },
        {
            "district_code": 320,
            "block_code": 7115,
            "id": 110778,
            "text": "SARATI"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110742,
            "text": "SAGARDIGHI"
        },
        {
            "district_code": 311,
            "block_code": 2883,
            "id": 109309,
            "text": "SURUN-I"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110304,
            "text": "KHANAMOHAN"
        },
        {
            "district_code": 304,
            "block_code": 2750,
            "id": 108043,
            "text": "KANGANBERIA"
        },
        {
            "district_code": 312,
            "block_code": 2901,
            "id": 109519,
            "text": "SHYAMPUR"
        },
        {
            "district_code": 702,
            "block_code": 2859,
            "id": 260978,
            "text": "PATENGODAK"
        },
        {
            "district_code": 317,
            "block_code": 2958,
            "id": 110090,
            "text": "DERIACHAK"
        },
        {
            "district_code": 319,
            "block_code": 3012,
            "id": 110629,
            "text": "CHOAPARA"
        },
        {
            "district_code": 306,
            "block_code": 2822,
            "id": 108716,
            "text": "MAJDIA"
        },
        {
            "district_code": 319,
            "block_code": 3011,
            "id": 110619,
            "text": "BEHARIA"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108973,
            "text": "GOBRA CHHARA NAYARHAT"
        },
        {
            "district_code": 664,
            "block_code": 2925,
            "id": 109792,
            "text": "RAIDAK"
        },
        {
            "district_code": 306,
            "block_code": 2800,
            "id": 108521,
            "text": "RAYAN-I"
        },
        {
            "district_code": 318,
            "block_code": 2980,
            "id": 110300,
            "text": "DUAN-I"
        },
        {
            "district_code": 704,
            "block_code": 2825,
            "id": 108742,
            "text": "JEMERI"
        },
        {
            "district_code": 703,
            "block_code": 2988,
            "id": 110388,
            "text": "SHALBONI"
        },
        {
            "district_code": 304,
            "block_code": 2757,
            "id": 108107,
            "text": "DEBIPUR"
        },
        {
            "district_code": 308,
            "block_code": 2852,
            "id": 109002,
            "text": "NAYARHAT"
        },
        {
            "district_code": 305,
            "block_code": 2794,
            "id": 108469,
            "text": "TALDANGRA"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109957,
            "text": "BEERNAGAR-II"
        },
        {
            "district_code": 318,
            "block_code": 2976,
            "id": 110259,
            "text": "CHAKISMAILPUR"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109507,
            "text": "MAHANAD"
        },
        {
            "district_code": 303,
            "block_code": 2734,
            "id": 107894,
            "text": "SHIMULPUR"
        },
        {
            "district_code": 317,
            "block_code": 2950,
            "id": 110033,
            "text": "HAIPUR"
        },
        {
            "district_code": 305,
            "block_code": 2777,
            "id": 108325,
            "text": "TEGHORI"
        },
        {
            "district_code": 316,
            "block_code": 2945,
            "id": 109988,
            "text": "CHANDMONI-II"
        },
        {
            "district_code": 704,
            "block_code": 2809,
            "id": 108597,
            "text": "AMLAJORA"
        },
        {
            "district_code": 303,
            "block_code": 2744,
            "id": 107968,
            "text": "BANKRA GOKULPUR"
        },
        {
            "district_code": 319,
            "block_code": 3023,
            "id": 110734,
            "text": "BARALA"
        },
        {
            "district_code": 318,
            "block_code": 2995,
            "id": 110445,
            "text": "BELDA-II"
        },
        {
            "district_code": 320,
            "block_code": 3029,
            "id": 110808,
            "text": "RAMNAGAR BARACHUPRIA-I"
        },
        {
            "district_code": 307,
            "block_code": 2843,
            "id": 108903,
            "text": "FULUR"
        },
        {
            "district_code": 319,
            "block_code": 3006,
            "id": 110572,
            "text": "GADDA"
        },
        {
            "district_code": 703,
            "block_code": 2985,
            "id": 110354,
            "text": "KHARBANDHI"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109050,
            "text": "SALBARI-II"
        },
        {
            "district_code": 308,
            "block_code": 2851,
            "id": 108988,
            "text": "GHOKSARDANGA"
        },
        {
            "district_code": 312,
            "block_code": 2899,
            "id": 109492,
            "text": "JAYERDWARBASINI"
        },
        {
            "district_code": 702,
            "block_code": 2861,
            "id": 261003,
            "text": "DUNGRA"
        },
        {
            "district_code": 303,
            "block_code": 2740,
            "id": 107937,
            "text": "ATPUKUR"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261041,
            "text": "SHIVAKHOLA"
        },
        {
            "district_code": 319,
            "block_code": 3001,
            "id": 110515,
            "text": "BHABTA-I"
        },
        {
            "district_code": 308,
            "block_code": 2856,
            "id": 109037,
            "text": "NAKKATIGACHH"
        },
        {
            "district_code": 303,
            "block_code": 2735,
            "id": 107902,
            "text": "RAUTARA"
        },
        {
            "district_code": 306,
            "block_code": 2801,
            "id": 108526,
            "text": "BANDUL-II"
        },
        {
            "district_code": 314,
            "block_code": 2928,
            "id": 109822,
            "text": "MATIALI-BATABARI-II"
        },
        {
            "district_code": 313,
            "block_code": 2909,
            "id": 109599,
            "text": "CHAMRAIL"
        },
        {
            "district_code": 319,
            "block_code": 3021,
            "id": 110722,
            "text": "TENKARAIPUR BALUMATI"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109767,
            "text": "KHARIJA-BERUBARI-I"
        },
        {
            "district_code": 310,
            "block_code": 2876,
            "id": 109229,
            "text": "AKCHA"
        },
        {
            "district_code": 320,
            "block_code": 3031,
            "id": 110819,
            "text": "DEBAGRAM"
        },
        {
            "district_code": 308,
            "block_code": 2857,
            "id": 109042,
            "text": "BHANUKUMARI-I"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109715,
            "text": "PURBA KANTHALBARI"
        },
        {
            "district_code": 304,
            "block_code": 2745,
            "id": 107977,
            "text": "BEGUMPUR"
        },
        {
            "district_code": 306,
            "block_code": 2813,
            "id": 108629,
            "text": "BERUGRAM"
        },
        {
            "district_code": 310,
            "block_code": 2870,
            "id": 109190,
            "text": "JALGHAR"
        },
        {
            "district_code": 316,
            "block_code": 2942,
            "id": 109953,
            "text": "AKANDABARIA"
        },
        {
            "district_code": 305,
            "block_code": 2786,
            "id": 108390,
            "text": "KANTABARI"
        },
        {
            "district_code": 320,
            "block_code": 7115,
            "id": 110775,
            "text": "MADANPUR-I"
        },
        {
            "district_code": 319,
            "block_code": 3007,
            "id": 110582,
            "text": "TALIBPUR"
        },
        {
            "district_code": 703,
            "block_code": 2996,
            "id": 110465,
            "text": "CHANDRAREKHA"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108965,
            "text": "PUTIMARI-I"
        },
        {
            "district_code": 313,
            "block_code": 2909,
            "id": 109598,
            "text": "CHAKPARA ANANDANAGAR"
        },
        {
            "district_code": 306,
            "block_code": 2824,
            "id": 108738,
            "text": "UCHALAN"
        },
        {
            "district_code": 307,
            "block_code": 2838,
            "id": 108858,
            "text": "BARA-I"
        },
        {
            "district_code": 305,
            "block_code": 2776,
            "id": 108309,
            "text": "KHANRARI"
        },
        {
            "district_code": 703,
            "block_code": 3000,
            "id": 110512,
            "text": "ROHINI"
        },
        {
            "district_code": 303,
            "block_code": 2744,
            "id": 107975,
            "text": "SWARUPNAGAR BANGLANI"
        },
        {
            "district_code": 313,
            "block_code": 2909,
            "id": 109597,
            "text": "BALI"
        },
        {
            "district_code": 318,
            "block_code": 2991,
            "id": 110418,
            "text": "KHELARH"
        },
        {
            "district_code": 312,
            "block_code": 2892,
            "id": 109417,
            "text": "PERAMBUASAHABAZAR"
        },
        {
            "district_code": 316,
            "block_code": 2934,
            "id": 109871,
            "text": "CHANDRAPARA"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109634,
            "text": "SHANKARHATI-I"
        },
        {
            "district_code": 303,
            "block_code": 2737,
            "id": 107917,
            "text": "KULTI"
        },
        {
            "district_code": 314,
            "block_code": 2929,
            "id": 109828,
            "text": "DOMOHONI-II"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109765,
            "text": "GARALBARI"
        },
        {
            "district_code": 704,
            "block_code": 2825,
            "id": 108743,
            "text": "RATIBATI"
        },
        {
            "district_code": 309,
            "block_code": 2864,
            "id": 261040,
            "text": "SETTONG-III"
        },
        {
            "district_code": 304,
            "block_code": 2772,
            "id": 108282,
            "text": "SONARPUR-II"
        },
        {
            "district_code": 317,
            "block_code": 2959,
            "id": 110101,
            "text": "GARHKAMALPUR"
        },
        {
            "district_code": 305,
            "block_code": 2782,
            "id": 108362,
            "text": "MOYNAPUR"
        },
        {
            "district_code": 308,
            "block_code": 2849,
            "id": 108977,
            "text": "SAHEBGANJ"
        },
        {
            "district_code": 308,
            "block_code": 2847,
            "id": 108949,
            "text": "PUTIMARI-FULESWARI"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109717,
            "text": "SHALKUMAR-II"
        },
        {
            "district_code": 304,
            "block_code": 2748,
            "id": 108020,
            "text": "BEENTA-II"
        },
        {
            "district_code": 304,
            "block_code": 2762,
            "id": 108164,
            "text": "CHANDIPUR"
        },
        {
            "district_code": 304,
            "block_code": 2758,
            "id": 108125,
            "text": "RADHANAGAR-TARANAGAR"
        },
        {
            "district_code": 309,
            "block_code": 2858,
            "id": 260966,
            "text": "RANGIT-II"
        },
        {
            "district_code": 308,
            "block_code": 2848,
            "id": 108962,
            "text": "MATALHAT"
        },
        {
            "district_code": 320,
            "block_code": 3033,
            "id": 110847,
            "text": "NARAYANPUR-II"
        },
        {
            "district_code": 664,
            "block_code": 2919,
            "id": 109718,
            "text": "TAPSIKHATA"
        },
        {
            "district_code": 307,
            "block_code": 2830,
            "id": 108790,
            "text": "NAKRAKONDA"
        },
        {
            "district_code": 309,
            "block_code": 2865,
            "id": 109148,
            "text": "ATHARAKHAI"
        },
        {
            "district_code": 313,
            "block_code": 2911,
            "id": 109624,
            "text": "BARAGACHHIA-II"
        },
        {
            "district_code": 321,
            "block_code": 3053,
            "id": 111038,
            "text": "RANGAMATI-RANJANDIH"
        },
        {
            "district_code": 312,
            "block_code": 2895,
            "id": 109440,
            "text": "DWARHATTA"
        },
        {
            "district_code": 307,
            "block_code": 2844,
            "id": 108912,
            "text": "KARIDHYA"
        },
        {
            "district_code": 312,
            "block_code": 2900,
            "id": 109501,
            "text": "AKHNA"
        },
        {
            "district_code": 311,
            "block_code": 2878,
            "id": 109254,
            "text": "MAJHIALI"
        },
        {
            "district_code": 318,
            "block_code": 2997,
            "id": 110477,
            "text": "KSHIRAI"
        },
        {
            "district_code": 305,
            "block_code": 2792,
            "id": 108449,
            "text": "PARSOLA"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110654,
            "text": "KHARGRAM"
        },
        {
            "district_code": 306,
            "block_code": 2824,
            "id": 108735,
            "text": "PAHALANPUR"
        },
        {
            "district_code": 303,
            "block_code": 2744,
            "id": 107976,
            "text": "TEPUR MIRZAPUR"
        },
        {
            "district_code": 314,
            "block_code": 2923,
            "id": 109770,
            "text": "NAGAR BERUBARI"
        },
        {
            "district_code": 319,
            "block_code": 3014,
            "id": 110650,
            "text": "EROALI"
        },
        {
            "district_code": 313,
            "block_code": 2915,
            "id": 109680,
            "text": "NAKOL"
        },
        {
            "district_code": 319,
            "block_code": 3021,
            "id": 110721,
            "text": "PAHARPUR"
        },
        {
            "district_code": 306,
            "block_code": 2823,
            "id": 108726,
            "text": "NATU"
        },
        {
            "district_code": 317,
            "block_code": 2962,
            "id": 110134,
            "text": "GOKULNAGAR"
        },
        {
            "district_code": 306,
            "block_code": 2823,
            "id": 108724,
            "text": "MUGURA"
        },
        {
            "district_code": 313,
            "block_code": 2910,
            "id": 109619,
            "text": "RUDRAPUR"
        },
        {
            "district_code": 704,
            "block_code": 2802,
            "id": 108537,
            "text": "LAUDOHA"
        },
        {
            "district_code": 317,
            "block_code": 2967,
            "id": 110186,
            "text": "TALGACHHARI-I"
        },
        {
            "district_code": 307,
            "block_code": 2835,
            "id": 108839,
            "text": "RAJGRAM"
        },
        {
            "district_code": 303,
            "block_code": 2738,
            "id": 107927,
            "text": "PATLIKHANPUR"
        },
        {
            "district_code": 303,
            "block_code": 2724,
            "id": 107798,
            "text": "SAYESTANAGAR-II"
        },
        {
            "district_code": 304,
            "block_code": 2767,
            "id": 108223,
            "text": "KRISHNACHANDRAPUR"
        },
        {
            "district_code": 317,
            "block_code": 2954,
            "id": 110067,
            "text": "MANJUSREE"
        },
        {
            "district_code": 312,
            "block_code": 2889,
            "id": 109380,
            "text": "MASAT"
        },
        {
            "district_code": 320,
            "block_code": 3028,
            "id": 110787,
            "text": "BRITTIHUDA"
        },
        {
            "district_code": 314,
            "block_code": 7483,
            "id": 109746,
            "text": "SALBARI-I"
        },
        {
            "district_code": 314,
            "block_code": 7483,
            "id": 109747,
            "text": "SALBARI-II"
        },
        {
            "district_code": 314,
            "block_code": 7483,
            "id": 109732,
            "text": "BANARHAT-I"
        },
        {
            "district_code": 314,
            "block_code": 7483,
            "id": 109736,
            "text": "CHAMURCHI"
        },
        {
            "district_code": 314,
            "block_code": 7483,
            "id": 109733,
            "text": "BANARHAT-II"
        },
        {
            "district_code": 314,
            "block_code": 7483,
            "id": 109744,
            "text": "SAKOYAJHORA-I"
        },
        {
            "district_code": 314,
            "block_code": 7483,
            "id": 109735,
            "text": "BINNAGURI"
        },
        {
            "district_code": 314,
            "block_code": 7484,
            "id": 109812,
            "text": "LATAGURI"
        },
        {
            "district_code": 314,
            "block_code": 7484,
            "id": 109813,
            "text": "MOULANI"
        },
        {
            "district_code": 314,
            "block_code": 7484,
            "id": 109810,
            "text": "JKRANTI"
        },
        {
            "district_code": 314,
            "block_code": 7484,
            "id": 109808,
            "text": "CHAPADANGA"
        },
        {
            "district_code": 314,
            "block_code": 7484,
            "id": 109807,
            "text": "CHANGMARI"
        },
        {
            "district_code": 314,
            "block_code": 7484,
            "id": 109815,
            "text": "RAJADANGA"
        }
    ];




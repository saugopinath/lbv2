window.masterDataV2 = window.masterDataV2 || {};

window.masterDataV2.ulb_wards= [
        {
            "urban_body_code": 249946,
            "id": 13464,
            "text": "Darjiling (M) - Ward No.1"
        },
        {
            "urban_body_code": 249946,
            "id": 13465,
            "text": "Darjiling (M) - Ward No.2"
        },
        {
            "urban_body_code": 249946,
            "id": 13466,
            "text": "Darjiling (M) - Ward No.3"
        },
        {
            "urban_body_code": 249946,
            "id": 13467,
            "text": "Darjiling (M) - Ward No.4"
        },
        {
            "urban_body_code": 249946,
            "id": 13468,
            "text": "Darjiling (M) - Ward No.5"
        },
        {
            "urban_body_code": 249946,
            "id": 13469,
            "text": "Darjiling (M) - Ward No.6"
        },
        {
            "urban_body_code": 249946,
            "id": 13470,
            "text": "Darjiling (M) - Ward No.7"
        },
        {
            "urban_body_code": 249946,
            "id": 13471,
            "text": "Darjiling (M) - Ward No.8"
        },
        {
            "urban_body_code": 249946,
            "id": 13479,
            "text": "Darjiling (M) - Ward No.9"
        },
        {
            "urban_body_code": 249946,
            "id": 13480,
            "text": "Darjiling (M) - Ward No.10"
        },
        {
            "urban_body_code": 249946,
            "id": 13481,
            "text": "Darjiling (M) - Ward No.11"
        },
        {
            "urban_body_code": 249946,
            "id": 13482,
            "text": "Darjiling (M) - Ward No.12"
        },
        {
            "urban_body_code": 249946,
            "id": 13483,
            "text": "Darjiling (M) - Ward No.13"
        },
        {
            "urban_body_code": 249946,
            "id": 13484,
            "text": "Darjiling (M) - Ward No.14"
        },
        {
            "urban_body_code": 249946,
            "id": 13485,
            "text": "Darjiling (M) - Ward No.15"
        },
        {
            "urban_body_code": 249946,
            "id": 13486,
            "text": "Darjiling (M) - Ward No.16"
        },
        {
            "urban_body_code": 249946,
            "id": 13472,
            "text": "Darjiling (M) - Ward No.17"
        },
        {
            "urban_body_code": 249946,
            "id": 13473,
            "text": "Darjiling (M) - Ward No.18"
        },
        {
            "urban_body_code": 249946,
            "id": 13474,
            "text": "Darjiling (M) - Ward No.19"
        },
        {
            "urban_body_code": 249946,
            "id": 13475,
            "text": "Darjiling (M) - Ward No.20"
        },
        {
            "urban_body_code": 249946,
            "id": 13476,
            "text": "Darjiling (M) - Ward No.21"
        },
        {
            "urban_body_code": 249946,
            "id": 13477,
            "text": "Darjiling (M) - Ward No.22"
        },
        {
            "urban_body_code": 249946,
            "id": 13478,
            "text": "Darjiling (M) - Ward No.23"
        },
        {
            "urban_body_code": 249946,
            "id": 13490,
            "text": "Darjiling (M) - Ward No.24"
        },
        {
            "urban_body_code": 249946,
            "id": 13487,
            "text": "Darjiling (M) - Ward No.25"
        },
        {
            "urban_body_code": 249946,
            "id": 13488,
            "text": "Darjiling (M) - Ward No.26"
        },
        {
            "urban_body_code": 249946,
            "id": 13489,
            "text": "Darjiling (M) - Ward No.27"
        },
        {
            "urban_body_code": 249946,
            "id": 13491,
            "text": "Darjiling (M) - Ward No.28"
        },
        {
            "urban_body_code": 249946,
            "id": 13492,
            "text": "Darjiling (M) - Ward No.29"
        },
        {
            "urban_body_code": 249946,
            "id": 13493,
            "text": "Darjiling (M) - Ward No.30"
        },
        {
            "urban_body_code": 249946,
            "id": 13494,
            "text": "Darjiling (M) - Ward No.31"
        },
        {
            "urban_body_code": 249946,
            "id": 13495,
            "text": "Darjiling (M) - Ward No.32"
        },
        {
            "urban_body_code": 249947,
            "id": 13496,
            "text": "Kalimpong (M) - Ward No.1"
        },
        {
            "urban_body_code": 249947,
            "id": 13497,
            "text": "Kalimpong (M) - Ward No.2"
        },
        {
            "urban_body_code": 249947,
            "id": 13498,
            "text": "Kalimpong (M) - Ward No.3"
        },
        {
            "urban_body_code": 249947,
            "id": 13499,
            "text": "Kalimpong (M) - Ward No.4"
        },
        {
            "urban_body_code": 249947,
            "id": 13500,
            "text": "Kalimpong (M) - Ward No.5"
        },
        {
            "urban_body_code": 249947,
            "id": 13501,
            "text": "Kalimpong (M) - Ward No.6"
        },
        {
            "urban_body_code": 249947,
            "id": 13502,
            "text": "Kalimpong (M) - Ward No.7"
        },
        {
            "urban_body_code": 249947,
            "id": 13503,
            "text": "Kalimpong (M) - Ward No.8"
        },
        {
            "urban_body_code": 249947,
            "id": 13504,
            "text": "Kalimpong (M) - Ward No.9"
        },
        {
            "urban_body_code": 249947,
            "id": 13505,
            "text": "Kalimpong (M) - Ward No.10"
        },
        {
            "urban_body_code": 249947,
            "id": 13506,
            "text": "Kalimpong (M) - Ward No.11"
        },
        {
            "urban_body_code": 249947,
            "id": 13507,
            "text": "Kalimpong (M) - Ward No.12"
        },
        {
            "urban_body_code": 249947,
            "id": 13508,
            "text": "Kalimpong (M) - Ward No.13"
        },
        {
            "urban_body_code": 249947,
            "id": 13509,
            "text": "Kalimpong (M) - Ward No.14"
        },
        {
            "urban_body_code": 249947,
            "id": 13510,
            "text": "Kalimpong (M) - Ward No.15"
        },
        {
            "urban_body_code": 249947,
            "id": 13511,
            "text": "Kalimpong (M) - Ward No.16"
        },
        {
            "urban_body_code": 249947,
            "id": 13512,
            "text": "Kalimpong (M) - Ward No.17"
        },
        {
            "urban_body_code": 249947,
            "id": 13513,
            "text": "Kalimpong (M) - Ward No.18"
        },
        {
            "urban_body_code": 249947,
            "id": 13514,
            "text": "Kalimpong (M) - Ward No.19"
        },
        {
            "urban_body_code": 249947,
            "id": 13515,
            "text": "Kalimpong (M) - Ward No.20"
        },
        {
            "urban_body_code": 249947,
            "id": 13516,
            "text": "Kalimpong (M) - Ward No.21"
        },
        {
            "urban_body_code": 249947,
            "id": 13517,
            "text": "Kalimpong (M) - Ward No.22"
        },
        {
            "urban_body_code": 249947,
            "id": 13518,
            "text": "Kalimpong (M) - Ward No.23"
        },
        {
            "urban_body_code": 249948,
            "id": 66441,
            "text": "Mirik (NA) - Ward No.1"
        },
        {
            "urban_body_code": 249948,
            "id": 66442,
            "text": "Mirik (NA) - Ward No.2"
        },
        {
            "urban_body_code": 249948,
            "id": 66443,
            "text": "Mirik (NA) - Ward No.3"
        },
        {
            "urban_body_code": 249948,
            "id": 66402,
            "text": "Mirik (NA) - Ward No.4"
        },
        {
            "urban_body_code": 249948,
            "id": 66403,
            "text": "Mirik (NA) - Ward No.5"
        },
        {
            "urban_body_code": 249948,
            "id": 66404,
            "text": "Mirik (NA) - Ward No.6"
        },
        {
            "urban_body_code": 249948,
            "id": 66405,
            "text": "Mirik (NA) - Ward No.7"
        },
        {
            "urban_body_code": 249948,
            "id": 66406,
            "text": "Mirik (NA) - Ward No.8"
        },
        {
            "urban_body_code": 249948,
            "id": 66407,
            "text": "Mirik (NA) - Ward No.9"
        },
        {
            "urban_body_code": 249949,
            "id": 13443,
            "text": "Kurseong (M) - Ward No.1"
        },
        {
            "urban_body_code": 249949,
            "id": 13444,
            "text": "Kurseong (M) - Ward No.2"
        },
        {
            "urban_body_code": 249949,
            "id": 13445,
            "text": "Kurseong (M) - Ward No.3"
        },
        {
            "urban_body_code": 249949,
            "id": 13446,
            "text": "Kurseong (M) - Ward No.4"
        },
        {
            "urban_body_code": 249949,
            "id": 13447,
            "text": "Kurseong (M) - Ward No.5"
        },
        {
            "urban_body_code": 249949,
            "id": 13448,
            "text": "Kurseong (M) - Ward No.6"
        },
        {
            "urban_body_code": 249949,
            "id": 13449,
            "text": "Kurseong (M) - Ward No.7"
        },
        {
            "urban_body_code": 249949,
            "id": 13450,
            "text": "Kurseong (M) - Ward No.8"
        },
        {
            "urban_body_code": 249949,
            "id": 13451,
            "text": "Kurseong (M) - Ward No.9"
        },
        {
            "urban_body_code": 249949,
            "id": 13452,
            "text": "Kurseong (M) - Ward No.10"
        },
        {
            "urban_body_code": 249949,
            "id": 13453,
            "text": "Kurseong (M) - Ward No.11"
        },
        {
            "urban_body_code": 249949,
            "id": 13454,
            "text": "Kurseong (M) - Ward No.12"
        },
        {
            "urban_body_code": 249949,
            "id": 13455,
            "text": "Kurseong (M) - Ward No.13"
        },
        {
            "urban_body_code": 249949,
            "id": 13456,
            "text": "Kurseong (M) - Ward No.14"
        },
        {
            "urban_body_code": 249949,
            "id": 13457,
            "text": "Kurseong (M) - Ward No.15"
        },
        {
            "urban_body_code": 249949,
            "id": 13458,
            "text": "Kurseong (M) - Ward No.16"
        },
        {
            "urban_body_code": 249949,
            "id": 13459,
            "text": "Kurseong (M) - Ward No.17"
        },
        {
            "urban_body_code": 249949,
            "id": 13460,
            "text": "Kurseong (M) - Ward No.18"
        },
        {
            "urban_body_code": 249949,
            "id": 13461,
            "text": "Kurseong (M) - Ward No.19"
        },
        {
            "urban_body_code": 249949,
            "id": 13462,
            "text": "Kurseong (M) - Ward No.20"
        },
        {
            "urban_body_code": 249955,
            "id": 13525,
            "text": "Mal (M) - Ward No.1"
        },
        {
            "urban_body_code": 249955,
            "id": 13526,
            "text": "Mal (M) - Ward No.2"
        },
        {
            "urban_body_code": 249955,
            "id": 13527,
            "text": "Mal (M) - Ward No.3"
        },
        {
            "urban_body_code": 249955,
            "id": 13528,
            "text": "Mal (M) - Ward No.4"
        },
        {
            "urban_body_code": 249955,
            "id": 13521,
            "text": "Mal (M) - Ward No.5"
        },
        {
            "urban_body_code": 249955,
            "id": 13522,
            "text": "Mal (M) - Ward No.6"
        },
        {
            "urban_body_code": 249955,
            "id": 13523,
            "text": "Mal (M) - Ward No.7"
        },
        {
            "urban_body_code": 249955,
            "id": 13524,
            "text": "Mal (M) - Ward No.8"
        },
        {
            "urban_body_code": 249955,
            "id": 13529,
            "text": "Mal (M) - Ward No.9"
        },
        {
            "urban_body_code": 249955,
            "id": 13530,
            "text": "Mal (M) - Ward No.10"
        },
        {
            "urban_body_code": 249955,
            "id": 13531,
            "text": "Mal (M) - Ward No.11"
        },
        {
            "urban_body_code": 249955,
            "id": 13532,
            "text": "Mal (M) - Ward No.12"
        },
        {
            "urban_body_code": 249955,
            "id": 13533,
            "text": "Mal (M) - Ward No.13"
        },
        {
            "urban_body_code": 249955,
            "id": 13534,
            "text": "Mal (M) - Ward No.14"
        },
        {
            "urban_body_code": 249955,
            "id": 13535,
            "text": "Mal (M) - Ward No.15"
        },
        {
            "urban_body_code": 249955,
            "id": 13536,
            "text": "Mal (M) - Ward No.16"
        },
        {
            "urban_body_code": 249956,
            "id": 13537,
            "text": "Jalpaiguri (M) - Ward No.1"
        },
        {
            "urban_body_code": 249956,
            "id": 13538,
            "text": "Jalpaiguri (M) - Ward No.2"
        },
        {
            "urban_body_code": 249956,
            "id": 13539,
            "text": "Jalpaiguri (M) - Ward No.3"
        },
        {
            "urban_body_code": 249956,
            "id": 13540,
            "text": "Jalpaiguri (M) - Ward No.4"
        },
        {
            "urban_body_code": 249956,
            "id": 13541,
            "text": "Jalpaiguri (M) - Ward No.5"
        },
        {
            "urban_body_code": 249956,
            "id": 13542,
            "text": "Jalpaiguri (M) - Ward No.6"
        },
        {
            "urban_body_code": 249956,
            "id": 13543,
            "text": "Jalpaiguri (M) - Ward No.7"
        },
        {
            "urban_body_code": 249956,
            "id": 13544,
            "text": "Jalpaiguri (M) - Ward No.8"
        },
        {
            "urban_body_code": 249956,
            "id": 13545,
            "text": "Jalpaiguri (M) - Ward No.9"
        },
        {
            "urban_body_code": 249956,
            "id": 13546,
            "text": "Jalpaiguri (M) - Ward No.10"
        },
        {
            "urban_body_code": 249956,
            "id": 13547,
            "text": "Jalpaiguri (M) - Ward No.11"
        },
        {
            "urban_body_code": 249956,
            "id": 13548,
            "text": "Jalpaiguri (M) - Ward No.12"
        },
        {
            "urban_body_code": 249956,
            "id": 13549,
            "text": "Jalpaiguri (M) - Ward No.13"
        },
        {
            "urban_body_code": 249956,
            "id": 13550,
            "text": "Jalpaiguri (M) - Ward No.14"
        },
        {
            "urban_body_code": 249956,
            "id": 13551,
            "text": "Jalpaiguri (M) - Ward No.15"
        },
        {
            "urban_body_code": 249956,
            "id": 13552,
            "text": "Jalpaiguri (M) - Ward No.16"
        },
        {
            "urban_body_code": 249956,
            "id": 13553,
            "text": "Jalpaiguri (M) - Ward No.17"
        },
        {
            "urban_body_code": 249956,
            "id": 13554,
            "text": "Jalpaiguri (M) - Ward No.18"
        },
        {
            "urban_body_code": 249956,
            "id": 13555,
            "text": "Jalpaiguri (M) - Ward No.19"
        },
        {
            "urban_body_code": 249956,
            "id": 13556,
            "text": "Jalpaiguri (M) - Ward No.20"
        },
        {
            "urban_body_code": 249956,
            "id": 13557,
            "text": "Jalpaiguri (M) - Ward No.21"
        },
        {
            "urban_body_code": 249956,
            "id": 13558,
            "text": "Jalpaiguri (M) - Ward No.22"
        },
        {
            "urban_body_code": 249956,
            "id": 13559,
            "text": "Jalpaiguri (M) - Ward No.23"
        },
        {
            "urban_body_code": 249956,
            "id": 13560,
            "text": "Jalpaiguri (M) - Ward No.24"
        },
        {
            "urban_body_code": 249956,
            "id": 13561,
            "text": "Jalpaiguri (M) - Ward No.25"
        },
        {
            "urban_body_code": 249957,
            "id": 9999379,
            "text": "Siliguri (M Corp.) - Ward No.1"
        },
        {
            "urban_body_code": 249957,
            "id": 9999380,
            "text": "Siliguri (M Corp.) - Ward No.2"
        },
        {
            "urban_body_code": 249957,
            "id": 9999381,
            "text": "Siliguri (M Corp.) - Ward No.3"
        },
        {
            "urban_body_code": 249957,
            "id": 9999382,
            "text": "Siliguri (M Corp.) - Ward No.4"
        },
        {
            "urban_body_code": 249957,
            "id": 9999383,
            "text": "Siliguri (M Corp.) - Ward No.5"
        },
        {
            "urban_body_code": 249957,
            "id": 9999384,
            "text": "Siliguri (M Corp.) - Ward No.6"
        },
        {
            "urban_body_code": 249957,
            "id": 9999385,
            "text": "Siliguri (M Corp.) - Ward No.7"
        },
        {
            "urban_body_code": 249957,
            "id": 9999386,
            "text": "Siliguri (M Corp.) - Ward No.8"
        },
        {
            "urban_body_code": 249957,
            "id": 9999387,
            "text": "Siliguri (M Corp.) - Ward No.9"
        },
        {
            "urban_body_code": 249957,
            "id": 9999388,
            "text": "Siliguri (M Corp.) - Ward No.10"
        },
        {
            "urban_body_code": 249957,
            "id": 9999389,
            "text": "Siliguri (M Corp.) - Ward No.11"
        },
        {
            "urban_body_code": 249957,
            "id": 9999390,
            "text": "Siliguri (M Corp.) - Ward No.12"
        },
        {
            "urban_body_code": 249957,
            "id": 9999391,
            "text": "Siliguri (M Corp.) - Ward No.13"
        },
        {
            "urban_body_code": 249957,
            "id": 9999392,
            "text": "Siliguri (M Corp.) - Ward No.14"
        },
        {
            "urban_body_code": 249957,
            "id": 9999393,
            "text": "Siliguri (M Corp.) - Ward No.15"
        },
        {
            "urban_body_code": 249957,
            "id": 9999394,
            "text": "Siliguri (M Corp.) - Ward No.16"
        },
        {
            "urban_body_code": 249957,
            "id": 9999395,
            "text": "Siliguri (M Corp.) - Ward No.17"
        },
        {
            "urban_body_code": 249957,
            "id": 9999396,
            "text": "Siliguri (M Corp.) - Ward No.18"
        },
        {
            "urban_body_code": 249957,
            "id": 9999397,
            "text": "Siliguri (M Corp.) - Ward No.19"
        },
        {
            "urban_body_code": 249957,
            "id": 9999398,
            "text": "Siliguri (M Corp.) - Ward No.20"
        },
        {
            "urban_body_code": 249957,
            "id": 9999399,
            "text": "Siliguri (M Corp.) - Ward No.21"
        },
        {
            "urban_body_code": 249957,
            "id": 9999400,
            "text": "Siliguri (M Corp.) - Ward No.22"
        },
        {
            "urban_body_code": 249957,
            "id": 9999401,
            "text": "Siliguri (M Corp.) - Ward No.23"
        },
        {
            "urban_body_code": 249957,
            "id": 9999402,
            "text": "Siliguri (M Corp.) - Ward No.24"
        },
        {
            "urban_body_code": 249957,
            "id": 9999403,
            "text": "Siliguri (M Corp.) - Ward No.25"
        },
        {
            "urban_body_code": 249957,
            "id": 9999404,
            "text": "Siliguri (M Corp.) - Ward No.26"
        },
        {
            "urban_body_code": 249957,
            "id": 9999405,
            "text": "Siliguri (M Corp.) - Ward No.27"
        },
        {
            "urban_body_code": 249957,
            "id": 9999406,
            "text": "Siliguri (M Corp.) - Ward No.28"
        },
        {
            "urban_body_code": 249957,
            "id": 9999407,
            "text": "Siliguri (M Corp.) - Ward No.29"
        },
        {
            "urban_body_code": 249957,
            "id": 9999408,
            "text": "Siliguri (M Corp.) - Ward No.30"
        },
        {
            "urban_body_code": 249957,
            "id": 9999409,
            "text": "Siliguri (M Corp.) - Ward No.45"
        },
        {
            "urban_body_code": 249957,
            "id": 9999410,
            "text": "Siliguri (M Corp.) - Ward No.46"
        },
        {
            "urban_body_code": 249957,
            "id": 9999411,
            "text": "Siliguri (M Corp.) - Ward No.47"
        },
        {
            "urban_body_code": 249958,
            "id": 66459,
            "text": "Alipurduar (M) - Ward No.1"
        },
        {
            "urban_body_code": 249958,
            "id": 66460,
            "text": "Alipurduar (M) - Ward No.2"
        },
        {
            "urban_body_code": 249958,
            "id": 66461,
            "text": "Alipurduar (M) - Ward No.3"
        },
        {
            "urban_body_code": 249958,
            "id": 66462,
            "text": "Alipurduar (M) - Ward No.4"
        },
        {
            "urban_body_code": 249958,
            "id": 66463,
            "text": "Alipurduar (M) - Ward No.5"
        },
        {
            "urban_body_code": 249958,
            "id": 66464,
            "text": "Alipurduar (M) - Ward No.6"
        },
        {
            "urban_body_code": 249958,
            "id": 66465,
            "text": "Alipurduar (M) - Ward No.7"
        },
        {
            "urban_body_code": 249958,
            "id": 66466,
            "text": "Alipurduar (M) - Ward No.8"
        },
        {
            "urban_body_code": 249958,
            "id": 66467,
            "text": "Alipurduar (M) - Ward No.9"
        },
        {
            "urban_body_code": 249958,
            "id": 66468,
            "text": "Alipurduar (M) - Ward No.10"
        },
        {
            "urban_body_code": 249958,
            "id": 66469,
            "text": "Alipurduar (M) - Ward No.11"
        },
        {
            "urban_body_code": 249958,
            "id": 66470,
            "text": "Alipurduar (M) - Ward No.12"
        },
        {
            "urban_body_code": 249958,
            "id": 66471,
            "text": "Alipurduar (M) - Ward No.13"
        },
        {
            "urban_body_code": 249958,
            "id": 66472,
            "text": "Alipurduar (M) - Ward No.14"
        },
        {
            "urban_body_code": 249958,
            "id": 66473,
            "text": "Alipurduar (M) - Ward No.15"
        },
        {
            "urban_body_code": 249958,
            "id": 66474,
            "text": "Alipurduar (M) - Ward No.16"
        },
        {
            "urban_body_code": 249958,
            "id": 66475,
            "text": "Alipurduar (M) - Ward No.17"
        },
        {
            "urban_body_code": 249958,
            "id": 66476,
            "text": "Alipurduar (M) - Ward No.18"
        },
        {
            "urban_body_code": 249958,
            "id": 66477,
            "text": "Alipurduar (M) - Ward No.19"
        },
        {
            "urban_body_code": 249958,
            "id": 66478,
            "text": "Alipurduar (M) - Ward No.20"
        },
        {
            "urban_body_code": 249970,
            "id": 13573,
            "text": "Dhupguri (CT) - Ward No.1"
        },
        {
            "urban_body_code": 249970,
            "id": 9999251,
            "text": "Dhupguri (CT) - Ward No.2"
        },
        {
            "urban_body_code": 249970,
            "id": 9999252,
            "text": "Dhupguri (CT) - Ward No.3"
        },
        {
            "urban_body_code": 249970,
            "id": 9999253,
            "text": "Dhupguri (CT) - Ward No.4"
        },
        {
            "urban_body_code": 249970,
            "id": 9999254,
            "text": "Dhupguri (CT) - Ward No.5"
        },
        {
            "urban_body_code": 249970,
            "id": 9999255,
            "text": "Dhupguri (CT) - Ward No.6"
        },
        {
            "urban_body_code": 249970,
            "id": 9999256,
            "text": "Dhupguri (CT) - Ward No.7"
        },
        {
            "urban_body_code": 249970,
            "id": 9999257,
            "text": "Dhupguri (CT) - Ward No.8"
        },
        {
            "urban_body_code": 249970,
            "id": 9999258,
            "text": "Dhupguri (CT) - Ward No.9"
        },
        {
            "urban_body_code": 249970,
            "id": 9999259,
            "text": "Dhupguri (CT) - Ward No.10"
        },
        {
            "urban_body_code": 249970,
            "id": 9999260,
            "text": "Dhupguri (CT) - Ward No.11"
        },
        {
            "urban_body_code": 249970,
            "id": 9999261,
            "text": "Dhupguri (CT) - Ward No.12"
        },
        {
            "urban_body_code": 249970,
            "id": 9999262,
            "text": "Dhupguri (CT) - Ward No.13"
        },
        {
            "urban_body_code": 249970,
            "id": 9999263,
            "text": "Dhupguri (CT) - Ward No.14"
        },
        {
            "urban_body_code": 249970,
            "id": 9999264,
            "text": "Dhupguri (CT) - Ward No.15"
        },
        {
            "urban_body_code": 249970,
            "id": 9999265,
            "text": "Dhupguri (CT) - Ward No.16"
        },
        {
            "urban_body_code": 249972,
            "id": 13578,
            "text": "Haldibari (M) - Ward No.1"
        },
        {
            "urban_body_code": 249972,
            "id": 13579,
            "text": "Haldibari (M) - Ward No.2"
        },
        {
            "urban_body_code": 249972,
            "id": 13580,
            "text": "Haldibari (M) - Ward No.3"
        },
        {
            "urban_body_code": 249972,
            "id": 13581,
            "text": "Haldibari (M) - Ward No.4"
        },
        {
            "urban_body_code": 249972,
            "id": 13575,
            "text": "Haldibari (M) - Ward No.5"
        },
        {
            "urban_body_code": 249972,
            "id": 13576,
            "text": "Haldibari (M) - Ward No.6"
        },
        {
            "urban_body_code": 249972,
            "id": 13577,
            "text": "Haldibari (M) - Ward No.7"
        },
        {
            "urban_body_code": 249972,
            "id": 13582,
            "text": "Haldibari (M) - Ward No.8"
        },
        {
            "urban_body_code": 249972,
            "id": 13583,
            "text": "Haldibari (M) - Ward No.9"
        },
        {
            "urban_body_code": 249972,
            "id": 13584,
            "text": "Haldibari (M) - Ward No.10"
        },
        {
            "urban_body_code": 249972,
            "id": 13585,
            "text": "Haldibari (M) - Ward No.11"
        },
        {
            "urban_body_code": 249973,
            "id": 66479,
            "text": "Mekliganj (M) - Ward No.1"
        },
        {
            "urban_body_code": 249973,
            "id": 66480,
            "text": "Mekliganj (M) - Ward No.2"
        },
        {
            "urban_body_code": 249973,
            "id": 66481,
            "text": "Mekliganj (M) - Ward No.3"
        },
        {
            "urban_body_code": 249973,
            "id": 66482,
            "text": "Mekliganj (M) - Ward No.4"
        },
        {
            "urban_body_code": 249973,
            "id": 66483,
            "text": "Mekliganj (M) - Ward No.5"
        },
        {
            "urban_body_code": 249973,
            "id": 66484,
            "text": "Mekliganj (M) - Ward No.6"
        },
        {
            "urban_body_code": 249973,
            "id": 66485,
            "text": "Mekliganj (M) - Ward No.7"
        },
        {
            "urban_body_code": 249973,
            "id": 66486,
            "text": "Mekliganj (M) - Ward No.8"
        },
        {
            "urban_body_code": 249973,
            "id": 66487,
            "text": "Mekliganj (M) - Ward No.9"
        },
        {
            "urban_body_code": 249974,
            "id": 13586,
            "text": "Mathabhanga (M) - Ward No.1"
        },
        {
            "urban_body_code": 249974,
            "id": 13587,
            "text": "Mathabhanga (M) - Ward No.2"
        },
        {
            "urban_body_code": 249974,
            "id": 13588,
            "text": "Mathabhanga (M) - Ward No.3"
        },
        {
            "urban_body_code": 249974,
            "id": 13589,
            "text": "Mathabhanga (M) - Ward No.4"
        },
        {
            "urban_body_code": 249974,
            "id": 13590,
            "text": "Mathabhanga (M) - Ward No.5"
        },
        {
            "urban_body_code": 249974,
            "id": 13591,
            "text": "Mathabhanga (M) - Ward No.6"
        },
        {
            "urban_body_code": 249974,
            "id": 13592,
            "text": "Mathabhanga (M) - Ward No.7"
        },
        {
            "urban_body_code": 249974,
            "id": 13593,
            "text": "Mathabhanga (M) - Ward No.8"
        },
        {
            "urban_body_code": 249974,
            "id": 13594,
            "text": "Mathabhanga (M) - Ward No.9"
        },
        {
            "urban_body_code": 249974,
            "id": 13595,
            "text": "Mathabhanga (M) - Ward No.10"
        },
        {
            "urban_body_code": 249974,
            "id": 13596,
            "text": "Mathabhanga (M) - Ward No.11"
        },
        {
            "urban_body_code": 249974,
            "id": 13597,
            "text": "Mathabhanga (M) - Ward No.12"
        },
        {
            "urban_body_code": 249975,
            "id": 13598,
            "text": "Koch Bihar (M) - Ward No.1"
        },
        {
            "urban_body_code": 249975,
            "id": 13599,
            "text": "Koch Bihar (M) - Ward No.2"
        },
        {
            "urban_body_code": 249975,
            "id": 13600,
            "text": "Koch Bihar (M) - Ward No.3"
        },
        {
            "urban_body_code": 249975,
            "id": 13601,
            "text": "Koch Bihar (M) - Ward No.4"
        },
        {
            "urban_body_code": 249975,
            "id": 13602,
            "text": "Koch Bihar (M) - Ward No.5"
        },
        {
            "urban_body_code": 249975,
            "id": 13603,
            "text": "Koch Bihar (M) - Ward No.6"
        },
        {
            "urban_body_code": 249975,
            "id": 13604,
            "text": "Koch Bihar (M) - Ward No.7"
        },
        {
            "urban_body_code": 249975,
            "id": 13605,
            "text": "Koch Bihar (M) - Ward No.8"
        },
        {
            "urban_body_code": 249975,
            "id": 13606,
            "text": "Koch Bihar (M) - Ward No.9"
        },
        {
            "urban_body_code": 249975,
            "id": 13607,
            "text": "Koch Bihar (M) - Ward No.10"
        },
        {
            "urban_body_code": 249975,
            "id": 13608,
            "text": "Koch Bihar (M) - Ward No.11"
        },
        {
            "urban_body_code": 249975,
            "id": 13609,
            "text": "Koch Bihar (M) - Ward No.12"
        },
        {
            "urban_body_code": 249975,
            "id": 13610,
            "text": "Koch Bihar (M) - Ward No.13"
        },
        {
            "urban_body_code": 249975,
            "id": 13611,
            "text": "Koch Bihar (M) - Ward No.14"
        },
        {
            "urban_body_code": 249975,
            "id": 13612,
            "text": "Koch Bihar (M) - Ward No.15"
        },
        {
            "urban_body_code": 249975,
            "id": 13613,
            "text": "Koch Bihar (M) - Ward No.16"
        },
        {
            "urban_body_code": 249975,
            "id": 13614,
            "text": "Koch Bihar (M) - Ward No.17"
        },
        {
            "urban_body_code": 249975,
            "id": 13615,
            "text": "Koch Bihar (M) - Ward No.18"
        },
        {
            "urban_body_code": 249975,
            "id": 13616,
            "text": "Koch Bihar (M) - Ward No.19"
        },
        {
            "urban_body_code": 249975,
            "id": 13617,
            "text": "Koch Bihar (M) - Ward No.20"
        },
        {
            "urban_body_code": 249976,
            "id": 66488,
            "text": "Tufanganj (M) - Ward No.1"
        },
        {
            "urban_body_code": 249976,
            "id": 66489,
            "text": "Tufanganj (M) - Ward No.2"
        },
        {
            "urban_body_code": 249976,
            "id": 66490,
            "text": "Tufanganj (M) - Ward No.3"
        },
        {
            "urban_body_code": 249976,
            "id": 66491,
            "text": "Tufanganj (M) - Ward No.4"
        },
        {
            "urban_body_code": 249976,
            "id": 66492,
            "text": "Tufanganj (M) - Ward No.5"
        },
        {
            "urban_body_code": 249976,
            "id": 66493,
            "text": "Tufanganj (M) - Ward No.6"
        },
        {
            "urban_body_code": 249976,
            "id": 66494,
            "text": "Tufanganj (M) - Ward No.7"
        },
        {
            "urban_body_code": 249976,
            "id": 66495,
            "text": "Tufanganj (M) - Ward No.8"
        },
        {
            "urban_body_code": 249976,
            "id": 66496,
            "text": "Tufanganj (M) - Ward No.9"
        },
        {
            "urban_body_code": 249976,
            "id": 66497,
            "text": "Tufanganj (M) - Ward No.10"
        },
        {
            "urban_body_code": 249976,
            "id": 66498,
            "text": "Tufanganj (M) - Ward No.11"
        },
        {
            "urban_body_code": 249976,
            "id": 66499,
            "text": "Tufanganj (M) - Ward No.12"
        },
        {
            "urban_body_code": 249977,
            "id": 13618,
            "text": "Dinhata (M) - Ward No.1"
        },
        {
            "urban_body_code": 249977,
            "id": 13619,
            "text": "Dinhata (M) - Ward No.2"
        },
        {
            "urban_body_code": 249977,
            "id": 13620,
            "text": "Dinhata (M) - Ward No.3"
        },
        {
            "urban_body_code": 249977,
            "id": 13621,
            "text": "Dinhata (M) - Ward No.4"
        },
        {
            "urban_body_code": 249977,
            "id": 13622,
            "text": "Dinhata (M) - Ward No.5"
        },
        {
            "urban_body_code": 249977,
            "id": 13623,
            "text": "Dinhata (M) - Ward No.6"
        },
        {
            "urban_body_code": 249977,
            "id": 13624,
            "text": "Dinhata (M) - Ward No.7"
        },
        {
            "urban_body_code": 249977,
            "id": 13625,
            "text": "Dinhata (M) - Ward No.8"
        },
        {
            "urban_body_code": 249977,
            "id": 13626,
            "text": "Dinhata (M) - Ward No.9"
        },
        {
            "urban_body_code": 249977,
            "id": 13627,
            "text": "Dinhata (M) - Ward No.10"
        },
        {
            "urban_body_code": 249977,
            "id": 13628,
            "text": "Dinhata (M) - Ward No.11"
        },
        {
            "urban_body_code": 249977,
            "id": 13629,
            "text": "Dinhata (M) - Ward No.12"
        },
        {
            "urban_body_code": 249977,
            "id": 13630,
            "text": "Dinhata (M) - Ward No.13"
        },
        {
            "urban_body_code": 249977,
            "id": 13631,
            "text": "Dinhata (M) - Ward No.14"
        },
        {
            "urban_body_code": 249977,
            "id": 13632,
            "text": "Dinhata (M) - Ward No.15"
        },
        {
            "urban_body_code": 249977,
            "id": 13633,
            "text": "Dinhata (M) - Ward No.16"
        },
        {
            "urban_body_code": 249982,
            "id": 13641,
            "text": "Islampur (M) - Ward No.1"
        },
        {
            "urban_body_code": 249982,
            "id": 13642,
            "text": "Islampur (M) - Ward No.2"
        },
        {
            "urban_body_code": 249982,
            "id": 13643,
            "text": "Islampur (M) - Ward No.3"
        },
        {
            "urban_body_code": 249982,
            "id": 13644,
            "text": "Islampur (M) - Ward No.4"
        },
        {
            "urban_body_code": 249982,
            "id": 13637,
            "text": "Islampur (M) - Ward No.5"
        },
        {
            "urban_body_code": 249982,
            "id": 13638,
            "text": "Islampur (M) - Ward No.6"
        },
        {
            "urban_body_code": 249982,
            "id": 13639,
            "text": "Islampur (M) - Ward No.7"
        },
        {
            "urban_body_code": 249982,
            "id": 13640,
            "text": "Islampur (M) - Ward No.8"
        },
        {
            "urban_body_code": 249982,
            "id": 13645,
            "text": "Islampur (M) - Ward No.9"
        },
        {
            "urban_body_code": 249982,
            "id": 13646,
            "text": "Islampur (M) - Ward No.10"
        },
        {
            "urban_body_code": 249982,
            "id": 13647,
            "text": "Islampur (M) - Ward No.11"
        },
        {
            "urban_body_code": 249982,
            "id": 13648,
            "text": "Islampur (M) - Ward No.12"
        },
        {
            "urban_body_code": 249982,
            "id": 13649,
            "text": "Islampur (M) - Ward No.13"
        },
        {
            "urban_body_code": 249982,
            "id": 13650,
            "text": "Islampur (M) - Ward No.14"
        },
        {
            "urban_body_code": 249982,
            "id": 9999331,
            "text": "Islampur (M) - Ward No.15"
        },
        {
            "urban_body_code": 249982,
            "id": 9999332,
            "text": "Islampur (M) - Ward No.16"
        },
        {
            "urban_body_code": 249982,
            "id": 9999333,
            "text": "Islampur (M) - Ward No.17"
        },
        {
            "urban_body_code": 249983,
            "id": 13651,
            "text": "Raiganj (M) - Ward No.1"
        },
        {
            "urban_body_code": 249983,
            "id": 13652,
            "text": "Raiganj (M) - Ward No.2"
        },
        {
            "urban_body_code": 249983,
            "id": 13653,
            "text": "Raiganj (M) - Ward No.3"
        },
        {
            "urban_body_code": 249983,
            "id": 13654,
            "text": "Raiganj (M) - Ward No.4"
        },
        {
            "urban_body_code": 249983,
            "id": 13655,
            "text": "Raiganj (M) - Ward No.5"
        },
        {
            "urban_body_code": 249983,
            "id": 13656,
            "text": "Raiganj (M) - Ward No.6"
        },
        {
            "urban_body_code": 249983,
            "id": 13657,
            "text": "Raiganj (M) - Ward No.7"
        },
        {
            "urban_body_code": 249983,
            "id": 13658,
            "text": "Raiganj (M) - Ward No.8"
        },
        {
            "urban_body_code": 249983,
            "id": 13659,
            "text": "Raiganj (M) - Ward No.9"
        },
        {
            "urban_body_code": 249983,
            "id": 13660,
            "text": "Raiganj (M) - Ward No.10"
        },
        {
            "urban_body_code": 249983,
            "id": 13661,
            "text": "Raiganj (M) - Ward No.11"
        },
        {
            "urban_body_code": 249983,
            "id": 13750,
            "text": "Raiganj (M) - Ward No.12"
        },
        {
            "urban_body_code": 249983,
            "id": 13751,
            "text": "Raiganj (M) - Ward No.13"
        },
        {
            "urban_body_code": 249983,
            "id": 13752,
            "text": "Raiganj (M) - Ward No.14"
        },
        {
            "urban_body_code": 249983,
            "id": 13753,
            "text": "Raiganj (M) - Ward No.15"
        },
        {
            "urban_body_code": 249983,
            "id": 13754,
            "text": "Raiganj (M) - Ward No.16"
        },
        {
            "urban_body_code": 249983,
            "id": 13755,
            "text": "Raiganj (M) - Ward No.17"
        },
        {
            "urban_body_code": 249983,
            "id": 13756,
            "text": "Raiganj (M) - Ward No.18"
        },
        {
            "urban_body_code": 249983,
            "id": 13757,
            "text": "Raiganj (M) - Ward No.19"
        },
        {
            "urban_body_code": 249983,
            "id": 13758,
            "text": "Raiganj (M) - Ward No.20"
        },
        {
            "urban_body_code": 249983,
            "id": 13759,
            "text": "Raiganj (M) - Ward No.21"
        },
        {
            "urban_body_code": 249983,
            "id": 13760,
            "text": "Raiganj (M) - Ward No.22"
        },
        {
            "urban_body_code": 249983,
            "id": 13761,
            "text": "Raiganj (M) - Ward No.23"
        },
        {
            "urban_body_code": 249983,
            "id": 13762,
            "text": "Raiganj (M) - Ward No.24"
        },
        {
            "urban_body_code": 249983,
            "id": 13763,
            "text": "Raiganj (M) - Ward No.25"
        },
        {
            "urban_body_code": 249983,
            "id": 13764,
            "text": "Raiganj (M) - Ward No.26"
        },
        {
            "urban_body_code": 249983,
            "id": 9999370,
            "text": "Raiganj (M) - Ward No.27"
        },
        {
            "urban_body_code": 249983,
            "id": 9999404,
            "text": "Raiganj (M) - Ward No.27"
        },
        {
            "urban_body_code": 249984,
            "id": 66501,
            "text": "Kaliaganj (M) - Ward No.1"
        },
        {
            "urban_body_code": 249984,
            "id": 66502,
            "text": "Kaliaganj (M) - Ward No.2"
        },
        {
            "urban_body_code": 249984,
            "id": 66503,
            "text": "Kaliaganj (M) - Ward No.3"
        },
        {
            "urban_body_code": 249984,
            "id": 66504,
            "text": "Kaliaganj (M) - Ward No.4"
        },
        {
            "urban_body_code": 249984,
            "id": 66505,
            "text": "Kaliaganj (M) - Ward No.5"
        },
        {
            "urban_body_code": 249984,
            "id": 66506,
            "text": "Kaliaganj (M) - Ward No.6"
        },
        {
            "urban_body_code": 249984,
            "id": 66507,
            "text": "Kaliaganj (M) - Ward No.7"
        },
        {
            "urban_body_code": 249984,
            "id": 66508,
            "text": "Kaliaganj (M) - Ward No.8"
        },
        {
            "urban_body_code": 249984,
            "id": 66509,
            "text": "Kaliaganj (M) - Ward No.9"
        },
        {
            "urban_body_code": 249984,
            "id": 66510,
            "text": "Kaliaganj (M) - Ward No.10"
        },
        {
            "urban_body_code": 249984,
            "id": 66511,
            "text": "Kaliaganj (M) - Ward No.11"
        },
        {
            "urban_body_code": 249984,
            "id": 66512,
            "text": "Kaliaganj (M) - Ward No.12"
        },
        {
            "urban_body_code": 249984,
            "id": 66513,
            "text": "Kaliaganj (M) - Ward No.13"
        },
        {
            "urban_body_code": 249984,
            "id": 66514,
            "text": "Kaliaganj (M) - Ward No.14"
        },
        {
            "urban_body_code": 249984,
            "id": 66515,
            "text": "Kaliaganj (M) - Ward No.15"
        },
        {
            "urban_body_code": 249984,
            "id": 66516,
            "text": "Kaliaganj (M) - Ward No.16"
        },
        {
            "urban_body_code": 249984,
            "id": 66517,
            "text": "Kaliaganj (M) - Ward No.17"
        },
        {
            "urban_body_code": 249985,
            "id": 13765,
            "text": "Dalkhola (CT) - Ward No.1"
        },
        {
            "urban_body_code": 249985,
            "id": 9999213,
            "text": "Dalkhola (CT) - Ward No.2"
        },
        {
            "urban_body_code": 249985,
            "id": 9999214,
            "text": "Dalkhola (CT) - Ward No.3"
        },
        {
            "urban_body_code": 249985,
            "id": 9999215,
            "text": "Dalkhola (CT) - Ward No.4"
        },
        {
            "urban_body_code": 249985,
            "id": 9999216,
            "text": "Dalkhola (CT) - Ward No.5"
        },
        {
            "urban_body_code": 249985,
            "id": 9999217,
            "text": "Dalkhola (CT) - Ward No.6"
        },
        {
            "urban_body_code": 249985,
            "id": 9999218,
            "text": "Dalkhola (CT) - Ward No.7"
        },
        {
            "urban_body_code": 249985,
            "id": 9999219,
            "text": "Dalkhola (CT) - Ward No.8"
        },
        {
            "urban_body_code": 249985,
            "id": 9999220,
            "text": "Dalkhola (CT) - Ward No.9"
        },
        {
            "urban_body_code": 249985,
            "id": 9999221,
            "text": "Dalkhola (CT) - Ward No.10"
        },
        {
            "urban_body_code": 249985,
            "id": 9999222,
            "text": "Dalkhola (CT) - Ward No.11"
        },
        {
            "urban_body_code": 249985,
            "id": 9999223,
            "text": "Dalkhola (CT) - Ward No.12"
        },
        {
            "urban_body_code": 249985,
            "id": 9999224,
            "text": "Dalkhola (CT) - Ward No.13"
        },
        {
            "urban_body_code": 249985,
            "id": 9999225,
            "text": "Dalkhola (CT) - Ward No.14"
        },
        {
            "urban_body_code": 249985,
            "id": 9999226,
            "text": "Dalkhola (CT) - Ward No.15"
        },
        {
            "urban_body_code": 249985,
            "id": 9999227,
            "text": "Dalkhola (CT) - Ward No.16"
        },
        {
            "urban_body_code": 249988,
            "id": 13773,
            "text": "Gangarampur (M) - Ward No.1"
        },
        {
            "urban_body_code": 249988,
            "id": 13774,
            "text": "Gangarampur (M) - Ward No.2"
        },
        {
            "urban_body_code": 249988,
            "id": 13775,
            "text": "Gangarampur (M) - Ward No.3"
        },
        {
            "urban_body_code": 249988,
            "id": 13776,
            "text": "Gangarampur (M) - Ward No.4"
        },
        {
            "urban_body_code": 249988,
            "id": 13766,
            "text": "Gangarampur (M) - Ward No.5"
        },
        {
            "urban_body_code": 249988,
            "id": 13767,
            "text": "Gangarampur (M) - Ward No.6"
        },
        {
            "urban_body_code": 249988,
            "id": 13768,
            "text": "Gangarampur (M) - Ward No.7"
        },
        {
            "urban_body_code": 249988,
            "id": 13769,
            "text": "Gangarampur (M) - Ward No.8"
        },
        {
            "urban_body_code": 249988,
            "id": 13770,
            "text": "Gangarampur (M) - Ward No.9"
        },
        {
            "urban_body_code": 249988,
            "id": 13771,
            "text": "Gangarampur (M) - Ward No.10"
        },
        {
            "urban_body_code": 249988,
            "id": 13772,
            "text": "Gangarampur (M) - Ward No.11"
        },
        {
            "urban_body_code": 249988,
            "id": 13777,
            "text": "Gangarampur (M) - Ward No.12"
        },
        {
            "urban_body_code": 249988,
            "id": 13778,
            "text": "Gangarampur (M) - Ward No.13"
        },
        {
            "urban_body_code": 249988,
            "id": 13779,
            "text": "Gangarampur (M) - Ward No.14"
        },
        {
            "urban_body_code": 249988,
            "id": 13780,
            "text": "Gangarampur (M) - Ward No.15"
        },
        {
            "urban_body_code": 249988,
            "id": 13781,
            "text": "Gangarampur (M) - Ward No.16"
        },
        {
            "urban_body_code": 249988,
            "id": 13782,
            "text": "Gangarampur (M) - Ward No.17"
        },
        {
            "urban_body_code": 249988,
            "id": 13783,
            "text": "Gangarampur (M) - Ward No.18"
        },
        {
            "urban_body_code": 249989,
            "id": 66519,
            "text": "Balurghat (M) - Ward No.1"
        },
        {
            "urban_body_code": 249989,
            "id": 66520,
            "text": "Balurghat (M) - Ward No.2"
        },
        {
            "urban_body_code": 249989,
            "id": 66521,
            "text": "Balurghat (M) - Ward No.3"
        },
        {
            "urban_body_code": 249989,
            "id": 66522,
            "text": "Balurghat (M) - Ward No.4"
        },
        {
            "urban_body_code": 249989,
            "id": 66523,
            "text": "Balurghat (M) - Ward No.5"
        },
        {
            "urban_body_code": 249989,
            "id": 66524,
            "text": "Balurghat (M) - Ward No.6"
        },
        {
            "urban_body_code": 249989,
            "id": 66525,
            "text": "Balurghat (M) - Ward No.7"
        },
        {
            "urban_body_code": 249989,
            "id": 66526,
            "text": "Balurghat (M) - Ward No.8"
        },
        {
            "urban_body_code": 249989,
            "id": 66527,
            "text": "Balurghat (M) - Ward No.9"
        },
        {
            "urban_body_code": 249989,
            "id": 66528,
            "text": "Balurghat (M) - Ward No.10"
        },
        {
            "urban_body_code": 249989,
            "id": 66529,
            "text": "Balurghat (M) - Ward No.11"
        },
        {
            "urban_body_code": 249989,
            "id": 66530,
            "text": "Balurghat (M) - Ward No.12"
        },
        {
            "urban_body_code": 249989,
            "id": 66531,
            "text": "Balurghat (M) - Ward No.13"
        },
        {
            "urban_body_code": 249989,
            "id": 66532,
            "text": "Balurghat (M) - Ward No.14"
        },
        {
            "urban_body_code": 249989,
            "id": 66533,
            "text": "Balurghat (M) - Ward No.15"
        },
        {
            "urban_body_code": 249989,
            "id": 66534,
            "text": "Balurghat (M) - Ward No.16"
        },
        {
            "urban_body_code": 249989,
            "id": 66535,
            "text": "Balurghat (M) - Ward No.17"
        },
        {
            "urban_body_code": 249989,
            "id": 66536,
            "text": "Balurghat (M) - Ward No.18"
        },
        {
            "urban_body_code": 249989,
            "id": 66537,
            "text": "Balurghat (M) - Ward No.19"
        },
        {
            "urban_body_code": 249989,
            "id": 66538,
            "text": "Balurghat (M) - Ward No.20"
        },
        {
            "urban_body_code": 249989,
            "id": 66539,
            "text": "Balurghat (M) - Ward No.21"
        },
        {
            "urban_body_code": 249989,
            "id": 66540,
            "text": "Balurghat (M) - Ward No.22"
        },
        {
            "urban_body_code": 249989,
            "id": 66541,
            "text": "Balurghat (M) - Ward No.23"
        },
        {
            "urban_body_code": 249989,
            "id": 66542,
            "text": "Chak Bhrigu (OG) - Ward No.24"
        },
        {
            "urban_body_code": 249989,
            "id": 66543,
            "text": "Baidyanathpara (OG) - Ward No.25"
        },
        {
            "urban_body_code": 249990,
            "id": 13786,
            "text": "Old Maldah (M) - Ward No.1"
        },
        {
            "urban_body_code": 249990,
            "id": 13787,
            "text": "Old Maldah (M) - Ward No.2"
        },
        {
            "urban_body_code": 249990,
            "id": 13788,
            "text": "Old Maldah (M) - Ward No.3"
        },
        {
            "urban_body_code": 249990,
            "id": 13789,
            "text": "Old Maldah (M) - Ward No.4"
        },
        {
            "urban_body_code": 249990,
            "id": 13784,
            "text": "Old Maldah (M) - Ward No.5"
        },
        {
            "urban_body_code": 249990,
            "id": 13785,
            "text": "Old Maldah (M) - Ward No.6"
        },
        {
            "urban_body_code": 249990,
            "id": 13790,
            "text": "Old Maldah (M) - Ward No.7"
        },
        {
            "urban_body_code": 249990,
            "id": 13791,
            "text": "Old Maldah (M) - Ward No.8"
        },
        {
            "urban_body_code": 249990,
            "id": 13792,
            "text": "Old Maldah (M) - Ward No.9"
        },
        {
            "urban_body_code": 249990,
            "id": 13793,
            "text": "Old Maldah (M) - Ward No.10"
        },
        {
            "urban_body_code": 249990,
            "id": 13794,
            "text": "Old Maldah (M) - Ward No.11"
        },
        {
            "urban_body_code": 249990,
            "id": 13795,
            "text": "Old Maldah (M) - Ward No.12"
        },
        {
            "urban_body_code": 249990,
            "id": 13796,
            "text": "Old Maldah (M) - Ward No.13"
        },
        {
            "urban_body_code": 249990,
            "id": 13797,
            "text": "Old Maldah (M) - Ward No.14"
        },
        {
            "urban_body_code": 249990,
            "id": 13798,
            "text": "Old Maldah (M) - Ward No.15"
        },
        {
            "urban_body_code": 249990,
            "id": 13799,
            "text": "Old Maldah (M) - Ward No.16"
        },
        {
            "urban_body_code": 249990,
            "id": 13800,
            "text": "Old Maldah (M) - Ward No.17"
        },
        {
            "urban_body_code": 249990,
            "id": 9999364,
            "text": "Old Maldah (M) - Ward No.18"
        },
        {
            "urban_body_code": 249990,
            "id": 9999365,
            "text": "Old Maldah (M) - Ward No.19"
        },
        {
            "urban_body_code": 249990,
            "id": 9999366,
            "text": "Old Maldah (M) - Ward No.20"
        },
        {
            "urban_body_code": 249991,
            "id": 13801,
            "text": "English Bazar (M) - Ward No.1"
        },
        {
            "urban_body_code": 249991,
            "id": 13802,
            "text": "English Bazar (M) - Ward No.2"
        },
        {
            "urban_body_code": 249991,
            "id": 13803,
            "text": "English Bazar (M) - Ward No.3"
        },
        {
            "urban_body_code": 249991,
            "id": 13804,
            "text": "English Bazar (M) - Ward No.4"
        },
        {
            "urban_body_code": 249991,
            "id": 13805,
            "text": "English Bazar (M) - Ward No.5"
        },
        {
            "urban_body_code": 249991,
            "id": 13806,
            "text": "English Bazar (M) - Ward No.6"
        },
        {
            "urban_body_code": 249991,
            "id": 13807,
            "text": "English Bazar (M) - Ward No.7"
        },
        {
            "urban_body_code": 249991,
            "id": 13808,
            "text": "English Bazar (M) - Ward No.8"
        },
        {
            "urban_body_code": 249991,
            "id": 13809,
            "text": "English Bazar (M) - Ward No.9"
        },
        {
            "urban_body_code": 249991,
            "id": 13810,
            "text": "English Bazar (M) - Ward No.10"
        },
        {
            "urban_body_code": 249991,
            "id": 13811,
            "text": "English Bazar (M) - Ward No.11"
        },
        {
            "urban_body_code": 249991,
            "id": 13812,
            "text": "English Bazar (M) - Ward No.12"
        },
        {
            "urban_body_code": 249991,
            "id": 13813,
            "text": "English Bazar (M) - Ward No.13"
        },
        {
            "urban_body_code": 249991,
            "id": 13814,
            "text": "English Bazar (M) - Ward No.14"
        },
        {
            "urban_body_code": 249991,
            "id": 13815,
            "text": "English Bazar (M) - Ward No.15"
        },
        {
            "urban_body_code": 249991,
            "id": 13816,
            "text": "English Bazar (M) - Ward No.16"
        },
        {
            "urban_body_code": 249991,
            "id": 13817,
            "text": "English Bazar (M) - Ward No.17"
        },
        {
            "urban_body_code": 249991,
            "id": 13818,
            "text": "English Bazar (M) - Ward No.18"
        },
        {
            "urban_body_code": 249991,
            "id": 13819,
            "text": "English Bazar (M) - Ward No.19"
        },
        {
            "urban_body_code": 249991,
            "id": 13820,
            "text": "English Bazar (M) - Ward No.20"
        },
        {
            "urban_body_code": 249991,
            "id": 13821,
            "text": "English Bazar (M) - Ward No.21"
        },
        {
            "urban_body_code": 249991,
            "id": 13822,
            "text": "English Bazar (M) - Ward No.22"
        },
        {
            "urban_body_code": 249991,
            "id": 13823,
            "text": "English Bazar (M) - Ward No.23"
        },
        {
            "urban_body_code": 249991,
            "id": 13824,
            "text": "English Bazar (M) - Ward No.24"
        },
        {
            "urban_body_code": 249991,
            "id": 13825,
            "text": "English Bazar (M) - Ward No.25"
        },
        {
            "urban_body_code": 249991,
            "id": 9999287,
            "text": "English Bazar (M) - Ward No.26"
        },
        {
            "urban_body_code": 249991,
            "id": 9999288,
            "text": "English Bazar (M) - Ward No.27"
        },
        {
            "urban_body_code": 249991,
            "id": 9999289,
            "text": "English Bazar (M) - Ward No.28"
        },
        {
            "urban_body_code": 249991,
            "id": 9999290,
            "text": "English Bazar (M) - Ward No.29"
        },
        {
            "urban_body_code": 249995,
            "id": 13834,
            "text": "Dhulian (M) - Ward No.1"
        },
        {
            "urban_body_code": 249995,
            "id": 13835,
            "text": "Dhulian (M) - Ward No.2"
        },
        {
            "urban_body_code": 249995,
            "id": 13836,
            "text": "Dhulian (M) - Ward No.3"
        },
        {
            "urban_body_code": 249995,
            "id": 13837,
            "text": "Dhulian (M) - Ward No.4"
        },
        {
            "urban_body_code": 249995,
            "id": 13828,
            "text": "Dhulian (M) - Ward No.5"
        },
        {
            "urban_body_code": 249995,
            "id": 13829,
            "text": "Dhulian (M) - Ward No.6"
        },
        {
            "urban_body_code": 249995,
            "id": 13830,
            "text": "Dhulian (M) - Ward No.7"
        },
        {
            "urban_body_code": 249995,
            "id": 13831,
            "text": "Dhulian (M) - Ward No.8"
        },
        {
            "urban_body_code": 249995,
            "id": 13832,
            "text": "Dhulian (M) - Ward No.9"
        },
        {
            "urban_body_code": 249995,
            "id": 13833,
            "text": "Dhulian (M) - Ward No.10"
        },
        {
            "urban_body_code": 249995,
            "id": 13838,
            "text": "Dhulian (M) - Ward No.11"
        },
        {
            "urban_body_code": 249995,
            "id": 13839,
            "text": "Dhulian (M) - Ward No.12"
        },
        {
            "urban_body_code": 249995,
            "id": 13840,
            "text": "Dhulian (M) - Ward No.13"
        },
        {
            "urban_body_code": 249995,
            "id": 13841,
            "text": "Dhulian (M) - Ward No.14"
        },
        {
            "urban_body_code": 249995,
            "id": 13842,
            "text": "Dhulian (M) - Ward No.15"
        },
        {
            "urban_body_code": 249995,
            "id": 13843,
            "text": "Dhulian (M) - Ward No.16"
        },
        {
            "urban_body_code": 249995,
            "id": 14209,
            "text": "Dhulian (M) - Ward No.17"
        },
        {
            "urban_body_code": 249995,
            "id": 14210,
            "text": "Dhulian (M) - Ward No.18"
        },
        {
            "urban_body_code": 249995,
            "id": 14211,
            "text": "Dhulian (M) - Ward No.19"
        },
        {
            "urban_body_code": 249995,
            "id": 9999249,
            "text": "Dhulian (M) - Ward No.20"
        },
        {
            "urban_body_code": 249995,
            "id": 9999250,
            "text": "Dhulian (M) - Ward No.21"
        },
        {
            "urban_body_code": 249996,
            "id": 14212,
            "text": "Jangipur(M) - Ward No.1"
        },
        {
            "urban_body_code": 249996,
            "id": 14213,
            "text": "Jangipur(M) - Ward No.2"
        },
        {
            "urban_body_code": 249996,
            "id": 14214,
            "text": "Jangipur(M) - Ward No.3"
        },
        {
            "urban_body_code": 249996,
            "id": 14215,
            "text": "Jangipur(M) - Ward No.4"
        },
        {
            "urban_body_code": 249996,
            "id": 14216,
            "text": "Jangipur(M) - Ward No.5"
        },
        {
            "urban_body_code": 249996,
            "id": 14217,
            "text": "Jangipur(M) - Ward No.6"
        },
        {
            "urban_body_code": 249996,
            "id": 14218,
            "text": "Jangipur(M) - Ward No.7"
        },
        {
            "urban_body_code": 249996,
            "id": 14219,
            "text": "Jangipur(M) - Ward No.8"
        },
        {
            "urban_body_code": 249996,
            "id": 14220,
            "text": "Jangipur(M) - Ward No.9"
        },
        {
            "urban_body_code": 249996,
            "id": 14221,
            "text": "Jangipur(M) - Ward No.10"
        },
        {
            "urban_body_code": 249996,
            "id": 14222,
            "text": "Jangipur(M) - Ward No.11"
        },
        {
            "urban_body_code": 249996,
            "id": 14223,
            "text": "Jangipur(M) - Ward No.12"
        },
        {
            "urban_body_code": 249996,
            "id": 14224,
            "text": "Jangipur(M) - Ward No.13"
        },
        {
            "urban_body_code": 249996,
            "id": 14225,
            "text": "Jangipur(M) - Ward No.14"
        },
        {
            "urban_body_code": 249996,
            "id": 14226,
            "text": "Jangipur(M) - Ward No.15"
        },
        {
            "urban_body_code": 249996,
            "id": 14227,
            "text": "Jangipur(M) - Ward No.16"
        },
        {
            "urban_body_code": 249996,
            "id": 14228,
            "text": "Jangipur(M) - Ward No.17"
        },
        {
            "urban_body_code": 249996,
            "id": 14229,
            "text": "Jangipur(M) - Ward No.18"
        },
        {
            "urban_body_code": 249996,
            "id": 14230,
            "text": "Jangipur(M) - Ward No.19"
        },
        {
            "urban_body_code": 249996,
            "id": 14231,
            "text": "Jangipur(M) - Ward No.20"
        },
        {
            "urban_body_code": 249996,
            "id": 9999334,
            "text": "Jangipur(M) - Ward No.21"
        },
        {
            "urban_body_code": 249997,
            "id": 14232,
            "text": "Jiaganj Azimganj (M) - Ward No.1"
        },
        {
            "urban_body_code": 249997,
            "id": 14233,
            "text": "Jiaganj Azimganj (M) - Ward No.2"
        },
        {
            "urban_body_code": 249997,
            "id": 14234,
            "text": "Jiaganj Azimganj (M) - Ward No.3"
        },
        {
            "urban_body_code": 249997,
            "id": 14235,
            "text": "Jiaganj Azimganj (M) - Ward No.4"
        },
        {
            "urban_body_code": 249997,
            "id": 14236,
            "text": "Jiaganj Azimganj (M) - Ward No.5"
        },
        {
            "urban_body_code": 249997,
            "id": 14237,
            "text": "Jiaganj Azimganj (M) - Ward No.6"
        },
        {
            "urban_body_code": 249997,
            "id": 14238,
            "text": "Jiaganj Azimganj (M) - Ward No.7"
        },
        {
            "urban_body_code": 249997,
            "id": 14239,
            "text": "Jiaganj Azimganj (M) - Ward No.8"
        },
        {
            "urban_body_code": 249997,
            "id": 14240,
            "text": "Jiaganj Azimganj (M) - Ward No.9"
        },
        {
            "urban_body_code": 249997,
            "id": 14241,
            "text": "Jiaganj Azimganj (M) - Ward No.10"
        },
        {
            "urban_body_code": 249997,
            "id": 14242,
            "text": "Jiaganj Azimganj (M) - Ward No.11"
        },
        {
            "urban_body_code": 249997,
            "id": 14243,
            "text": "Jiaganj Azimganj (M) - Ward No.12"
        },
        {
            "urban_body_code": 249997,
            "id": 14244,
            "text": "Jiaganj Azimganj (M) - Ward No.13"
        },
        {
            "urban_body_code": 249997,
            "id": 14245,
            "text": "Jiaganj Azimganj (M) - Ward No.14"
        },
        {
            "urban_body_code": 249997,
            "id": 14246,
            "text": "Jiaganj Azimganj (M) - Ward No.15"
        },
        {
            "urban_body_code": 249997,
            "id": 14247,
            "text": "Jiaganj Azimganj (M) - Ward No.16"
        },
        {
            "urban_body_code": 249997,
            "id": 14248,
            "text": "Jiaganj Azimganj (M) - Ward No.17"
        },
        {
            "urban_body_code": 249998,
            "id": 66545,
            "text": "Murshidabad (M) - Ward No.1"
        },
        {
            "urban_body_code": 249998,
            "id": 66546,
            "text": "Murshidabad (M) - Ward No.2"
        },
        {
            "urban_body_code": 249998,
            "id": 66547,
            "text": "Murshidabad (M) - Ward No.3"
        },
        {
            "urban_body_code": 249998,
            "id": 66548,
            "text": "Murshidabad (M) - Ward No.4"
        },
        {
            "urban_body_code": 249998,
            "id": 66549,
            "text": "Murshidabad (M) - Ward No.5"
        },
        {
            "urban_body_code": 249998,
            "id": 66641,
            "text": "Murshidabad (M) - Ward No.6"
        },
        {
            "urban_body_code": 249998,
            "id": 66642,
            "text": "Murshidabad (M) - Ward No.7"
        },
        {
            "urban_body_code": 249998,
            "id": 66643,
            "text": "Murshidabad (M) - Ward No.8"
        },
        {
            "urban_body_code": 249998,
            "id": 66644,
            "text": "Murshidabad (M) - Ward No.9"
        },
        {
            "urban_body_code": 249998,
            "id": 66645,
            "text": "Murshidabad (M) - Ward No.10"
        },
        {
            "urban_body_code": 249998,
            "id": 66646,
            "text": "Murshidabad (M) - Ward No.11"
        },
        {
            "urban_body_code": 249998,
            "id": 66647,
            "text": "Murshidabad (M) - Ward No.12"
        },
        {
            "urban_body_code": 249998,
            "id": 66648,
            "text": "Murshidabad (M) - Ward No.13"
        },
        {
            "urban_body_code": 249998,
            "id": 66649,
            "text": "Murshidabad (M) - Ward No.14"
        },
        {
            "urban_body_code": 249998,
            "id": 66650,
            "text": "Murshidabad (M) - Ward No.15"
        },
        {
            "urban_body_code": 249998,
            "id": 66651,
            "text": "Murshidabad (M) - Ward No.16"
        },
        {
            "urban_body_code": 249999,
            "id": 14249,
            "text": "Baharampur (M) - Ward No.1"
        },
        {
            "urban_body_code": 249999,
            "id": 14250,
            "text": "Baharampur (M) - Ward No.2"
        },
        {
            "urban_body_code": 249999,
            "id": 14251,
            "text": "Baharampur (M) - Ward No.3"
        },
        {
            "urban_body_code": 249999,
            "id": 14252,
            "text": "Baharampur (M) - Ward No.4"
        },
        {
            "urban_body_code": 249999,
            "id": 14253,
            "text": "Baharampur (M) - Ward No.5"
        },
        {
            "urban_body_code": 249999,
            "id": 14254,
            "text": "Baharampur (M) - Ward No.6"
        },
        {
            "urban_body_code": 249999,
            "id": 14255,
            "text": "Baharampur (M) - Ward No.7"
        },
        {
            "urban_body_code": 249999,
            "id": 14256,
            "text": "Baharampur (M) - Ward No.8"
        },
        {
            "urban_body_code": 249999,
            "id": 14257,
            "text": "Baharampur (M) - Ward No.9"
        },
        {
            "urban_body_code": 249999,
            "id": 14258,
            "text": "Baharampur (M) - Ward No.10"
        },
        {
            "urban_body_code": 249999,
            "id": 14259,
            "text": "Baharampur (M) - Ward No.11"
        },
        {
            "urban_body_code": 249999,
            "id": 14260,
            "text": "Baharampur (M) - Ward No.12"
        },
        {
            "urban_body_code": 249999,
            "id": 14261,
            "text": "Baharampur (M) - Ward No.13"
        },
        {
            "urban_body_code": 249999,
            "id": 14262,
            "text": "Baharampur (M) - Ward No.14"
        },
        {
            "urban_body_code": 249999,
            "id": 14263,
            "text": "Baharampur (M) - Ward No.15"
        },
        {
            "urban_body_code": 249999,
            "id": 14264,
            "text": "Baharampur (M) - Ward No.16"
        },
        {
            "urban_body_code": 249999,
            "id": 14265,
            "text": "Baharampur (M) - Ward No.17"
        },
        {
            "urban_body_code": 249999,
            "id": 14266,
            "text": "Baharampur (M) - Ward No.18"
        },
        {
            "urban_body_code": 249999,
            "id": 14267,
            "text": "Baharampur (M) - Ward No.19"
        },
        {
            "urban_body_code": 249999,
            "id": 14268,
            "text": "Baharampur (M) - Ward No.20"
        },
        {
            "urban_body_code": 249999,
            "id": 14269,
            "text": "Baharampur (M) - Ward No.21"
        },
        {
            "urban_body_code": 249999,
            "id": 14270,
            "text": "Baharampur (M) - Ward No.22"
        },
        {
            "urban_body_code": 249999,
            "id": 14271,
            "text": "Baharampur (M) - Ward No.23"
        },
        {
            "urban_body_code": 249999,
            "id": 9999158,
            "text": "Baharampur (M) - Ward No.24"
        },
        {
            "urban_body_code": 249999,
            "id": 9999159,
            "text": "Baharampur (M) - Ward No.25"
        },
        {
            "urban_body_code": 249999,
            "id": 9999160,
            "text": "Baharampur (M) - Ward No.26"
        },
        {
            "urban_body_code": 249999,
            "id": 9999161,
            "text": "Baharampur (M) - Ward No.27"
        },
        {
            "urban_body_code": 249999,
            "id": 9999162,
            "text": "Baharampur (M) - Ward No.28"
        },
        {
            "urban_body_code": 250000,
            "id": 66652,
            "text": "Kandi (M) - Ward No.1"
        },
        {
            "urban_body_code": 250000,
            "id": 66653,
            "text": "Kandi (M) - Ward No.2"
        },
        {
            "urban_body_code": 250000,
            "id": 66654,
            "text": "Kandi (M) - Ward No.3"
        },
        {
            "urban_body_code": 250000,
            "id": 66655,
            "text": "Kandi (M) - Ward No.4"
        },
        {
            "urban_body_code": 250000,
            "id": 66656,
            "text": "Kandi (M) - Ward No.5"
        },
        {
            "urban_body_code": 250000,
            "id": 66657,
            "text": "Kandi (M) - Ward No.6"
        },
        {
            "urban_body_code": 250000,
            "id": 66658,
            "text": "Kandi (M) - Ward No.7"
        },
        {
            "urban_body_code": 250000,
            "id": 66659,
            "text": "Kandi (M) - Ward No.8"
        },
        {
            "urban_body_code": 250000,
            "id": 66660,
            "text": "Kandi (M) - Ward No.9"
        },
        {
            "urban_body_code": 250000,
            "id": 66661,
            "text": "Kandi (M) - Ward No.10"
        },
        {
            "urban_body_code": 250000,
            "id": 66662,
            "text": "Kandi (M) - Ward No.11"
        },
        {
            "urban_body_code": 250000,
            "id": 66663,
            "text": "Kandi (M) - Ward No.12"
        },
        {
            "urban_body_code": 250000,
            "id": 66664,
            "text": "Kandi (M) - Ward No.13"
        },
        {
            "urban_body_code": 250000,
            "id": 66665,
            "text": "Kandi (M) - Ward No.14"
        },
        {
            "urban_body_code": 250000,
            "id": 66666,
            "text": "Kandi (M) - Ward No.15"
        },
        {
            "urban_body_code": 250000,
            "id": 66667,
            "text": "Kandi (M) - Ward No.16"
        },
        {
            "urban_body_code": 250000,
            "id": 66668,
            "text": "Kandi (M) - Ward No.17"
        },
        {
            "urban_body_code": 250000,
            "id": 9999337,
            "text": "Kandi (M) - Ward No.18"
        },
        {
            "urban_body_code": 250001,
            "id": 66669,
            "text": "Beldanga (M) - Ward No.1"
        },
        {
            "urban_body_code": 250001,
            "id": 66670,
            "text": "Beldanga (M) - Ward No.2"
        },
        {
            "urban_body_code": 250001,
            "id": 66671,
            "text": "Beldanga (M) - Ward No.3"
        },
        {
            "urban_body_code": 250001,
            "id": 66672,
            "text": "Beldanga (M) - Ward No.4"
        },
        {
            "urban_body_code": 250001,
            "id": 66673,
            "text": "Beldanga (M) - Ward No.5"
        },
        {
            "urban_body_code": 250001,
            "id": 66674,
            "text": "Beldanga (M) - Ward No.6"
        },
        {
            "urban_body_code": 250001,
            "id": 66675,
            "text": "Beldanga (M) - Ward No.7"
        },
        {
            "urban_body_code": 250001,
            "id": 66676,
            "text": "Beldanga (M) - Ward No.8"
        },
        {
            "urban_body_code": 250001,
            "id": 66677,
            "text": "Beldanga (M) - Ward No.9"
        },
        {
            "urban_body_code": 250001,
            "id": 66678,
            "text": "Beldanga (M) - Ward No.10"
        },
        {
            "urban_body_code": 250001,
            "id": 66679,
            "text": "Beldanga (M) - Ward No.11"
        },
        {
            "urban_body_code": 250001,
            "id": 66680,
            "text": "Beldanga (M) - Ward No.12"
        },
        {
            "urban_body_code": 250001,
            "id": 66681,
            "text": "Beldanga (M) - Ward No.13"
        },
        {
            "urban_body_code": 250001,
            "id": 66682,
            "text": "Beldanga (M) - Ward No.14"
        },
        {
            "urban_body_code": 250024,
            "id": 14295,
            "text": "Rampurhat (M) - Ward No.1"
        },
        {
            "urban_body_code": 250024,
            "id": 14296,
            "text": "Rampurhat (M) - Ward No.2"
        },
        {
            "urban_body_code": 250024,
            "id": 14297,
            "text": "Rampurhat (M) - Ward No.3"
        },
        {
            "urban_body_code": 250024,
            "id": 14298,
            "text": "Rampurhat (M) - Ward No.4"
        },
        {
            "urban_body_code": 250024,
            "id": 14288,
            "text": "Rampurhat (M) - Ward No.5"
        },
        {
            "urban_body_code": 250024,
            "id": 14289,
            "text": "Rampurhat (M) - Ward No.6"
        },
        {
            "urban_body_code": 250024,
            "id": 14290,
            "text": "Rampurhat (M) - Ward No.7"
        },
        {
            "urban_body_code": 250024,
            "id": 14291,
            "text": "Rampurhat (M) - Ward No.8"
        },
        {
            "urban_body_code": 250024,
            "id": 14292,
            "text": "Rampurhat (M) - Ward No.9"
        },
        {
            "urban_body_code": 250024,
            "id": 14293,
            "text": "Rampurhat (M) - Ward No.10"
        },
        {
            "urban_body_code": 250024,
            "id": 14294,
            "text": "Rampurhat (M) - Ward No.11"
        },
        {
            "urban_body_code": 250024,
            "id": 14299,
            "text": "Rampurhat (M) - Ward No.12"
        },
        {
            "urban_body_code": 250024,
            "id": 14300,
            "text": "Rampurhat (M) - Ward No.13"
        },
        {
            "urban_body_code": 250024,
            "id": 14490,
            "text": "Rampurhat (M) - Ward No.14"
        },
        {
            "urban_body_code": 250024,
            "id": 14491,
            "text": "Rampurhat (M) - Ward No.15"
        },
        {
            "urban_body_code": 250024,
            "id": 14492,
            "text": "Rampurhat (M) - Ward No.16"
        },
        {
            "urban_body_code": 250024,
            "id": 14493,
            "text": "Rampurhat (M) - Ward No.17"
        },
        {
            "urban_body_code": 250024,
            "id": 9999373,
            "text": "Rampurhat (M) - Ward No.18"
        },
        {
            "urban_body_code": 250024,
            "id": 9999407,
            "text": "Rampurhat (M) - Ward No.18"
        },
        {
            "urban_body_code": 250025,
            "id": 14494,
            "text": "Sainthia (M) - Ward No.1"
        },
        {
            "urban_body_code": 250025,
            "id": 14495,
            "text": "Sainthia (M) - Ward No.2"
        },
        {
            "urban_body_code": 250025,
            "id": 14496,
            "text": "Sainthia (M) - Ward No.3"
        },
        {
            "urban_body_code": 250025,
            "id": 14497,
            "text": "Sainthia (M) - Ward No.4"
        },
        {
            "urban_body_code": 250025,
            "id": 14498,
            "text": "Sainthia (M) - Ward No.5"
        },
        {
            "urban_body_code": 250025,
            "id": 14499,
            "text": "Sainthia (M) - Ward No.6"
        },
        {
            "urban_body_code": 250025,
            "id": 14500,
            "text": "Sainthia (M) - Ward No.7"
        },
        {
            "urban_body_code": 250025,
            "id": 14501,
            "text": "Sainthia (M) - Ward No.8"
        },
        {
            "urban_body_code": 250025,
            "id": 14502,
            "text": "Sainthia (M) - Ward No.9"
        },
        {
            "urban_body_code": 250025,
            "id": 14503,
            "text": "Sainthia (M) - Ward No.10"
        },
        {
            "urban_body_code": 250025,
            "id": 14504,
            "text": "Sainthia (M) - Ward No.11"
        },
        {
            "urban_body_code": 250025,
            "id": 14505,
            "text": "Sainthia (M) - Ward No.12"
        },
        {
            "urban_body_code": 250025,
            "id": 14506,
            "text": "Sainthia (M) - Ward No.13"
        },
        {
            "urban_body_code": 250025,
            "id": 14507,
            "text": "Sainthia (M) - Ward No.14"
        },
        {
            "urban_body_code": 250025,
            "id": 14508,
            "text": "Sainthia (M) - Ward No.15"
        },
        {
            "urban_body_code": 250025,
            "id": 14509,
            "text": "Sainthia (M) - Ward No.16"
        },
        {
            "urban_body_code": 250026,
            "id": 14510,
            "text": "Suri (M) - Ward No.1"
        },
        {
            "urban_body_code": 250026,
            "id": 14511,
            "text": "Suri (M) - Ward No.2"
        },
        {
            "urban_body_code": 250026,
            "id": 14512,
            "text": "Suri (M) - Ward No.3"
        },
        {
            "urban_body_code": 250026,
            "id": 14513,
            "text": "Suri (M) - Ward No.4"
        },
        {
            "urban_body_code": 250026,
            "id": 14514,
            "text": "Suri (M) - Ward No.5"
        },
        {
            "urban_body_code": 250026,
            "id": 14515,
            "text": "Suri (M) - Ward No.6"
        },
        {
            "urban_body_code": 250026,
            "id": 14516,
            "text": "Suri (M) - Ward No.7"
        },
        {
            "urban_body_code": 250026,
            "id": 14517,
            "text": "Suri (M) - Ward No.8"
        },
        {
            "urban_body_code": 250026,
            "id": 14518,
            "text": "Suri (M) - Ward No.9"
        },
        {
            "urban_body_code": 250026,
            "id": 14519,
            "text": "Suri (M) - Ward No.10"
        },
        {
            "urban_body_code": 250026,
            "id": 14520,
            "text": "Suri (M) - Ward No.11"
        },
        {
            "urban_body_code": 250026,
            "id": 14521,
            "text": "Suri (M) - Ward No.12"
        },
        {
            "urban_body_code": 250026,
            "id": 14522,
            "text": "Suri (M) - Ward No.13"
        },
        {
            "urban_body_code": 250026,
            "id": 14523,
            "text": "Suri (M) - Ward No.14"
        },
        {
            "urban_body_code": 250026,
            "id": 14524,
            "text": "Suri (M) - Ward No.15"
        },
        {
            "urban_body_code": 250026,
            "id": 14525,
            "text": "Suri (M) - Ward No.16"
        },
        {
            "urban_body_code": 250026,
            "id": 14526,
            "text": "Suri (M) - Ward No.17"
        },
        {
            "urban_body_code": 250026,
            "id": 14527,
            "text": "Suri (M) - Ward No.18"
        },
        {
            "urban_body_code": 250026,
            "id": 9999412,
            "text": "Suri (M) - Ward No.19"
        },
        {
            "urban_body_code": 250026,
            "id": 9999413,
            "text": "Suri (M) - Ward No.19"
        },
        {
            "urban_body_code": 250027,
            "id": 14528,
            "text": "Dubrajpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250027,
            "id": 14529,
            "text": "Dubrajpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250027,
            "id": 14530,
            "text": "Dubrajpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250027,
            "id": 14531,
            "text": "Dubrajpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250027,
            "id": 14532,
            "text": "Dubrajpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250027,
            "id": 14533,
            "text": "Dubrajpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250027,
            "id": 14534,
            "text": "Dubrajpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250027,
            "id": 14535,
            "text": "Dubrajpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250027,
            "id": 14536,
            "text": "Dubrajpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250027,
            "id": 14537,
            "text": "Dubrajpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250027,
            "id": 14538,
            "text": "Dubrajpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250027,
            "id": 14539,
            "text": "Dubrajpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250027,
            "id": 14540,
            "text": "Dubrajpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250027,
            "id": 14541,
            "text": "Dubrajpur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250027,
            "id": 14542,
            "text": "Dubrajpur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250027,
            "id": 14543,
            "text": "Dubrajpur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250028,
            "id": 14544,
            "text": "Bolpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250028,
            "id": 14545,
            "text": "Bolpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250028,
            "id": 14546,
            "text": "Bolpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250028,
            "id": 14547,
            "text": "Bolpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250028,
            "id": 14548,
            "text": "Bolpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250028,
            "id": 14549,
            "text": "Bolpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250028,
            "id": 14550,
            "text": "Bolpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250028,
            "id": 14551,
            "text": "Bolpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250028,
            "id": 14552,
            "text": "Bolpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250028,
            "id": 14553,
            "text": "Bolpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250028,
            "id": 14554,
            "text": "Bolpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250028,
            "id": 14555,
            "text": "Bolpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250028,
            "id": 14556,
            "text": "Bolpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250028,
            "id": 14557,
            "text": "Bolpur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250028,
            "id": 14558,
            "text": "Bolpur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250028,
            "id": 14559,
            "text": "Bolpur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250028,
            "id": 14560,
            "text": "Bolpur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250028,
            "id": 14561,
            "text": "Bolpur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250028,
            "id": 9999193,
            "text": "Bolpur (M) - Ward No.19"
        },
        {
            "urban_body_code": 250028,
            "id": 9999194,
            "text": "Bolpur (M) - Ward No.20"
        },
        {
            "urban_body_code": 250030,
            "id": 66692,
            "text": "Jamuria (M) - Ward No.1"
        },
        {
            "urban_body_code": 250030,
            "id": 66693,
            "text": "Jamuria (M) - Ward No.2"
        },
        {
            "urban_body_code": 250030,
            "id": 66694,
            "text": "Jamuria (M) - Ward No.3"
        },
        {
            "urban_body_code": 250030,
            "id": 66688,
            "text": "Jamuria (M) - Ward No.4"
        },
        {
            "urban_body_code": 250030,
            "id": 66689,
            "text": "Jamuria (M) - Ward No.5"
        },
        {
            "urban_body_code": 250030,
            "id": 66690,
            "text": "Jamuria (M) - Ward No.6"
        },
        {
            "urban_body_code": 250030,
            "id": 66691,
            "text": "Jamuria (M) - Ward No.7"
        },
        {
            "urban_body_code": 250030,
            "id": 66695,
            "text": "Jamuria (M) - Ward No.8"
        },
        {
            "urban_body_code": 250030,
            "id": 66696,
            "text": "Jamuria (M) - Ward No.9"
        },
        {
            "urban_body_code": 250030,
            "id": 66697,
            "text": "Jamuria (M) - Ward No.10"
        },
        {
            "urban_body_code": 250030,
            "id": 66698,
            "text": "Jamuria (M) - Ward No.11"
        },
        {
            "urban_body_code": 250030,
            "id": 66699,
            "text": "Jamuria (M) - Ward No.12"
        },
        {
            "urban_body_code": 250030,
            "id": 66700,
            "text": "Jamuria (M) - Ward No.13"
        },
        {
            "urban_body_code": 250030,
            "id": 66701,
            "text": "Jamuria (M) - Ward No.14"
        },
        {
            "urban_body_code": 250030,
            "id": 66702,
            "text": "Jamuria (M) - Ward No.15"
        },
        {
            "urban_body_code": 250030,
            "id": 66703,
            "text": "Jamuria (M) - Ward No.16"
        },
        {
            "urban_body_code": 250030,
            "id": 66704,
            "text": "Jamuria (M) - Ward No.17"
        },
        {
            "urban_body_code": 250030,
            "id": 66705,
            "text": "Jamuria (M) - Ward No.18"
        },
        {
            "urban_body_code": 250030,
            "id": 66706,
            "text": "Jamuria (M) - Ward No.19"
        },
        {
            "urban_body_code": 250030,
            "id": 66707,
            "text": "Jamuria (M) - Ward No.20"
        },
        {
            "urban_body_code": 250030,
            "id": 66708,
            "text": "Jamuria (M) - Ward No.21"
        },
        {
            "urban_body_code": 250030,
            "id": 66709,
            "text": "Jamuria (M) - Ward No.22"
        },
        {
            "urban_body_code": 250030,
            "id": 67237,
            "text": "Charanpur (OG) - Ward No.23"
        },
        {
            "urban_body_code": 250031,
            "id": 14562,
            "text": "Kulti (M) - Ward No.1"
        },
        {
            "urban_body_code": 250031,
            "id": 14563,
            "text": "Kulti (M) - Ward No.2"
        },
        {
            "urban_body_code": 250031,
            "id": 14564,
            "text": "Kulti (M) - Ward No.3"
        },
        {
            "urban_body_code": 250031,
            "id": 14565,
            "text": "Kulti (M) - Ward No.4"
        },
        {
            "urban_body_code": 250031,
            "id": 14566,
            "text": "Kulti (M) - Ward No.5"
        },
        {
            "urban_body_code": 250031,
            "id": 14567,
            "text": "Kulti (M) - Ward No.6"
        },
        {
            "urban_body_code": 250031,
            "id": 14568,
            "text": "Kulti (M) - Ward No.7"
        },
        {
            "urban_body_code": 250031,
            "id": 14569,
            "text": "Kulti (M) - Ward No.8"
        },
        {
            "urban_body_code": 250031,
            "id": 14570,
            "text": "Kulti (M) - Ward No.9"
        },
        {
            "urban_body_code": 250031,
            "id": 14571,
            "text": "Kulti (M) - Ward No.10"
        },
        {
            "urban_body_code": 250031,
            "id": 14572,
            "text": "Kulti (M) - Ward No.11"
        },
        {
            "urban_body_code": 250031,
            "id": 14573,
            "text": "Kulti (M) - Ward No.12"
        },
        {
            "urban_body_code": 250031,
            "id": 14574,
            "text": "Kulti (M) - Ward No.13"
        },
        {
            "urban_body_code": 250031,
            "id": 14575,
            "text": "Kulti (M) - Ward No.14"
        },
        {
            "urban_body_code": 250031,
            "id": 14576,
            "text": "Kulti (M) - Ward No.15"
        },
        {
            "urban_body_code": 250031,
            "id": 14577,
            "text": "Kulti (M) - Ward No.16"
        },
        {
            "urban_body_code": 250031,
            "id": 14578,
            "text": "Kulti (M) - Ward No.17"
        },
        {
            "urban_body_code": 250031,
            "id": 14579,
            "text": "Kulti (M) - Ward No.18"
        },
        {
            "urban_body_code": 250031,
            "id": 14580,
            "text": "Kulti (M) - Ward No.19"
        },
        {
            "urban_body_code": 250031,
            "id": 14581,
            "text": "Kulti (M) - Ward No.20"
        },
        {
            "urban_body_code": 250031,
            "id": 14582,
            "text": "Kulti (M) - Ward No.21"
        },
        {
            "urban_body_code": 250031,
            "id": 14583,
            "text": "Kulti (M) - Ward No.22"
        },
        {
            "urban_body_code": 250031,
            "id": 14584,
            "text": "Kulti (M) - Ward No.23"
        },
        {
            "urban_body_code": 250031,
            "id": 14585,
            "text": "Kulti (M) - Ward No.24"
        },
        {
            "urban_body_code": 250031,
            "id": 14586,
            "text": "Kulti (M) - Ward No.25"
        },
        {
            "urban_body_code": 250031,
            "id": 14587,
            "text": "Kulti (M) - Ward No.26"
        },
        {
            "urban_body_code": 250031,
            "id": 14588,
            "text": "Kulti (M) - Ward No.27"
        },
        {
            "urban_body_code": 250031,
            "id": 14589,
            "text": "Kulti (M) - Ward No.28"
        },
        {
            "urban_body_code": 250031,
            "id": 14590,
            "text": "Kulti (M) - Ward No.29"
        },
        {
            "urban_body_code": 250031,
            "id": 14591,
            "text": "Kulti (M) - Ward No.30"
        },
        {
            "urban_body_code": 250031,
            "id": 14592,
            "text": "Kulti (M) - Ward No.31"
        },
        {
            "urban_body_code": 250031,
            "id": 14683,
            "text": "Kulti (M) - Ward No.32"
        },
        {
            "urban_body_code": 250031,
            "id": 14684,
            "text": "Kulti (M) - Ward No.33"
        },
        {
            "urban_body_code": 250031,
            "id": 14685,
            "text": "Kulti (M) - Ward No.34"
        },
        {
            "urban_body_code": 250031,
            "id": 14686,
            "text": "Kulti (M) - Ward No.35"
        },
        {
            "urban_body_code": 250032,
            "id": 66710,
            "text": "Asansol (M Corp.) - Ward No.1"
        },
        {
            "urban_body_code": 250032,
            "id": 66711,
            "text": "Asansol (M Corp.) - Ward No.2"
        },
        {
            "urban_body_code": 250032,
            "id": 66712,
            "text": "Asansol (M Corp.) - Ward No.3"
        },
        {
            "urban_body_code": 250032,
            "id": 66713,
            "text": "Asansol (M Corp.) - Ward No.4"
        },
        {
            "urban_body_code": 250032,
            "id": 66714,
            "text": "Asansol (M Corp.) - Ward No.5"
        },
        {
            "urban_body_code": 250032,
            "id": 66715,
            "text": "Asansol (M Corp.) - Ward No.6"
        },
        {
            "urban_body_code": 250032,
            "id": 66716,
            "text": "Asansol (M Corp.) - Ward No.7"
        },
        {
            "urban_body_code": 250032,
            "id": 66717,
            "text": "Asansol (M Corp.) - Ward No.8"
        },
        {
            "urban_body_code": 250032,
            "id": 66718,
            "text": "Asansol (M Corp.) - Ward No.9"
        },
        {
            "urban_body_code": 250032,
            "id": 66719,
            "text": "Asansol (M Corp.) - Ward No.10"
        },
        {
            "urban_body_code": 250032,
            "id": 66720,
            "text": "Asansol (M Corp.) - Ward No.11"
        },
        {
            "urban_body_code": 250032,
            "id": 66721,
            "text": "Asansol (M Corp.) - Ward No.12"
        },
        {
            "urban_body_code": 250032,
            "id": 66722,
            "text": "Asansol (M Corp.) - Ward No.13"
        },
        {
            "urban_body_code": 250032,
            "id": 66723,
            "text": "Asansol (M Corp.) - Ward No.14"
        },
        {
            "urban_body_code": 250032,
            "id": 66724,
            "text": "Asansol (M Corp.) - Ward No.15"
        },
        {
            "urban_body_code": 250032,
            "id": 66725,
            "text": "Asansol (M Corp.) - Ward No.16"
        },
        {
            "urban_body_code": 250032,
            "id": 66726,
            "text": "Asansol (M Corp.) - Ward No.17"
        },
        {
            "urban_body_code": 250032,
            "id": 66727,
            "text": "Asansol (M Corp.) - Ward No.18"
        },
        {
            "urban_body_code": 250032,
            "id": 66728,
            "text": "Asansol (M Corp.) - Ward No.19"
        },
        {
            "urban_body_code": 250032,
            "id": 66729,
            "text": "Asansol (M Corp.) - Ward No.20"
        },
        {
            "urban_body_code": 250032,
            "id": 66730,
            "text": "Asansol (M Corp.) - Ward No.21"
        },
        {
            "urban_body_code": 250032,
            "id": 66731,
            "text": "Asansol (M Corp.) - Ward No.22"
        },
        {
            "urban_body_code": 250032,
            "id": 66732,
            "text": "Asansol (M Corp.) - Ward No.23"
        },
        {
            "urban_body_code": 250032,
            "id": 66733,
            "text": "Asansol (M Corp.) - Ward No.24"
        },
        {
            "urban_body_code": 250032,
            "id": 66734,
            "text": "Asansol (M Corp.) - Ward No.25"
        },
        {
            "urban_body_code": 250032,
            "id": 66735,
            "text": "Asansol (M Corp.) - Ward No.26"
        },
        {
            "urban_body_code": 250032,
            "id": 66736,
            "text": "Asansol (M Corp.) - Ward No.27"
        },
        {
            "urban_body_code": 250032,
            "id": 67119,
            "text": "Asansol (M Corp.) - Ward No.28"
        },
        {
            "urban_body_code": 250032,
            "id": 67120,
            "text": "Asansol (M Corp.) - Ward No.29"
        },
        {
            "urban_body_code": 250032,
            "id": 67121,
            "text": "Asansol (M Corp.) - Ward No.30"
        },
        {
            "urban_body_code": 250032,
            "id": 67122,
            "text": "Asansol (M Corp.) - Ward No.31"
        },
        {
            "urban_body_code": 250032,
            "id": 67123,
            "text": "Asansol (M Corp.) - Ward No.32"
        },
        {
            "urban_body_code": 250032,
            "id": 67124,
            "text": "Asansol (M Corp.) - Ward No.33"
        },
        {
            "urban_body_code": 250032,
            "id": 67125,
            "text": "Asansol (M Corp.) - Ward No.34"
        },
        {
            "urban_body_code": 250032,
            "id": 67126,
            "text": "Asansol (M Corp.) - Ward No.35"
        },
        {
            "urban_body_code": 250032,
            "id": 67127,
            "text": "Asansol (M Corp.) - Ward No.36"
        },
        {
            "urban_body_code": 250032,
            "id": 67128,
            "text": "Asansol (M Corp.) - Ward No.37"
        },
        {
            "urban_body_code": 250032,
            "id": 67129,
            "text": "Asansol (M Corp.) - Ward No.38"
        },
        {
            "urban_body_code": 250032,
            "id": 67130,
            "text": "Asansol (M Corp.) - Ward No.39"
        },
        {
            "urban_body_code": 250032,
            "id": 67131,
            "text": "Asansol (M Corp.) - Ward No.40"
        },
        {
            "urban_body_code": 250032,
            "id": 67132,
            "text": "Asansol (M Corp.) - Ward No.41"
        },
        {
            "urban_body_code": 250032,
            "id": 67133,
            "text": "Asansol (M Corp.) - Ward No.42"
        },
        {
            "urban_body_code": 250032,
            "id": 67134,
            "text": "Asansol (M Corp.) - Ward No.43"
        },
        {
            "urban_body_code": 250032,
            "id": 67135,
            "text": "Asansol (M Corp.) - Ward No.44"
        },
        {
            "urban_body_code": 250032,
            "id": 67136,
            "text": "Asansol (M Corp.) - Ward No.45"
        },
        {
            "urban_body_code": 250032,
            "id": 67137,
            "text": "Asansol (M Corp.) - Ward No.46"
        },
        {
            "urban_body_code": 250032,
            "id": 67138,
            "text": "Asansol (M Corp.) - Ward No.47"
        },
        {
            "urban_body_code": 250032,
            "id": 67139,
            "text": "Asansol (M Corp.) - Ward No.48"
        },
        {
            "urban_body_code": 250032,
            "id": 67140,
            "text": "Asansol (M Corp.) - Ward No.49"
        },
        {
            "urban_body_code": 250032,
            "id": 67141,
            "text": "Asansol (M Corp.) - Ward No.50"
        },
        {
            "urban_body_code": 250032,
            "id": 9999101,
            "text": "Asansol (M Corp.) - Ward No.51"
        },
        {
            "urban_body_code": 250032,
            "id": 9999102,
            "text": "Asansol (M Corp.) - Ward No.52"
        },
        {
            "urban_body_code": 250032,
            "id": 9999103,
            "text": "Asansol (M Corp.) - Ward No.53"
        },
        {
            "urban_body_code": 250032,
            "id": 9999104,
            "text": "Asansol (M Corp.) - Ward No.54"
        },
        {
            "urban_body_code": 250032,
            "id": 9999105,
            "text": "Asansol (M Corp.) - Ward No.55"
        },
        {
            "urban_body_code": 250032,
            "id": 9999106,
            "text": "Asansol (M Corp.) - Ward No.56"
        },
        {
            "urban_body_code": 250032,
            "id": 9999107,
            "text": "Asansol (M Corp.) - Ward No.57"
        },
        {
            "urban_body_code": 250032,
            "id": 9999108,
            "text": "Asansol (M Corp.) - Ward No.58"
        },
        {
            "urban_body_code": 250032,
            "id": 9999109,
            "text": "Asansol (M Corp.) - Ward No.59"
        },
        {
            "urban_body_code": 250032,
            "id": 9999110,
            "text": "Asansol (M Corp.) - Ward No.60"
        },
        {
            "urban_body_code": 250032,
            "id": 9999111,
            "text": "Asansol (M Corp.) - Ward No.61"
        },
        {
            "urban_body_code": 250032,
            "id": 9999112,
            "text": "Asansol (M Corp.) - Ward No.62"
        },
        {
            "urban_body_code": 250032,
            "id": 9999113,
            "text": "Asansol (M Corp.) - Ward No.63"
        },
        {
            "urban_body_code": 250032,
            "id": 9999114,
            "text": "Asansol (M Corp.) - Ward No.64"
        },
        {
            "urban_body_code": 250032,
            "id": 9999115,
            "text": "Asansol (M Corp.) - Ward No.65"
        },
        {
            "urban_body_code": 250032,
            "id": 9999116,
            "text": "Asansol (M Corp.) - Ward No.66"
        },
        {
            "urban_body_code": 250032,
            "id": 9999117,
            "text": "Asansol (M Corp.) - Ward No.67"
        },
        {
            "urban_body_code": 250032,
            "id": 9999118,
            "text": "Asansol (M Corp.) - Ward No.68"
        },
        {
            "urban_body_code": 250032,
            "id": 9999119,
            "text": "Asansol (M Corp.) - Ward No.69"
        },
        {
            "urban_body_code": 250032,
            "id": 9999120,
            "text": "Asansol (M Corp.) - Ward No.70"
        },
        {
            "urban_body_code": 250032,
            "id": 9999121,
            "text": "Asansol (M Corp.) - Ward No.71"
        },
        {
            "urban_body_code": 250032,
            "id": 9999122,
            "text": "Asansol (M Corp.) - Ward No.72"
        },
        {
            "urban_body_code": 250032,
            "id": 9999123,
            "text": "Asansol (M Corp.) - Ward No.73"
        },
        {
            "urban_body_code": 250032,
            "id": 9999124,
            "text": "Asansol (M Corp.) - Ward No.74"
        },
        {
            "urban_body_code": 250032,
            "id": 9999125,
            "text": "Asansol (M Corp.) - Ward No.75"
        },
        {
            "urban_body_code": 250032,
            "id": 9999126,
            "text": "Asansol (M Corp.) - Ward No.76"
        },
        {
            "urban_body_code": 250032,
            "id": 9999127,
            "text": "Asansol (M Corp.) - Ward No.77"
        },
        {
            "urban_body_code": 250032,
            "id": 9999128,
            "text": "Asansol (M Corp.) - Ward No.78"
        },
        {
            "urban_body_code": 250032,
            "id": 9999129,
            "text": "Asansol (M Corp.) - Ward No.79"
        },
        {
            "urban_body_code": 250032,
            "id": 9999130,
            "text": "Asansol (M Corp.) - Ward No.80"
        },
        {
            "urban_body_code": 250032,
            "id": 9999131,
            "text": "Asansol (M Corp.) - Ward No.81"
        },
        {
            "urban_body_code": 250032,
            "id": 9999132,
            "text": "Asansol (M Corp.) - Ward No.82"
        },
        {
            "urban_body_code": 250032,
            "id": 9999133,
            "text": "Asansol (M Corp.) - Ward No.83"
        },
        {
            "urban_body_code": 250032,
            "id": 9999134,
            "text": "Asansol (M Corp.) - Ward No.84"
        },
        {
            "urban_body_code": 250032,
            "id": 9999135,
            "text": "Asansol (M Corp.) - Ward No.85"
        },
        {
            "urban_body_code": 250032,
            "id": 9999136,
            "text": "Asansol (M Corp.) - Ward No.86"
        },
        {
            "urban_body_code": 250032,
            "id": 9999137,
            "text": "Asansol (M Corp.) - Ward No.87"
        },
        {
            "urban_body_code": 250032,
            "id": 9999138,
            "text": "Asansol (M Corp.) - Ward No.88"
        },
        {
            "urban_body_code": 250032,
            "id": 9999139,
            "text": "Asansol (M Corp.) - Ward No.89"
        },
        {
            "urban_body_code": 250032,
            "id": 9999140,
            "text": "Asansol (M Corp.) - Ward No.90"
        },
        {
            "urban_body_code": 250032,
            "id": 9999141,
            "text": "Asansol (M Corp.) - Ward No.91"
        },
        {
            "urban_body_code": 250032,
            "id": 9999142,
            "text": "Asansol (M Corp.) - Ward No.92"
        },
        {
            "urban_body_code": 250032,
            "id": 9999143,
            "text": "Asansol (M Corp.) - Ward No.93"
        },
        {
            "urban_body_code": 250032,
            "id": 9999144,
            "text": "Asansol (M Corp.) - Ward No.94"
        },
        {
            "urban_body_code": 250032,
            "id": 9999145,
            "text": "Asansol (M Corp.) - Ward No.95"
        },
        {
            "urban_body_code": 250032,
            "id": 9999146,
            "text": "Asansol (M Corp.) - Ward No.96"
        },
        {
            "urban_body_code": 250032,
            "id": 9999147,
            "text": "Asansol (M Corp.) - Ward No.97"
        },
        {
            "urban_body_code": 250032,
            "id": 9999148,
            "text": "Asansol (M Corp.) - Ward No.98"
        },
        {
            "urban_body_code": 250032,
            "id": 9999149,
            "text": "Asansol (M Corp.) - Ward No.99"
        },
        {
            "urban_body_code": 250032,
            "id": 9999150,
            "text": "Asansol (M Corp.) - Ward No.100"
        },
        {
            "urban_body_code": 250032,
            "id": 9999151,
            "text": "Asansol (M Corp.) - Ward No.101"
        },
        {
            "urban_body_code": 250032,
            "id": 9999152,
            "text": "Asansol (M Corp.) - Ward No.102"
        },
        {
            "urban_body_code": 250032,
            "id": 9999153,
            "text": "Asansol (M Corp.) - Ward No.103"
        },
        {
            "urban_body_code": 250032,
            "id": 9999154,
            "text": "Asansol (M Corp.) - Ward No.104"
        },
        {
            "urban_body_code": 250032,
            "id": 9999155,
            "text": "Asansol (M Corp.) - Ward No.105"
        },
        {
            "urban_body_code": 250032,
            "id": 9999156,
            "text": "Asansol (M Corp.) - Ward No.106"
        },
        {
            "urban_body_code": 250033,
            "id": 14687,
            "text": "Raniganj (M) - Ward No.1"
        },
        {
            "urban_body_code": 250033,
            "id": 14688,
            "text": "Raniganj (M) - Ward No.2"
        },
        {
            "urban_body_code": 250033,
            "id": 14689,
            "text": "Raniganj (M) - Ward No.3"
        },
        {
            "urban_body_code": 250033,
            "id": 14690,
            "text": "Raniganj (M) - Ward No.4"
        },
        {
            "urban_body_code": 250033,
            "id": 14691,
            "text": "Raniganj (M) - Ward No.5"
        },
        {
            "urban_body_code": 250033,
            "id": 14692,
            "text": "Raniganj (M) - Ward No.6"
        },
        {
            "urban_body_code": 250033,
            "id": 14693,
            "text": "Raniganj (M) - Ward No.7"
        },
        {
            "urban_body_code": 250033,
            "id": 14694,
            "text": "Raniganj (M) - Ward No.8"
        },
        {
            "urban_body_code": 250033,
            "id": 14695,
            "text": "Raniganj (M) - Ward No.9"
        },
        {
            "urban_body_code": 250033,
            "id": 14696,
            "text": "Raniganj (M) - Ward No.10"
        },
        {
            "urban_body_code": 250033,
            "id": 14697,
            "text": "Raniganj (M) - Ward No.11"
        },
        {
            "urban_body_code": 250033,
            "id": 14698,
            "text": "Raniganj (M) - Ward No.12"
        },
        {
            "urban_body_code": 250033,
            "id": 14699,
            "text": "Raniganj (M) - Ward No.13"
        },
        {
            "urban_body_code": 250033,
            "id": 14700,
            "text": "Raniganj (M) - Ward No.14"
        },
        {
            "urban_body_code": 250033,
            "id": 14701,
            "text": "Raniganj (M) - Ward No.15"
        },
        {
            "urban_body_code": 250033,
            "id": 14702,
            "text": "Raniganj (M) - Ward No.16"
        },
        {
            "urban_body_code": 250033,
            "id": 14703,
            "text": "Raniganj (M) - Ward No.17"
        },
        {
            "urban_body_code": 250033,
            "id": 14704,
            "text": "Raniganj (M) - Ward No.18"
        },
        {
            "urban_body_code": 250033,
            "id": 14705,
            "text": "Raniganj (M) - Ward No.19"
        },
        {
            "urban_body_code": 250033,
            "id": 14706,
            "text": "Raniganj (M) - Ward No.20"
        },
        {
            "urban_body_code": 250033,
            "id": 14707,
            "text": "Raniganj (M) - Ward No.21"
        },
        {
            "urban_body_code": 250033,
            "id": 14784,
            "text": "Sahebganj (OG) - Ward No.22"
        },
        {
            "urban_body_code": 250033,
            "id": 14785,
            "text": "Egara (OG) - Ward No.23"
        },
        {
            "urban_body_code": 250033,
            "id": 14786,
            "text": "Nimeha (OG) - Ward No.24"
        },
        {
            "urban_body_code": 250034,
            "id": 67142,
            "text": "Durgapur (M Corp.) - Ward No.1"
        },
        {
            "urban_body_code": 250034,
            "id": 67143,
            "text": "Durgapur (M Corp.) - Ward No.2"
        },
        {
            "urban_body_code": 250034,
            "id": 67144,
            "text": "Durgapur (M Corp.) - Ward No.3"
        },
        {
            "urban_body_code": 250034,
            "id": 67145,
            "text": "Durgapur (M Corp.) - Ward No.4"
        },
        {
            "urban_body_code": 250034,
            "id": 67146,
            "text": "Durgapur (M Corp.) - Ward No.5"
        },
        {
            "urban_body_code": 250034,
            "id": 67147,
            "text": "Durgapur (M Corp.) - Ward No.6"
        },
        {
            "urban_body_code": 250034,
            "id": 67148,
            "text": "Durgapur (M Corp.) - Ward No.7"
        },
        {
            "urban_body_code": 250034,
            "id": 67149,
            "text": "Durgapur (M Corp.) - Ward No.8"
        },
        {
            "urban_body_code": 250034,
            "id": 67150,
            "text": "Durgapur (M Corp.) - Ward No.9"
        },
        {
            "urban_body_code": 250034,
            "id": 67151,
            "text": "Durgapur (M Corp.) - Ward No.10"
        },
        {
            "urban_body_code": 250034,
            "id": 67152,
            "text": "Durgapur (M Corp.) - Ward No.11"
        },
        {
            "urban_body_code": 250034,
            "id": 67153,
            "text": "Durgapur (M Corp.) - Ward No.12"
        },
        {
            "urban_body_code": 250034,
            "id": 67154,
            "text": "Durgapur (M Corp.) - Ward No.13"
        },
        {
            "urban_body_code": 250034,
            "id": 67155,
            "text": "Durgapur (M Corp.) - Ward No.14"
        },
        {
            "urban_body_code": 250034,
            "id": 67156,
            "text": "Durgapur (M Corp.) - Ward No.15"
        },
        {
            "urban_body_code": 250034,
            "id": 67157,
            "text": "Durgapur (M Corp.) - Ward No.16"
        },
        {
            "urban_body_code": 250034,
            "id": 67158,
            "text": "Durgapur (M Corp.) - Ward No.17"
        },
        {
            "urban_body_code": 250034,
            "id": 67159,
            "text": "Durgapur (M Corp.) - Ward No.18"
        },
        {
            "urban_body_code": 250034,
            "id": 67160,
            "text": "Durgapur (M Corp.) - Ward No.19"
        },
        {
            "urban_body_code": 250034,
            "id": 67161,
            "text": "Durgapur (M Corp.) - Ward No.20"
        },
        {
            "urban_body_code": 250034,
            "id": 67162,
            "text": "Durgapur (M Corp.) - Ward No.21"
        },
        {
            "urban_body_code": 250034,
            "id": 67163,
            "text": "Durgapur (M Corp.) - Ward No.22"
        },
        {
            "urban_body_code": 250034,
            "id": 67164,
            "text": "Durgapur (M Corp.) - Ward No.23"
        },
        {
            "urban_body_code": 250034,
            "id": 67165,
            "text": "Durgapur (M Corp.) - Ward No.24"
        },
        {
            "urban_body_code": 250034,
            "id": 67166,
            "text": "Durgapur (M Corp.) - Ward No.25"
        },
        {
            "urban_body_code": 250034,
            "id": 67167,
            "text": "Durgapur (M Corp.) - Ward No.26"
        },
        {
            "urban_body_code": 250034,
            "id": 67168,
            "text": "Durgapur (M Corp.) - Ward No.27"
        },
        {
            "urban_body_code": 250034,
            "id": 67169,
            "text": "Durgapur (M Corp.) - Ward No.28"
        },
        {
            "urban_body_code": 250034,
            "id": 67170,
            "text": "Durgapur (M Corp.) - Ward No.29"
        },
        {
            "urban_body_code": 250034,
            "id": 67171,
            "text": "Durgapur (M Corp.) - Ward No.30"
        },
        {
            "urban_body_code": 250034,
            "id": 67172,
            "text": "Durgapur (M Corp.) - Ward No.31"
        },
        {
            "urban_body_code": 250034,
            "id": 67173,
            "text": "Durgapur (M Corp.) - Ward No.32"
        },
        {
            "urban_body_code": 250034,
            "id": 67174,
            "text": "Durgapur (M Corp.) - Ward No.33"
        },
        {
            "urban_body_code": 250034,
            "id": 67175,
            "text": "Durgapur (M Corp.) - Ward No.34"
        },
        {
            "urban_body_code": 250034,
            "id": 67176,
            "text": "Durgapur (M Corp.) - Ward No.35"
        },
        {
            "urban_body_code": 250034,
            "id": 67177,
            "text": "Durgapur (M Corp.) - Ward No.36"
        },
        {
            "urban_body_code": 250034,
            "id": 67178,
            "text": "Durgapur (M Corp.) - Ward No.37"
        },
        {
            "urban_body_code": 250034,
            "id": 67179,
            "text": "Durgapur (M Corp.) - Ward No.38"
        },
        {
            "urban_body_code": 250034,
            "id": 67180,
            "text": "Durgapur (M Corp.) - Ward No.39"
        },
        {
            "urban_body_code": 250034,
            "id": 67181,
            "text": "Durgapur (M Corp.) - Ward No.40"
        },
        {
            "urban_body_code": 250034,
            "id": 67182,
            "text": "Durgapur (M Corp.) - Ward No.41"
        },
        {
            "urban_body_code": 250034,
            "id": 67183,
            "text": "Durgapur (M Corp.) - Ward No.42"
        },
        {
            "urban_body_code": 250034,
            "id": 67184,
            "text": "Durgapur (M Corp.) - Ward No.43"
        },
        {
            "urban_body_code": 250035,
            "id": 14708,
            "text": "Katwa (M) - Ward No.1"
        },
        {
            "urban_body_code": 250035,
            "id": 14709,
            "text": "Katwa (M) - Ward No.2"
        },
        {
            "urban_body_code": 250035,
            "id": 14710,
            "text": "Katwa (M) - Ward No.3"
        },
        {
            "urban_body_code": 250035,
            "id": 14711,
            "text": "Katwa (M) - Ward No.4"
        },
        {
            "urban_body_code": 250035,
            "id": 14712,
            "text": "Katwa (M) - Ward No.5"
        },
        {
            "urban_body_code": 250035,
            "id": 14713,
            "text": "Katwa (M) - Ward No.6"
        },
        {
            "urban_body_code": 250035,
            "id": 14714,
            "text": "Katwa (M) - Ward No.7"
        },
        {
            "urban_body_code": 250035,
            "id": 14715,
            "text": "Katwa (M) - Ward No.8"
        },
        {
            "urban_body_code": 250035,
            "id": 14716,
            "text": "Katwa (M) - Ward No.9"
        },
        {
            "urban_body_code": 250035,
            "id": 14717,
            "text": "Katwa (M) - Ward No.10"
        },
        {
            "urban_body_code": 250035,
            "id": 14718,
            "text": "Katwa (M) - Ward No.11"
        },
        {
            "urban_body_code": 250035,
            "id": 14719,
            "text": "Katwa (M) - Ward No.12"
        },
        {
            "urban_body_code": 250035,
            "id": 14720,
            "text": "Katwa (M) - Ward No.13"
        },
        {
            "urban_body_code": 250035,
            "id": 14721,
            "text": "Katwa (M) - Ward No.14"
        },
        {
            "urban_body_code": 250035,
            "id": 14722,
            "text": "Katwa (M) - Ward No.15"
        },
        {
            "urban_body_code": 250035,
            "id": 14723,
            "text": "Katwa (M) - Ward No.16"
        },
        {
            "urban_body_code": 250035,
            "id": 14724,
            "text": "Katwa (M) - Ward No.17"
        },
        {
            "urban_body_code": 250035,
            "id": 14725,
            "text": "Katwa (M) - Ward No.18"
        },
        {
            "urban_body_code": 250035,
            "id": 14726,
            "text": "Katwa (M) - Ward No.19"
        },
        {
            "urban_body_code": 250035,
            "id": 9999338,
            "text": "Katwa (M) - Ward No.20"
        },
        {
            "urban_body_code": 250036,
            "id": 14727,
            "text": "Dainhat (M) - Ward No.1"
        },
        {
            "urban_body_code": 250036,
            "id": 14728,
            "text": "Dainhat (M) - Ward No.2"
        },
        {
            "urban_body_code": 250036,
            "id": 14729,
            "text": "Dainhat (M) - Ward No.3"
        },
        {
            "urban_body_code": 250036,
            "id": 14730,
            "text": "Dainhat (M) - Ward No.4"
        },
        {
            "urban_body_code": 250036,
            "id": 14731,
            "text": "Dainhat (M) - Ward No.5"
        },
        {
            "urban_body_code": 250036,
            "id": 14732,
            "text": "Dainhat (M) - Ward No.6"
        },
        {
            "urban_body_code": 250036,
            "id": 14733,
            "text": "Dainhat (M) - Ward No.7"
        },
        {
            "urban_body_code": 250036,
            "id": 14734,
            "text": "Dainhat (M) - Ward No.8"
        },
        {
            "urban_body_code": 250036,
            "id": 14735,
            "text": "Dainhat (M) - Ward No.9"
        },
        {
            "urban_body_code": 250036,
            "id": 14736,
            "text": "Dainhat (M) - Ward No.10"
        },
        {
            "urban_body_code": 250036,
            "id": 14737,
            "text": "Dainhat (M) - Ward No.11"
        },
        {
            "urban_body_code": 250036,
            "id": 14738,
            "text": "Dainhat (M) - Ward No.12"
        },
        {
            "urban_body_code": 250036,
            "id": 14739,
            "text": "Dainhat (M) - Ward No.13"
        },
        {
            "urban_body_code": 250036,
            "id": 14740,
            "text": "Dainhat (M) - Ward No.14"
        },
        {
            "urban_body_code": 250037,
            "id": 14741,
            "text": "Guskara (M) - Ward No.1"
        },
        {
            "urban_body_code": 250037,
            "id": 14742,
            "text": "Guskara (M) - Ward No.2"
        },
        {
            "urban_body_code": 250037,
            "id": 14743,
            "text": "Guskara (M) - Ward No.3"
        },
        {
            "urban_body_code": 250037,
            "id": 14744,
            "text": "Guskara (M) - Ward No.4"
        },
        {
            "urban_body_code": 250037,
            "id": 14745,
            "text": "Guskara (M) - Ward No.5"
        },
        {
            "urban_body_code": 250037,
            "id": 14746,
            "text": "Guskara (M) - Ward No.6"
        },
        {
            "urban_body_code": 250037,
            "id": 14747,
            "text": "Guskara (M) - Ward No.7"
        },
        {
            "urban_body_code": 250037,
            "id": 14748,
            "text": "Guskara (M) - Ward No.8"
        },
        {
            "urban_body_code": 250037,
            "id": 14749,
            "text": "Guskara (M) - Ward No.9"
        },
        {
            "urban_body_code": 250037,
            "id": 14750,
            "text": "Guskara (M) - Ward No.10"
        },
        {
            "urban_body_code": 250037,
            "id": 14751,
            "text": "Guskara (M) - Ward No.11"
        },
        {
            "urban_body_code": 250037,
            "id": 14752,
            "text": "Guskara (M) - Ward No.12"
        },
        {
            "urban_body_code": 250037,
            "id": 14753,
            "text": "Guskara (M) - Ward No.13"
        },
        {
            "urban_body_code": 250037,
            "id": 14754,
            "text": "Guskara (M) - Ward No.14"
        },
        {
            "urban_body_code": 250037,
            "id": 14755,
            "text": "Guskara (M) - Ward No.15"
        },
        {
            "urban_body_code": 250037,
            "id": 14756,
            "text": "Guskara (M) - Ward No.16"
        },
        {
            "urban_body_code": 250038,
            "id": 67185,
            "text": "Barddhaman (M) - Ward No.1"
        },
        {
            "urban_body_code": 250038,
            "id": 67186,
            "text": "Barddhaman (M) - Ward No.2"
        },
        {
            "urban_body_code": 250038,
            "id": 67187,
            "text": "Barddhaman (M) - Ward No.3"
        },
        {
            "urban_body_code": 250038,
            "id": 67188,
            "text": "Barddhaman (M) - Ward No.4"
        },
        {
            "urban_body_code": 250038,
            "id": 67189,
            "text": "Barddhaman (M) - Ward No.5"
        },
        {
            "urban_body_code": 250038,
            "id": 67190,
            "text": "Barddhaman (M) - Ward No.6"
        },
        {
            "urban_body_code": 250038,
            "id": 67191,
            "text": "Barddhaman (M) - Ward No.7"
        },
        {
            "urban_body_code": 250038,
            "id": 67192,
            "text": "Barddhaman (M) - Ward No.8"
        },
        {
            "urban_body_code": 250038,
            "id": 67193,
            "text": "Barddhaman (M) - Ward No.9"
        },
        {
            "urban_body_code": 250038,
            "id": 67194,
            "text": "Barddhaman (M) - Ward No.10"
        },
        {
            "urban_body_code": 250038,
            "id": 67195,
            "text": "Barddhaman (M) - Ward No.11"
        },
        {
            "urban_body_code": 250038,
            "id": 67196,
            "text": "Barddhaman (M) - Ward No.12"
        },
        {
            "urban_body_code": 250038,
            "id": 67197,
            "text": "Barddhaman (M) - Ward No.13"
        },
        {
            "urban_body_code": 250038,
            "id": 67198,
            "text": "Barddhaman (M) - Ward No.14"
        },
        {
            "urban_body_code": 250038,
            "id": 67199,
            "text": "Barddhaman (M) - Ward No.15"
        },
        {
            "urban_body_code": 250038,
            "id": 67200,
            "text": "Barddhaman (M) - Ward No.16"
        },
        {
            "urban_body_code": 250038,
            "id": 67201,
            "text": "Barddhaman (M) - Ward No.17"
        },
        {
            "urban_body_code": 250038,
            "id": 67202,
            "text": "Barddhaman (M) - Ward No.18"
        },
        {
            "urban_body_code": 250038,
            "id": 67203,
            "text": "Barddhaman (M) - Ward No.19"
        },
        {
            "urban_body_code": 250038,
            "id": 67204,
            "text": "Barddhaman (M) - Ward No.20"
        },
        {
            "urban_body_code": 250038,
            "id": 67205,
            "text": "Barddhaman (M) - Ward No.21"
        },
        {
            "urban_body_code": 250038,
            "id": 67206,
            "text": "Barddhaman (M) - Ward No.22"
        },
        {
            "urban_body_code": 250038,
            "id": 67207,
            "text": "Barddhaman (M) - Ward No.23"
        },
        {
            "urban_body_code": 250038,
            "id": 67208,
            "text": "Barddhaman (M) - Ward No.24"
        },
        {
            "urban_body_code": 250038,
            "id": 67209,
            "text": "Barddhaman (M) - Ward No.25"
        },
        {
            "urban_body_code": 250038,
            "id": 67210,
            "text": "Barddhaman (M) - Ward No.26"
        },
        {
            "urban_body_code": 250038,
            "id": 67211,
            "text": "Barddhaman (M) - Ward No.27"
        },
        {
            "urban_body_code": 250038,
            "id": 67212,
            "text": "Barddhaman (M) - Ward No.28"
        },
        {
            "urban_body_code": 250038,
            "id": 67213,
            "text": "Barddhaman (M) - Ward No.29"
        },
        {
            "urban_body_code": 250038,
            "id": 67214,
            "text": "Barddhaman (M) - Ward No.30"
        },
        {
            "urban_body_code": 250038,
            "id": 67215,
            "text": "Barddhaman (M) - Ward No.31"
        },
        {
            "urban_body_code": 250038,
            "id": 67216,
            "text": "Barddhaman (M) - Ward No.32"
        },
        {
            "urban_body_code": 250038,
            "id": 67217,
            "text": "Barddhaman (M) - Ward No.33"
        },
        {
            "urban_body_code": 250038,
            "id": 67218,
            "text": "Barddhaman (M) - Ward No.34"
        },
        {
            "urban_body_code": 250038,
            "id": 67219,
            "text": "Barddhaman (M) - Ward No.35"
        },
        {
            "urban_body_code": 250039,
            "id": 67220,
            "text": "Memari (M) - Ward No.1"
        },
        {
            "urban_body_code": 250039,
            "id": 67221,
            "text": "Memari (M) - Ward No.2"
        },
        {
            "urban_body_code": 250039,
            "id": 67222,
            "text": "Memari (M) - Ward No.3"
        },
        {
            "urban_body_code": 250039,
            "id": 67223,
            "text": "Memari (M) - Ward No.4"
        },
        {
            "urban_body_code": 250039,
            "id": 67224,
            "text": "Memari (M) - Ward No.5"
        },
        {
            "urban_body_code": 250039,
            "id": 67225,
            "text": "Memari (M) - Ward No.6"
        },
        {
            "urban_body_code": 250039,
            "id": 67226,
            "text": "Memari (M) - Ward No.7"
        },
        {
            "urban_body_code": 250039,
            "id": 67227,
            "text": "Memari (M) - Ward No.8"
        },
        {
            "urban_body_code": 250039,
            "id": 67228,
            "text": "Memari (M) - Ward No.9"
        },
        {
            "urban_body_code": 250039,
            "id": 67229,
            "text": "Memari (M) - Ward No.10"
        },
        {
            "urban_body_code": 250039,
            "id": 67230,
            "text": "Memari (M) - Ward No.11"
        },
        {
            "urban_body_code": 250039,
            "id": 67231,
            "text": "Memari (M) - Ward No.12"
        },
        {
            "urban_body_code": 250039,
            "id": 67232,
            "text": "Memari (M) - Ward No.13"
        },
        {
            "urban_body_code": 250039,
            "id": 67233,
            "text": "Memari (M) - Ward No.14"
        },
        {
            "urban_body_code": 250039,
            "id": 67234,
            "text": "Memari (M) - Ward No.15"
        },
        {
            "urban_body_code": 250039,
            "id": 67235,
            "text": "Memari (M) - Ward No.16"
        },
        {
            "urban_body_code": 250040,
            "id": 14757,
            "text": "Kalna (M) - Ward No.1"
        },
        {
            "urban_body_code": 250040,
            "id": 14758,
            "text": "Kalna (M) - Ward No.2"
        },
        {
            "urban_body_code": 250040,
            "id": 14759,
            "text": "Kalna (M) - Ward No.3"
        },
        {
            "urban_body_code": 250040,
            "id": 14760,
            "text": "Kalna (M) - Ward No.4"
        },
        {
            "urban_body_code": 250040,
            "id": 14761,
            "text": "Kalna (M) - Ward No.5"
        },
        {
            "urban_body_code": 250040,
            "id": 14762,
            "text": "Kalna (M) - Ward No.6"
        },
        {
            "urban_body_code": 250040,
            "id": 14763,
            "text": "Kalna (M) - Ward No.7"
        },
        {
            "urban_body_code": 250040,
            "id": 14764,
            "text": "Kalna (M) - Ward No.8"
        },
        {
            "urban_body_code": 250040,
            "id": 14765,
            "text": "Kalna (M) - Ward No.9"
        },
        {
            "urban_body_code": 250040,
            "id": 14766,
            "text": "Kalna (M) - Ward No.10"
        },
        {
            "urban_body_code": 250040,
            "id": 14767,
            "text": "Kalna (M) - Ward No.11"
        },
        {
            "urban_body_code": 250040,
            "id": 14768,
            "text": "Kalna (M) - Ward No.12"
        },
        {
            "urban_body_code": 250040,
            "id": 14769,
            "text": "Kalna (M) - Ward No.13"
        },
        {
            "urban_body_code": 250040,
            "id": 14770,
            "text": "Kalna (M) - Ward No.14"
        },
        {
            "urban_body_code": 250040,
            "id": 14771,
            "text": "Kalna (M) - Ward No.15"
        },
        {
            "urban_body_code": 250040,
            "id": 14772,
            "text": "Kalna (M) - Ward No.16"
        },
        {
            "urban_body_code": 250040,
            "id": 14773,
            "text": "Kalna (M) - Ward No.17"
        },
        {
            "urban_body_code": 250040,
            "id": 14774,
            "text": "Kalna (M) - Ward No.18"
        },
        {
            "urban_body_code": 250096,
            "id": 14822,
            "text": "Krishnanagar (M) - Ward No.1"
        },
        {
            "urban_body_code": 250096,
            "id": 14823,
            "text": "Krishnanagar (M) - Ward No.2"
        },
        {
            "urban_body_code": 250096,
            "id": 14824,
            "text": "Krishnanagar (M) - Ward No.3"
        },
        {
            "urban_body_code": 250096,
            "id": 14825,
            "text": "Krishnanagar (M) - Ward No.4"
        },
        {
            "urban_body_code": 250096,
            "id": 14826,
            "text": "Krishnanagar (M) - Ward No.5"
        },
        {
            "urban_body_code": 250096,
            "id": 14827,
            "text": "Krishnanagar (M) - Ward No.6"
        },
        {
            "urban_body_code": 250096,
            "id": 14828,
            "text": "Krishnanagar (M) - Ward No.7"
        },
        {
            "urban_body_code": 250096,
            "id": 14829,
            "text": "Krishnanagar (M) - Ward No.8"
        },
        {
            "urban_body_code": 250096,
            "id": 14830,
            "text": "Krishnanagar (M) - Ward No.9"
        },
        {
            "urban_body_code": 250096,
            "id": 14831,
            "text": "Krishnanagar (M) - Ward No.10"
        },
        {
            "urban_body_code": 250096,
            "id": 14832,
            "text": "Krishnanagar (M) - Ward No.11"
        },
        {
            "urban_body_code": 250096,
            "id": 14833,
            "text": "Krishnanagar (M) - Ward No.12"
        },
        {
            "urban_body_code": 250096,
            "id": 14834,
            "text": "Krishnanagar (M) - Ward No.13"
        },
        {
            "urban_body_code": 250096,
            "id": 14835,
            "text": "Krishnanagar (M) - Ward No.14"
        },
        {
            "urban_body_code": 250096,
            "id": 14836,
            "text": "Krishnanagar (M) - Ward No.15"
        },
        {
            "urban_body_code": 250096,
            "id": 14837,
            "text": "Krishnanagar (M) - Ward No.16"
        },
        {
            "urban_body_code": 250096,
            "id": 14838,
            "text": "Krishnanagar (M) - Ward No.17"
        },
        {
            "urban_body_code": 250096,
            "id": 14839,
            "text": "Krishnanagar (M) - Ward No.18"
        },
        {
            "urban_body_code": 250096,
            "id": 14840,
            "text": "Krishnanagar (M) - Ward No.19"
        },
        {
            "urban_body_code": 250096,
            "id": 14841,
            "text": "Krishnanagar (M) - Ward No.20"
        },
        {
            "urban_body_code": 250096,
            "id": 14842,
            "text": "Krishnanagar (M) - Ward No.21"
        },
        {
            "urban_body_code": 250096,
            "id": 14843,
            "text": "Krishnanagar (M) - Ward No.22"
        },
        {
            "urban_body_code": 250096,
            "id": 14844,
            "text": "Krishnanagar (M) - Ward No.23"
        },
        {
            "urban_body_code": 250096,
            "id": 14845,
            "text": "Krishnanagar (M) - Ward No.24"
        },
        {
            "urban_body_code": 250096,
            "id": 9999348,
            "text": "Krishnanagar (M) - Ward No.25"
        },
        {
            "urban_body_code": 250097,
            "id": 14846,
            "text": "Nabadwip (M) - Ward No.1"
        },
        {
            "urban_body_code": 250097,
            "id": 14847,
            "text": "Nabadwip (M) - Ward No.2"
        },
        {
            "urban_body_code": 250097,
            "id": 14848,
            "text": "Nabadwip (M) - Ward No.3"
        },
        {
            "urban_body_code": 250097,
            "id": 14849,
            "text": "Nabadwip (M) - Ward No.4"
        },
        {
            "urban_body_code": 250097,
            "id": 14850,
            "text": "Nabadwip (M) - Ward No.5"
        },
        {
            "urban_body_code": 250097,
            "id": 14851,
            "text": "Nabadwip (M) - Ward No.6"
        },
        {
            "urban_body_code": 250097,
            "id": 14852,
            "text": "Nabadwip (M) - Ward No.7"
        },
        {
            "urban_body_code": 250097,
            "id": 14853,
            "text": "Nabadwip (M) - Ward No.8"
        },
        {
            "urban_body_code": 250097,
            "id": 14854,
            "text": "Nabadwip (M) - Ward No.9"
        },
        {
            "urban_body_code": 250097,
            "id": 14855,
            "text": "Nabadwip (M) - Ward No.10"
        },
        {
            "urban_body_code": 250097,
            "id": 14856,
            "text": "Nabadwip (M) - Ward No.11"
        },
        {
            "urban_body_code": 250097,
            "id": 14857,
            "text": "Nabadwip (M) - Ward No.12"
        },
        {
            "urban_body_code": 250097,
            "id": 14858,
            "text": "Nabadwip (M) - Ward No.13"
        },
        {
            "urban_body_code": 250097,
            "id": 14859,
            "text": "Nabadwip (M) - Ward No.14"
        },
        {
            "urban_body_code": 250097,
            "id": 14860,
            "text": "Nabadwip (M) - Ward No.15"
        },
        {
            "urban_body_code": 250097,
            "id": 14861,
            "text": "Nabadwip (M) - Ward No.16"
        },
        {
            "urban_body_code": 250097,
            "id": 14862,
            "text": "Nabadwip (M) - Ward No.17"
        },
        {
            "urban_body_code": 250097,
            "id": 14863,
            "text": "Nabadwip (M) - Ward No.18"
        },
        {
            "urban_body_code": 250097,
            "id": 14864,
            "text": "Nabadwip (M) - Ward No.19"
        },
        {
            "urban_body_code": 250097,
            "id": 14865,
            "text": "Nabadwip (M) - Ward No.20"
        },
        {
            "urban_body_code": 250097,
            "id": 14866,
            "text": "Nabadwip (M) - Ward No.21"
        },
        {
            "urban_body_code": 250097,
            "id": 14867,
            "text": "Nabadwip (M) - Ward No.22"
        },
        {
            "urban_body_code": 250097,
            "id": 14868,
            "text": "Nabadwip (M) - Ward No.23"
        },
        {
            "urban_body_code": 250097,
            "id": 14869,
            "text": "Nabadwip (M) - Ward No.24"
        },
        {
            "urban_body_code": 250098,
            "id": 14870,
            "text": "Taherpur (NA) - Ward No.1"
        },
        {
            "urban_body_code": 250098,
            "id": 14871,
            "text": "Taherpur (NA) - Ward No.2"
        },
        {
            "urban_body_code": 250098,
            "id": 14872,
            "text": "Taherpur (NA) - Ward No.3"
        },
        {
            "urban_body_code": 250098,
            "id": 14873,
            "text": "Taherpur (NA) - Ward No.4"
        },
        {
            "urban_body_code": 250098,
            "id": 14874,
            "text": "Taherpur (NA) - Ward No.5"
        },
        {
            "urban_body_code": 250098,
            "id": 14875,
            "text": "Taherpur (NA) - Ward No.6"
        },
        {
            "urban_body_code": 250098,
            "id": 14876,
            "text": "Taherpur (NA) - Ward No.7"
        },
        {
            "urban_body_code": 250098,
            "id": 14877,
            "text": "Taherpur (NA) - Ward No.8"
        },
        {
            "urban_body_code": 250098,
            "id": 14878,
            "text": "Taherpur (NA) - Ward No.9"
        },
        {
            "urban_body_code": 250098,
            "id": 14879,
            "text": "Taherpur (NA) - Ward No.10"
        },
        {
            "urban_body_code": 250098,
            "id": 14880,
            "text": "Taherpur (NA) - Ward No.11"
        },
        {
            "urban_body_code": 250098,
            "id": 14881,
            "text": "Taherpur (NA) - Ward No.12"
        },
        {
            "urban_body_code": 250098,
            "id": 14882,
            "text": "Taherpur (NA) - Ward No.13"
        },
        {
            "urban_body_code": 250098,
            "id": 14961,
            "text": "Taherpur (OG) - Ward No.14"
        },
        {
            "urban_body_code": 250098,
            "id": 14962,
            "text": "Barasat (OG) - Ward No.15"
        },
        {
            "urban_body_code": 250098,
            "id": 14963,
            "text": "Bhaduri (OG) - Ward No.16"
        },
        {
            "urban_body_code": 250098,
            "id": 14964,
            "text": "Mahishdanga (OG) - Ward No.17"
        },
        {
            "urban_body_code": 250099,
            "id": 14883,
            "text": "Santipur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250099,
            "id": 14884,
            "text": "Santipur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250099,
            "id": 14885,
            "text": "Santipur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250099,
            "id": 14886,
            "text": "Santipur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250099,
            "id": 14887,
            "text": "Santipur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250099,
            "id": 14888,
            "text": "Santipur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250099,
            "id": 14889,
            "text": "Santipur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250099,
            "id": 14890,
            "text": "Santipur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250099,
            "id": 14891,
            "text": "Santipur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250099,
            "id": 14892,
            "text": "Santipur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250099,
            "id": 14893,
            "text": "Santipur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250099,
            "id": 14894,
            "text": "Santipur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250099,
            "id": 14895,
            "text": "Santipur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250099,
            "id": 14896,
            "text": "Santipur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250099,
            "id": 14897,
            "text": "Santipur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250099,
            "id": 14898,
            "text": "Santipur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250099,
            "id": 14899,
            "text": "Santipur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250099,
            "id": 14900,
            "text": "Santipur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250099,
            "id": 14901,
            "text": "Santipur (M) - Ward No.19"
        },
        {
            "urban_body_code": 250099,
            "id": 14902,
            "text": "Santipur (M) - Ward No.20"
        },
        {
            "urban_body_code": 250099,
            "id": 14903,
            "text": "Santipur (M) - Ward No.21"
        },
        {
            "urban_body_code": 250099,
            "id": 14904,
            "text": "Santipur (M) - Ward No.22"
        },
        {
            "urban_body_code": 250099,
            "id": 14905,
            "text": "Santipur (M) - Ward No.23"
        },
        {
            "urban_body_code": 250099,
            "id": 9999408,
            "text": "Santipur (M) - Ward No.24"
        },
        {
            "urban_body_code": 250099,
            "id": 9999374,
            "text": "Santipur (M) - Ward No.24"
        },
        {
            "urban_body_code": 250100,
            "id": 67249,
            "text": "Birnagar (M) - Ward No.1"
        },
        {
            "urban_body_code": 250100,
            "id": 67250,
            "text": "Birnagar (M) - Ward No.2"
        },
        {
            "urban_body_code": 250100,
            "id": 67251,
            "text": "Birnagar (M) - Ward No.3"
        },
        {
            "urban_body_code": 250100,
            "id": 67252,
            "text": "Birnagar (M) - Ward No.4"
        },
        {
            "urban_body_code": 250100,
            "id": 67253,
            "text": "Birnagar (M) - Ward No.5"
        },
        {
            "urban_body_code": 250100,
            "id": 67254,
            "text": "Birnagar (M) - Ward No.6"
        },
        {
            "urban_body_code": 250100,
            "id": 67255,
            "text": "Birnagar (M) - Ward No.7"
        },
        {
            "urban_body_code": 250100,
            "id": 67256,
            "text": "Birnagar (M) - Ward No.8"
        },
        {
            "urban_body_code": 250100,
            "id": 67257,
            "text": "Birnagar (M) - Ward No.9"
        },
        {
            "urban_body_code": 250100,
            "id": 67258,
            "text": "Birnagar (M) - Ward No.10"
        },
        {
            "urban_body_code": 250100,
            "id": 67259,
            "text": "Birnagar (M) - Ward No.11"
        },
        {
            "urban_body_code": 250100,
            "id": 67260,
            "text": "Birnagar (M) - Ward No.12"
        },
        {
            "urban_body_code": 250100,
            "id": 67261,
            "text": "Birnagar (M) - Ward No.13"
        },
        {
            "urban_body_code": 250100,
            "id": 67262,
            "text": "Birnagar (M) - Ward No.14"
        },
        {
            "urban_body_code": 250100,
            "id": 67304,
            "text": "Palitpara (OG) - Ward No.15"
        },
        {
            "urban_body_code": 250101,
            "id": 14906,
            "text": "Ranaghat (M) - Ward No.1"
        },
        {
            "urban_body_code": 250101,
            "id": 14907,
            "text": "Ranaghat (M) - Ward No.2"
        },
        {
            "urban_body_code": 250101,
            "id": 14908,
            "text": "Ranaghat (M) - Ward No.3"
        },
        {
            "urban_body_code": 250101,
            "id": 14909,
            "text": "Ranaghat (M) - Ward No.4"
        },
        {
            "urban_body_code": 250101,
            "id": 14910,
            "text": "Ranaghat (M) - Ward No.5"
        },
        {
            "urban_body_code": 250101,
            "id": 14911,
            "text": "Ranaghat (M) - Ward No.6"
        },
        {
            "urban_body_code": 250101,
            "id": 14912,
            "text": "Ranaghat (M) - Ward No.7"
        },
        {
            "urban_body_code": 250101,
            "id": 14913,
            "text": "Ranaghat (M) - Ward No.8"
        },
        {
            "urban_body_code": 250101,
            "id": 14914,
            "text": "Ranaghat (M) - Ward No.9"
        },
        {
            "urban_body_code": 250101,
            "id": 14915,
            "text": "Ranaghat (M) - Ward No.10"
        },
        {
            "urban_body_code": 250101,
            "id": 14916,
            "text": "Ranaghat (M) - Ward No.11"
        },
        {
            "urban_body_code": 250101,
            "id": 14917,
            "text": "Ranaghat (M) - Ward No.12"
        },
        {
            "urban_body_code": 250101,
            "id": 14918,
            "text": "Ranaghat (M) - Ward No.13"
        },
        {
            "urban_body_code": 250101,
            "id": 14919,
            "text": "Ranaghat (M) - Ward No.14"
        },
        {
            "urban_body_code": 250101,
            "id": 14920,
            "text": "Ranaghat (M) - Ward No.15"
        },
        {
            "urban_body_code": 250101,
            "id": 14921,
            "text": "Ranaghat (M) - Ward No.16"
        },
        {
            "urban_body_code": 250101,
            "id": 14922,
            "text": "Ranaghat (M) - Ward No.17"
        },
        {
            "urban_body_code": 250101,
            "id": 14923,
            "text": "Ranaghat (M) - Ward No.18"
        },
        {
            "urban_body_code": 250101,
            "id": 14924,
            "text": "Ranaghat (M) - Ward No.19"
        },
        {
            "urban_body_code": 250101,
            "id": 14967,
            "text": "Hijuli (OG) - Ward No.20"
        },
        {
            "urban_body_code": 250101,
            "id": 14968,
            "text": "Ranaghat (OG) - Ward No.21"
        },
        {
            "urban_body_code": 250102,
            "id": 14925,
            "text": "Cooper's Camp (NA) - Ward No.1"
        },
        {
            "urban_body_code": 250102,
            "id": 14926,
            "text": "Cooper's Camp (NA) - Ward No.2"
        },
        {
            "urban_body_code": 250102,
            "id": 14927,
            "text": "Cooper's Camp (NA) - Ward No.3"
        },
        {
            "urban_body_code": 250102,
            "id": 14928,
            "text": "Cooper's Camp (NA) - Ward No.4"
        },
        {
            "urban_body_code": 250102,
            "id": 14929,
            "text": "Cooper's Camp (NA) - Ward No.5"
        },
        {
            "urban_body_code": 250102,
            "id": 14930,
            "text": "Cooper's Camp (NA) - Ward No.6"
        },
        {
            "urban_body_code": 250102,
            "id": 14931,
            "text": "Cooper's Camp (NA) - Ward No.7"
        },
        {
            "urban_body_code": 250102,
            "id": 14932,
            "text": "Cooper's Camp (NA) - Ward No.8"
        },
        {
            "urban_body_code": 250102,
            "id": 14933,
            "text": "Cooper's Camp (NA) - Ward No.9"
        },
        {
            "urban_body_code": 250102,
            "id": 14934,
            "text": "Cooper's Camp (NA) - Ward No.10"
        },
        {
            "urban_body_code": 250102,
            "id": 14935,
            "text": "Cooper's Camp (NA) - Ward No.11"
        },
        {
            "urban_body_code": 250102,
            "id": 14936,
            "text": "Cooper's Camp (NA) - Ward No.12"
        },
        {
            "urban_body_code": 250102,
            "id": 14969,
            "text": "Magurkhali (OG) - Ward No.13"
        },
        {
            "urban_body_code": 250103,
            "id": 14937,
            "text": "Chakdaha (M) - Ward No.1"
        },
        {
            "urban_body_code": 250103,
            "id": 14938,
            "text": "Chakdaha (M) - Ward No.2"
        },
        {
            "urban_body_code": 250103,
            "id": 14939,
            "text": "Chakdaha (M) - Ward No.3"
        },
        {
            "urban_body_code": 250103,
            "id": 14940,
            "text": "Chakdaha (M) - Ward No.4"
        },
        {
            "urban_body_code": 250103,
            "id": 14941,
            "text": "Chakdaha (M) - Ward No.5"
        },
        {
            "urban_body_code": 250103,
            "id": 14942,
            "text": "Chakdaha (M) - Ward No.6"
        },
        {
            "urban_body_code": 250103,
            "id": 14943,
            "text": "Chakdaha (M) - Ward No.7"
        },
        {
            "urban_body_code": 250103,
            "id": 14944,
            "text": "Chakdaha (M) - Ward No.8"
        },
        {
            "urban_body_code": 250103,
            "id": 14945,
            "text": "Chakdaha (M) - Ward No.9"
        },
        {
            "urban_body_code": 250103,
            "id": 14946,
            "text": "Chakdaha (M) - Ward No.10"
        },
        {
            "urban_body_code": 250103,
            "id": 14947,
            "text": "Chakdaha (M) - Ward No.11"
        },
        {
            "urban_body_code": 250103,
            "id": 14948,
            "text": "Chakdaha (M) - Ward No.12"
        },
        {
            "urban_body_code": 250103,
            "id": 14949,
            "text": "Chakdaha (M) - Ward No.13"
        },
        {
            "urban_body_code": 250103,
            "id": 14950,
            "text": "Chakdaha (M) - Ward No.14"
        },
        {
            "urban_body_code": 250103,
            "id": 14951,
            "text": "Chakdaha (M) - Ward No.15"
        },
        {
            "urban_body_code": 250103,
            "id": 14952,
            "text": "Chakdaha (M) - Ward No.16"
        },
        {
            "urban_body_code": 250103,
            "id": 14953,
            "text": "Chakdaha (M) - Ward No.17"
        },
        {
            "urban_body_code": 250103,
            "id": 14954,
            "text": "Chakdaha (M) - Ward No.18"
        },
        {
            "urban_body_code": 250103,
            "id": 14955,
            "text": "Chakdaha (M) - Ward No.19"
        },
        {
            "urban_body_code": 250103,
            "id": 14956,
            "text": "Chakdaha (M) - Ward No.20"
        },
        {
            "urban_body_code": 250103,
            "id": 9999209,
            "text": "Chakdaha (M) - Ward No.21"
        },
        {
            "urban_body_code": 250104,
            "id": 67263,
            "text": "Kalyani (M) - Ward No.1"
        },
        {
            "urban_body_code": 250104,
            "id": 67264,
            "text": "Kalyani (M) - Ward No.2"
        },
        {
            "urban_body_code": 250104,
            "id": 67265,
            "text": "Kalyani (M) - Ward No.3"
        },
        {
            "urban_body_code": 250104,
            "id": 67266,
            "text": "Kalyani (M) - Ward No.4"
        },
        {
            "urban_body_code": 250104,
            "id": 67267,
            "text": "Kalyani (M) - Ward No.5"
        },
        {
            "urban_body_code": 250104,
            "id": 67268,
            "text": "Kalyani (M) - Ward No.6"
        },
        {
            "urban_body_code": 250104,
            "id": 67269,
            "text": "Kalyani (M) - Ward No.7"
        },
        {
            "urban_body_code": 250104,
            "id": 67270,
            "text": "Kalyani (M) - Ward No.8"
        },
        {
            "urban_body_code": 250104,
            "id": 67271,
            "text": "Kalyani (M) - Ward No.9"
        },
        {
            "urban_body_code": 250104,
            "id": 67272,
            "text": "Kalyani (M) - Ward No.10"
        },
        {
            "urban_body_code": 250104,
            "id": 67273,
            "text": "Kalyani (M) - Ward No.11"
        },
        {
            "urban_body_code": 250104,
            "id": 67274,
            "text": "Kalyani (M) - Ward No.12"
        },
        {
            "urban_body_code": 250104,
            "id": 67275,
            "text": "Kalyani (M) - Ward No.13"
        },
        {
            "urban_body_code": 250104,
            "id": 67276,
            "text": "Kalyani (M) - Ward No.14"
        },
        {
            "urban_body_code": 250104,
            "id": 67277,
            "text": "Kalyani (M) - Ward No.15"
        },
        {
            "urban_body_code": 250104,
            "id": 67278,
            "text": "Kalyani (M) - Ward No.16"
        },
        {
            "urban_body_code": 250104,
            "id": 67279,
            "text": "Kalyani (M) - Ward No.17"
        },
        {
            "urban_body_code": 250104,
            "id": 67280,
            "text": "Kalyani (M) - Ward No.18"
        },
        {
            "urban_body_code": 250104,
            "id": 67281,
            "text": "Kalyani (M) - Ward No.19"
        },
        {
            "urban_body_code": 250104,
            "id": 67306,
            "text": "Kanchrapara (OG) - Ward No.20"
        },
        {
            "urban_body_code": 250104,
            "id": 9999336,
            "text": "Kalyani (M) - Ward No.21"
        },
        {
            "urban_body_code": 250105,
            "id": 67282,
            "text": "Gayespur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250105,
            "id": 67283,
            "text": "Gayespur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250105,
            "id": 67284,
            "text": "Gayespur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250105,
            "id": 67285,
            "text": "Gayespur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250105,
            "id": 67286,
            "text": "Gayespur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250105,
            "id": 67287,
            "text": "Gayespur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250105,
            "id": 67288,
            "text": "Gayespur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250105,
            "id": 67289,
            "text": "Gayespur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250105,
            "id": 67290,
            "text": "Gayespur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250105,
            "id": 67291,
            "text": "Gayespur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250105,
            "id": 67292,
            "text": "Gayespur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250105,
            "id": 67293,
            "text": "Gayespur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250105,
            "id": 67294,
            "text": "Gayespur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250105,
            "id": 67295,
            "text": "Gayespur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250105,
            "id": 67296,
            "text": "Gayespur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250105,
            "id": 67297,
            "text": "Gayespur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250105,
            "id": 67298,
            "text": "Gayespur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250105,
            "id": 67299,
            "text": "Gayespur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250121,
            "id": 15457,
            "text": "Bangaon (M) - Ward No.1"
        },
        {
            "urban_body_code": 250121,
            "id": 15458,
            "text": "Bangaon (M) - Ward No.2"
        },
        {
            "urban_body_code": 250121,
            "id": 15459,
            "text": "Bangaon (M) - Ward No.3"
        },
        {
            "urban_body_code": 250121,
            "id": 15460,
            "text": "Bangaon (M) - Ward No.4"
        },
        {
            "urban_body_code": 250121,
            "id": 14973,
            "text": "Bangaon (M) - Ward No.5"
        },
        {
            "urban_body_code": 250121,
            "id": 14974,
            "text": "Bangaon (M) - Ward No.6"
        },
        {
            "urban_body_code": 250121,
            "id": 15456,
            "text": "Bangaon (M) - Ward No.7"
        },
        {
            "urban_body_code": 250121,
            "id": 15461,
            "text": "Bangaon (M) - Ward No.8"
        },
        {
            "urban_body_code": 250121,
            "id": 15462,
            "text": "Bangaon (M) - Ward No.9"
        },
        {
            "urban_body_code": 250121,
            "id": 15463,
            "text": "Bangaon (M) - Ward No.10"
        },
        {
            "urban_body_code": 250121,
            "id": 15464,
            "text": "Bangaon (M) - Ward No.11"
        },
        {
            "urban_body_code": 250121,
            "id": 15465,
            "text": "Bangaon (M) - Ward No.12"
        },
        {
            "urban_body_code": 250121,
            "id": 15466,
            "text": "Bangaon (M) - Ward No.13"
        },
        {
            "urban_body_code": 250121,
            "id": 15467,
            "text": "Bangaon (M) - Ward No.14"
        },
        {
            "urban_body_code": 250121,
            "id": 15468,
            "text": "Bangaon (M) - Ward No.15"
        },
        {
            "urban_body_code": 250121,
            "id": 15469,
            "text": "Bangaon (M) - Ward No.16"
        },
        {
            "urban_body_code": 250121,
            "id": 15470,
            "text": "Bangaon (M) - Ward No.17"
        },
        {
            "urban_body_code": 250121,
            "id": 15471,
            "text": "Bangaon (M) - Ward No.18"
        },
        {
            "urban_body_code": 250121,
            "id": 15472,
            "text": "Bangaon (M) - Ward No.19"
        },
        {
            "urban_body_code": 250121,
            "id": 15473,
            "text": "Bangaon (M) - Ward No.20"
        },
        {
            "urban_body_code": 250121,
            "id": 15474,
            "text": "Bangaon (M) - Ward No.21"
        },
        {
            "urban_body_code": 250121,
            "id": 9999164,
            "text": "Bangaon (M) - Ward No.22"
        },
        {
            "urban_body_code": 250122,
            "id": 15475,
            "text": "Kanchrapara (M) - Ward No.1"
        },
        {
            "urban_body_code": 250122,
            "id": 15476,
            "text": "Kanchrapara (M) - Ward No.2"
        },
        {
            "urban_body_code": 250122,
            "id": 15477,
            "text": "Kanchrapara (M) - Ward No.3"
        },
        {
            "urban_body_code": 250122,
            "id": 15478,
            "text": "Kanchrapara (M) - Ward No.4"
        },
        {
            "urban_body_code": 250122,
            "id": 15479,
            "text": "Kanchrapara (M) - Ward No.5"
        },
        {
            "urban_body_code": 250122,
            "id": 15480,
            "text": "Kanchrapara (M) - Ward No.6"
        },
        {
            "urban_body_code": 250122,
            "id": 15481,
            "text": "Kanchrapara (M) - Ward No.7"
        },
        {
            "urban_body_code": 250122,
            "id": 15482,
            "text": "Kanchrapara (M) - Ward No.8"
        },
        {
            "urban_body_code": 250122,
            "id": 15483,
            "text": "Kanchrapara (M) - Ward No.9"
        },
        {
            "urban_body_code": 250122,
            "id": 15484,
            "text": "Kanchrapara (M) - Ward No.10"
        },
        {
            "urban_body_code": 250122,
            "id": 15485,
            "text": "Kanchrapara (M) - Ward No.11"
        },
        {
            "urban_body_code": 250122,
            "id": 15486,
            "text": "Kanchrapara (M) - Ward No.12"
        },
        {
            "urban_body_code": 250122,
            "id": 15487,
            "text": "Kanchrapara (M) - Ward No.13"
        },
        {
            "urban_body_code": 250122,
            "id": 15488,
            "text": "Kanchrapara (M) - Ward No.14"
        },
        {
            "urban_body_code": 250122,
            "id": 15489,
            "text": "Kanchrapara (M) - Ward No.15"
        },
        {
            "urban_body_code": 250122,
            "id": 15490,
            "text": "Kanchrapara (M) - Ward No.16"
        },
        {
            "urban_body_code": 250122,
            "id": 15491,
            "text": "Kanchrapara (M) - Ward No.17"
        },
        {
            "urban_body_code": 250122,
            "id": 15492,
            "text": "Kanchrapara (M) - Ward No.18"
        },
        {
            "urban_body_code": 250122,
            "id": 15493,
            "text": "Kanchrapara (M) - Ward No.19"
        },
        {
            "urban_body_code": 250122,
            "id": 15494,
            "text": "Kanchrapara (M) - Ward No.20"
        },
        {
            "urban_body_code": 250122,
            "id": 15495,
            "text": "Kanchrapara (M) - Ward No.21"
        },
        {
            "urban_body_code": 250122,
            "id": 15496,
            "text": "Kanchrapara (M) - Ward No.22"
        },
        {
            "urban_body_code": 250122,
            "id": 15497,
            "text": "Kanchrapara (M) - Ward No.23"
        },
        {
            "urban_body_code": 250122,
            "id": 15498,
            "text": "Kanchrapara (M) - Ward No.24"
        },
        {
            "urban_body_code": 250122,
            "id": 16219,
            "text": "Srotribati (OG) - Ward No.25"
        },
        {
            "urban_body_code": 250122,
            "id": 16220,
            "text": "Chakla (OG) - Ward No.26"
        },
        {
            "urban_body_code": 250122,
            "id": 16221,
            "text": "Nanna (OG) - Ward No.27"
        },
        {
            "urban_body_code": 250123,
            "id": 67307,
            "text": "Halisahar (M) - Ward No.1"
        },
        {
            "urban_body_code": 250123,
            "id": 67308,
            "text": "Halisahar (M) - Ward No.2"
        },
        {
            "urban_body_code": 250123,
            "id": 67309,
            "text": "Halisahar (M) - Ward No.3"
        },
        {
            "urban_body_code": 250123,
            "id": 67310,
            "text": "Halisahar (M) - Ward No.4"
        },
        {
            "urban_body_code": 250123,
            "id": 67311,
            "text": "Halisahar (M) - Ward No.5"
        },
        {
            "urban_body_code": 250123,
            "id": 67312,
            "text": "Halisahar (M) - Ward No.6"
        },
        {
            "urban_body_code": 250123,
            "id": 67313,
            "text": "Halisahar (M) - Ward No.7"
        },
        {
            "urban_body_code": 250123,
            "id": 67314,
            "text": "Halisahar (M) - Ward No.8"
        },
        {
            "urban_body_code": 250123,
            "id": 67315,
            "text": "Halisahar (M) - Ward No.9"
        },
        {
            "urban_body_code": 250123,
            "id": 67316,
            "text": "Halisahar (M) - Ward No.10"
        },
        {
            "urban_body_code": 250123,
            "id": 67317,
            "text": "Halisahar (M) - Ward No.11"
        },
        {
            "urban_body_code": 250123,
            "id": 67318,
            "text": "Halisahar (M) - Ward No.12"
        },
        {
            "urban_body_code": 250123,
            "id": 67319,
            "text": "Halisahar (M) - Ward No.13"
        },
        {
            "urban_body_code": 250123,
            "id": 67320,
            "text": "Halisahar (M) - Ward No.14"
        },
        {
            "urban_body_code": 250123,
            "id": 67321,
            "text": "Halisahar (M) - Ward No.15"
        },
        {
            "urban_body_code": 250123,
            "id": 67322,
            "text": "Halisahar (M) - Ward No.16"
        },
        {
            "urban_body_code": 250123,
            "id": 67323,
            "text": "Halisahar (M) - Ward No.17"
        },
        {
            "urban_body_code": 250123,
            "id": 67324,
            "text": "Halisahar (M) - Ward No.18"
        },
        {
            "urban_body_code": 250123,
            "id": 67325,
            "text": "Halisahar (M) - Ward No.19"
        },
        {
            "urban_body_code": 250123,
            "id": 67326,
            "text": "Halisahar (M) - Ward No.20"
        },
        {
            "urban_body_code": 250123,
            "id": 67327,
            "text": "Halisahar (M) - Ward No.21"
        },
        {
            "urban_body_code": 250123,
            "id": 67328,
            "text": "Halisahar (M) - Ward No.22"
        },
        {
            "urban_body_code": 250123,
            "id": 67329,
            "text": "Halisahar (M) - Ward No.23"
        },
        {
            "urban_body_code": 250123,
            "id": 63930,
            "text": "Balibhara (OG) - Ward No.24"
        },
        {
            "urban_body_code": 250124,
            "id": 15499,
            "text": "Naihati (M) - Ward No.1"
        },
        {
            "urban_body_code": 250124,
            "id": 15500,
            "text": "Naihati (M) - Ward No.2"
        },
        {
            "urban_body_code": 250124,
            "id": 15501,
            "text": "Naihati (M) - Ward No.3"
        },
        {
            "urban_body_code": 250124,
            "id": 15502,
            "text": "Naihati (M) - Ward No.4"
        },
        {
            "urban_body_code": 250124,
            "id": 15503,
            "text": "Naihati (M) - Ward No.5"
        },
        {
            "urban_body_code": 250124,
            "id": 15504,
            "text": "Naihati (M) - Ward No.6"
        },
        {
            "urban_body_code": 250124,
            "id": 15505,
            "text": "Naihati (M) - Ward No.7"
        },
        {
            "urban_body_code": 250124,
            "id": 15506,
            "text": "Naihati (M) - Ward No.8"
        },
        {
            "urban_body_code": 250124,
            "id": 15507,
            "text": "Naihati (M) - Ward No.9"
        },
        {
            "urban_body_code": 250124,
            "id": 15508,
            "text": "Naihati (M) - Ward No.10"
        },
        {
            "urban_body_code": 250124,
            "id": 15509,
            "text": "Naihati (M) - Ward No.11"
        },
        {
            "urban_body_code": 250124,
            "id": 15510,
            "text": "Naihati (M) - Ward No.12"
        },
        {
            "urban_body_code": 250124,
            "id": 15511,
            "text": "Naihati (M) - Ward No.13"
        },
        {
            "urban_body_code": 250124,
            "id": 15512,
            "text": "Naihati (M) - Ward No.14"
        },
        {
            "urban_body_code": 250124,
            "id": 15513,
            "text": "Naihati (M) - Ward No.15"
        },
        {
            "urban_body_code": 250124,
            "id": 15514,
            "text": "Naihati (M) - Ward No.16"
        },
        {
            "urban_body_code": 250124,
            "id": 15515,
            "text": "Naihati (M) - Ward No.17"
        },
        {
            "urban_body_code": 250124,
            "id": 15516,
            "text": "Naihati (M) - Ward No.18"
        },
        {
            "urban_body_code": 250124,
            "id": 15517,
            "text": "Naihati (M) - Ward No.19"
        },
        {
            "urban_body_code": 250124,
            "id": 15518,
            "text": "Naihati (M) - Ward No.20"
        },
        {
            "urban_body_code": 250124,
            "id": 15519,
            "text": "Naihati (M) - Ward No.21"
        },
        {
            "urban_body_code": 250124,
            "id": 15520,
            "text": "Naihati (M) - Ward No.22"
        },
        {
            "urban_body_code": 250124,
            "id": 15521,
            "text": "Naihati (M) - Ward No.23"
        },
        {
            "urban_body_code": 250124,
            "id": 15522,
            "text": "Naihati (M) - Ward No.24"
        },
        {
            "urban_body_code": 250124,
            "id": 15523,
            "text": "Naihati (M) - Ward No.25"
        },
        {
            "urban_body_code": 250124,
            "id": 15524,
            "text": "Naihati (M) - Ward No.26"
        },
        {
            "urban_body_code": 250124,
            "id": 15525,
            "text": "Naihati (M) - Ward No.27"
        },
        {
            "urban_body_code": 250124,
            "id": 15526,
            "text": "Naihati (M) - Ward No.28"
        },
        {
            "urban_body_code": 250124,
            "id": 9999355,
            "text": "Naihati (M) - Ward No.29"
        },
        {
            "urban_body_code": 250124,
            "id": 9999356,
            "text": "Naihati (M) - Ward No.30"
        },
        {
            "urban_body_code": 250124,
            "id": 9999357,
            "text": "Naihati (M) - Ward No.31"
        },
        {
            "urban_body_code": 250125,
            "id": 15527,
            "text": "Bhatpara (M) - Ward No.1"
        },
        {
            "urban_body_code": 250125,
            "id": 15528,
            "text": "Bhatpara (M) - Ward No.2"
        },
        {
            "urban_body_code": 250125,
            "id": 15529,
            "text": "Bhatpara (M) - Ward No.3"
        },
        {
            "urban_body_code": 250125,
            "id": 15530,
            "text": "Bhatpara (M) - Ward No.4"
        },
        {
            "urban_body_code": 250125,
            "id": 15531,
            "text": "Bhatpara (M) - Ward No.5"
        },
        {
            "urban_body_code": 250125,
            "id": 15532,
            "text": "Bhatpara (M) - Ward No.6"
        },
        {
            "urban_body_code": 250125,
            "id": 15533,
            "text": "Bhatpara (M) - Ward No.7"
        },
        {
            "urban_body_code": 250125,
            "id": 15534,
            "text": "Bhatpara (M) - Ward No.8"
        },
        {
            "urban_body_code": 250125,
            "id": 15535,
            "text": "Bhatpara (M) - Ward No.9"
        },
        {
            "urban_body_code": 250125,
            "id": 15536,
            "text": "Bhatpara (M) - Ward No.10"
        },
        {
            "urban_body_code": 250125,
            "id": 15537,
            "text": "Bhatpara (M) - Ward No.11"
        },
        {
            "urban_body_code": 250125,
            "id": 15538,
            "text": "Bhatpara (M) - Ward No.12"
        },
        {
            "urban_body_code": 250125,
            "id": 15539,
            "text": "Bhatpara (M) - Ward No.13"
        },
        {
            "urban_body_code": 250125,
            "id": 15540,
            "text": "Bhatpara (M) - Ward No.14"
        },
        {
            "urban_body_code": 250125,
            "id": 15541,
            "text": "Bhatpara (M) - Ward No.15"
        },
        {
            "urban_body_code": 250125,
            "id": 15542,
            "text": "Bhatpara (M) - Ward No.16"
        },
        {
            "urban_body_code": 250125,
            "id": 15543,
            "text": "Bhatpara (M) - Ward No.17"
        },
        {
            "urban_body_code": 250125,
            "id": 15544,
            "text": "Bhatpara (M) - Ward No.18"
        },
        {
            "urban_body_code": 250125,
            "id": 15545,
            "text": "Bhatpara (M) - Ward No.19"
        },
        {
            "urban_body_code": 250125,
            "id": 15546,
            "text": "Bhatpara (M) - Ward No.20"
        },
        {
            "urban_body_code": 250125,
            "id": 15547,
            "text": "Bhatpara (M) - Ward No.21"
        },
        {
            "urban_body_code": 250125,
            "id": 15548,
            "text": "Bhatpara (M) - Ward No.22"
        },
        {
            "urban_body_code": 250125,
            "id": 15549,
            "text": "Bhatpara (M) - Ward No.23"
        },
        {
            "urban_body_code": 250125,
            "id": 15550,
            "text": "Bhatpara (M) - Ward No.24"
        },
        {
            "urban_body_code": 250125,
            "id": 15551,
            "text": "Bhatpara (M) - Ward No.25"
        },
        {
            "urban_body_code": 250125,
            "id": 15552,
            "text": "Bhatpara (M) - Ward No.26"
        },
        {
            "urban_body_code": 250125,
            "id": 15553,
            "text": "Bhatpara (M) - Ward No.27"
        },
        {
            "urban_body_code": 250125,
            "id": 15634,
            "text": "Bhatpara (M) - Ward No.28"
        },
        {
            "urban_body_code": 250125,
            "id": 15635,
            "text": "Bhatpara (M) - Ward No.29"
        },
        {
            "urban_body_code": 250125,
            "id": 15636,
            "text": "Bhatpara (M) - Ward No.30"
        },
        {
            "urban_body_code": 250125,
            "id": 15637,
            "text": "Bhatpara (M) - Ward No.31"
        },
        {
            "urban_body_code": 250125,
            "id": 15638,
            "text": "Bhatpara (M) - Ward No.32"
        },
        {
            "urban_body_code": 250125,
            "id": 15639,
            "text": "Bhatpara (M) - Ward No.33"
        },
        {
            "urban_body_code": 250125,
            "id": 15640,
            "text": "Bhatpara (M) - Ward No.34"
        },
        {
            "urban_body_code": 250125,
            "id": 15641,
            "text": "Bhatpara (M) - Ward No.35"
        },
        {
            "urban_body_code": 250125,
            "id": 16223,
            "text": "Panpur (OG) - Ward No.36"
        },
        {
            "urban_body_code": 250125,
            "id": 16224,
            "text": "Bidyadharpur (OG) - Ward No.37"
        },
        {
            "urban_body_code": 250126,
            "id": 15642,
            "text": "Gobardanga (M) - Ward No.1"
        },
        {
            "urban_body_code": 250126,
            "id": 15643,
            "text": "Gobardanga (M) - Ward No.2"
        },
        {
            "urban_body_code": 250126,
            "id": 15644,
            "text": "Gobardanga (M) - Ward No.3"
        },
        {
            "urban_body_code": 250126,
            "id": 15645,
            "text": "Gobardanga (M) - Ward No.4"
        },
        {
            "urban_body_code": 250126,
            "id": 15646,
            "text": "Gobardanga (M) - Ward No.5"
        },
        {
            "urban_body_code": 250126,
            "id": 15647,
            "text": "Gobardanga (M) - Ward No.6"
        },
        {
            "urban_body_code": 250126,
            "id": 15648,
            "text": "Gobardanga (M) - Ward No.7"
        },
        {
            "urban_body_code": 250126,
            "id": 15649,
            "text": "Gobardanga (M) - Ward No.8"
        },
        {
            "urban_body_code": 250126,
            "id": 15650,
            "text": "Gobardanga (M) - Ward No.9"
        },
        {
            "urban_body_code": 250126,
            "id": 15651,
            "text": "Gobardanga (M) - Ward No.10"
        },
        {
            "urban_body_code": 250126,
            "id": 15652,
            "text": "Gobardanga (M) - Ward No.11"
        },
        {
            "urban_body_code": 250126,
            "id": 15653,
            "text": "Gobardanga (M) - Ward No.12"
        },
        {
            "urban_body_code": 250126,
            "id": 15654,
            "text": "Gobardanga (M) - Ward No.13"
        },
        {
            "urban_body_code": 250126,
            "id": 15655,
            "text": "Gobardanga (M) - Ward No.14"
        },
        {
            "urban_body_code": 250126,
            "id": 15656,
            "text": "Gobardanga (M) - Ward No.15"
        },
        {
            "urban_body_code": 250126,
            "id": 15657,
            "text": "Gobardanga (M) - Ward No.16"
        },
        {
            "urban_body_code": 250126,
            "id": 15658,
            "text": "Gobardanga (M) - Ward No.17"
        },
        {
            "urban_body_code": 250127,
            "id": 15659,
            "text": "Habra (M) - Ward No.1"
        },
        {
            "urban_body_code": 250127,
            "id": 15660,
            "text": "Habra (M) - Ward No.2"
        },
        {
            "urban_body_code": 250127,
            "id": 15661,
            "text": "Habra (M) - Ward No.3"
        },
        {
            "urban_body_code": 250127,
            "id": 15662,
            "text": "Habra (M) - Ward No.4"
        },
        {
            "urban_body_code": 250127,
            "id": 15663,
            "text": "Habra (M) - Ward No.5"
        },
        {
            "urban_body_code": 250127,
            "id": 15664,
            "text": "Habra (M) - Ward No.6"
        },
        {
            "urban_body_code": 250127,
            "id": 15665,
            "text": "Habra (M) - Ward No.7"
        },
        {
            "urban_body_code": 250127,
            "id": 15666,
            "text": "Habra (M) - Ward No.8"
        },
        {
            "urban_body_code": 250127,
            "id": 15667,
            "text": "Habra (M) - Ward No.9"
        },
        {
            "urban_body_code": 250127,
            "id": 15668,
            "text": "Habra (M) - Ward No.10"
        },
        {
            "urban_body_code": 250127,
            "id": 15669,
            "text": "Habra (M) - Ward No.11"
        },
        {
            "urban_body_code": 250127,
            "id": 15670,
            "text": "Habra (M) - Ward No.12"
        },
        {
            "urban_body_code": 250127,
            "id": 15671,
            "text": "Habra (M) - Ward No.13"
        },
        {
            "urban_body_code": 250127,
            "id": 15672,
            "text": "Habra (M) - Ward No.14"
        },
        {
            "urban_body_code": 250127,
            "id": 15673,
            "text": "Habra (M) - Ward No.15"
        },
        {
            "urban_body_code": 250127,
            "id": 15674,
            "text": "Habra (M) - Ward No.16"
        },
        {
            "urban_body_code": 250127,
            "id": 15675,
            "text": "Habra (M) - Ward No.17"
        },
        {
            "urban_body_code": 250127,
            "id": 15676,
            "text": "Habra (M) - Ward No.18"
        },
        {
            "urban_body_code": 250127,
            "id": 15677,
            "text": "Habra (M) - Ward No.19"
        },
        {
            "urban_body_code": 250127,
            "id": 15678,
            "text": "Habra (M) - Ward No.20"
        },
        {
            "urban_body_code": 250127,
            "id": 15679,
            "text": "Habra (M) - Ward No.21"
        },
        {
            "urban_body_code": 250127,
            "id": 15680,
            "text": "Habra (M) - Ward No.22"
        },
        {
            "urban_body_code": 250127,
            "id": 9999291,
            "text": "Habra (M) - Ward No.23"
        },
        {
            "urban_body_code": 250127,
            "id": 9999292,
            "text": "Habra (M) - Ward No.24"
        },
        {
            "urban_body_code": 250128,
            "id": 15681,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.1"
        },
        {
            "urban_body_code": 250128,
            "id": 15682,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.2"
        },
        {
            "urban_body_code": 250128,
            "id": 15683,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.3"
        },
        {
            "urban_body_code": 250128,
            "id": 15684,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.4"
        },
        {
            "urban_body_code": 250128,
            "id": 15685,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.5"
        },
        {
            "urban_body_code": 250128,
            "id": 15686,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.6"
        },
        {
            "urban_body_code": 250128,
            "id": 15687,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.7"
        },
        {
            "urban_body_code": 250128,
            "id": 15688,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.8"
        },
        {
            "urban_body_code": 250128,
            "id": 15689,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.9"
        },
        {
            "urban_body_code": 250128,
            "id": 15690,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.10"
        },
        {
            "urban_body_code": 250128,
            "id": 15691,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.11"
        },
        {
            "urban_body_code": 250128,
            "id": 15692,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.12"
        },
        {
            "urban_body_code": 250128,
            "id": 15693,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.13"
        },
        {
            "urban_body_code": 250128,
            "id": 15694,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.14"
        },
        {
            "urban_body_code": 250128,
            "id": 15695,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.15"
        },
        {
            "urban_body_code": 250128,
            "id": 15696,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.16"
        },
        {
            "urban_body_code": 250128,
            "id": 15697,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.17"
        },
        {
            "urban_body_code": 250128,
            "id": 15698,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.18"
        },
        {
            "urban_body_code": 250128,
            "id": 15699,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.19"
        },
        {
            "urban_body_code": 250128,
            "id": 15700,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.20"
        },
        {
            "urban_body_code": 250128,
            "id": 15701,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.21"
        },
        {
            "urban_body_code": 250128,
            "id": 15702,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.22"
        },
        {
            "urban_body_code": 250128,
            "id": 9999157,
            "text": "Ashoknagar Kalyangarh (M) - Ward No.23"
        },
        {
            "urban_body_code": 250129,
            "id": 15703,
            "text": "Garulia (M) - Ward No.1"
        },
        {
            "urban_body_code": 250129,
            "id": 15704,
            "text": "Garulia (M) - Ward No.2"
        },
        {
            "urban_body_code": 250129,
            "id": 15705,
            "text": "Garulia (M) - Ward No.3"
        },
        {
            "urban_body_code": 250129,
            "id": 15706,
            "text": "Garulia (M) - Ward No.4"
        },
        {
            "urban_body_code": 250129,
            "id": 15707,
            "text": "Garulia (M) - Ward No.5"
        },
        {
            "urban_body_code": 250129,
            "id": 15708,
            "text": "Garulia (M) - Ward No.6"
        },
        {
            "urban_body_code": 250129,
            "id": 15709,
            "text": "Garulia (M) - Ward No.7"
        },
        {
            "urban_body_code": 250129,
            "id": 15710,
            "text": "Garulia (M) - Ward No.8"
        },
        {
            "urban_body_code": 250129,
            "id": 15711,
            "text": "Garulia (M) - Ward No.9"
        },
        {
            "urban_body_code": 250129,
            "id": 15712,
            "text": "Garulia (M) - Ward No.10"
        },
        {
            "urban_body_code": 250129,
            "id": 15713,
            "text": "Garulia (M) - Ward No.11"
        },
        {
            "urban_body_code": 250129,
            "id": 15714,
            "text": "Garulia (M) - Ward No.12"
        },
        {
            "urban_body_code": 250129,
            "id": 15715,
            "text": "Garulia (M) - Ward No.13"
        },
        {
            "urban_body_code": 250129,
            "id": 15716,
            "text": "Garulia (M) - Ward No.14"
        },
        {
            "urban_body_code": 250129,
            "id": 15717,
            "text": "Garulia (M) - Ward No.15"
        },
        {
            "urban_body_code": 250129,
            "id": 15718,
            "text": "Garulia (M) - Ward No.16"
        },
        {
            "urban_body_code": 250129,
            "id": 15719,
            "text": "Garulia (M) - Ward No.17"
        },
        {
            "urban_body_code": 250129,
            "id": 15720,
            "text": "Garulia (M) - Ward No.18"
        },
        {
            "urban_body_code": 250129,
            "id": 15721,
            "text": "Garulia (M) - Ward No.19"
        },
        {
            "urban_body_code": 250129,
            "id": 15722,
            "text": "Garulia (M) - Ward No.20"
        },
        {
            "urban_body_code": 250129,
            "id": 15723,
            "text": "Garulia (M) - Ward No.21"
        },
        {
            "urban_body_code": 250131,
            "id": 15725,
            "text": "North Barrackpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250131,
            "id": 15726,
            "text": "North Barrackpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250131,
            "id": 15727,
            "text": "North Barrackpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250131,
            "id": 15728,
            "text": "North Barrackpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250131,
            "id": 15729,
            "text": "North Barrackpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250131,
            "id": 15730,
            "text": "North Barrackpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250131,
            "id": 15731,
            "text": "North Barrackpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250131,
            "id": 15732,
            "text": "North Barrackpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250131,
            "id": 15733,
            "text": "North Barrackpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250131,
            "id": 15734,
            "text": "North Barrackpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250131,
            "id": 15735,
            "text": "North Barrackpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250131,
            "id": 15736,
            "text": "North Barrackpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250131,
            "id": 15737,
            "text": "North Barrackpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250131,
            "id": 15738,
            "text": "North Barrackpur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250131,
            "id": 15739,
            "text": "North Barrackpur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250131,
            "id": 15740,
            "text": "North Barrackpur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250131,
            "id": 15741,
            "text": "North Barrackpur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250131,
            "id": 15742,
            "text": "North Barrackpur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250131,
            "id": 15743,
            "text": "North Barrackpur (M) - Ward No.19"
        },
        {
            "urban_body_code": 250131,
            "id": 15744,
            "text": "North Barrackpur (M) - Ward No.20"
        },
        {
            "urban_body_code": 250131,
            "id": 15745,
            "text": "North Barrackpur (M) - Ward No.21"
        },
        {
            "urban_body_code": 250131,
            "id": 15746,
            "text": "North Barrackpur (M) - Ward No.22"
        },
        {
            "urban_body_code": 250131,
            "id": 9999359,
            "text": "North Barrackpur (M) - Ward No.23"
        },
        {
            "urban_body_code": 250132,
            "id": 15747,
            "text": "Barrackpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250132,
            "id": 15748,
            "text": "Barrackpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250132,
            "id": 15749,
            "text": "Barrackpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250132,
            "id": 15750,
            "text": "Barrackpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250132,
            "id": 15751,
            "text": "Barrackpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250132,
            "id": 15752,
            "text": "Barrackpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250132,
            "id": 15753,
            "text": "Barrackpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250132,
            "id": 15754,
            "text": "Barrackpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250132,
            "id": 15755,
            "text": "Barrackpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250132,
            "id": 15756,
            "text": "Barrackpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250132,
            "id": 15757,
            "text": "Barrackpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250132,
            "id": 15758,
            "text": "Barrackpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250132,
            "id": 15759,
            "text": "Barrackpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250132,
            "id": 15760,
            "text": "Barrackpur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250132,
            "id": 15761,
            "text": "Barrackpur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250132,
            "id": 15762,
            "text": "Barrackpur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250132,
            "id": 15763,
            "text": "Barrackpur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250132,
            "id": 15764,
            "text": "Barrackpur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250132,
            "id": 15765,
            "text": "Barrackpur (M) - Ward No.19"
        },
        {
            "urban_body_code": 250132,
            "id": 15766,
            "text": "Barrackpur (M) - Ward No.20"
        },
        {
            "urban_body_code": 250132,
            "id": 15767,
            "text": "Barrackpur (M) - Ward No.21"
        },
        {
            "urban_body_code": 250132,
            "id": 15768,
            "text": "Barrackpur (M) - Ward No.22"
        },
        {
            "urban_body_code": 250132,
            "id": 15769,
            "text": "Barrackpur (M) - Ward No.23"
        },
        {
            "urban_body_code": 250132,
            "id": 15770,
            "text": "Barrackpur (M) - Ward No.24"
        },
        {
            "urban_body_code": 250133,
            "id": 15771,
            "text": "Titagarh (M) - Ward No.1"
        },
        {
            "urban_body_code": 250133,
            "id": 15772,
            "text": "Titagarh (M) - Ward No.2"
        },
        {
            "urban_body_code": 250133,
            "id": 15773,
            "text": "Titagarh (M) - Ward No.3"
        },
        {
            "urban_body_code": 250133,
            "id": 15774,
            "text": "Titagarh (M) - Ward No.4"
        },
        {
            "urban_body_code": 250133,
            "id": 15775,
            "text": "Titagarh (M) - Ward No.5"
        },
        {
            "urban_body_code": 250133,
            "id": 15776,
            "text": "Titagarh (M) - Ward No.6"
        },
        {
            "urban_body_code": 250133,
            "id": 15777,
            "text": "Titagarh (M) - Ward No.7"
        },
        {
            "urban_body_code": 250133,
            "id": 15778,
            "text": "Titagarh (M) - Ward No.8"
        },
        {
            "urban_body_code": 250133,
            "id": 15779,
            "text": "Titagarh (M) - Ward No.9"
        },
        {
            "urban_body_code": 250133,
            "id": 15780,
            "text": "Titagarh (M) - Ward No.10"
        },
        {
            "urban_body_code": 250133,
            "id": 15781,
            "text": "Titagarh (M) - Ward No.11"
        },
        {
            "urban_body_code": 250133,
            "id": 15782,
            "text": "Titagarh (M) - Ward No.12"
        },
        {
            "urban_body_code": 250133,
            "id": 15783,
            "text": "Titagarh (M) - Ward No.13"
        },
        {
            "urban_body_code": 250133,
            "id": 15784,
            "text": "Titagarh (M) - Ward No.14"
        },
        {
            "urban_body_code": 250133,
            "id": 15785,
            "text": "Titagarh (M) - Ward No.15"
        },
        {
            "urban_body_code": 250133,
            "id": 15786,
            "text": "Titagarh (M) - Ward No.16"
        },
        {
            "urban_body_code": 250133,
            "id": 15787,
            "text": "Titagarh (M) - Ward No.17"
        },
        {
            "urban_body_code": 250133,
            "id": 15788,
            "text": "Titagarh (M) - Ward No.18"
        },
        {
            "urban_body_code": 250133,
            "id": 15789,
            "text": "Titagarh (M) - Ward No.19"
        },
        {
            "urban_body_code": 250133,
            "id": 15790,
            "text": "Titagarh (M) - Ward No.20"
        },
        {
            "urban_body_code": 250133,
            "id": 15791,
            "text": "Titagarh (M) - Ward No.21"
        },
        {
            "urban_body_code": 250133,
            "id": 15792,
            "text": "Titagarh (M) - Ward No.22"
        },
        {
            "urban_body_code": 250133,
            "id": 15793,
            "text": "Titagarh (M) - Ward No.23"
        },
        {
            "urban_body_code": 250134,
            "id": 15794,
            "text": "Baduria (M) - Ward No.1"
        },
        {
            "urban_body_code": 250134,
            "id": 15795,
            "text": "Baduria (M) - Ward No.2"
        },
        {
            "urban_body_code": 250134,
            "id": 15796,
            "text": "Baduria (M) - Ward No.3"
        },
        {
            "urban_body_code": 250134,
            "id": 15797,
            "text": "Baduria (M) - Ward No.4"
        },
        {
            "urban_body_code": 250134,
            "id": 15798,
            "text": "Baduria (M) - Ward No.5"
        },
        {
            "urban_body_code": 250134,
            "id": 15799,
            "text": "Baduria (M) - Ward No.6"
        },
        {
            "urban_body_code": 250134,
            "id": 15800,
            "text": "Baduria (M) - Ward No.7"
        },
        {
            "urban_body_code": 250134,
            "id": 15801,
            "text": "Baduria (M) - Ward No.8"
        },
        {
            "urban_body_code": 250134,
            "id": 15802,
            "text": "Baduria (M) - Ward No.9"
        },
        {
            "urban_body_code": 250134,
            "id": 15803,
            "text": "Baduria (M) - Ward No.10"
        },
        {
            "urban_body_code": 250134,
            "id": 15804,
            "text": "Baduria (M) - Ward No.11"
        },
        {
            "urban_body_code": 250134,
            "id": 15805,
            "text": "Baduria (M) - Ward No.12"
        },
        {
            "urban_body_code": 250134,
            "id": 15806,
            "text": "Baduria (M) - Ward No.13"
        },
        {
            "urban_body_code": 250134,
            "id": 15807,
            "text": "Baduria (M) - Ward No.14"
        },
        {
            "urban_body_code": 250134,
            "id": 15808,
            "text": "Baduria (M) - Ward No.15"
        },
        {
            "urban_body_code": 250134,
            "id": 15809,
            "text": "Baduria (M) - Ward No.16"
        },
        {
            "urban_body_code": 250134,
            "id": 15810,
            "text": "Baduria (M) - Ward No.17"
        },
        {
            "urban_body_code": 250135,
            "id": 67330,
            "text": "Barasat (M) - Ward No.1"
        },
        {
            "urban_body_code": 250135,
            "id": 67331,
            "text": "Barasat (M) - Ward No.2"
        },
        {
            "urban_body_code": 250135,
            "id": 67332,
            "text": "Barasat (M) - Ward No.3"
        },
        {
            "urban_body_code": 250135,
            "id": 67333,
            "text": "Barasat (M) - Ward No.4"
        },
        {
            "urban_body_code": 250135,
            "id": 67334,
            "text": "Barasat (M) - Ward No.5"
        },
        {
            "urban_body_code": 250135,
            "id": 67335,
            "text": "Barasat (M) - Ward No.6"
        },
        {
            "urban_body_code": 250135,
            "id": 67336,
            "text": "Barasat (M) - Ward No.7"
        },
        {
            "urban_body_code": 250135,
            "id": 67337,
            "text": "Barasat (M) - Ward No.8"
        },
        {
            "urban_body_code": 250135,
            "id": 67338,
            "text": "Barasat (M) - Ward No.9"
        },
        {
            "urban_body_code": 250135,
            "id": 67339,
            "text": "Barasat (M) - Ward No.10"
        },
        {
            "urban_body_code": 250135,
            "id": 67340,
            "text": "Barasat (M) - Ward No.11"
        },
        {
            "urban_body_code": 250135,
            "id": 67341,
            "text": "Barasat (M) - Ward No.12"
        },
        {
            "urban_body_code": 250135,
            "id": 67342,
            "text": "Barasat (M) - Ward No.13"
        },
        {
            "urban_body_code": 250135,
            "id": 67343,
            "text": "Barasat (M) - Ward No.14"
        },
        {
            "urban_body_code": 250135,
            "id": 67344,
            "text": "Barasat (M) - Ward No.15"
        },
        {
            "urban_body_code": 250135,
            "id": 67345,
            "text": "Barasat (M) - Ward No.16"
        },
        {
            "urban_body_code": 250135,
            "id": 67346,
            "text": "Barasat (M) - Ward No.17"
        },
        {
            "urban_body_code": 250135,
            "id": 67347,
            "text": "Barasat (M) - Ward No.18"
        },
        {
            "urban_body_code": 250135,
            "id": 67348,
            "text": "Barasat (M) - Ward No.19"
        },
        {
            "urban_body_code": 250135,
            "id": 67349,
            "text": "Barasat (M) - Ward No.20"
        },
        {
            "urban_body_code": 250135,
            "id": 67350,
            "text": "Barasat (M) - Ward No.21"
        },
        {
            "urban_body_code": 250135,
            "id": 67351,
            "text": "Barasat (M) - Ward No.22"
        },
        {
            "urban_body_code": 250135,
            "id": 67352,
            "text": "Barasat (M) - Ward No.23"
        },
        {
            "urban_body_code": 250135,
            "id": 67353,
            "text": "Barasat (M) - Ward No.24"
        },
        {
            "urban_body_code": 250135,
            "id": 67354,
            "text": "Barasat (M) - Ward No.25"
        },
        {
            "urban_body_code": 250135,
            "id": 67355,
            "text": "Barasat (M) - Ward No.26"
        },
        {
            "urban_body_code": 250135,
            "id": 67356,
            "text": "Barasat (M) - Ward No.27"
        },
        {
            "urban_body_code": 250135,
            "id": 67357,
            "text": "Barasat (M) - Ward No.28"
        },
        {
            "urban_body_code": 250135,
            "id": 67358,
            "text": "Barasat (M) - Ward No.29"
        },
        {
            "urban_body_code": 250135,
            "id": 67359,
            "text": "Barasat (M) - Ward No.30"
        },
        {
            "urban_body_code": 250135,
            "id": 9999167,
            "text": "Barasat (M) - Ward No.31"
        },
        {
            "urban_body_code": 250135,
            "id": 9999168,
            "text": "Barasat (M) - Ward No.32"
        },
        {
            "urban_body_code": 250135,
            "id": 9999169,
            "text": "Barasat (M) - Ward No.33"
        },
        {
            "urban_body_code": 250135,
            "id": 9999170,
            "text": "Barasat (M) - Ward No.34"
        },
        {
            "urban_body_code": 250135,
            "id": 9999171,
            "text": "Barasat (M) - Ward No.35"
        },
        {
            "urban_body_code": 250136,
            "id": 67360,
            "text": "Madhyamgram (M) - Ward No.1"
        },
        {
            "urban_body_code": 250136,
            "id": 67361,
            "text": "Madhyamgram (M) - Ward No.2"
        },
        {
            "urban_body_code": 250136,
            "id": 67362,
            "text": "Madhyamgram (M) - Ward No.3"
        },
        {
            "urban_body_code": 250136,
            "id": 67363,
            "text": "Madhyamgram (M) - Ward No.4"
        },
        {
            "urban_body_code": 250136,
            "id": 67364,
            "text": "Madhyamgram (M) - Ward No.5"
        },
        {
            "urban_body_code": 250136,
            "id": 67365,
            "text": "Madhyamgram (M) - Ward No.6"
        },
        {
            "urban_body_code": 250136,
            "id": 67366,
            "text": "Madhyamgram (M) - Ward No.7"
        },
        {
            "urban_body_code": 250136,
            "id": 67367,
            "text": "Madhyamgram (M) - Ward No.8"
        },
        {
            "urban_body_code": 250136,
            "id": 67368,
            "text": "Madhyamgram (M) - Ward No.9"
        },
        {
            "urban_body_code": 250136,
            "id": 67369,
            "text": "Madhyamgram (M) - Ward No.10"
        },
        {
            "urban_body_code": 250136,
            "id": 63819,
            "text": "Madhyamgram (M) - Ward No.11"
        },
        {
            "urban_body_code": 250136,
            "id": 63820,
            "text": "Madhyamgram (M) - Ward No.12"
        },
        {
            "urban_body_code": 250136,
            "id": 63821,
            "text": "Madhyamgram (M) - Ward No.13"
        },
        {
            "urban_body_code": 250136,
            "id": 63822,
            "text": "Madhyamgram (M) - Ward No.14"
        },
        {
            "urban_body_code": 250136,
            "id": 63823,
            "text": "Madhyamgram (M) - Ward No.15"
        },
        {
            "urban_body_code": 250136,
            "id": 63824,
            "text": "Madhyamgram (M) - Ward No.16"
        },
        {
            "urban_body_code": 250136,
            "id": 63825,
            "text": "Madhyamgram (M) - Ward No.17"
        },
        {
            "urban_body_code": 250136,
            "id": 63826,
            "text": "Madhyamgram (M) - Ward No.18"
        },
        {
            "urban_body_code": 250136,
            "id": 63827,
            "text": "Madhyamgram (M) - Ward No.19"
        },
        {
            "urban_body_code": 250136,
            "id": 63828,
            "text": "Madhyamgram (M) - Ward No.20"
        },
        {
            "urban_body_code": 250136,
            "id": 63829,
            "text": "Madhyamgram (M) - Ward No.21"
        },
        {
            "urban_body_code": 250136,
            "id": 63830,
            "text": "Madhyamgram (M) - Ward No.22"
        },
        {
            "urban_body_code": 250136,
            "id": 63831,
            "text": "Madhyamgram (M) - Ward No.23"
        },
        {
            "urban_body_code": 250136,
            "id": 9999349,
            "text": "Madhyamgram (M) - Ward No.24"
        },
        {
            "urban_body_code": 250136,
            "id": 9999350,
            "text": "Madhyamgram (M) - Ward No.25"
        },
        {
            "urban_body_code": 250136,
            "id": 9999351,
            "text": "Madhyamgram (M) - Ward No.26"
        },
        {
            "urban_body_code": 250136,
            "id": 9999352,
            "text": "Madhyamgram (M) - Ward No.27"
        },
        {
            "urban_body_code": 250136,
            "id": 9999353,
            "text": "Madhyamgram (M) - Ward No.28"
        },
        {
            "urban_body_code": 250137,
            "id": 15811,
            "text": "Khardaha (M) - Ward No.1"
        },
        {
            "urban_body_code": 250137,
            "id": 15812,
            "text": "Khardaha (M) - Ward No.2"
        },
        {
            "urban_body_code": 250137,
            "id": 15813,
            "text": "Khardaha (M) - Ward No.3"
        },
        {
            "urban_body_code": 250137,
            "id": 15814,
            "text": "Khardaha (M) - Ward No.4"
        },
        {
            "urban_body_code": 250137,
            "id": 15815,
            "text": "Khardaha (M) - Ward No.5"
        },
        {
            "urban_body_code": 250137,
            "id": 15816,
            "text": "Khardaha (M) - Ward No.6"
        },
        {
            "urban_body_code": 250137,
            "id": 15817,
            "text": "Khardaha (M) - Ward No.7"
        },
        {
            "urban_body_code": 250137,
            "id": 15818,
            "text": "Khardaha (M) - Ward No.8"
        },
        {
            "urban_body_code": 250137,
            "id": 15819,
            "text": "Khardaha (M) - Ward No.9"
        },
        {
            "urban_body_code": 250137,
            "id": 15820,
            "text": "Khardaha (M) - Ward No.10"
        },
        {
            "urban_body_code": 250137,
            "id": 15821,
            "text": "Khardaha (M) - Ward No.11"
        },
        {
            "urban_body_code": 250137,
            "id": 15822,
            "text": "Khardaha (M) - Ward No.12"
        },
        {
            "urban_body_code": 250137,
            "id": 15823,
            "text": "Khardaha (M) - Ward No.13"
        },
        {
            "urban_body_code": 250137,
            "id": 15824,
            "text": "Khardaha (M) - Ward No.14"
        },
        {
            "urban_body_code": 250137,
            "id": 15825,
            "text": "Khardaha (M) - Ward No.15"
        },
        {
            "urban_body_code": 250137,
            "id": 15826,
            "text": "Khardaha (M) - Ward No.16"
        },
        {
            "urban_body_code": 250137,
            "id": 15827,
            "text": "Khardaha (M) - Ward No.17"
        },
        {
            "urban_body_code": 250137,
            "id": 15828,
            "text": "Khardaha (M) - Ward No.18"
        },
        {
            "urban_body_code": 250137,
            "id": 15829,
            "text": "Khardaha (M) - Ward No.19"
        },
        {
            "urban_body_code": 250137,
            "id": 15830,
            "text": "Khardaha (M) - Ward No.20"
        },
        {
            "urban_body_code": 250137,
            "id": 15831,
            "text": "Khardaha (M) - Ward No.21"
        },
        {
            "urban_body_code": 250137,
            "id": 16229,
            "text": "Bandipur (OG) - Ward No.22"
        },
        {
            "urban_body_code": 250138,
            "id": 63832,
            "text": "Panihati (M) - Ward No.1"
        },
        {
            "urban_body_code": 250138,
            "id": 63833,
            "text": "Panihati (M) - Ward No.2"
        },
        {
            "urban_body_code": 250138,
            "id": 63834,
            "text": "Panihati (M) - Ward No.3"
        },
        {
            "urban_body_code": 250138,
            "id": 63835,
            "text": "Panihati (M) - Ward No.4"
        },
        {
            "urban_body_code": 250138,
            "id": 63836,
            "text": "Panihati (M) - Ward No.5"
        },
        {
            "urban_body_code": 250138,
            "id": 63837,
            "text": "Panihati (M) - Ward No.6"
        },
        {
            "urban_body_code": 250138,
            "id": 63838,
            "text": "Panihati (M) - Ward No.7"
        },
        {
            "urban_body_code": 250138,
            "id": 63839,
            "text": "Panihati (M) - Ward No.8"
        },
        {
            "urban_body_code": 250138,
            "id": 63840,
            "text": "Panihati (M) - Ward No.9"
        },
        {
            "urban_body_code": 250138,
            "id": 63841,
            "text": "Panihati (M) - Ward No.10"
        },
        {
            "urban_body_code": 250138,
            "id": 63842,
            "text": "Panihati (M) - Ward No.11"
        },
        {
            "urban_body_code": 250138,
            "id": 63843,
            "text": "Panihati (M) - Ward No.12"
        },
        {
            "urban_body_code": 250138,
            "id": 63844,
            "text": "Panihati (M) - Ward No.13"
        },
        {
            "urban_body_code": 250138,
            "id": 63845,
            "text": "Panihati (M) - Ward No.14"
        },
        {
            "urban_body_code": 250138,
            "id": 63846,
            "text": "Panihati (M) - Ward No.15"
        },
        {
            "urban_body_code": 250138,
            "id": 63847,
            "text": "Panihati (M) - Ward No.16"
        },
        {
            "urban_body_code": 250138,
            "id": 63848,
            "text": "Panihati (M) - Ward No.17"
        },
        {
            "urban_body_code": 250138,
            "id": 63849,
            "text": "Panihati (M) - Ward No.18"
        },
        {
            "urban_body_code": 250138,
            "id": 63850,
            "text": "Panihati (M) - Ward No.19"
        },
        {
            "urban_body_code": 250138,
            "id": 63851,
            "text": "Panihati (M) - Ward No.20"
        },
        {
            "urban_body_code": 250138,
            "id": 63852,
            "text": "Panihati (M) - Ward No.21"
        },
        {
            "urban_body_code": 250138,
            "id": 63853,
            "text": "Panihati (M) - Ward No.22"
        },
        {
            "urban_body_code": 250138,
            "id": 63854,
            "text": "Panihati (M) - Ward No.23"
        },
        {
            "urban_body_code": 250138,
            "id": 63855,
            "text": "Panihati (M) - Ward No.24"
        },
        {
            "urban_body_code": 250138,
            "id": 63856,
            "text": "Panihati (M) - Ward No.25"
        },
        {
            "urban_body_code": 250138,
            "id": 63857,
            "text": "Panihati (M) - Ward No.26"
        },
        {
            "urban_body_code": 250138,
            "id": 63858,
            "text": "Panihati (M) - Ward No.27"
        },
        {
            "urban_body_code": 250138,
            "id": 63859,
            "text": "Panihati (M) - Ward No.28"
        },
        {
            "urban_body_code": 250138,
            "id": 63860,
            "text": "Panihati (M) - Ward No.29"
        },
        {
            "urban_body_code": 250138,
            "id": 63861,
            "text": "Panihati (M) - Ward No.30"
        },
        {
            "urban_body_code": 250138,
            "id": 63862,
            "text": "Panihati (M) - Ward No.31"
        },
        {
            "urban_body_code": 250138,
            "id": 63863,
            "text": "Panihati (M) - Ward No.32"
        },
        {
            "urban_body_code": 250138,
            "id": 63864,
            "text": "Panihati (M) - Ward No.33"
        },
        {
            "urban_body_code": 250138,
            "id": 63865,
            "text": "Panihati (M) - Ward No.34"
        },
        {
            "urban_body_code": 250138,
            "id": 63866,
            "text": "Panihati (M) - Ward No.35"
        },
        {
            "urban_body_code": 250139,
            "id": 15832,
            "text": "New Barrackpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250139,
            "id": 15833,
            "text": "New Barrackpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250139,
            "id": 15834,
            "text": "New Barrackpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250139,
            "id": 15835,
            "text": "New Barrackpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250139,
            "id": 15836,
            "text": "New Barrackpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250139,
            "id": 15837,
            "text": "New Barrackpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250139,
            "id": 15838,
            "text": "New Barrackpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250139,
            "id": 15839,
            "text": "New Barrackpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250139,
            "id": 15840,
            "text": "New Barrackpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250139,
            "id": 15841,
            "text": "New Barrackpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250139,
            "id": 15842,
            "text": "New Barrackpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250139,
            "id": 15843,
            "text": "New Barrackpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250139,
            "id": 15844,
            "text": "New Barrackpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250139,
            "id": 15845,
            "text": "New Barrackpur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250139,
            "id": 15846,
            "text": "New Barrackpur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250139,
            "id": 15847,
            "text": "New Barrackpur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250139,
            "id": 15848,
            "text": "New Barrackpur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250139,
            "id": 15849,
            "text": "New Barrackpur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250139,
            "id": 15850,
            "text": "New Barrackpur (M) - Ward No.19"
        },
        {
            "urban_body_code": 250139,
            "id": 9999358,
            "text": "New Barrackpur (M) - Ward No.20"
        },
        {
            "urban_body_code": 250140,
            "id": 15851,
            "text": "Kamarhati (M) - Ward No.1"
        },
        {
            "urban_body_code": 250140,
            "id": 15852,
            "text": "Kamarhati (M) - Ward No.2"
        },
        {
            "urban_body_code": 250140,
            "id": 15853,
            "text": "Kamarhati (M) - Ward No.3"
        },
        {
            "urban_body_code": 250140,
            "id": 15854,
            "text": "Kamarhati (M) - Ward No.4"
        },
        {
            "urban_body_code": 250140,
            "id": 15855,
            "text": "Kamarhati (M) - Ward No.5"
        },
        {
            "urban_body_code": 250140,
            "id": 15856,
            "text": "Kamarhati (M) - Ward No.6"
        },
        {
            "urban_body_code": 250140,
            "id": 15857,
            "text": "Kamarhati (M) - Ward No.7"
        },
        {
            "urban_body_code": 250140,
            "id": 15858,
            "text": "Kamarhati (M) - Ward No.8"
        },
        {
            "urban_body_code": 250140,
            "id": 15859,
            "text": "Kamarhati (M) - Ward No.9"
        },
        {
            "urban_body_code": 250140,
            "id": 15860,
            "text": "Kamarhati (M) - Ward No.10"
        },
        {
            "urban_body_code": 250140,
            "id": 15861,
            "text": "Kamarhati (M) - Ward No.11"
        },
        {
            "urban_body_code": 250140,
            "id": 15862,
            "text": "Kamarhati (M) - Ward No.12"
        },
        {
            "urban_body_code": 250140,
            "id": 15863,
            "text": "Kamarhati (M) - Ward No.13"
        },
        {
            "urban_body_code": 250140,
            "id": 15864,
            "text": "Kamarhati (M) - Ward No.14"
        },
        {
            "urban_body_code": 250140,
            "id": 15865,
            "text": "Kamarhati (M) - Ward No.15"
        },
        {
            "urban_body_code": 250140,
            "id": 15866,
            "text": "Kamarhati (M) - Ward No.16"
        },
        {
            "urban_body_code": 250140,
            "id": 15867,
            "text": "Kamarhati (M) - Ward No.17"
        },
        {
            "urban_body_code": 250140,
            "id": 15868,
            "text": "Kamarhati (M) - Ward No.18"
        },
        {
            "urban_body_code": 250140,
            "id": 15869,
            "text": "Kamarhati (M) - Ward No.19"
        },
        {
            "urban_body_code": 250140,
            "id": 15870,
            "text": "Kamarhati (M) - Ward No.20"
        },
        {
            "urban_body_code": 250140,
            "id": 15871,
            "text": "Kamarhati (M) - Ward No.21"
        },
        {
            "urban_body_code": 250140,
            "id": 15872,
            "text": "Kamarhati (M) - Ward No.22"
        },
        {
            "urban_body_code": 250140,
            "id": 15873,
            "text": "Kamarhati (M) - Ward No.23"
        },
        {
            "urban_body_code": 250140,
            "id": 15874,
            "text": "Kamarhati (M) - Ward No.24"
        },
        {
            "urban_body_code": 250140,
            "id": 15875,
            "text": "Kamarhati (M) - Ward No.25"
        },
        {
            "urban_body_code": 250140,
            "id": 15876,
            "text": "Kamarhati (M) - Ward No.26"
        },
        {
            "urban_body_code": 250140,
            "id": 15877,
            "text": "Kamarhati (M) - Ward No.27"
        },
        {
            "urban_body_code": 250140,
            "id": 15878,
            "text": "Kamarhati (M) - Ward No.28"
        },
        {
            "urban_body_code": 250140,
            "id": 15879,
            "text": "Kamarhati (M) - Ward No.29"
        },
        {
            "urban_body_code": 250140,
            "id": 15880,
            "text": "Kamarhati (M) - Ward No.30"
        },
        {
            "urban_body_code": 250140,
            "id": 15881,
            "text": "Kamarhati (M) - Ward No.31"
        },
        {
            "urban_body_code": 250140,
            "id": 15882,
            "text": "Kamarhati (M) - Ward No.32"
        },
        {
            "urban_body_code": 250140,
            "id": 15883,
            "text": "Kamarhati (M) - Ward No.33"
        },
        {
            "urban_body_code": 250140,
            "id": 15884,
            "text": "Kamarhati (M) - Ward No.34"
        },
        {
            "urban_body_code": 250140,
            "id": 15885,
            "text": "Kamarhati (M) - Ward No.35"
        },
        {
            "urban_body_code": 250141,
            "id": 15886,
            "text": "Baranagar (M) - Ward No.1"
        },
        {
            "urban_body_code": 250141,
            "id": 15887,
            "text": "Baranagar (M) - Ward No.2"
        },
        {
            "urban_body_code": 250141,
            "id": 15888,
            "text": "Baranagar (M) - Ward No.3"
        },
        {
            "urban_body_code": 250141,
            "id": 15889,
            "text": "Baranagar (M) - Ward No.4"
        },
        {
            "urban_body_code": 250141,
            "id": 15890,
            "text": "Baranagar (M) - Ward No.5"
        },
        {
            "urban_body_code": 250141,
            "id": 15891,
            "text": "Baranagar (M) - Ward No.6"
        },
        {
            "urban_body_code": 250141,
            "id": 15892,
            "text": "Baranagar (M) - Ward No.7"
        },
        {
            "urban_body_code": 250141,
            "id": 15893,
            "text": "Baranagar (M) - Ward No.8"
        },
        {
            "urban_body_code": 250141,
            "id": 15894,
            "text": "Baranagar (M) - Ward No.9"
        },
        {
            "urban_body_code": 250141,
            "id": 15895,
            "text": "Baranagar (M) - Ward No.10"
        },
        {
            "urban_body_code": 250141,
            "id": 15896,
            "text": "Baranagar (M) - Ward No.11"
        },
        {
            "urban_body_code": 250141,
            "id": 15897,
            "text": "Baranagar (M) - Ward No.12"
        },
        {
            "urban_body_code": 250141,
            "id": 15898,
            "text": "Baranagar (M) - Ward No.13"
        },
        {
            "urban_body_code": 250141,
            "id": 15899,
            "text": "Baranagar (M) - Ward No.14"
        },
        {
            "urban_body_code": 250141,
            "id": 15900,
            "text": "Baranagar (M) - Ward No.15"
        },
        {
            "urban_body_code": 250141,
            "id": 15901,
            "text": "Baranagar (M) - Ward No.16"
        },
        {
            "urban_body_code": 250141,
            "id": 15902,
            "text": "Baranagar (M) - Ward No.17"
        },
        {
            "urban_body_code": 250141,
            "id": 15903,
            "text": "Baranagar (M) - Ward No.18"
        },
        {
            "urban_body_code": 250141,
            "id": 15904,
            "text": "Baranagar (M) - Ward No.19"
        },
        {
            "urban_body_code": 250141,
            "id": 15905,
            "text": "Baranagar (M) - Ward No.20"
        },
        {
            "urban_body_code": 250141,
            "id": 15906,
            "text": "Baranagar (M) - Ward No.21"
        },
        {
            "urban_body_code": 250141,
            "id": 15907,
            "text": "Baranagar (M) - Ward No.22"
        },
        {
            "urban_body_code": 250141,
            "id": 15908,
            "text": "Baranagar (M) - Ward No.23"
        },
        {
            "urban_body_code": 250141,
            "id": 15909,
            "text": "Baranagar (M) - Ward No.24"
        },
        {
            "urban_body_code": 250141,
            "id": 15910,
            "text": "Baranagar (M) - Ward No.25"
        },
        {
            "urban_body_code": 250141,
            "id": 15911,
            "text": "Baranagar (M) - Ward No.26"
        },
        {
            "urban_body_code": 250141,
            "id": 15912,
            "text": "Baranagar (M) - Ward No.27"
        },
        {
            "urban_body_code": 250141,
            "id": 15913,
            "text": "Baranagar (M) - Ward No.28"
        },
        {
            "urban_body_code": 250141,
            "id": 15914,
            "text": "Baranagar (M) - Ward No.29"
        },
        {
            "urban_body_code": 250141,
            "id": 15915,
            "text": "Baranagar (M) - Ward No.30"
        },
        {
            "urban_body_code": 250141,
            "id": 15916,
            "text": "Baranagar (M) - Ward No.31"
        },
        {
            "urban_body_code": 250141,
            "id": 15917,
            "text": "Baranagar (M) - Ward No.32"
        },
        {
            "urban_body_code": 250141,
            "id": 15918,
            "text": "Baranagar (M) - Ward No.33"
        },
        {
            "urban_body_code": 250141,
            "id": 9999166,
            "text": "Baranagar (M) - Ward No.34"
        },
        {
            "urban_body_code": 250142,
            "id": 15919,
            "text": "North Dum Dum (M) - Ward No.1"
        },
        {
            "urban_body_code": 250142,
            "id": 15920,
            "text": "North Dum Dum (M) - Ward No.2"
        },
        {
            "urban_body_code": 250142,
            "id": 15921,
            "text": "North Dum Dum (M) - Ward No.3"
        },
        {
            "urban_body_code": 250142,
            "id": 15922,
            "text": "North Dum Dum (M) - Ward No.4"
        },
        {
            "urban_body_code": 250142,
            "id": 15923,
            "text": "North Dum Dum (M) - Ward No.5"
        },
        {
            "urban_body_code": 250142,
            "id": 15924,
            "text": "North Dum Dum (M) - Ward No.6"
        },
        {
            "urban_body_code": 250142,
            "id": 15925,
            "text": "North Dum Dum (M) - Ward No.7"
        },
        {
            "urban_body_code": 250142,
            "id": 15926,
            "text": "North Dum Dum (M) - Ward No.8"
        },
        {
            "urban_body_code": 250142,
            "id": 15927,
            "text": "North Dum Dum (M) - Ward No.9"
        },
        {
            "urban_body_code": 250142,
            "id": 15928,
            "text": "North Dum Dum (M) - Ward No.10"
        },
        {
            "urban_body_code": 250142,
            "id": 15929,
            "text": "North Dum Dum (M) - Ward No.11"
        },
        {
            "urban_body_code": 250142,
            "id": 15930,
            "text": "North Dum Dum (M) - Ward No.12"
        },
        {
            "urban_body_code": 250142,
            "id": 15931,
            "text": "North Dum Dum (M) - Ward No.13"
        },
        {
            "urban_body_code": 250142,
            "id": 15932,
            "text": "North Dum Dum (M) - Ward No.14"
        },
        {
            "urban_body_code": 250142,
            "id": 15933,
            "text": "North Dum Dum (M) - Ward No.15"
        },
        {
            "urban_body_code": 250142,
            "id": 15934,
            "text": "North Dum Dum (M) - Ward No.16"
        },
        {
            "urban_body_code": 250142,
            "id": 15935,
            "text": "North Dum Dum (M) - Ward No.17"
        },
        {
            "urban_body_code": 250142,
            "id": 15936,
            "text": "North Dum Dum (M) - Ward No.18"
        },
        {
            "urban_body_code": 250142,
            "id": 15937,
            "text": "North Dum Dum (M) - Ward No.19"
        },
        {
            "urban_body_code": 250142,
            "id": 15938,
            "text": "North Dum Dum (M) - Ward No.20"
        },
        {
            "urban_body_code": 250142,
            "id": 15939,
            "text": "North Dum Dum (M) - Ward No.21"
        },
        {
            "urban_body_code": 250142,
            "id": 15940,
            "text": "North Dum Dum (M) - Ward No.22"
        },
        {
            "urban_body_code": 250142,
            "id": 15941,
            "text": "North Dum Dum (M) - Ward No.23"
        },
        {
            "urban_body_code": 250142,
            "id": 15942,
            "text": "North Dum Dum (M) - Ward No.24"
        },
        {
            "urban_body_code": 250142,
            "id": 15943,
            "text": "North Dum Dum (M) - Ward No.25"
        },
        {
            "urban_body_code": 250142,
            "id": 15944,
            "text": "North Dum Dum (M) - Ward No.26"
        },
        {
            "urban_body_code": 250142,
            "id": 15945,
            "text": "North Dum Dum (M) - Ward No.27"
        },
        {
            "urban_body_code": 250142,
            "id": 15946,
            "text": "North Dum Dum (M) - Ward No.28"
        },
        {
            "urban_body_code": 250142,
            "id": 15947,
            "text": "North Dum Dum (M) - Ward No.29"
        },
        {
            "urban_body_code": 250142,
            "id": 15948,
            "text": "North Dum Dum (M) - Ward No.30"
        },
        {
            "urban_body_code": 250142,
            "id": 9999360,
            "text": "North Dum Dum (M) - Ward No.31"
        },
        {
            "urban_body_code": 250142,
            "id": 9999361,
            "text": "North Dum Dum (M) - Ward No.32"
        },
        {
            "urban_body_code": 250142,
            "id": 9999362,
            "text": "North Dum Dum (M) - Ward No.33"
        },
        {
            "urban_body_code": 250142,
            "id": 9999363,
            "text": "North Dum Dum (M) - Ward No.34"
        },
        {
            "urban_body_code": 250143,
            "id": 15949,
            "text": "Dum Dum (M) - Ward No.1"
        },
        {
            "urban_body_code": 250143,
            "id": 15950,
            "text": "Dum Dum (M) - Ward No.2"
        },
        {
            "urban_body_code": 250143,
            "id": 15951,
            "text": "Dum Dum (M) - Ward No.3"
        },
        {
            "urban_body_code": 250143,
            "id": 15952,
            "text": "Dum Dum (M) - Ward No.4"
        },
        {
            "urban_body_code": 250143,
            "id": 15953,
            "text": "Dum Dum (M) - Ward No.5"
        },
        {
            "urban_body_code": 250143,
            "id": 15954,
            "text": "Dum Dum (M) - Ward No.6"
        },
        {
            "urban_body_code": 250143,
            "id": 15955,
            "text": "Dum Dum (M) - Ward No.7"
        },
        {
            "urban_body_code": 250143,
            "id": 15956,
            "text": "Dum Dum (M) - Ward No.8"
        },
        {
            "urban_body_code": 250143,
            "id": 15957,
            "text": "Dum Dum (M) - Ward No.9"
        },
        {
            "urban_body_code": 250143,
            "id": 15958,
            "text": "Dum Dum (M) - Ward No.10"
        },
        {
            "urban_body_code": 250143,
            "id": 15959,
            "text": "Dum Dum (M) - Ward No.11"
        },
        {
            "urban_body_code": 250143,
            "id": 15960,
            "text": "Dum Dum (M) - Ward No.12"
        },
        {
            "urban_body_code": 250143,
            "id": 15961,
            "text": "Dum Dum (M) - Ward No.13"
        },
        {
            "urban_body_code": 250143,
            "id": 15962,
            "text": "Dum Dum (M) - Ward No.14"
        },
        {
            "urban_body_code": 250143,
            "id": 15963,
            "text": "Dum Dum (M) - Ward No.15"
        },
        {
            "urban_body_code": 250143,
            "id": 15964,
            "text": "Dum Dum (M) - Ward No.16"
        },
        {
            "urban_body_code": 250143,
            "id": 15965,
            "text": "Dum Dum (M) - Ward No.17"
        },
        {
            "urban_body_code": 250143,
            "id": 15966,
            "text": "Dum Dum (M) - Ward No.18"
        },
        {
            "urban_body_code": 250143,
            "id": 15967,
            "text": "Dum Dum (M) - Ward No.19"
        },
        {
            "urban_body_code": 250143,
            "id": 15968,
            "text": "Dum Dum (M) - Ward No.20"
        },
        {
            "urban_body_code": 250143,
            "id": 15969,
            "text": "Dum Dum (M) - Ward No.21"
        },
        {
            "urban_body_code": 250143,
            "id": 15970,
            "text": "Dum Dum (M) - Ward No.22"
        },
        {
            "urban_body_code": 250144,
            "id": 63867,
            "text": "South Dum Dum (M) - Ward No.1"
        },
        {
            "urban_body_code": 250144,
            "id": 63868,
            "text": "South Dum Dum (M) - Ward No.2"
        },
        {
            "urban_body_code": 250144,
            "id": 63869,
            "text": "South Dum Dum (M) - Ward No.3"
        },
        {
            "urban_body_code": 250144,
            "id": 63870,
            "text": "South Dum Dum (M) - Ward No.4"
        },
        {
            "urban_body_code": 250144,
            "id": 63871,
            "text": "South Dum Dum (M) - Ward No.5"
        },
        {
            "urban_body_code": 250144,
            "id": 63872,
            "text": "South Dum Dum (M) - Ward No.6"
        },
        {
            "urban_body_code": 250144,
            "id": 63873,
            "text": "South Dum Dum (M) - Ward No.7"
        },
        {
            "urban_body_code": 250144,
            "id": 63874,
            "text": "South Dum Dum (M) - Ward No.8"
        },
        {
            "urban_body_code": 250144,
            "id": 63875,
            "text": "South Dum Dum (M) - Ward No.9"
        },
        {
            "urban_body_code": 250144,
            "id": 63876,
            "text": "South Dum Dum (M) - Ward No.10"
        },
        {
            "urban_body_code": 250144,
            "id": 63877,
            "text": "South Dum Dum (M) - Ward No.11"
        },
        {
            "urban_body_code": 250144,
            "id": 63878,
            "text": "South Dum Dum (M) - Ward No.12"
        },
        {
            "urban_body_code": 250144,
            "id": 63879,
            "text": "South Dum Dum (M) - Ward No.13"
        },
        {
            "urban_body_code": 250144,
            "id": 63880,
            "text": "South Dum Dum (M) - Ward No.14"
        },
        {
            "urban_body_code": 250144,
            "id": 63881,
            "text": "South Dum Dum (M) - Ward No.15"
        },
        {
            "urban_body_code": 250144,
            "id": 63882,
            "text": "South Dum Dum (M) - Ward No.16"
        },
        {
            "urban_body_code": 250144,
            "id": 63883,
            "text": "South Dum Dum (M) - Ward No.17"
        },
        {
            "urban_body_code": 250144,
            "id": 63884,
            "text": "South Dum Dum (M) - Ward No.18"
        },
        {
            "urban_body_code": 250144,
            "id": 63885,
            "text": "South Dum Dum (M) - Ward No.19"
        },
        {
            "urban_body_code": 250144,
            "id": 63886,
            "text": "South Dum Dum (M) - Ward No.20"
        },
        {
            "urban_body_code": 250144,
            "id": 63887,
            "text": "South Dum Dum (M) - Ward No.21"
        },
        {
            "urban_body_code": 250144,
            "id": 63888,
            "text": "South Dum Dum (M) - Ward No.22"
        },
        {
            "urban_body_code": 250144,
            "id": 63889,
            "text": "South Dum Dum (M) - Ward No.23"
        },
        {
            "urban_body_code": 250144,
            "id": 63890,
            "text": "South Dum Dum (M) - Ward No.24"
        },
        {
            "urban_body_code": 250144,
            "id": 63891,
            "text": "South Dum Dum (M) - Ward No.25"
        },
        {
            "urban_body_code": 250144,
            "id": 63892,
            "text": "South Dum Dum (M) - Ward No.26"
        },
        {
            "urban_body_code": 250144,
            "id": 63893,
            "text": "South Dum Dum (M) - Ward No.27"
        },
        {
            "urban_body_code": 250144,
            "id": 63894,
            "text": "South Dum Dum (M) - Ward No.28"
        },
        {
            "urban_body_code": 250144,
            "id": 63895,
            "text": "South Dum Dum (M) - Ward No.29"
        },
        {
            "urban_body_code": 250144,
            "id": 63896,
            "text": "South Dum Dum (M) - Ward No.30"
        },
        {
            "urban_body_code": 250144,
            "id": 63897,
            "text": "South Dum Dum (M) - Ward No.31"
        },
        {
            "urban_body_code": 250144,
            "id": 63898,
            "text": "South Dum Dum (M) - Ward No.32"
        },
        {
            "urban_body_code": 250144,
            "id": 63899,
            "text": "South Dum Dum (M) - Ward No.33"
        },
        {
            "urban_body_code": 250144,
            "id": 63900,
            "text": "South Dum Dum (M) - Ward No.34"
        },
        {
            "urban_body_code": 250144,
            "id": 63901,
            "text": "South Dum Dum (M) - Ward No.35"
        },
        {
            "urban_body_code": 250145,
            "id": 63902,
            "text": "Bidhan Nagar (M) - Ward No.1"
        },
        {
            "urban_body_code": 250145,
            "id": 63903,
            "text": "Bidhan Nagar (M) - Ward No.2"
        },
        {
            "urban_body_code": 250145,
            "id": 63904,
            "text": "Bidhan Nagar (M) - Ward No.3"
        },
        {
            "urban_body_code": 250145,
            "id": 63905,
            "text": "Bidhan Nagar (M) - Ward No.4"
        },
        {
            "urban_body_code": 250145,
            "id": 63906,
            "text": "Bidhan Nagar (M) - Ward No.5"
        },
        {
            "urban_body_code": 250145,
            "id": 63907,
            "text": "Bidhan Nagar (M) - Ward No.6"
        },
        {
            "urban_body_code": 250145,
            "id": 63908,
            "text": "Bidhan Nagar (M) - Ward No.7"
        },
        {
            "urban_body_code": 250145,
            "id": 63909,
            "text": "Bidhan Nagar (M) - Ward No.8"
        },
        {
            "urban_body_code": 250145,
            "id": 63910,
            "text": "Bidhan Nagar (M) - Ward No.9"
        },
        {
            "urban_body_code": 250145,
            "id": 63911,
            "text": "Bidhan Nagar (M) - Ward No.10"
        },
        {
            "urban_body_code": 250145,
            "id": 63912,
            "text": "Bidhan Nagar (M) - Ward No.11"
        },
        {
            "urban_body_code": 250145,
            "id": 63913,
            "text": "Bidhan Nagar (M) - Ward No.12"
        },
        {
            "urban_body_code": 250145,
            "id": 63914,
            "text": "Bidhan Nagar (M) - Ward No.13"
        },
        {
            "urban_body_code": 250145,
            "id": 63915,
            "text": "Bidhan Nagar (M) - Ward No.14"
        },
        {
            "urban_body_code": 250145,
            "id": 63916,
            "text": "Bidhan Nagar (M) - Ward No.15"
        },
        {
            "urban_body_code": 250145,
            "id": 63917,
            "text": "Bidhan Nagar (M) - Ward No.16"
        },
        {
            "urban_body_code": 250145,
            "id": 63918,
            "text": "Bidhan Nagar (M) - Ward No.17"
        },
        {
            "urban_body_code": 250145,
            "id": 63919,
            "text": "Bidhan Nagar (M) - Ward No.18"
        },
        {
            "urban_body_code": 250145,
            "id": 63920,
            "text": "Bidhan Nagar (M) - Ward No.19"
        },
        {
            "urban_body_code": 250145,
            "id": 63921,
            "text": "Bidhan Nagar (M) - Ward No.20"
        },
        {
            "urban_body_code": 250145,
            "id": 63922,
            "text": "Bidhan Nagar (M) - Ward No.21"
        },
        {
            "urban_body_code": 250145,
            "id": 63923,
            "text": "Bidhan Nagar (M) - Ward No.22"
        },
        {
            "urban_body_code": 250145,
            "id": 63924,
            "text": "Bidhan Nagar (M) - Ward No.23"
        },
        {
            "urban_body_code": 250145,
            "id": 9999175,
            "text": "Bidhan Nagar (M) - Ward No.24"
        },
        {
            "urban_body_code": 250145,
            "id": 9999176,
            "text": "Bidhan Nagar (M) - Ward No.25"
        },
        {
            "urban_body_code": 250145,
            "id": 9999177,
            "text": "Bidhan Nagar (M) - Ward No.26"
        },
        {
            "urban_body_code": 250145,
            "id": 9999178,
            "text": "Bidhan Nagar (M) - Ward No.27"
        },
        {
            "urban_body_code": 250145,
            "id": 9999179,
            "text": "Bidhan Nagar (M) - Ward No.28"
        },
        {
            "urban_body_code": 250145,
            "id": 9999180,
            "text": "Bidhan Nagar (M) - Ward No.29"
        },
        {
            "urban_body_code": 250145,
            "id": 9999181,
            "text": "Bidhan Nagar (M) - Ward No.30"
        },
        {
            "urban_body_code": 250145,
            "id": 9999182,
            "text": "Bidhan Nagar (M) - Ward No.31"
        },
        {
            "urban_body_code": 250145,
            "id": 9999183,
            "text": "Bidhan Nagar (M) - Ward No.32"
        },
        {
            "urban_body_code": 250145,
            "id": 9999184,
            "text": "Bidhan Nagar (M) - Ward No.33"
        },
        {
            "urban_body_code": 250145,
            "id": 9999185,
            "text": "Bidhan Nagar (M) - Ward No.34"
        },
        {
            "urban_body_code": 250145,
            "id": 9999186,
            "text": "Bidhan Nagar (M) - Ward No.35"
        },
        {
            "urban_body_code": 250145,
            "id": 9999187,
            "text": "Bidhan Nagar (M) - Ward No.36"
        },
        {
            "urban_body_code": 250145,
            "id": 9999188,
            "text": "Bidhan Nagar (M) - Ward No.37"
        },
        {
            "urban_body_code": 250145,
            "id": 9999189,
            "text": "Bidhan Nagar (M) - Ward No.38"
        },
        {
            "urban_body_code": 250145,
            "id": 9999190,
            "text": "Bidhan Nagar (M) - Ward No.39"
        },
        {
            "urban_body_code": 250145,
            "id": 9999191,
            "text": "Bidhan Nagar (M) - Ward No.40"
        },
        {
            "urban_body_code": 250145,
            "id": 9999192,
            "text": "Bidhan Nagar (M) - Ward No.41"
        },
        {
            "urban_body_code": 250146,
            "id": 15971,
            "text": "Rajarhat Gopalpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250146,
            "id": 15972,
            "text": "Rajarhat Gopalpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250146,
            "id": 15973,
            "text": "Rajarhat Gopalpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250146,
            "id": 15974,
            "text": "Rajarhat Gopalpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250146,
            "id": 15975,
            "text": "Rajarhat Gopalpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250146,
            "id": 15976,
            "text": "Rajarhat Gopalpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250146,
            "id": 15977,
            "text": "Rajarhat Gopalpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250146,
            "id": 15978,
            "text": "Rajarhat Gopalpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250146,
            "id": 15979,
            "text": "Rajarhat Gopalpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250146,
            "id": 15980,
            "text": "Rajarhat Gopalpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250146,
            "id": 15981,
            "text": "Rajarhat Gopalpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250146,
            "id": 15982,
            "text": "Rajarhat Gopalpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250146,
            "id": 15983,
            "text": "Rajarhat Gopalpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250146,
            "id": 15984,
            "text": "Rajarhat Gopalpur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250146,
            "id": 15985,
            "text": "Rajarhat Gopalpur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250146,
            "id": 15986,
            "text": "Rajarhat Gopalpur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250146,
            "id": 15987,
            "text": "Rajarhat Gopalpur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250146,
            "id": 15988,
            "text": "Rajarhat Gopalpur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250146,
            "id": 15989,
            "text": "Rajarhat Gopalpur (M) - Ward No.19"
        },
        {
            "urban_body_code": 250146,
            "id": 15990,
            "text": "Rajarhat Gopalpur (M) - Ward No.20"
        },
        {
            "urban_body_code": 250146,
            "id": 15991,
            "text": "Rajarhat Gopalpur (M) - Ward No.21"
        },
        {
            "urban_body_code": 250146,
            "id": 15992,
            "text": "Rajarhat Gopalpur (M) - Ward No.22"
        },
        {
            "urban_body_code": 250146,
            "id": 15993,
            "text": "Rajarhat Gopalpur (M) - Ward No.23"
        },
        {
            "urban_body_code": 250146,
            "id": 15994,
            "text": "Rajarhat Gopalpur (M) - Ward No.24"
        },
        {
            "urban_body_code": 250146,
            "id": 15995,
            "text": "Rajarhat Gopalpur (M) - Ward No.25"
        },
        {
            "urban_body_code": 250146,
            "id": 15996,
            "text": "Rajarhat Gopalpur (M) - Ward No.26"
        },
        {
            "urban_body_code": 250146,
            "id": 15997,
            "text": "Rajarhat Gopalpur (M) - Ward No.27"
        },
        {
            "urban_body_code": 250147,
            "id": 15998,
            "text": "Basirhat (M) - Ward No.1"
        },
        {
            "urban_body_code": 250147,
            "id": 15999,
            "text": "Basirhat (M) - Ward No.2"
        },
        {
            "urban_body_code": 250147,
            "id": 16000,
            "text": "Basirhat (M) - Ward No.3"
        },
        {
            "urban_body_code": 250147,
            "id": 16001,
            "text": "Basirhat (M) - Ward No.4"
        },
        {
            "urban_body_code": 250147,
            "id": 16183,
            "text": "Basirhat (M) - Ward No.5"
        },
        {
            "urban_body_code": 250147,
            "id": 16184,
            "text": "Basirhat (M) - Ward No.6"
        },
        {
            "urban_body_code": 250147,
            "id": 16185,
            "text": "Basirhat (M) - Ward No.7"
        },
        {
            "urban_body_code": 250147,
            "id": 16186,
            "text": "Basirhat (M) - Ward No.8"
        },
        {
            "urban_body_code": 250147,
            "id": 16187,
            "text": "Basirhat (M) - Ward No.9"
        },
        {
            "urban_body_code": 250147,
            "id": 16188,
            "text": "Basirhat (M) - Ward No.10"
        },
        {
            "urban_body_code": 250147,
            "id": 16189,
            "text": "Basirhat (M) - Ward No.11"
        },
        {
            "urban_body_code": 250147,
            "id": 16190,
            "text": "Basirhat (M) - Ward No.12"
        },
        {
            "urban_body_code": 250147,
            "id": 16191,
            "text": "Basirhat (M) - Ward No.13"
        },
        {
            "urban_body_code": 250147,
            "id": 16192,
            "text": "Basirhat (M) - Ward No.14"
        },
        {
            "urban_body_code": 250147,
            "id": 16193,
            "text": "Basirhat (M) - Ward No.15"
        },
        {
            "urban_body_code": 250147,
            "id": 16194,
            "text": "Basirhat (M) - Ward No.16"
        },
        {
            "urban_body_code": 250147,
            "id": 16195,
            "text": "Basirhat (M) - Ward No.17"
        },
        {
            "urban_body_code": 250147,
            "id": 16196,
            "text": "Basirhat (M) - Ward No.18"
        },
        {
            "urban_body_code": 250147,
            "id": 16197,
            "text": "Basirhat (M) - Ward No.19"
        },
        {
            "urban_body_code": 250147,
            "id": 16198,
            "text": "Basirhat (M) - Ward No.20"
        },
        {
            "urban_body_code": 250147,
            "id": 16199,
            "text": "Basirhat (M) - Ward No.21"
        },
        {
            "urban_body_code": 250147,
            "id": 16200,
            "text": "Basirhat (M) - Ward No.22"
        },
        {
            "urban_body_code": 250147,
            "id": 9999172,
            "text": "Basirhat (M) - Ward No.23"
        },
        {
            "urban_body_code": 250148,
            "id": 16201,
            "text": "Taki (M) - Ward No.1"
        },
        {
            "urban_body_code": 250148,
            "id": 16202,
            "text": "Taki (M) - Ward No.2"
        },
        {
            "urban_body_code": 250148,
            "id": 16203,
            "text": "Taki (M) - Ward No.3"
        },
        {
            "urban_body_code": 250148,
            "id": 16204,
            "text": "Taki (M) - Ward No.4"
        },
        {
            "urban_body_code": 250148,
            "id": 16205,
            "text": "Taki (M) - Ward No.5"
        },
        {
            "urban_body_code": 250148,
            "id": 16206,
            "text": "Taki (M) - Ward No.6"
        },
        {
            "urban_body_code": 250148,
            "id": 16207,
            "text": "Taki (M) - Ward No.7"
        },
        {
            "urban_body_code": 250148,
            "id": 16208,
            "text": "Taki (M) - Ward No.8"
        },
        {
            "urban_body_code": 250148,
            "id": 16209,
            "text": "Taki (M) - Ward No.9"
        },
        {
            "urban_body_code": 250148,
            "id": 16210,
            "text": "Taki (M) - Ward No.10"
        },
        {
            "urban_body_code": 250148,
            "id": 16211,
            "text": "Taki (M) - Ward No.11"
        },
        {
            "urban_body_code": 250148,
            "id": 16212,
            "text": "Taki (M) - Ward No.12"
        },
        {
            "urban_body_code": 250148,
            "id": 16213,
            "text": "Taki (M) - Ward No.13"
        },
        {
            "urban_body_code": 250148,
            "id": 16214,
            "text": "Taki (M) - Ward No.14"
        },
        {
            "urban_body_code": 250148,
            "id": 16215,
            "text": "Taki (M) - Ward No.15"
        },
        {
            "urban_body_code": 250148,
            "id": 16216,
            "text": "Taki (M) - Ward No.16"
        },
        {
            "urban_body_code": 250168,
            "id": 16235,
            "text": "Arambag (M) - Ward No.1"
        },
        {
            "urban_body_code": 250168,
            "id": 16236,
            "text": "Arambag (M) - Ward No.2"
        },
        {
            "urban_body_code": 250168,
            "id": 16237,
            "text": "Arambag (M) - Ward No.3"
        },
        {
            "urban_body_code": 250168,
            "id": 16238,
            "text": "Arambag (M) - Ward No.4"
        },
        {
            "urban_body_code": 250168,
            "id": 16233,
            "text": "Arambag (M) - Ward No.5"
        },
        {
            "urban_body_code": 250168,
            "id": 16234,
            "text": "Arambag (M) - Ward No.6"
        },
        {
            "urban_body_code": 250168,
            "id": 16239,
            "text": "Arambag (M) - Ward No.7"
        },
        {
            "urban_body_code": 250168,
            "id": 16240,
            "text": "Arambag (M) - Ward No.8"
        },
        {
            "urban_body_code": 250168,
            "id": 16241,
            "text": "Arambag (M) - Ward No.9"
        },
        {
            "urban_body_code": 250168,
            "id": 16242,
            "text": "Arambag (M) - Ward No.10"
        },
        {
            "urban_body_code": 250168,
            "id": 16243,
            "text": "Arambag (M) - Ward No.11"
        },
        {
            "urban_body_code": 250168,
            "id": 16244,
            "text": "Arambag (M) - Ward No.12"
        },
        {
            "urban_body_code": 250168,
            "id": 16245,
            "text": "Arambag (M) - Ward No.13"
        },
        {
            "urban_body_code": 250168,
            "id": 16246,
            "text": "Arambag (M) - Ward No.14"
        },
        {
            "urban_body_code": 250168,
            "id": 16247,
            "text": "Arambag (M) - Ward No.15"
        },
        {
            "urban_body_code": 250168,
            "id": 16248,
            "text": "Arambag (M) - Ward No.16"
        },
        {
            "urban_body_code": 250168,
            "id": 16249,
            "text": "Arambag (M) - Ward No.17"
        },
        {
            "urban_body_code": 250168,
            "id": 16250,
            "text": "Arambag (M) - Ward No.18"
        },
        {
            "urban_body_code": 250168,
            "id": 9999100,
            "text": "Arambag (M) - Ward No.19"
        },
        {
            "urban_body_code": 250169,
            "id": 63934,
            "text": "Tarakeswar (M) - Ward No.1"
        },
        {
            "urban_body_code": 250169,
            "id": 63935,
            "text": "Tarakeswar (M) - Ward No.2"
        },
        {
            "urban_body_code": 250169,
            "id": 63936,
            "text": "Tarakeswar (M) - Ward No.3"
        },
        {
            "urban_body_code": 250169,
            "id": 63937,
            "text": "Tarakeswar (M) - Ward No.4"
        },
        {
            "urban_body_code": 250169,
            "id": 63938,
            "text": "Tarakeswar (M) - Ward No.5"
        },
        {
            "urban_body_code": 250169,
            "id": 63939,
            "text": "Tarakeswar (M) - Ward No.6"
        },
        {
            "urban_body_code": 250169,
            "id": 63940,
            "text": "Tarakeswar (M) - Ward No.7"
        },
        {
            "urban_body_code": 250169,
            "id": 63941,
            "text": "Tarakeswar (M) - Ward No.8"
        },
        {
            "urban_body_code": 250169,
            "id": 63942,
            "text": "Tarakeswar (M) - Ward No.9"
        },
        {
            "urban_body_code": 250169,
            "id": 63943,
            "text": "Tarakeswar (M) - Ward No.10"
        },
        {
            "urban_body_code": 250169,
            "id": 63944,
            "text": "Tarakeswar (M) - Ward No.11"
        },
        {
            "urban_body_code": 250169,
            "id": 67534,
            "text": "Tarakeswar (M) - Ward No.12"
        },
        {
            "urban_body_code": 250169,
            "id": 67535,
            "text": "Tarakeswar (M) - Ward No.13"
        },
        {
            "urban_body_code": 250169,
            "id": 67536,
            "text": "Tarakeswar (M) - Ward No.14"
        },
        {
            "urban_body_code": 250169,
            "id": 67537,
            "text": "Tarakeswar (M) - Ward No.15"
        },
        {
            "urban_body_code": 250170,
            "id": 14337,
            "text": "Bansberia (M) - Ward No.1"
        },
        {
            "urban_body_code": 250170,
            "id": 14338,
            "text": "Bansberia (M) - Ward No.2"
        },
        {
            "urban_body_code": 250170,
            "id": 14339,
            "text": "Bansberia (M) - Ward No.3"
        },
        {
            "urban_body_code": 250170,
            "id": 14340,
            "text": "Bansberia (M) - Ward No.4"
        },
        {
            "urban_body_code": 250170,
            "id": 14341,
            "text": "Bansberia (M) - Ward No.5"
        },
        {
            "urban_body_code": 250170,
            "id": 14342,
            "text": "Bansberia (M) - Ward No.6"
        },
        {
            "urban_body_code": 250170,
            "id": 14343,
            "text": "Bansberia (M) - Ward No.7"
        },
        {
            "urban_body_code": 250170,
            "id": 14344,
            "text": "Bansberia (M) - Ward No.8"
        },
        {
            "urban_body_code": 250170,
            "id": 14345,
            "text": "Bansberia (M) - Ward No.9"
        },
        {
            "urban_body_code": 250170,
            "id": 14346,
            "text": "Bansberia (M) - Ward No.10"
        },
        {
            "urban_body_code": 250170,
            "id": 14347,
            "text": "Bansberia (M) - Ward No.11"
        },
        {
            "urban_body_code": 250170,
            "id": 14348,
            "text": "Bansberia (M) - Ward No.12"
        },
        {
            "urban_body_code": 250170,
            "id": 14349,
            "text": "Bansberia (M) - Ward No.13"
        },
        {
            "urban_body_code": 250170,
            "id": 14350,
            "text": "Bansberia (M) - Ward No.14"
        },
        {
            "urban_body_code": 250170,
            "id": 14351,
            "text": "Bansberia (M) - Ward No.15"
        },
        {
            "urban_body_code": 250170,
            "id": 14352,
            "text": "Bansberia (M) - Ward No.16"
        },
        {
            "urban_body_code": 250170,
            "id": 14353,
            "text": "Bansberia (M) - Ward No.17"
        },
        {
            "urban_body_code": 250170,
            "id": 14354,
            "text": "Bansberia (M) - Ward No.18"
        },
        {
            "urban_body_code": 250170,
            "id": 14355,
            "text": "Bansberia (M) - Ward No.19"
        },
        {
            "urban_body_code": 250170,
            "id": 14356,
            "text": "Bansberia (M) - Ward No.20"
        },
        {
            "urban_body_code": 250170,
            "id": 14357,
            "text": "Bansberia (M) - Ward No.21"
        },
        {
            "urban_body_code": 250170,
            "id": 14358,
            "text": "Bansberia (M) - Ward No.22"
        },
        {
            "urban_body_code": 250170,
            "id": 14656,
            "text": "Khamarpara (OG) - Ward No.23"
        },
        {
            "urban_body_code": 250170,
            "id": 14657,
            "text": "Bandel Thermal Power Project Town (OG) - Ward No.24"
        },
        {
            "urban_body_code": 250170,
            "id": 14658,
            "text": "Bara Khejuria (OG) - Ward No.25"
        },
        {
            "urban_body_code": 250171,
            "id": 67538,
            "text": "Hugli-Chinsurah (M) - Ward No.1"
        },
        {
            "urban_body_code": 250171,
            "id": 67539,
            "text": "Hugli-Chinsurah (M) - Ward No.2"
        },
        {
            "urban_body_code": 250171,
            "id": 67540,
            "text": "Hugli-Chinsurah (M) - Ward No.3"
        },
        {
            "urban_body_code": 250171,
            "id": 67541,
            "text": "Hugli-Chinsurah (M) - Ward No.4"
        },
        {
            "urban_body_code": 250171,
            "id": 67542,
            "text": "Hugli-Chinsurah (M) - Ward No.5"
        },
        {
            "urban_body_code": 250171,
            "id": 67543,
            "text": "Hugli-Chinsurah (M) - Ward No.6"
        },
        {
            "urban_body_code": 250171,
            "id": 67544,
            "text": "Hugli-Chinsurah (M) - Ward No.7"
        },
        {
            "urban_body_code": 250171,
            "id": 67545,
            "text": "Hugli-Chinsurah (M) - Ward No.8"
        },
        {
            "urban_body_code": 250171,
            "id": 67546,
            "text": "Hugli-Chinsurah (M) - Ward No.9"
        },
        {
            "urban_body_code": 250171,
            "id": 67547,
            "text": "Hugli-Chinsurah (M) - Ward No.10"
        },
        {
            "urban_body_code": 250171,
            "id": 67548,
            "text": "Hugli-Chinsurah (M) - Ward No.11"
        },
        {
            "urban_body_code": 250171,
            "id": 67549,
            "text": "Hugli-Chinsurah (M) - Ward No.12"
        },
        {
            "urban_body_code": 250171,
            "id": 67550,
            "text": "Hugli-Chinsurah (M) - Ward No.13"
        },
        {
            "urban_body_code": 250171,
            "id": 67551,
            "text": "Hugli-Chinsurah (M) - Ward No.14"
        },
        {
            "urban_body_code": 250171,
            "id": 67552,
            "text": "Hugli-Chinsurah (M) - Ward No.15"
        },
        {
            "urban_body_code": 250171,
            "id": 67553,
            "text": "Hugli-Chinsurah (M) - Ward No.16"
        },
        {
            "urban_body_code": 250171,
            "id": 67554,
            "text": "Hugli-Chinsurah (M) - Ward No.17"
        },
        {
            "urban_body_code": 250171,
            "id": 67555,
            "text": "Hugli-Chinsurah (M) - Ward No.18"
        },
        {
            "urban_body_code": 250171,
            "id": 67556,
            "text": "Hugli-Chinsurah (M) - Ward No.19"
        },
        {
            "urban_body_code": 250171,
            "id": 67557,
            "text": "Hugli-Chinsurah (M) - Ward No.20"
        },
        {
            "urban_body_code": 250171,
            "id": 67558,
            "text": "Hugli-Chinsurah (M) - Ward No.21"
        },
        {
            "urban_body_code": 250171,
            "id": 67559,
            "text": "Hugli-Chinsurah (M) - Ward No.22"
        },
        {
            "urban_body_code": 250171,
            "id": 67560,
            "text": "Hugli-Chinsurah (M) - Ward No.23"
        },
        {
            "urban_body_code": 250171,
            "id": 67561,
            "text": "Hugli-Chinsurah (M) - Ward No.24"
        },
        {
            "urban_body_code": 250171,
            "id": 67562,
            "text": "Hugli-Chinsurah (M) - Ward No.25"
        },
        {
            "urban_body_code": 250171,
            "id": 67563,
            "text": "Hugli-Chinsurah (M) - Ward No.26"
        },
        {
            "urban_body_code": 250171,
            "id": 67564,
            "text": "Hugli-Chinsurah (M) - Ward No.27"
        },
        {
            "urban_body_code": 250171,
            "id": 67565,
            "text": "Hugli-Chinsurah (M) - Ward No.28"
        },
        {
            "urban_body_code": 250171,
            "id": 67566,
            "text": "Hugli-Chinsurah (M) - Ward No.29"
        },
        {
            "urban_body_code": 250171,
            "id": 67567,
            "text": "Hugli-Chinsurah (M) - Ward No.30"
        },
        {
            "urban_body_code": 250171,
            "id": 68258,
            "text": "Naldanga (OG) - Ward No.31"
        },
        {
            "urban_body_code": 250172,
            "id": 14359,
            "text": "Chandannagar (M Corp) - Ward No.1"
        },
        {
            "urban_body_code": 250172,
            "id": 14360,
            "text": "Chandannagar (M Corp) - Ward No.2"
        },
        {
            "urban_body_code": 250172,
            "id": 14361,
            "text": "Chandannagar (M Corp) - Ward No.3"
        },
        {
            "urban_body_code": 250172,
            "id": 14362,
            "text": "Chandannagar (M Corp) - Ward No.4"
        },
        {
            "urban_body_code": 250172,
            "id": 14363,
            "text": "Chandannagar (M Corp) - Ward No.5"
        },
        {
            "urban_body_code": 250172,
            "id": 14364,
            "text": "Chandannagar (M Corp) - Ward No.6"
        },
        {
            "urban_body_code": 250172,
            "id": 14365,
            "text": "Chandannagar (M Corp) - Ward No.7"
        },
        {
            "urban_body_code": 250172,
            "id": 14366,
            "text": "Chandannagar (M Corp) - Ward No.8"
        },
        {
            "urban_body_code": 250172,
            "id": 14367,
            "text": "Chandannagar (M Corp) - Ward No.9"
        },
        {
            "urban_body_code": 250172,
            "id": 14368,
            "text": "Chandannagar (M Corp) - Ward No.10"
        },
        {
            "urban_body_code": 250172,
            "id": 14369,
            "text": "Chandannagar (M Corp) - Ward No.11"
        },
        {
            "urban_body_code": 250172,
            "id": 14370,
            "text": "Chandannagar (M Corp) - Ward No.12"
        },
        {
            "urban_body_code": 250172,
            "id": 14371,
            "text": "Chandannagar (M Corp) - Ward No.13"
        },
        {
            "urban_body_code": 250172,
            "id": 14372,
            "text": "Chandannagar (M Corp) - Ward No.14"
        },
        {
            "urban_body_code": 250172,
            "id": 14373,
            "text": "Chandannagar (M Corp) - Ward No.15"
        },
        {
            "urban_body_code": 250172,
            "id": 14374,
            "text": "Chandannagar (M Corp) - Ward No.16"
        },
        {
            "urban_body_code": 250172,
            "id": 14375,
            "text": "Chandannagar (M Corp) - Ward No.17"
        },
        {
            "urban_body_code": 250172,
            "id": 14376,
            "text": "Chandannagar (M Corp) - Ward No.18"
        },
        {
            "urban_body_code": 250172,
            "id": 14377,
            "text": "Chandannagar (M Corp) - Ward No.19"
        },
        {
            "urban_body_code": 250172,
            "id": 14378,
            "text": "Chandannagar (M Corp) - Ward No.20"
        },
        {
            "urban_body_code": 250172,
            "id": 14379,
            "text": "Chandannagar (M Corp) - Ward No.21"
        },
        {
            "urban_body_code": 250172,
            "id": 14380,
            "text": "Chandannagar (M Corp) - Ward No.22"
        },
        {
            "urban_body_code": 250172,
            "id": 14381,
            "text": "Chandannagar (M Corp) - Ward No.23"
        },
        {
            "urban_body_code": 250172,
            "id": 14382,
            "text": "Chandannagar (M Corp) - Ward No.24"
        },
        {
            "urban_body_code": 250172,
            "id": 14383,
            "text": "Chandannagar (M Corp) - Ward No.25"
        },
        {
            "urban_body_code": 250172,
            "id": 14384,
            "text": "Chandannagar (M Corp) - Ward No.26"
        },
        {
            "urban_body_code": 250172,
            "id": 14385,
            "text": "Chandannagar (M Corp) - Ward No.27"
        },
        {
            "urban_body_code": 250172,
            "id": 14386,
            "text": "Chandannagar (M Corp) - Ward No.28"
        },
        {
            "urban_body_code": 250172,
            "id": 14387,
            "text": "Chandannagar (M Corp) - Ward No.29"
        },
        {
            "urban_body_code": 250172,
            "id": 14388,
            "text": "Chandannagar (M Corp) - Ward No.30"
        },
        {
            "urban_body_code": 250172,
            "id": 14389,
            "text": "Chandannagar (M Corp) - Ward No.31"
        },
        {
            "urban_body_code": 250172,
            "id": 14390,
            "text": "Chandannagar (M Corp) - Ward No.32"
        },
        {
            "urban_body_code": 250172,
            "id": 14391,
            "text": "Chandannagar (M Corp) - Ward No.33"
        },
        {
            "urban_body_code": 250173,
            "id": 14392,
            "text": "Bhadreswar (M) - Ward No.1"
        },
        {
            "urban_body_code": 250173,
            "id": 14393,
            "text": "Bhadreswar (M) - Ward No.2"
        },
        {
            "urban_body_code": 250173,
            "id": 14394,
            "text": "Bhadreswar (M) - Ward No.3"
        },
        {
            "urban_body_code": 250173,
            "id": 14395,
            "text": "Bhadreswar (M) - Ward No.4"
        },
        {
            "urban_body_code": 250173,
            "id": 14396,
            "text": "Bhadreswar (M) - Ward No.5"
        },
        {
            "urban_body_code": 250173,
            "id": 14397,
            "text": "Bhadreswar (M) - Ward No.6"
        },
        {
            "urban_body_code": 250173,
            "id": 14398,
            "text": "Bhadreswar (M) - Ward No.7"
        },
        {
            "urban_body_code": 250173,
            "id": 14399,
            "text": "Bhadreswar (M) - Ward No.8"
        },
        {
            "urban_body_code": 250173,
            "id": 14400,
            "text": "Bhadreswar (M) - Ward No.9"
        },
        {
            "urban_body_code": 250173,
            "id": 14401,
            "text": "Bhadreswar (M) - Ward No.10"
        },
        {
            "urban_body_code": 250173,
            "id": 14402,
            "text": "Bhadreswar (M) - Ward No.11"
        },
        {
            "urban_body_code": 250173,
            "id": 14403,
            "text": "Bhadreswar (M) - Ward No.12"
        },
        {
            "urban_body_code": 250173,
            "id": 14404,
            "text": "Bhadreswar (M) - Ward No.13"
        },
        {
            "urban_body_code": 250173,
            "id": 14405,
            "text": "Bhadreswar (M) - Ward No.14"
        },
        {
            "urban_body_code": 250173,
            "id": 14406,
            "text": "Bhadreswar (M) - Ward No.15"
        },
        {
            "urban_body_code": 250173,
            "id": 14407,
            "text": "Bhadreswar (M) - Ward No.16"
        },
        {
            "urban_body_code": 250173,
            "id": 14408,
            "text": "Bhadreswar (M) - Ward No.17"
        },
        {
            "urban_body_code": 250173,
            "id": 14409,
            "text": "Bhadreswar (M) - Ward No.18"
        },
        {
            "urban_body_code": 250173,
            "id": 14410,
            "text": "Bhadreswar (M) - Ward No.19"
        },
        {
            "urban_body_code": 250173,
            "id": 14411,
            "text": "Bhadreswar (M) - Ward No.20"
        },
        {
            "urban_body_code": 250173,
            "id": 9999173,
            "text": "Bhadreswar (M) - Ward No.21"
        },
        {
            "urban_body_code": 250173,
            "id": 9999174,
            "text": "Bhadreswar (M) - Ward No.22"
        },
        {
            "urban_body_code": 250174,
            "id": 67568,
            "text": "Champdani (M) - Ward No.1"
        },
        {
            "urban_body_code": 250174,
            "id": 67569,
            "text": "Champdani (M) - Ward No.2"
        },
        {
            "urban_body_code": 250174,
            "id": 67570,
            "text": "Champdani (M) - Ward No.3"
        },
        {
            "urban_body_code": 250174,
            "id": 67571,
            "text": "Champdani (M) - Ward No.4"
        },
        {
            "urban_body_code": 250174,
            "id": 67572,
            "text": "Champdani (M) - Ward No.5"
        },
        {
            "urban_body_code": 250174,
            "id": 67573,
            "text": "Champdani (M) - Ward No.6"
        },
        {
            "urban_body_code": 250174,
            "id": 67574,
            "text": "Champdani (M) - Ward No.7"
        },
        {
            "urban_body_code": 250174,
            "id": 67575,
            "text": "Champdani (M) - Ward No.8"
        },
        {
            "urban_body_code": 250174,
            "id": 67576,
            "text": "Champdani (M) - Ward No.9"
        },
        {
            "urban_body_code": 250174,
            "id": 67577,
            "text": "Champdani (M) - Ward No.10"
        },
        {
            "urban_body_code": 250174,
            "id": 67578,
            "text": "Champdani (M) - Ward No.11"
        },
        {
            "urban_body_code": 250174,
            "id": 67579,
            "text": "Champdani (M) - Ward No.12"
        },
        {
            "urban_body_code": 250174,
            "id": 67580,
            "text": "Champdani (M) - Ward No.13"
        },
        {
            "urban_body_code": 250174,
            "id": 68247,
            "text": "Champdani (M) - Ward No.14"
        },
        {
            "urban_body_code": 250174,
            "id": 68248,
            "text": "Champdani (M) - Ward No.15"
        },
        {
            "urban_body_code": 250174,
            "id": 68249,
            "text": "Champdani (M) - Ward No.16"
        },
        {
            "urban_body_code": 250174,
            "id": 68250,
            "text": "Champdani (M) - Ward No.17"
        },
        {
            "urban_body_code": 250174,
            "id": 68251,
            "text": "Champdani (M) - Ward No.18"
        },
        {
            "urban_body_code": 250174,
            "id": 68252,
            "text": "Champdani (M) - Ward No.19"
        },
        {
            "urban_body_code": 250174,
            "id": 68253,
            "text": "Champdani (M) - Ward No.20"
        },
        {
            "urban_body_code": 250174,
            "id": 68254,
            "text": "Champdani (M) - Ward No.21"
        },
        {
            "urban_body_code": 250174,
            "id": 68255,
            "text": "Champdani (M) - Ward No.22"
        },
        {
            "urban_body_code": 250175,
            "id": 14412,
            "text": "Baidyabati (M) - Ward No.1"
        },
        {
            "urban_body_code": 250175,
            "id": 14413,
            "text": "Baidyabati (M) - Ward No.2"
        },
        {
            "urban_body_code": 250175,
            "id": 14414,
            "text": "Baidyabati (M) - Ward No.3"
        },
        {
            "urban_body_code": 250175,
            "id": 14415,
            "text": "Baidyabati (M) - Ward No.4"
        },
        {
            "urban_body_code": 250175,
            "id": 14416,
            "text": "Baidyabati (M) - Ward No.5"
        },
        {
            "urban_body_code": 250175,
            "id": 14417,
            "text": "Baidyabati (M) - Ward No.6"
        },
        {
            "urban_body_code": 250175,
            "id": 14418,
            "text": "Baidyabati (M) - Ward No.7"
        },
        {
            "urban_body_code": 250175,
            "id": 14419,
            "text": "Baidyabati (M) - Ward No.8"
        },
        {
            "urban_body_code": 250175,
            "id": 14420,
            "text": "Baidyabati (M) - Ward No.9"
        },
        {
            "urban_body_code": 250175,
            "id": 14421,
            "text": "Baidyabati (M) - Ward No.10"
        },
        {
            "urban_body_code": 250175,
            "id": 14422,
            "text": "Baidyabati (M) - Ward No.11"
        },
        {
            "urban_body_code": 250175,
            "id": 14423,
            "text": "Baidyabati (M) - Ward No.12"
        },
        {
            "urban_body_code": 250175,
            "id": 14424,
            "text": "Baidyabati (M) - Ward No.13"
        },
        {
            "urban_body_code": 250175,
            "id": 14425,
            "text": "Baidyabati (M) - Ward No.14"
        },
        {
            "urban_body_code": 250175,
            "id": 14426,
            "text": "Baidyabati (M) - Ward No.15"
        },
        {
            "urban_body_code": 250175,
            "id": 14427,
            "text": "Baidyabati (M) - Ward No.16"
        },
        {
            "urban_body_code": 250175,
            "id": 14428,
            "text": "Baidyabati (M) - Ward No.17"
        },
        {
            "urban_body_code": 250175,
            "id": 14429,
            "text": "Baidyabati (M) - Ward No.18"
        },
        {
            "urban_body_code": 250175,
            "id": 14430,
            "text": "Baidyabati (M) - Ward No.19"
        },
        {
            "urban_body_code": 250175,
            "id": 14431,
            "text": "Baidyabati (M) - Ward No.20"
        },
        {
            "urban_body_code": 250175,
            "id": 14432,
            "text": "Baidyabati (M) - Ward No.21"
        },
        {
            "urban_body_code": 250175,
            "id": 14433,
            "text": "Baidyabati (M) - Ward No.22"
        },
        {
            "urban_body_code": 250175,
            "id": 9999163,
            "text": "Baidyabati (M) - Ward No.23"
        },
        {
            "urban_body_code": 250176,
            "id": 14434,
            "text": "Serampore (M) - Ward No.1"
        },
        {
            "urban_body_code": 250176,
            "id": 14435,
            "text": "Serampore (M) - Ward No.2"
        },
        {
            "urban_body_code": 250176,
            "id": 14436,
            "text": "Serampore (M) - Ward No.3"
        },
        {
            "urban_body_code": 250176,
            "id": 14437,
            "text": "Serampore (M) - Ward No.4"
        },
        {
            "urban_body_code": 250176,
            "id": 14438,
            "text": "Serampore (M) - Ward No.5"
        },
        {
            "urban_body_code": 250176,
            "id": 14439,
            "text": "Serampore (M) - Ward No.6"
        },
        {
            "urban_body_code": 250176,
            "id": 14440,
            "text": "Serampore (M) - Ward No.7"
        },
        {
            "urban_body_code": 250176,
            "id": 14441,
            "text": "Serampore (M) - Ward No.8"
        },
        {
            "urban_body_code": 250176,
            "id": 14442,
            "text": "Serampore (M) - Ward No.9"
        },
        {
            "urban_body_code": 250176,
            "id": 14443,
            "text": "Serampore (M) - Ward No.10"
        },
        {
            "urban_body_code": 250176,
            "id": 14444,
            "text": "Serampore (M) - Ward No.11"
        },
        {
            "urban_body_code": 250176,
            "id": 14445,
            "text": "Serampore (M) - Ward No.12"
        },
        {
            "urban_body_code": 250176,
            "id": 14446,
            "text": "Serampore (M) - Ward No.13"
        },
        {
            "urban_body_code": 250176,
            "id": 14447,
            "text": "Serampore (M) - Ward No.14"
        },
        {
            "urban_body_code": 250176,
            "id": 14448,
            "text": "Serampore (M) - Ward No.15"
        },
        {
            "urban_body_code": 250176,
            "id": 14449,
            "text": "Serampore (M) - Ward No.16"
        },
        {
            "urban_body_code": 250176,
            "id": 14450,
            "text": "Serampore (M) - Ward No.17"
        },
        {
            "urban_body_code": 250176,
            "id": 14451,
            "text": "Serampore (M) - Ward No.18"
        },
        {
            "urban_body_code": 250176,
            "id": 14452,
            "text": "Serampore (M) - Ward No.19"
        },
        {
            "urban_body_code": 250176,
            "id": 14453,
            "text": "Serampore (M) - Ward No.20"
        },
        {
            "urban_body_code": 250176,
            "id": 14454,
            "text": "Serampore (M) - Ward No.21"
        },
        {
            "urban_body_code": 250176,
            "id": 14455,
            "text": "Serampore (M) - Ward No.22"
        },
        {
            "urban_body_code": 250176,
            "id": 14456,
            "text": "Serampore (M) - Ward No.23"
        },
        {
            "urban_body_code": 250176,
            "id": 14457,
            "text": "Serampore (M) - Ward No.24"
        },
        {
            "urban_body_code": 250176,
            "id": 14458,
            "text": "Serampore (M) - Ward No.25"
        },
        {
            "urban_body_code": 250176,
            "id": 9999409,
            "text": "Serampore (M) - Ward No.26"
        },
        {
            "urban_body_code": 250176,
            "id": 9999375,
            "text": "Serampore (M) - Ward No.26"
        },
        {
            "urban_body_code": 250176,
            "id": 9999376,
            "text": "Serampore (M) - Ward No.27"
        },
        {
            "urban_body_code": 250176,
            "id": 9999410,
            "text": "Serampore (M) - Ward No.27"
        },
        {
            "urban_body_code": 250176,
            "id": 9999411,
            "text": "Serampore (M) - Ward No.28"
        },
        {
            "urban_body_code": 250176,
            "id": 9999377,
            "text": "Serampore (M) - Ward No.28"
        },
        {
            "urban_body_code": 250176,
            "id": 9999412,
            "text": "Serampore (M) - Ward No.29"
        },
        {
            "urban_body_code": 250176,
            "id": 9999378,
            "text": "Serampore (M) - Ward No.29"
        },
        {
            "urban_body_code": 250177,
            "id": 14459,
            "text": "Rishra (M) - Ward No.1"
        },
        {
            "urban_body_code": 250177,
            "id": 14461,
            "text": "Rishra (M) - Ward No.2"
        },
        {
            "urban_body_code": 250177,
            "id": 14463,
            "text": "Rishra (M) - Ward No.3"
        },
        {
            "urban_body_code": 250177,
            "id": 14465,
            "text": "Rishra (M) - Ward No.4"
        },
        {
            "urban_body_code": 250177,
            "id": 14467,
            "text": "Rishra (M) - Ward No.5"
        },
        {
            "urban_body_code": 250177,
            "id": 14469,
            "text": "Rishra (M) - Ward No.6"
        },
        {
            "urban_body_code": 250177,
            "id": 14471,
            "text": "Rishra (M) - Ward No.7"
        },
        {
            "urban_body_code": 250177,
            "id": 14473,
            "text": "Rishra (M) - Ward No.8"
        },
        {
            "urban_body_code": 250177,
            "id": 14475,
            "text": "Rishra (M) - Ward No.9"
        },
        {
            "urban_body_code": 250177,
            "id": 14477,
            "text": "Rishra (M) - Ward No.10"
        },
        {
            "urban_body_code": 250177,
            "id": 14479,
            "text": "Rishra (M) - Ward No.11"
        },
        {
            "urban_body_code": 250177,
            "id": 14481,
            "text": "Rishra (M) - Ward No.12"
        },
        {
            "urban_body_code": 250177,
            "id": 14483,
            "text": "Rishra (M) - Ward No.13"
        },
        {
            "urban_body_code": 250177,
            "id": 14485,
            "text": "Rishra (M) - Ward No.14"
        },
        {
            "urban_body_code": 250177,
            "id": 14487,
            "text": "Rishra (M) - Ward No.15"
        },
        {
            "urban_body_code": 250177,
            "id": 14489,
            "text": "Rishra (M) - Ward No.16"
        },
        {
            "urban_body_code": 250177,
            "id": 14594,
            "text": "Rishra (M) - Ward No.17"
        },
        {
            "urban_body_code": 250177,
            "id": 14596,
            "text": "Rishra (M) - Ward No.18"
        },
        {
            "urban_body_code": 250177,
            "id": 14598,
            "text": "Rishra (M) - Ward No.19"
        },
        {
            "urban_body_code": 250177,
            "id": 14600,
            "text": "Rishra (M) - Ward No.20"
        },
        {
            "urban_body_code": 250177,
            "id": 14602,
            "text": "Rishra (M) - Ward No.21"
        },
        {
            "urban_body_code": 250177,
            "id": 14604,
            "text": "Rishra (M) - Ward No.22"
        },
        {
            "urban_body_code": 250177,
            "id": 14606,
            "text": "Rishra (M) - Ward No.23"
        },
        {
            "urban_body_code": 250178,
            "id": 14608,
            "text": "Konnagar (M) - Ward No.1"
        },
        {
            "urban_body_code": 250178,
            "id": 14609,
            "text": "Konnagar (M) - Ward No.2"
        },
        {
            "urban_body_code": 250178,
            "id": 14610,
            "text": "Konnagar (M) - Ward No.3"
        },
        {
            "urban_body_code": 250178,
            "id": 14611,
            "text": "Konnagar (M) - Ward No.4"
        },
        {
            "urban_body_code": 250178,
            "id": 14612,
            "text": "Konnagar (M) - Ward No.5"
        },
        {
            "urban_body_code": 250178,
            "id": 14613,
            "text": "Konnagar (M) - Ward No.6"
        },
        {
            "urban_body_code": 250178,
            "id": 14614,
            "text": "Konnagar (M) - Ward No.7"
        },
        {
            "urban_body_code": 250178,
            "id": 14615,
            "text": "Konnagar (M) - Ward No.8"
        },
        {
            "urban_body_code": 250178,
            "id": 14616,
            "text": "Konnagar (M) - Ward No.9"
        },
        {
            "urban_body_code": 250178,
            "id": 14617,
            "text": "Konnagar (M) - Ward No.10"
        },
        {
            "urban_body_code": 250178,
            "id": 14618,
            "text": "Konnagar (M) - Ward No.11"
        },
        {
            "urban_body_code": 250178,
            "id": 14619,
            "text": "Konnagar (M) - Ward No.12"
        },
        {
            "urban_body_code": 250178,
            "id": 14620,
            "text": "Konnagar (M) - Ward No.13"
        },
        {
            "urban_body_code": 250178,
            "id": 14621,
            "text": "Konnagar (M) - Ward No.14"
        },
        {
            "urban_body_code": 250178,
            "id": 14622,
            "text": "Konnagar (M) - Ward No.15"
        },
        {
            "urban_body_code": 250178,
            "id": 14623,
            "text": "Konnagar (M) - Ward No.16"
        },
        {
            "urban_body_code": 250178,
            "id": 14624,
            "text": "Konnagar (M) - Ward No.17"
        },
        {
            "urban_body_code": 250178,
            "id": 14625,
            "text": "Konnagar (M) - Ward No.18"
        },
        {
            "urban_body_code": 250178,
            "id": 14626,
            "text": "Konnagar (M) - Ward No.19"
        },
        {
            "urban_body_code": 250178,
            "id": 9999347,
            "text": "Konnagar (M) - Ward No.20"
        },
        {
            "urban_body_code": 250179,
            "id": 14627,
            "text": "Uttarpara Kotrung (M) - Ward No.1"
        },
        {
            "urban_body_code": 250179,
            "id": 14628,
            "text": "Uttarpara Kotrung (M) - Ward No.2"
        },
        {
            "urban_body_code": 250179,
            "id": 14629,
            "text": "Uttarpara Kotrung (M) - Ward No.3"
        },
        {
            "urban_body_code": 250179,
            "id": 14630,
            "text": "Uttarpara Kotrung (M) - Ward No.4"
        },
        {
            "urban_body_code": 250179,
            "id": 14631,
            "text": "Uttarpara Kotrung (M) - Ward No.5"
        },
        {
            "urban_body_code": 250179,
            "id": 14632,
            "text": "Uttarpara Kotrung (M) - Ward No.6"
        },
        {
            "urban_body_code": 250179,
            "id": 14633,
            "text": "Uttarpara Kotrung (M) - Ward No.7"
        },
        {
            "urban_body_code": 250179,
            "id": 14634,
            "text": "Uttarpara Kotrung (M) - Ward No.8"
        },
        {
            "urban_body_code": 250179,
            "id": 14635,
            "text": "Uttarpara Kotrung (M) - Ward No.9"
        },
        {
            "urban_body_code": 250179,
            "id": 14636,
            "text": "Uttarpara Kotrung (M) - Ward No.10"
        },
        {
            "urban_body_code": 250179,
            "id": 14637,
            "text": "Uttarpara Kotrung (M) - Ward No.11"
        },
        {
            "urban_body_code": 250179,
            "id": 14638,
            "text": "Uttarpara Kotrung (M) - Ward No.12"
        },
        {
            "urban_body_code": 250179,
            "id": 14639,
            "text": "Uttarpara Kotrung (M) - Ward No.13"
        },
        {
            "urban_body_code": 250179,
            "id": 14640,
            "text": "Uttarpara Kotrung (M) - Ward No.14"
        },
        {
            "urban_body_code": 250179,
            "id": 14641,
            "text": "Uttarpara Kotrung (M) - Ward No.15"
        },
        {
            "urban_body_code": 250179,
            "id": 14642,
            "text": "Uttarpara Kotrung (M) - Ward No.16"
        },
        {
            "urban_body_code": 250179,
            "id": 14643,
            "text": "Uttarpara Kotrung (M) - Ward No.17"
        },
        {
            "urban_body_code": 250179,
            "id": 14644,
            "text": "Uttarpara Kotrung (M) - Ward No.18"
        },
        {
            "urban_body_code": 250179,
            "id": 14645,
            "text": "Uttarpara Kotrung (M) - Ward No.19"
        },
        {
            "urban_body_code": 250179,
            "id": 14646,
            "text": "Uttarpara Kotrung (M) - Ward No.20"
        },
        {
            "urban_body_code": 250179,
            "id": 14647,
            "text": "Uttarpara Kotrung (M) - Ward No.21"
        },
        {
            "urban_body_code": 250179,
            "id": 14648,
            "text": "Uttarpara Kotrung (M) - Ward No.22"
        },
        {
            "urban_body_code": 250179,
            "id": 14649,
            "text": "Uttarpara Kotrung (M) - Ward No.23"
        },
        {
            "urban_body_code": 250179,
            "id": 14650,
            "text": "Uttarpara Kotrung (M) - Ward No.24"
        },
        {
            "urban_body_code": 250179,
            "id": 14651,
            "text": "Uttarpara Kotrung (M) - Ward No.25"
        },
        {
            "urban_body_code": 250208,
            "id": 14681,
            "text": "Sonamukhi (M) - Ward No.1"
        },
        {
            "urban_body_code": 250208,
            "id": 14682,
            "text": "Sonamukhi (M) - Ward No.2"
        },
        {
            "urban_body_code": 250208,
            "id": 15069,
            "text": "Sonamukhi (M) - Ward No.3"
        },
        {
            "urban_body_code": 250208,
            "id": 15070,
            "text": "Sonamukhi (M) - Ward No.4"
        },
        {
            "urban_body_code": 250208,
            "id": 14676,
            "text": "Sonamukhi (M) - Ward No.5"
        },
        {
            "urban_body_code": 250208,
            "id": 14677,
            "text": "Sonamukhi (M) - Ward No.6"
        },
        {
            "urban_body_code": 250208,
            "id": 14678,
            "text": "Sonamukhi (M) - Ward No.7"
        },
        {
            "urban_body_code": 250208,
            "id": 14679,
            "text": "Sonamukhi (M) - Ward No.8"
        },
        {
            "urban_body_code": 250208,
            "id": 14680,
            "text": "Sonamukhi (M) - Ward No.9"
        },
        {
            "urban_body_code": 250208,
            "id": 15071,
            "text": "Sonamukhi (M) - Ward No.10"
        },
        {
            "urban_body_code": 250208,
            "id": 15072,
            "text": "Sonamukhi (M) - Ward No.11"
        },
        {
            "urban_body_code": 250208,
            "id": 15073,
            "text": "Sonamukhi (M) - Ward No.12"
        },
        {
            "urban_body_code": 250208,
            "id": 15074,
            "text": "Sonamukhi (M) - Ward No.13"
        },
        {
            "urban_body_code": 250208,
            "id": 15075,
            "text": "Sonamukhi (M) - Ward No.14"
        },
        {
            "urban_body_code": 250208,
            "id": 15076,
            "text": "Sonamukhi (M) - Ward No.15"
        },
        {
            "urban_body_code": 250209,
            "id": 15077,
            "text": "Bankura (M) - Ward No.1"
        },
        {
            "urban_body_code": 250209,
            "id": 15078,
            "text": "Bankura (M) - Ward No.2"
        },
        {
            "urban_body_code": 250209,
            "id": 15079,
            "text": "Bankura (M) - Ward No.3"
        },
        {
            "urban_body_code": 250209,
            "id": 15080,
            "text": "Bankura (M) - Ward No.4"
        },
        {
            "urban_body_code": 250209,
            "id": 15081,
            "text": "Bankura (M) - Ward No.5"
        },
        {
            "urban_body_code": 250209,
            "id": 15082,
            "text": "Bankura (M) - Ward No.6"
        },
        {
            "urban_body_code": 250209,
            "id": 15083,
            "text": "Bankura (M) - Ward No.7"
        },
        {
            "urban_body_code": 250209,
            "id": 15084,
            "text": "Bankura (M) - Ward No.8"
        },
        {
            "urban_body_code": 250209,
            "id": 15085,
            "text": "Bankura (M) - Ward No.9"
        },
        {
            "urban_body_code": 250209,
            "id": 15086,
            "text": "Bankura (M) - Ward No.10"
        },
        {
            "urban_body_code": 250209,
            "id": 15087,
            "text": "Bankura (M) - Ward No.11"
        },
        {
            "urban_body_code": 250209,
            "id": 15088,
            "text": "Bankura (M) - Ward No.12"
        },
        {
            "urban_body_code": 250209,
            "id": 15089,
            "text": "Bankura (M) - Ward No.13"
        },
        {
            "urban_body_code": 250209,
            "id": 15090,
            "text": "Bankura (M) - Ward No.14"
        },
        {
            "urban_body_code": 250209,
            "id": 15091,
            "text": "Bankura (M) - Ward No.15"
        },
        {
            "urban_body_code": 250209,
            "id": 15092,
            "text": "Bankura (M) - Ward No.16"
        },
        {
            "urban_body_code": 250209,
            "id": 15093,
            "text": "Bankura (M) - Ward No.17"
        },
        {
            "urban_body_code": 250209,
            "id": 15094,
            "text": "Bankura (M) - Ward No.18"
        },
        {
            "urban_body_code": 250209,
            "id": 15095,
            "text": "Bankura (M) - Ward No.19"
        },
        {
            "urban_body_code": 250209,
            "id": 15096,
            "text": "Bankura (M) - Ward No.20"
        },
        {
            "urban_body_code": 250209,
            "id": 15097,
            "text": "Bankura (M) - Ward No.21"
        },
        {
            "urban_body_code": 250209,
            "id": 15098,
            "text": "Bankura (M) - Ward No.22"
        },
        {
            "urban_body_code": 250209,
            "id": 15099,
            "text": "Bankura (M) - Ward No.23"
        },
        {
            "urban_body_code": 250209,
            "id": 9999165,
            "text": "Bankura (M) - Ward No.24"
        },
        {
            "urban_body_code": 250210,
            "id": 15100,
            "text": "Bishnupur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250210,
            "id": 15101,
            "text": "Bishnupur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250210,
            "id": 15102,
            "text": "Bishnupur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250210,
            "id": 15103,
            "text": "Bishnupur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250210,
            "id": 15104,
            "text": "Bishnupur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250210,
            "id": 15105,
            "text": "Bishnupur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250210,
            "id": 15106,
            "text": "Bishnupur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250210,
            "id": 15107,
            "text": "Bishnupur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250210,
            "id": 15108,
            "text": "Bishnupur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250210,
            "id": 15109,
            "text": "Bishnupur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250210,
            "id": 15110,
            "text": "Bishnupur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250210,
            "id": 15111,
            "text": "Bishnupur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250210,
            "id": 15112,
            "text": "Bishnupur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250210,
            "id": 15113,
            "text": "Bishnupur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250210,
            "id": 15114,
            "text": "Bishnupur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250210,
            "id": 15115,
            "text": "Bishnupur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250210,
            "id": 15116,
            "text": "Bishnupur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250210,
            "id": 15117,
            "text": "Bishnupur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250210,
            "id": 15118,
            "text": "Bishnupur (M) - Ward No.19"
        },
        {
            "urban_body_code": 250213,
            "id": 15144,
            "text": "Raghunathpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250213,
            "id": 15147,
            "text": "Raghunathpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250213,
            "id": 15150,
            "text": "Raghunathpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250213,
            "id": 15153,
            "text": "Raghunathpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250213,
            "id": 15123,
            "text": "Raghunathpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250213,
            "id": 15126,
            "text": "Raghunathpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250213,
            "id": 15129,
            "text": "Raghunathpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250213,
            "id": 15132,
            "text": "Raghunathpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250213,
            "id": 15135,
            "text": "Raghunathpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250213,
            "id": 15138,
            "text": "Raghunathpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250213,
            "id": 15141,
            "text": "Raghunathpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250213,
            "id": 15156,
            "text": "Raghunathpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250213,
            "id": 15159,
            "text": "Raghunathpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250214,
            "id": 15160,
            "text": "Jhalda (M) - Ward No.1"
        },
        {
            "urban_body_code": 250214,
            "id": 15161,
            "text": "Jhalda (M) - Ward No.2"
        },
        {
            "urban_body_code": 250214,
            "id": 15162,
            "text": "Jhalda (M) - Ward No.3"
        },
        {
            "urban_body_code": 250214,
            "id": 15163,
            "text": "Jhalda (M) - Ward No.4"
        },
        {
            "urban_body_code": 250214,
            "id": 15164,
            "text": "Jhalda (M) - Ward No.5"
        },
        {
            "urban_body_code": 250214,
            "id": 15165,
            "text": "Jhalda (M) - Ward No.6"
        },
        {
            "urban_body_code": 250214,
            "id": 15166,
            "text": "Jhalda (M) - Ward No.7"
        },
        {
            "urban_body_code": 250214,
            "id": 15167,
            "text": "Jhalda (M) - Ward No.8"
        },
        {
            "urban_body_code": 250214,
            "id": 15168,
            "text": "Jhalda (M) - Ward No.9"
        },
        {
            "urban_body_code": 250214,
            "id": 15169,
            "text": "Jhalda (M) - Ward No.10"
        },
        {
            "urban_body_code": 250214,
            "id": 15170,
            "text": "Jhalda (M) - Ward No.11"
        },
        {
            "urban_body_code": 250214,
            "id": 15171,
            "text": "Jhalda (M) - Ward No.12"
        },
        {
            "urban_body_code": 250215,
            "id": 68261,
            "text": "Puruliya (M) - Ward No.1"
        },
        {
            "urban_body_code": 250215,
            "id": 68262,
            "text": "Puruliya (M) - Ward No.2"
        },
        {
            "urban_body_code": 250215,
            "id": 68263,
            "text": "Puruliya (M) - Ward No.3"
        },
        {
            "urban_body_code": 250215,
            "id": 68264,
            "text": "Puruliya (M) - Ward No.4"
        },
        {
            "urban_body_code": 250215,
            "id": 68265,
            "text": "Puruliya (M) - Ward No.5"
        },
        {
            "urban_body_code": 250215,
            "id": 68266,
            "text": "Puruliya (M) - Ward No.6"
        },
        {
            "urban_body_code": 250215,
            "id": 68267,
            "text": "Puruliya (M) - Ward No.7"
        },
        {
            "urban_body_code": 250215,
            "id": 68268,
            "text": "Puruliya (M) - Ward No.8"
        },
        {
            "urban_body_code": 250215,
            "id": 68269,
            "text": "Puruliya (M) - Ward No.9"
        },
        {
            "urban_body_code": 250215,
            "id": 68270,
            "text": "Puruliya (M) - Ward No.10"
        },
        {
            "urban_body_code": 250215,
            "id": 68271,
            "text": "Puruliya (M) - Ward No.11"
        },
        {
            "urban_body_code": 250215,
            "id": 68272,
            "text": "Puruliya (M) - Ward No.12"
        },
        {
            "urban_body_code": 250215,
            "id": 68273,
            "text": "Puruliya (M) - Ward No.13"
        },
        {
            "urban_body_code": 250215,
            "id": 68274,
            "text": "Puruliya (M) - Ward No.14"
        },
        {
            "urban_body_code": 250215,
            "id": 68275,
            "text": "Puruliya (M) - Ward No.15"
        },
        {
            "urban_body_code": 250215,
            "id": 68276,
            "text": "Puruliya (M) - Ward No.16"
        },
        {
            "urban_body_code": 250215,
            "id": 68277,
            "text": "Puruliya (M) - Ward No.17"
        },
        {
            "urban_body_code": 250215,
            "id": 68278,
            "text": "Puruliya (M) - Ward No.18"
        },
        {
            "urban_body_code": 250215,
            "id": 68279,
            "text": "Puruliya (M) - Ward No.19"
        },
        {
            "urban_body_code": 250215,
            "id": 68280,
            "text": "Puruliya (M) - Ward No.20"
        },
        {
            "urban_body_code": 250215,
            "id": 68281,
            "text": "Puruliya (M) - Ward No.21"
        },
        {
            "urban_body_code": 250215,
            "id": 68282,
            "text": "Puruliya (M) - Ward No.22"
        },
        {
            "urban_body_code": 250215,
            "id": 9999369,
            "text": "Puruliya (M) - Ward No.23"
        },
        {
            "urban_body_code": 250215,
            "id": 9999403,
            "text": "Puruliya (M) - Ward No.23"
        },
        {
            "urban_body_code": 250225,
            "id": 68287,
            "text": "Ramjibanpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250225,
            "id": 68288,
            "text": "Ramjibanpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250225,
            "id": 68289,
            "text": "Ramjibanpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250225,
            "id": 68290,
            "text": "Ramjibanpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250225,
            "id": 68291,
            "text": "Ramjibanpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250225,
            "id": 68292,
            "text": "Ramjibanpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250225,
            "id": 68293,
            "text": "Ramjibanpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250225,
            "id": 68294,
            "text": "Ramjibanpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250225,
            "id": 68295,
            "text": "Ramjibanpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250225,
            "id": 68296,
            "text": "Ramjibanpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250225,
            "id": 68297,
            "text": "Ramjibanpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250226,
            "id": 15177,
            "text": "Chandrakona (M) - Ward No.1"
        },
        {
            "urban_body_code": 250226,
            "id": 15178,
            "text": "Chandrakona (M) - Ward No.2"
        },
        {
            "urban_body_code": 250226,
            "id": 15179,
            "text": "Chandrakona (M) - Ward No.3"
        },
        {
            "urban_body_code": 250226,
            "id": 15180,
            "text": "Chandrakona (M) - Ward No.4"
        },
        {
            "urban_body_code": 250226,
            "id": 15181,
            "text": "Chandrakona (M) - Ward No.5"
        },
        {
            "urban_body_code": 250226,
            "id": 15182,
            "text": "Chandrakona (M) - Ward No.6"
        },
        {
            "urban_body_code": 250226,
            "id": 15183,
            "text": "Chandrakona (M) - Ward No.7"
        },
        {
            "urban_body_code": 250226,
            "id": 15184,
            "text": "Chandrakona (M) - Ward No.8"
        },
        {
            "urban_body_code": 250226,
            "id": 15185,
            "text": "Chandrakona (M) - Ward No.9"
        },
        {
            "urban_body_code": 250226,
            "id": 15186,
            "text": "Chandrakona (M) - Ward No.10"
        },
        {
            "urban_body_code": 250226,
            "id": 15187,
            "text": "Chandrakona (M) - Ward No.11"
        },
        {
            "urban_body_code": 250226,
            "id": 15188,
            "text": "Chandrakona (M) - Ward No.12"
        },
        {
            "urban_body_code": 250227,
            "id": 68298,
            "text": "Kshirpai (M) - Ward No.1"
        },
        {
            "urban_body_code": 250227,
            "id": 68299,
            "text": "Kshirpai (M) - Ward No.2"
        },
        {
            "urban_body_code": 250227,
            "id": 68300,
            "text": "Kshirpai (M) - Ward No.3"
        },
        {
            "urban_body_code": 250227,
            "id": 68301,
            "text": "Kshirpai (M) - Ward No.4"
        },
        {
            "urban_body_code": 250227,
            "id": 68302,
            "text": "Kshirpai (M) - Ward No.5"
        },
        {
            "urban_body_code": 250227,
            "id": 68303,
            "text": "Kshirpai (M) - Ward No.6"
        },
        {
            "urban_body_code": 250227,
            "id": 68304,
            "text": "Kshirpai (M) - Ward No.7"
        },
        {
            "urban_body_code": 250227,
            "id": 68305,
            "text": "Kshirpai (M) - Ward No.8"
        },
        {
            "urban_body_code": 250227,
            "id": 68306,
            "text": "Kshirpai (M) - Ward No.9"
        },
        {
            "urban_body_code": 250227,
            "id": 68307,
            "text": "Kshirpai (M) - Ward No.10"
        },
        {
            "urban_body_code": 250228,
            "id": 15189,
            "text": "Kharar (M) - Ward No.1"
        },
        {
            "urban_body_code": 250228,
            "id": 15190,
            "text": "Kharar (M) - Ward No.2"
        },
        {
            "urban_body_code": 250228,
            "id": 15191,
            "text": "Kharar (M) - Ward No.3"
        },
        {
            "urban_body_code": 250228,
            "id": 15192,
            "text": "Kharar (M) - Ward No.4"
        },
        {
            "urban_body_code": 250228,
            "id": 15193,
            "text": "Kharar (M) - Ward No.5"
        },
        {
            "urban_body_code": 250228,
            "id": 15194,
            "text": "Kharar (M) - Ward No.6"
        },
        {
            "urban_body_code": 250228,
            "id": 15195,
            "text": "Kharar (M) - Ward No.7"
        },
        {
            "urban_body_code": 250228,
            "id": 15196,
            "text": "Kharar (M) - Ward No.8"
        },
        {
            "urban_body_code": 250228,
            "id": 15197,
            "text": "Kharar (M) - Ward No.9"
        },
        {
            "urban_body_code": 250228,
            "id": 15198,
            "text": "Kharar (M) - Ward No.10"
        },
        {
            "urban_body_code": 250229,
            "id": 15199,
            "text": "Ghatal (M) - Ward No.1"
        },
        {
            "urban_body_code": 250229,
            "id": 15200,
            "text": "Ghatal (M) - Ward No.2"
        },
        {
            "urban_body_code": 250229,
            "id": 15201,
            "text": "Ghatal (M) - Ward No.3"
        },
        {
            "urban_body_code": 250229,
            "id": 15202,
            "text": "Ghatal (M) - Ward No.4"
        },
        {
            "urban_body_code": 250229,
            "id": 15203,
            "text": "Ghatal (M) - Ward No.5"
        },
        {
            "urban_body_code": 250229,
            "id": 15204,
            "text": "Ghatal (M) - Ward No.6"
        },
        {
            "urban_body_code": 250229,
            "id": 15205,
            "text": "Ghatal (M) - Ward No.7"
        },
        {
            "urban_body_code": 250229,
            "id": 15206,
            "text": "Ghatal (M) - Ward No.8"
        },
        {
            "urban_body_code": 250229,
            "id": 15207,
            "text": "Ghatal (M) - Ward No.9"
        },
        {
            "urban_body_code": 250229,
            "id": 15208,
            "text": "Ghatal (M) - Ward No.10"
        },
        {
            "urban_body_code": 250229,
            "id": 15209,
            "text": "Ghatal (M) - Ward No.11"
        },
        {
            "urban_body_code": 250229,
            "id": 15210,
            "text": "Ghatal (M) - Ward No.12"
        },
        {
            "urban_body_code": 250229,
            "id": 15211,
            "text": "Ghatal (M) - Ward No.13"
        },
        {
            "urban_body_code": 250229,
            "id": 15212,
            "text": "Ghatal (M) - Ward No.14"
        },
        {
            "urban_body_code": 250229,
            "id": 15213,
            "text": "Ghatal (M) - Ward No.15"
        },
        {
            "urban_body_code": 250229,
            "id": 15214,
            "text": "Ghatal (M) - Ward No.16"
        },
        {
            "urban_body_code": 250229,
            "id": 15215,
            "text": "Ghatal (M) - Ward No.17"
        },
        {
            "urban_body_code": 250230,
            "id": 15216,
            "text": "Medinipur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250230,
            "id": 15217,
            "text": "Medinipur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250230,
            "id": 15218,
            "text": "Medinipur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250230,
            "id": 15219,
            "text": "Medinipur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250230,
            "id": 15220,
            "text": "Medinipur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250230,
            "id": 15221,
            "text": "Medinipur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250230,
            "id": 15222,
            "text": "Medinipur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250230,
            "id": 15223,
            "text": "Medinipur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250230,
            "id": 15224,
            "text": "Medinipur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250230,
            "id": 15225,
            "text": "Medinipur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250230,
            "id": 15226,
            "text": "Medinipur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250230,
            "id": 15227,
            "text": "Medinipur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250230,
            "id": 15228,
            "text": "Medinipur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250230,
            "id": 15229,
            "text": "Medinipur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250230,
            "id": 15230,
            "text": "Medinipur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250230,
            "id": 15231,
            "text": "Medinipur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250230,
            "id": 15232,
            "text": "Medinipur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250230,
            "id": 15233,
            "text": "Medinipur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250230,
            "id": 15234,
            "text": "Medinipur (M) - Ward No.19"
        },
        {
            "urban_body_code": 250230,
            "id": 15235,
            "text": "Medinipur (M) - Ward No.20"
        },
        {
            "urban_body_code": 250230,
            "id": 15236,
            "text": "Medinipur (M) - Ward No.21"
        },
        {
            "urban_body_code": 250230,
            "id": 15237,
            "text": "Medinipur (M) - Ward No.22"
        },
        {
            "urban_body_code": 250230,
            "id": 15238,
            "text": "Medinipur (M) - Ward No.23"
        },
        {
            "urban_body_code": 250230,
            "id": 15239,
            "text": "Medinipur (M) - Ward No.24"
        },
        {
            "urban_body_code": 250230,
            "id": 9999354,
            "text": "Medinipur (M) - Ward No.25"
        },
        {
            "urban_body_code": 250231,
            "id": 15240,
            "text": "Jhargram (M) - Ward No.1"
        },
        {
            "urban_body_code": 250231,
            "id": 15241,
            "text": "Jhargram (M) - Ward No.2"
        },
        {
            "urban_body_code": 250231,
            "id": 15242,
            "text": "Jhargram (M) - Ward No.3"
        },
        {
            "urban_body_code": 250231,
            "id": 15243,
            "text": "Jhargram (M) - Ward No.4"
        },
        {
            "urban_body_code": 250231,
            "id": 15244,
            "text": "Jhargram (M) - Ward No.5"
        },
        {
            "urban_body_code": 250231,
            "id": 15245,
            "text": "Jhargram (M) - Ward No.6"
        },
        {
            "urban_body_code": 250231,
            "id": 15246,
            "text": "Jhargram (M) - Ward No.7"
        },
        {
            "urban_body_code": 250231,
            "id": 15247,
            "text": "Jhargram (M) - Ward No.8"
        },
        {
            "urban_body_code": 250231,
            "id": 15248,
            "text": "Jhargram (M) - Ward No.9"
        },
        {
            "urban_body_code": 250231,
            "id": 15249,
            "text": "Jhargram (M) - Ward No.10"
        },
        {
            "urban_body_code": 250231,
            "id": 15250,
            "text": "Jhargram (M) - Ward No.11"
        },
        {
            "urban_body_code": 250231,
            "id": 15251,
            "text": "Jhargram (M) - Ward No.12"
        },
        {
            "urban_body_code": 250231,
            "id": 15252,
            "text": "Jhargram (M) - Ward No.13"
        },
        {
            "urban_body_code": 250231,
            "id": 15253,
            "text": "Jhargram (M) - Ward No.14"
        },
        {
            "urban_body_code": 250231,
            "id": 15254,
            "text": "Jhargram (M) - Ward No.15"
        },
        {
            "urban_body_code": 250231,
            "id": 15255,
            "text": "Jhargram (M) - Ward No.16"
        },
        {
            "urban_body_code": 250231,
            "id": 15256,
            "text": "Jhargram (M) - Ward No.17"
        },
        {
            "urban_body_code": 250231,
            "id": 9999335,
            "text": "Jhargram (M) - Ward No.18"
        },
        {
            "urban_body_code": 250232,
            "id": 15257,
            "text": "Kharagpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250232,
            "id": 15258,
            "text": "Kharagpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250232,
            "id": 15259,
            "text": "Kharagpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250232,
            "id": 15260,
            "text": "Kharagpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250232,
            "id": 15261,
            "text": "Kharagpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250232,
            "id": 15262,
            "text": "Kharagpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250232,
            "id": 15263,
            "text": "Kharagpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250232,
            "id": 15264,
            "text": "Kharagpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250232,
            "id": 15265,
            "text": "Kharagpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250232,
            "id": 15266,
            "text": "Kharagpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250232,
            "id": 15267,
            "text": "Kharagpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250232,
            "id": 15268,
            "text": "Kharagpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250232,
            "id": 15269,
            "text": "Kharagpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250232,
            "id": 15270,
            "text": "Kharagpur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250232,
            "id": 15271,
            "text": "Kharagpur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250232,
            "id": 15272,
            "text": "Kharagpur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250232,
            "id": 15273,
            "text": "Kharagpur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250232,
            "id": 15274,
            "text": "Kharagpur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250232,
            "id": 15275,
            "text": "Kharagpur (M) - Ward No.19"
        },
        {
            "urban_body_code": 250232,
            "id": 15276,
            "text": "Kharagpur (M) - Ward No.20"
        },
        {
            "urban_body_code": 250232,
            "id": 15277,
            "text": "Kharagpur (M) - Ward No.21"
        },
        {
            "urban_body_code": 250232,
            "id": 15278,
            "text": "Kharagpur (M) - Ward No.22"
        },
        {
            "urban_body_code": 250232,
            "id": 15279,
            "text": "Kharagpur (M) - Ward No.23"
        },
        {
            "urban_body_code": 250232,
            "id": 15280,
            "text": "Kharagpur (M) - Ward No.24"
        },
        {
            "urban_body_code": 250232,
            "id": 15281,
            "text": "Kharagpur (M) - Ward No.25"
        },
        {
            "urban_body_code": 250232,
            "id": 15282,
            "text": "Kharagpur (M) - Ward No.26"
        },
        {
            "urban_body_code": 250232,
            "id": 15283,
            "text": "Kharagpur (M) - Ward No.27"
        },
        {
            "urban_body_code": 250232,
            "id": 15284,
            "text": "Kharagpur (M) - Ward No.28"
        },
        {
            "urban_body_code": 250232,
            "id": 15285,
            "text": "Kharagpur (M) - Ward No.29"
        },
        {
            "urban_body_code": 250232,
            "id": 15286,
            "text": "Kharagpur (M) - Ward No.30"
        },
        {
            "urban_body_code": 250232,
            "id": 9999339,
            "text": "Kharagpur (M) - Ward No.31"
        },
        {
            "urban_body_code": 250232,
            "id": 9999340,
            "text": "Kharagpur (M) - Ward No.32"
        },
        {
            "urban_body_code": 250232,
            "id": 9999341,
            "text": "Kharagpur (M) - Ward No.33"
        },
        {
            "urban_body_code": 250232,
            "id": 9999342,
            "text": "Kharagpur (M) - Ward No.34"
        },
        {
            "urban_body_code": 250232,
            "id": 9999343,
            "text": "Kharagpur (M) - Ward No.35"
        },
        {
            "urban_body_code": 250233,
            "id": 15287,
            "text": "Tamluk (M) - Ward No.1"
        },
        {
            "urban_body_code": 250233,
            "id": 15288,
            "text": "Tamluk (M) - Ward No.2"
        },
        {
            "urban_body_code": 250233,
            "id": 15289,
            "text": "Tamluk (M) - Ward No.3"
        },
        {
            "urban_body_code": 250233,
            "id": 15290,
            "text": "Tamluk (M) - Ward No.4"
        },
        {
            "urban_body_code": 250233,
            "id": 15291,
            "text": "Tamluk (M) - Ward No.5"
        },
        {
            "urban_body_code": 250233,
            "id": 15292,
            "text": "Tamluk (M) - Ward No.6"
        },
        {
            "urban_body_code": 250233,
            "id": 15293,
            "text": "Tamluk (M) - Ward No.7"
        },
        {
            "urban_body_code": 250233,
            "id": 15294,
            "text": "Tamluk (M) - Ward No.8"
        },
        {
            "urban_body_code": 250233,
            "id": 15295,
            "text": "Tamluk (M) - Ward No.9"
        },
        {
            "urban_body_code": 250233,
            "id": 15296,
            "text": "Tamluk (M) - Ward No.10"
        },
        {
            "urban_body_code": 250233,
            "id": 15297,
            "text": "Tamluk (M) - Ward No.11"
        },
        {
            "urban_body_code": 250233,
            "id": 15298,
            "text": "Tamluk (M) - Ward No.12"
        },
        {
            "urban_body_code": 250233,
            "id": 15299,
            "text": "Tamluk (M) - Ward No.13"
        },
        {
            "urban_body_code": 250233,
            "id": 15300,
            "text": "Tamluk (M) - Ward No.14"
        },
        {
            "urban_body_code": 250233,
            "id": 15301,
            "text": "Tamluk (M) - Ward No.15"
        },
        {
            "urban_body_code": 250233,
            "id": 15302,
            "text": "Tamluk (M) - Ward No.16"
        },
        {
            "urban_body_code": 250233,
            "id": 15303,
            "text": "Tamluk (M) - Ward No.17"
        },
        {
            "urban_body_code": 250233,
            "id": 15304,
            "text": "Tamluk (M) - Ward No.18"
        },
        {
            "urban_body_code": 250233,
            "id": 15305,
            "text": "Tamluk (M) - Ward No.19"
        },
        {
            "urban_body_code": 250233,
            "id": 9999414,
            "text": "Tamluk (M) - Ward No.20"
        },
        {
            "urban_body_code": 250233,
            "id": 9999413,
            "text": "Tamluk (M) - Ward No.20"
        },
        {
            "urban_body_code": 250234,
            "id": 15306,
            "text": "Haldia (M) - Ward No.1"
        },
        {
            "urban_body_code": 250234,
            "id": 15307,
            "text": "Haldia (M) - Ward No.2"
        },
        {
            "urban_body_code": 250234,
            "id": 15308,
            "text": "Haldia (M) - Ward No.3"
        },
        {
            "urban_body_code": 250234,
            "id": 15309,
            "text": "Haldia (M) - Ward No.4"
        },
        {
            "urban_body_code": 250234,
            "id": 15310,
            "text": "Haldia (M) - Ward No.5"
        },
        {
            "urban_body_code": 250234,
            "id": 15311,
            "text": "Haldia (M) - Ward No.6"
        },
        {
            "urban_body_code": 250234,
            "id": 15312,
            "text": "Haldia (M) - Ward No.7"
        },
        {
            "urban_body_code": 250234,
            "id": 15313,
            "text": "Haldia (M) - Ward No.8"
        },
        {
            "urban_body_code": 250234,
            "id": 15314,
            "text": "Haldia (M) - Ward No.9"
        },
        {
            "urban_body_code": 250234,
            "id": 15315,
            "text": "Haldia (M) - Ward No.10"
        },
        {
            "urban_body_code": 250234,
            "id": 15316,
            "text": "Haldia (M) - Ward No.11"
        },
        {
            "urban_body_code": 250234,
            "id": 15317,
            "text": "Haldia (M) - Ward No.12"
        },
        {
            "urban_body_code": 250234,
            "id": 15318,
            "text": "Haldia (M) - Ward No.13"
        },
        {
            "urban_body_code": 250234,
            "id": 15319,
            "text": "Haldia (M) - Ward No.14"
        },
        {
            "urban_body_code": 250234,
            "id": 15320,
            "text": "Haldia (M) - Ward No.15"
        },
        {
            "urban_body_code": 250234,
            "id": 15321,
            "text": "Haldia (M) - Ward No.16"
        },
        {
            "urban_body_code": 250234,
            "id": 15322,
            "text": "Haldia (M) - Ward No.17"
        },
        {
            "urban_body_code": 250234,
            "id": 15323,
            "text": "Haldia (M) - Ward No.18"
        },
        {
            "urban_body_code": 250234,
            "id": 15324,
            "text": "Haldia (M) - Ward No.19"
        },
        {
            "urban_body_code": 250234,
            "id": 15325,
            "text": "Haldia (M) - Ward No.20"
        },
        {
            "urban_body_code": 250234,
            "id": 15326,
            "text": "Haldia (M) - Ward No.21"
        },
        {
            "urban_body_code": 250234,
            "id": 15327,
            "text": "Haldia (M) - Ward No.22"
        },
        {
            "urban_body_code": 250234,
            "id": 15328,
            "text": "Haldia (M) - Ward No.23"
        },
        {
            "urban_body_code": 250234,
            "id": 15329,
            "text": "Haldia (M) - Ward No.24"
        },
        {
            "urban_body_code": 250234,
            "id": 9999293,
            "text": "Haldia (M) - Ward No.25"
        },
        {
            "urban_body_code": 250234,
            "id": 9999294,
            "text": "Haldia (M) - Ward No.26"
        },
        {
            "urban_body_code": 250234,
            "id": 9999295,
            "text": "Haldia (M) - Ward No.27"
        },
        {
            "urban_body_code": 250234,
            "id": 9999296,
            "text": "Haldia (M) - Ward No.28"
        },
        {
            "urban_body_code": 250234,
            "id": 9999297,
            "text": "Haldia (M) - Ward No.29"
        },
        {
            "urban_body_code": 250235,
            "id": 15330,
            "text": "Egra (M) - Ward No.1"
        },
        {
            "urban_body_code": 250235,
            "id": 15331,
            "text": "Egra (M) - Ward No.2"
        },
        {
            "urban_body_code": 250235,
            "id": 15332,
            "text": "Egra (M) - Ward No.3"
        },
        {
            "urban_body_code": 250235,
            "id": 15333,
            "text": "Egra (M) - Ward No.4"
        },
        {
            "urban_body_code": 250235,
            "id": 15334,
            "text": "Egra (M) - Ward No.5"
        },
        {
            "urban_body_code": 250235,
            "id": 15335,
            "text": "Egra (M) - Ward No.6"
        },
        {
            "urban_body_code": 250235,
            "id": 15336,
            "text": "Egra (M) - Ward No.7"
        },
        {
            "urban_body_code": 250235,
            "id": 15337,
            "text": "Egra (M) - Ward No.8"
        },
        {
            "urban_body_code": 250235,
            "id": 15338,
            "text": "Egra (M) - Ward No.9"
        },
        {
            "urban_body_code": 250235,
            "id": 15339,
            "text": "Egra (M) - Ward No.10"
        },
        {
            "urban_body_code": 250235,
            "id": 15340,
            "text": "Egra (M) - Ward No.11"
        },
        {
            "urban_body_code": 250235,
            "id": 15341,
            "text": "Egra (M) - Ward No.12"
        },
        {
            "urban_body_code": 250235,
            "id": 15342,
            "text": "Egra (M) - Ward No.13"
        },
        {
            "urban_body_code": 250235,
            "id": 15343,
            "text": "Egra (M) - Ward No.14"
        },
        {
            "urban_body_code": 250236,
            "id": 68308,
            "text": "Contai (M) - Ward No.1"
        },
        {
            "urban_body_code": 250236,
            "id": 68309,
            "text": "Contai (M) - Ward No.2"
        },
        {
            "urban_body_code": 250236,
            "id": 68310,
            "text": "Contai (M) - Ward No.3"
        },
        {
            "urban_body_code": 250236,
            "id": 68311,
            "text": "Contai (M) - Ward No.4"
        },
        {
            "urban_body_code": 250236,
            "id": 68312,
            "text": "Contai (M) - Ward No.5"
        },
        {
            "urban_body_code": 250236,
            "id": 68313,
            "text": "Contai (M) - Ward No.6"
        },
        {
            "urban_body_code": 250236,
            "id": 68314,
            "text": "Contai (M) - Ward No.7"
        },
        {
            "urban_body_code": 250236,
            "id": 68315,
            "text": "Contai (M) - Ward No.8"
        },
        {
            "urban_body_code": 250236,
            "id": 68316,
            "text": "Contai (M) - Ward No.9"
        },
        {
            "urban_body_code": 250236,
            "id": 68317,
            "text": "Contai (M) - Ward No.10"
        },
        {
            "urban_body_code": 250236,
            "id": 68318,
            "text": "Contai (M) - Ward No.11"
        },
        {
            "urban_body_code": 250236,
            "id": 68319,
            "text": "Contai (M) - Ward No.12"
        },
        {
            "urban_body_code": 250236,
            "id": 68320,
            "text": "Contai (M) - Ward No.13"
        },
        {
            "urban_body_code": 250236,
            "id": 68321,
            "text": "Contai (M) - Ward No.14"
        },
        {
            "urban_body_code": 250236,
            "id": 68322,
            "text": "Contai (M) - Ward No.15"
        },
        {
            "urban_body_code": 250236,
            "id": 68323,
            "text": "Contai (M) - Ward No.16"
        },
        {
            "urban_body_code": 250236,
            "id": 68324,
            "text": "Contai (M) - Ward No.17"
        },
        {
            "urban_body_code": 250236,
            "id": 68325,
            "text": "Contai (M) - Ward No.18"
        },
        {
            "urban_body_code": 250236,
            "id": 9999210,
            "text": "Contai (M) - Ward No.19"
        },
        {
            "urban_body_code": 250236,
            "id": 9999211,
            "text": "Contai (M) - Ward No.20"
        },
        {
            "urban_body_code": 250236,
            "id": 9999212,
            "text": "Contai (M) - Ward No.21"
        },
        {
            "urban_body_code": 250246,
            "id": 15352,
            "text": "Bally (M) - Ward No.1"
        },
        {
            "urban_body_code": 250246,
            "id": 15354,
            "text": "Bally (M) - Ward No.2"
        },
        {
            "urban_body_code": 250246,
            "id": 15356,
            "text": "Bally (M) - Ward No.3"
        },
        {
            "urban_body_code": 250246,
            "id": 15358,
            "text": "Bally (M) - Ward No.4"
        },
        {
            "urban_body_code": 250246,
            "id": 15346,
            "text": "Bally (M) - Ward No.5"
        },
        {
            "urban_body_code": 250246,
            "id": 15348,
            "text": "Bally (M) - Ward No.6"
        },
        {
            "urban_body_code": 250246,
            "id": 15350,
            "text": "Bally (M) - Ward No.7"
        },
        {
            "urban_body_code": 250246,
            "id": 15360,
            "text": "Bally (M) - Ward No.8"
        },
        {
            "urban_body_code": 250246,
            "id": 15362,
            "text": "Bally (M) - Ward No.9"
        },
        {
            "urban_body_code": 250246,
            "id": 15364,
            "text": "Bally (M) - Ward No.10"
        },
        {
            "urban_body_code": 250246,
            "id": 17096,
            "text": "Bally (M) - Ward No.11"
        },
        {
            "urban_body_code": 250246,
            "id": 17098,
            "text": "Bally (M) - Ward No.12"
        },
        {
            "urban_body_code": 250246,
            "id": 17100,
            "text": "Bally (M) - Ward No.13"
        },
        {
            "urban_body_code": 250246,
            "id": 17102,
            "text": "Bally (M) - Ward No.14"
        },
        {
            "urban_body_code": 250246,
            "id": 17104,
            "text": "Bally (M) - Ward No.15"
        },
        {
            "urban_body_code": 250246,
            "id": 17106,
            "text": "Bally (M) - Ward No.16"
        },
        {
            "urban_body_code": 250246,
            "id": 17108,
            "text": "Bally (M) - Ward No.17"
        },
        {
            "urban_body_code": 250246,
            "id": 17110,
            "text": "Bally (M) - Ward No.18"
        },
        {
            "urban_body_code": 250246,
            "id": 17112,
            "text": "Bally (M) - Ward No.19"
        },
        {
            "urban_body_code": 250246,
            "id": 17114,
            "text": "Bally (M) - Ward No.20"
        },
        {
            "urban_body_code": 250246,
            "id": 17116,
            "text": "Bally (M) - Ward No.21"
        },
        {
            "urban_body_code": 250246,
            "id": 17118,
            "text": "Bally (M) - Ward No.22"
        },
        {
            "urban_body_code": 250246,
            "id": 17120,
            "text": "Bally (M) - Ward No.23"
        },
        {
            "urban_body_code": 250246,
            "id": 17122,
            "text": "Bally (M) - Ward No.24"
        },
        {
            "urban_body_code": 250246,
            "id": 17124,
            "text": "Bally (M) - Ward No.25"
        },
        {
            "urban_body_code": 250246,
            "id": 17126,
            "text": "Bally (M) - Ward No.26"
        },
        {
            "urban_body_code": 250246,
            "id": 17128,
            "text": "Bally (M) - Ward No.27"
        },
        {
            "urban_body_code": 250246,
            "id": 17130,
            "text": "Bally (M) - Ward No.28"
        },
        {
            "urban_body_code": 250246,
            "id": 17132,
            "text": "Bally (M) - Ward No.29"
        },
        {
            "urban_body_code": 250247,
            "id": 17134,
            "text": "Haora (M Corp) - Ward No.1"
        },
        {
            "urban_body_code": 250247,
            "id": 17135,
            "text": "Haora (M Corp) - Ward No.2"
        },
        {
            "urban_body_code": 250247,
            "id": 17136,
            "text": "Haora (M Corp) - Ward No.3"
        },
        {
            "urban_body_code": 250247,
            "id": 17137,
            "text": "Haora (M Corp) - Ward No.4"
        },
        {
            "urban_body_code": 250247,
            "id": 17138,
            "text": "Haora (M Corp) - Ward No.5"
        },
        {
            "urban_body_code": 250247,
            "id": 17139,
            "text": "Haora (M Corp) - Ward No.6"
        },
        {
            "urban_body_code": 250247,
            "id": 17140,
            "text": "Haora (M Corp) - Ward No.7"
        },
        {
            "urban_body_code": 250247,
            "id": 17141,
            "text": "Haora (M Corp) - Ward No.8"
        },
        {
            "urban_body_code": 250247,
            "id": 17142,
            "text": "Haora (M Corp) - Ward No.9"
        },
        {
            "urban_body_code": 250247,
            "id": 17143,
            "text": "Haora (M Corp) - Ward No.10"
        },
        {
            "urban_body_code": 250247,
            "id": 17144,
            "text": "Haora (M Corp) - Ward No.11"
        },
        {
            "urban_body_code": 250247,
            "id": 17145,
            "text": "Haora (M Corp) - Ward No.12"
        },
        {
            "urban_body_code": 250247,
            "id": 17146,
            "text": "Haora (M Corp) - Ward No.13"
        },
        {
            "urban_body_code": 250247,
            "id": 17147,
            "text": "Haora (M Corp) - Ward No.14"
        },
        {
            "urban_body_code": 250247,
            "id": 17148,
            "text": "Haora (M Corp) - Ward No.15"
        },
        {
            "urban_body_code": 250247,
            "id": 17149,
            "text": "Haora (M Corp) - Ward No.16"
        },
        {
            "urban_body_code": 250247,
            "id": 17150,
            "text": "Haora (M Corp) - Ward No.17"
        },
        {
            "urban_body_code": 250247,
            "id": 17151,
            "text": "Haora (M Corp) - Ward No.18"
        },
        {
            "urban_body_code": 250247,
            "id": 17152,
            "text": "Haora (M Corp) - Ward No.19"
        },
        {
            "urban_body_code": 250247,
            "id": 17153,
            "text": "Haora (M Corp) - Ward No.20"
        },
        {
            "urban_body_code": 250247,
            "id": 17154,
            "text": "Haora (M Corp) - Ward No.21"
        },
        {
            "urban_body_code": 250247,
            "id": 17155,
            "text": "Haora (M Corp) - Ward No.22"
        },
        {
            "urban_body_code": 250247,
            "id": 17156,
            "text": "Haora (M Corp) - Ward No.23"
        },
        {
            "urban_body_code": 250247,
            "id": 17157,
            "text": "Haora (M Corp) - Ward No.24"
        },
        {
            "urban_body_code": 250247,
            "id": 17158,
            "text": "Haora (M Corp) - Ward No.25"
        },
        {
            "urban_body_code": 250247,
            "id": 17159,
            "text": "Haora (M Corp) - Ward No.26"
        },
        {
            "urban_body_code": 250247,
            "id": 17160,
            "text": "Haora (M Corp) - Ward No.27"
        },
        {
            "urban_body_code": 250247,
            "id": 17161,
            "text": "Haora (M Corp) - Ward No.28"
        },
        {
            "urban_body_code": 250247,
            "id": 17162,
            "text": "Haora (M Corp) - Ward No.29"
        },
        {
            "urban_body_code": 250247,
            "id": 17163,
            "text": "Haora (M Corp) - Ward No.30"
        },
        {
            "urban_body_code": 250247,
            "id": 17164,
            "text": "Haora (M Corp) - Ward No.31"
        },
        {
            "urban_body_code": 250247,
            "id": 17165,
            "text": "Haora (M Corp) - Ward No.32"
        },
        {
            "urban_body_code": 250247,
            "id": 17166,
            "text": "Haora (M Corp) - Ward No.33"
        },
        {
            "urban_body_code": 250247,
            "id": 17167,
            "text": "Haora (M Corp) - Ward No.34"
        },
        {
            "urban_body_code": 250247,
            "id": 17168,
            "text": "Haora (M Corp) - Ward No.35"
        },
        {
            "urban_body_code": 250247,
            "id": 17169,
            "text": "Haora (M Corp) - Ward No.36"
        },
        {
            "urban_body_code": 250247,
            "id": 17170,
            "text": "Haora (M Corp) - Ward No.37"
        },
        {
            "urban_body_code": 250247,
            "id": 17171,
            "text": "Haora (M Corp) - Ward No.38"
        },
        {
            "urban_body_code": 250247,
            "id": 17172,
            "text": "Haora (M Corp) - Ward No.39"
        },
        {
            "urban_body_code": 250247,
            "id": 17173,
            "text": "Haora (M Corp) - Ward No.40"
        },
        {
            "urban_body_code": 250247,
            "id": 17174,
            "text": "Haora (M Corp) - Ward No.41"
        },
        {
            "urban_body_code": 250247,
            "id": 17175,
            "text": "Haora (M Corp) - Ward No.42"
        },
        {
            "urban_body_code": 250247,
            "id": 17176,
            "text": "Haora (M Corp) - Ward No.43"
        },
        {
            "urban_body_code": 250247,
            "id": 17177,
            "text": "Haora (M Corp) - Ward No.44"
        },
        {
            "urban_body_code": 250247,
            "id": 17178,
            "text": "Haora (M Corp) - Ward No.45"
        },
        {
            "urban_body_code": 250247,
            "id": 17179,
            "text": "Haora (M Corp) - Ward No.46"
        },
        {
            "urban_body_code": 250247,
            "id": 17180,
            "text": "Haora (M Corp) - Ward No.47"
        },
        {
            "urban_body_code": 250247,
            "id": 17181,
            "text": "Haora (M Corp) - Ward No.48"
        },
        {
            "urban_body_code": 250247,
            "id": 17182,
            "text": "Haora (M Corp) - Ward No.49"
        },
        {
            "urban_body_code": 250247,
            "id": 17183,
            "text": "Haora (M Corp) - Ward No.50"
        },
        {
            "urban_body_code": 250247,
            "id": 9999298,
            "text": "Haora (M Corp) - Ward No.51"
        },
        {
            "urban_body_code": 250247,
            "id": 9999299,
            "text": "Haora (M Corp) - Ward No.52"
        },
        {
            "urban_body_code": 250247,
            "id": 9999300,
            "text": "Haora (M Corp) - Ward No.53"
        },
        {
            "urban_body_code": 250247,
            "id": 9999301,
            "text": "Haora (M Corp) - Ward No.54"
        },
        {
            "urban_body_code": 250247,
            "id": 9999302,
            "text": "Haora (M Corp) - Ward No.55"
        },
        {
            "urban_body_code": 250247,
            "id": 9999303,
            "text": "Haora (M Corp) - Ward No.56"
        },
        {
            "urban_body_code": 250247,
            "id": 9999304,
            "text": "Haora (M Corp) - Ward No.57"
        },
        {
            "urban_body_code": 250247,
            "id": 9999305,
            "text": "Haora (M Corp) - Ward No.58"
        },
        {
            "urban_body_code": 250247,
            "id": 9999306,
            "text": "Haora (M Corp) - Ward No.59"
        },
        {
            "urban_body_code": 250247,
            "id": 9999307,
            "text": "Haora (M Corp) - Ward No.60"
        },
        {
            "urban_body_code": 250247,
            "id": 9999308,
            "text": "Haora (M Corp) - Ward No.61"
        },
        {
            "urban_body_code": 250247,
            "id": 9999309,
            "text": "Haora (M Corp) - Ward No.62"
        },
        {
            "urban_body_code": 250247,
            "id": 9999310,
            "text": "Haora (M Corp) - Ward No.63"
        },
        {
            "urban_body_code": 250247,
            "id": 9999311,
            "text": "Haora (M Corp) - Ward No.64"
        },
        {
            "urban_body_code": 250247,
            "id": 9999312,
            "text": "Haora (M Corp) - Ward No.65"
        },
        {
            "urban_body_code": 250247,
            "id": 9999313,
            "text": "Haora (M Corp) - Ward No.66"
        },
        {
            "urban_body_code": 250248,
            "id": 68332,
            "text": "Uluberia (M) - Ward No.1"
        },
        {
            "urban_body_code": 250248,
            "id": 68333,
            "text": "Uluberia (M) - Ward No.2"
        },
        {
            "urban_body_code": 250248,
            "id": 68334,
            "text": "Uluberia (M) - Ward No.3"
        },
        {
            "urban_body_code": 250248,
            "id": 68335,
            "text": "Uluberia (M) - Ward No.4"
        },
        {
            "urban_body_code": 250248,
            "id": 68336,
            "text": "Uluberia (M) - Ward No.5"
        },
        {
            "urban_body_code": 250248,
            "id": 68337,
            "text": "Uluberia (M) - Ward No.6"
        },
        {
            "urban_body_code": 250248,
            "id": 68338,
            "text": "Uluberia (M) - Ward No.7"
        },
        {
            "urban_body_code": 250248,
            "id": 68339,
            "text": "Uluberia (M) - Ward No.8"
        },
        {
            "urban_body_code": 250248,
            "id": 68340,
            "text": "Uluberia (M) - Ward No.9"
        },
        {
            "urban_body_code": 250248,
            "id": 68341,
            "text": "Uluberia (M) - Ward No.10"
        },
        {
            "urban_body_code": 250248,
            "id": 68342,
            "text": "Uluberia (M) - Ward No.11"
        },
        {
            "urban_body_code": 250248,
            "id": 68343,
            "text": "Uluberia (M) - Ward No.12"
        },
        {
            "urban_body_code": 250248,
            "id": 68344,
            "text": "Uluberia (M) - Ward No.13"
        },
        {
            "urban_body_code": 250248,
            "id": 69251,
            "text": "Uluberia (M) - Ward No.14"
        },
        {
            "urban_body_code": 250248,
            "id": 69252,
            "text": "Uluberia (M) - Ward No.15"
        },
        {
            "urban_body_code": 250248,
            "id": 69253,
            "text": "Uluberia (M) - Ward No.16"
        },
        {
            "urban_body_code": 250248,
            "id": 69254,
            "text": "Uluberia (M) - Ward No.17"
        },
        {
            "urban_body_code": 250248,
            "id": 69255,
            "text": "Uluberia (M) - Ward No.18"
        },
        {
            "urban_body_code": 250248,
            "id": 69256,
            "text": "Uluberia (M) - Ward No.19"
        },
        {
            "urban_body_code": 250248,
            "id": 69257,
            "text": "Uluberia (M) - Ward No.20"
        },
        {
            "urban_body_code": 250248,
            "id": 69258,
            "text": "Uluberia (M) - Ward No.21"
        },
        {
            "urban_body_code": 250248,
            "id": 69259,
            "text": "Uluberia (M) - Ward No.22"
        },
        {
            "urban_body_code": 250248,
            "id": 69260,
            "text": "Uluberia (M) - Ward No.23"
        },
        {
            "urban_body_code": 250248,
            "id": 69261,
            "text": "Uluberia (M) - Ward No.24"
        },
        {
            "urban_body_code": 250248,
            "id": 69262,
            "text": "Uluberia (M) - Ward No.25"
        },
        {
            "urban_body_code": 250248,
            "id": 69263,
            "text": "Uluberia (M) - Ward No.26"
        },
        {
            "urban_body_code": 250248,
            "id": 69264,
            "text": "Uluberia (M) - Ward No.27"
        },
        {
            "urban_body_code": 250248,
            "id": 69265,
            "text": "Uluberia (M) - Ward No.28"
        },
        {
            "urban_body_code": 250248,
            "id": 69275,
            "text": "Khalisani (OG) - Ward No.29"
        },
        {
            "urban_body_code": 250248,
            "id": 69271,
            "text": "Chak Srikrishna (OG) - Ward No.30"
        },
        {
            "urban_body_code": 250248,
            "id": 9999415,
            "text": "Uluberia (M) - Ward No.31"
        },
        {
            "urban_body_code": 250248,
            "id": 9999416,
            "text": "Uluberia (M) - Ward No.32"
        },
        {
            "urban_body_code": 250299,
            "id": 17223,
            "text": "Kolkata (M Corp.) - Ward No.1"
        },
        {
            "urban_body_code": 250299,
            "id": 17224,
            "text": "Kolkata (M Corp.) - Ward No.2"
        },
        {
            "urban_body_code": 250299,
            "id": 17225,
            "text": "Kolkata (M Corp.) - Ward No.3"
        },
        {
            "urban_body_code": 250299,
            "id": 17226,
            "text": "Kolkata (M Corp.) - Ward No.4"
        },
        {
            "urban_body_code": 250299,
            "id": 17227,
            "text": "Kolkata (M Corp.) - Ward No.5"
        },
        {
            "urban_body_code": 250299,
            "id": 17228,
            "text": "Kolkata (M Corp.) - Ward No.6"
        },
        {
            "urban_body_code": 250299,
            "id": 17229,
            "text": "Kolkata (M Corp.) - Ward No.7"
        },
        {
            "urban_body_code": 250299,
            "id": 17230,
            "text": "Kolkata (M Corp.) - Ward No.8"
        },
        {
            "urban_body_code": 250299,
            "id": 17231,
            "text": "Kolkata (M Corp.) - Ward No.9"
        },
        {
            "urban_body_code": 250299,
            "id": 17232,
            "text": "Kolkata (M Corp.) - Ward No.10"
        },
        {
            "urban_body_code": 250299,
            "id": 17233,
            "text": "Kolkata (M Corp.) - Ward No.11"
        },
        {
            "urban_body_code": 250299,
            "id": 17234,
            "text": "Kolkata (M Corp.) - Ward No.12"
        },
        {
            "urban_body_code": 250299,
            "id": 17235,
            "text": "Kolkata (M Corp.) - Ward No.13"
        },
        {
            "urban_body_code": 250299,
            "id": 17236,
            "text": "Kolkata (M Corp.) - Ward No.14"
        },
        {
            "urban_body_code": 250299,
            "id": 17237,
            "text": "Kolkata (M Corp.) - Ward No.15"
        },
        {
            "urban_body_code": 250299,
            "id": 17238,
            "text": "Kolkata (M Corp.) - Ward No.16"
        },
        {
            "urban_body_code": 250299,
            "id": 17239,
            "text": "Kolkata (M Corp.) - Ward No.17"
        },
        {
            "urban_body_code": 250299,
            "id": 17240,
            "text": "Kolkata (M Corp.) - Ward No.18"
        },
        {
            "urban_body_code": 250299,
            "id": 17241,
            "text": "Kolkata (M Corp.) - Ward No.19"
        },
        {
            "urban_body_code": 250299,
            "id": 17242,
            "text": "Kolkata (M Corp.) - Ward No.20"
        },
        {
            "urban_body_code": 250299,
            "id": 17243,
            "text": "Kolkata (M Corp.) - Ward No.21"
        },
        {
            "urban_body_code": 250299,
            "id": 17244,
            "text": "Kolkata (M Corp.) - Ward No.22"
        },
        {
            "urban_body_code": 250299,
            "id": 17245,
            "text": "Kolkata (M Corp.) - Ward No.23"
        },
        {
            "urban_body_code": 250299,
            "id": 17246,
            "text": "Kolkata (M Corp.) - Ward No.24"
        },
        {
            "urban_body_code": 250299,
            "id": 17247,
            "text": "Kolkata (M Corp.) - Ward No.25"
        },
        {
            "urban_body_code": 250299,
            "id": 17248,
            "text": "Kolkata (M Corp.) - Ward No.26"
        },
        {
            "urban_body_code": 250299,
            "id": 17249,
            "text": "Kolkata (M Corp.) - Ward No.27"
        },
        {
            "urban_body_code": 250299,
            "id": 17250,
            "text": "Kolkata (M Corp.) - Ward No.28"
        },
        {
            "urban_body_code": 250299,
            "id": 17251,
            "text": "Kolkata (M Corp.) - Ward No.29"
        },
        {
            "urban_body_code": 250299,
            "id": 17252,
            "text": "Kolkata (M Corp.) - Ward No.30"
        },
        {
            "urban_body_code": 250299,
            "id": 17253,
            "text": "Kolkata (M Corp.) - Ward No.31"
        },
        {
            "urban_body_code": 250299,
            "id": 17254,
            "text": "Kolkata (M Corp.) - Ward No.32"
        },
        {
            "urban_body_code": 250299,
            "id": 17255,
            "text": "Kolkata (M Corp.) - Ward No.33"
        },
        {
            "urban_body_code": 250299,
            "id": 17256,
            "text": "Kolkata (M Corp.) - Ward No.34"
        },
        {
            "urban_body_code": 250299,
            "id": 17257,
            "text": "Kolkata (M Corp.) - Ward No.35"
        },
        {
            "urban_body_code": 250299,
            "id": 17258,
            "text": "Kolkata (M Corp.) - Ward No.36"
        },
        {
            "urban_body_code": 250299,
            "id": 17259,
            "text": "Kolkata (M Corp.) - Ward No.37"
        },
        {
            "urban_body_code": 250299,
            "id": 17260,
            "text": "Kolkata (M Corp.) - Ward No.38"
        },
        {
            "urban_body_code": 250299,
            "id": 17261,
            "text": "Kolkata (M Corp.) - Ward No.39"
        },
        {
            "urban_body_code": 250299,
            "id": 17262,
            "text": "Kolkata (M Corp.) - Ward No.40"
        },
        {
            "urban_body_code": 250299,
            "id": 17263,
            "text": "Kolkata (M Corp.) - Ward No.41"
        },
        {
            "urban_body_code": 250299,
            "id": 17264,
            "text": "Kolkata (M Corp.) - Ward No.42"
        },
        {
            "urban_body_code": 250299,
            "id": 17265,
            "text": "Kolkata (M Corp.) - Ward No.43"
        },
        {
            "urban_body_code": 250299,
            "id": 17266,
            "text": "Kolkata (M Corp.) - Ward No.44"
        },
        {
            "urban_body_code": 250299,
            "id": 17267,
            "text": "Kolkata (M Corp.) - Ward No.45"
        },
        {
            "urban_body_code": 250299,
            "id": 17268,
            "text": "Kolkata (M Corp.) - Ward No.46"
        },
        {
            "urban_body_code": 250299,
            "id": 17269,
            "text": "Kolkata (M Corp.) - Ward No.47"
        },
        {
            "urban_body_code": 250299,
            "id": 17270,
            "text": "Kolkata (M Corp.) - Ward No.48"
        },
        {
            "urban_body_code": 250299,
            "id": 17271,
            "text": "Kolkata (M Corp.) - Ward No.49"
        },
        {
            "urban_body_code": 250299,
            "id": 17272,
            "text": "Kolkata (M Corp.) - Ward No.50"
        },
        {
            "urban_body_code": 250299,
            "id": 17273,
            "text": "Kolkata (M Corp.) - Ward No.51"
        },
        {
            "urban_body_code": 250299,
            "id": 17274,
            "text": "Kolkata (M Corp.) - Ward No.52"
        },
        {
            "urban_body_code": 250299,
            "id": 17275,
            "text": "Kolkata (M Corp.) - Ward No.53"
        },
        {
            "urban_body_code": 250299,
            "id": 17276,
            "text": "Kolkata (M Corp.) - Ward No.54"
        },
        {
            "urban_body_code": 250299,
            "id": 17277,
            "text": "Kolkata (M Corp.) - Ward No.55"
        },
        {
            "urban_body_code": 250299,
            "id": 17278,
            "text": "Kolkata (M Corp.) - Ward No.56"
        },
        {
            "urban_body_code": 250299,
            "id": 17279,
            "text": "Kolkata (M Corp.) - Ward No.57"
        },
        {
            "urban_body_code": 250299,
            "id": 17280,
            "text": "Kolkata (M Corp.) - Ward No.58"
        },
        {
            "urban_body_code": 250299,
            "id": 17281,
            "text": "Kolkata (M Corp.) - Ward No.59"
        },
        {
            "urban_body_code": 250299,
            "id": 17282,
            "text": "Kolkata (M Corp.) - Ward No.60"
        },
        {
            "urban_body_code": 250299,
            "id": 17283,
            "text": "Kolkata (M Corp.) - Ward No.61"
        },
        {
            "urban_body_code": 250299,
            "id": 17284,
            "text": "Kolkata (M Corp.) - Ward No.62"
        },
        {
            "urban_body_code": 250299,
            "id": 17285,
            "text": "Kolkata (M Corp.) - Ward No.63"
        },
        {
            "urban_body_code": 250299,
            "id": 17286,
            "text": "Kolkata (M Corp.) - Ward No.64"
        },
        {
            "urban_body_code": 250299,
            "id": 17287,
            "text": "Kolkata (M Corp.) - Ward No.65"
        },
        {
            "urban_body_code": 250299,
            "id": 17288,
            "text": "Kolkata (M Corp.) - Ward No.66"
        },
        {
            "urban_body_code": 250299,
            "id": 17289,
            "text": "Kolkata (M Corp.) - Ward No.67"
        },
        {
            "urban_body_code": 250299,
            "id": 17290,
            "text": "Kolkata (M Corp.) - Ward No.68"
        },
        {
            "urban_body_code": 250299,
            "id": 17291,
            "text": "Kolkata (M Corp.) - Ward No.69"
        },
        {
            "urban_body_code": 250299,
            "id": 17292,
            "text": "Kolkata (M Corp.) - Ward No.70"
        },
        {
            "urban_body_code": 250299,
            "id": 17293,
            "text": "Kolkata (M Corp.) - Ward No.71"
        },
        {
            "urban_body_code": 250299,
            "id": 17294,
            "text": "Kolkata (M Corp.) - Ward No.72"
        },
        {
            "urban_body_code": 250299,
            "id": 17295,
            "text": "Kolkata (M Corp.) - Ward No.73"
        },
        {
            "urban_body_code": 250299,
            "id": 17296,
            "text": "Kolkata (M Corp.) - Ward No.74"
        },
        {
            "urban_body_code": 250299,
            "id": 17297,
            "text": "Kolkata (M Corp.) - Ward No.75"
        },
        {
            "urban_body_code": 250299,
            "id": 17298,
            "text": "Kolkata (M Corp.) - Ward No.76"
        },
        {
            "urban_body_code": 250299,
            "id": 17299,
            "text": "Kolkata (M Corp.) - Ward No.77"
        },
        {
            "urban_body_code": 250299,
            "id": 17300,
            "text": "Kolkata (M Corp.) - Ward No.78"
        },
        {
            "urban_body_code": 250299,
            "id": 17301,
            "text": "Kolkata (M Corp.) - Ward No.79"
        },
        {
            "urban_body_code": 250299,
            "id": 17302,
            "text": "Kolkata (M Corp.) - Ward No.80"
        },
        {
            "urban_body_code": 250299,
            "id": 17303,
            "text": "Kolkata (M Corp.) - Ward No.81"
        },
        {
            "urban_body_code": 250299,
            "id": 17304,
            "text": "Kolkata (M Corp.) - Ward No.82"
        },
        {
            "urban_body_code": 250299,
            "id": 17305,
            "text": "Kolkata (M Corp.) - Ward No.83"
        },
        {
            "urban_body_code": 250299,
            "id": 17306,
            "text": "Kolkata (M Corp.) - Ward No.84"
        },
        {
            "urban_body_code": 250299,
            "id": 17307,
            "text": "Kolkata (M Corp.) - Ward No.85"
        },
        {
            "urban_body_code": 250299,
            "id": 17308,
            "text": "Kolkata (M Corp.) - Ward No.86"
        },
        {
            "urban_body_code": 250299,
            "id": 17309,
            "text": "Kolkata (M Corp.) - Ward No.87"
        },
        {
            "urban_body_code": 250299,
            "id": 17310,
            "text": "Kolkata (M Corp.) - Ward No.88"
        },
        {
            "urban_body_code": 250299,
            "id": 17311,
            "text": "Kolkata (M Corp.) - Ward No.89"
        },
        {
            "urban_body_code": 250299,
            "id": 17312,
            "text": "Kolkata (M Corp.) - Ward No.90"
        },
        {
            "urban_body_code": 250299,
            "id": 17313,
            "text": "Kolkata (M Corp.) - Ward No.91"
        },
        {
            "urban_body_code": 250299,
            "id": 17314,
            "text": "Kolkata (M Corp.) - Ward No.92"
        },
        {
            "urban_body_code": 250299,
            "id": 17315,
            "text": "Kolkata (M Corp.) - Ward No.93"
        },
        {
            "urban_body_code": 250299,
            "id": 17316,
            "text": "Kolkata (M Corp.) - Ward No.94"
        },
        {
            "urban_body_code": 250299,
            "id": 17317,
            "text": "Kolkata (M Corp.) - Ward No.95"
        },
        {
            "urban_body_code": 250299,
            "id": 17318,
            "text": "Kolkata (M Corp.) - Ward No.96"
        },
        {
            "urban_body_code": 250299,
            "id": 17319,
            "text": "Kolkata (M Corp.) - Ward No.97"
        },
        {
            "urban_body_code": 250299,
            "id": 17320,
            "text": "Kolkata (M Corp.) - Ward No.98"
        },
        {
            "urban_body_code": 250299,
            "id": 17321,
            "text": "Kolkata (M Corp.) - Ward No.99"
        },
        {
            "urban_body_code": 250299,
            "id": 17322,
            "text": "Kolkata (M Corp.) - Ward No.100"
        },
        {
            "urban_body_code": 250299,
            "id": 17323,
            "text": "Kolkata (M Corp.) - Ward No.101"
        },
        {
            "urban_body_code": 250299,
            "id": 17324,
            "text": "Kolkata (M Corp.) - Ward No.102"
        },
        {
            "urban_body_code": 250299,
            "id": 17325,
            "text": "Kolkata (M Corp.) - Ward No.103"
        },
        {
            "urban_body_code": 250299,
            "id": 17326,
            "text": "Kolkata (M Corp.) - Ward No.104"
        },
        {
            "urban_body_code": 250299,
            "id": 17327,
            "text": "Kolkata (M Corp.) - Ward No.105"
        },
        {
            "urban_body_code": 250299,
            "id": 17328,
            "text": "Kolkata (M Corp.) - Ward No.106"
        },
        {
            "urban_body_code": 250299,
            "id": 17329,
            "text": "Kolkata (M Corp.) - Ward No.107"
        },
        {
            "urban_body_code": 250299,
            "id": 17330,
            "text": "Kolkata (M Corp.) - Ward No.108"
        },
        {
            "urban_body_code": 250299,
            "id": 17331,
            "text": "Kolkata (M Corp.) - Ward No.109"
        },
        {
            "urban_body_code": 250299,
            "id": 17332,
            "text": "Kolkata (M Corp.) - Ward No.110"
        },
        {
            "urban_body_code": 250299,
            "id": 17333,
            "text": "Kolkata (M Corp.) - Ward No.111"
        },
        {
            "urban_body_code": 250299,
            "id": 17334,
            "text": "Kolkata (M Corp.) - Ward No.112"
        },
        {
            "urban_body_code": 250299,
            "id": 17335,
            "text": "Kolkata (M Corp.) - Ward No.113"
        },
        {
            "urban_body_code": 250299,
            "id": 17336,
            "text": "Kolkata (M Corp.) - Ward No.114"
        },
        {
            "urban_body_code": 250299,
            "id": 17337,
            "text": "Kolkata (M Corp.) - Ward No.115"
        },
        {
            "urban_body_code": 250299,
            "id": 17338,
            "text": "Kolkata (M Corp.) - Ward No.116"
        },
        {
            "urban_body_code": 250299,
            "id": 17339,
            "text": "Kolkata (M Corp.) - Ward No.117"
        },
        {
            "urban_body_code": 250299,
            "id": 17340,
            "text": "Kolkata (M Corp.) - Ward No.118"
        },
        {
            "urban_body_code": 250299,
            "id": 17341,
            "text": "Kolkata (M Corp.) - Ward No.119"
        },
        {
            "urban_body_code": 250299,
            "id": 17342,
            "text": "Kolkata (M Corp.) - Ward No.120"
        },
        {
            "urban_body_code": 250299,
            "id": 17343,
            "text": "Kolkata (M Corp.) - Ward No.121"
        },
        {
            "urban_body_code": 250299,
            "id": 17344,
            "text": "Kolkata (M Corp.) - Ward No.122"
        },
        {
            "urban_body_code": 250299,
            "id": 17345,
            "text": "Kolkata (M Corp.) - Ward No.123"
        },
        {
            "urban_body_code": 250299,
            "id": 17346,
            "text": "Kolkata (M Corp.) - Ward No.124"
        },
        {
            "urban_body_code": 250299,
            "id": 17347,
            "text": "Kolkata (M Corp.) - Ward No.125"
        },
        {
            "urban_body_code": 250299,
            "id": 17348,
            "text": "Kolkata (M Corp.) - Ward No.126"
        },
        {
            "urban_body_code": 250299,
            "id": 17349,
            "text": "Kolkata (M Corp.) - Ward No.127"
        },
        {
            "urban_body_code": 250299,
            "id": 17350,
            "text": "Kolkata (M Corp.) - Ward No.128"
        },
        {
            "urban_body_code": 250299,
            "id": 17351,
            "text": "Kolkata (M Corp.) - Ward No.129"
        },
        {
            "urban_body_code": 250299,
            "id": 17352,
            "text": "Kolkata (M Corp.) - Ward No.130"
        },
        {
            "urban_body_code": 250299,
            "id": 17353,
            "text": "Kolkata (M Corp.) - Ward No.131"
        },
        {
            "urban_body_code": 250299,
            "id": 17354,
            "text": "Kolkata (M Corp.) - Ward No.132"
        },
        {
            "urban_body_code": 250299,
            "id": 17355,
            "text": "Kolkata (M Corp.) - Ward No.133"
        },
        {
            "urban_body_code": 250299,
            "id": 17356,
            "text": "Kolkata (M Corp.) - Ward No.134"
        },
        {
            "urban_body_code": 250299,
            "id": 17357,
            "text": "Kolkata (M Corp.) - Ward No.135"
        },
        {
            "urban_body_code": 250299,
            "id": 17358,
            "text": "Kolkata (M Corp.) - Ward No.136"
        },
        {
            "urban_body_code": 250299,
            "id": 17359,
            "text": "Kolkata (M Corp.) - Ward No.137"
        },
        {
            "urban_body_code": 250299,
            "id": 17360,
            "text": "Kolkata (M Corp.) - Ward No.138"
        },
        {
            "urban_body_code": 250299,
            "id": 17361,
            "text": "Kolkata (M Corp.) - Ward No.139"
        },
        {
            "urban_body_code": 250299,
            "id": 17362,
            "text": "Kolkata (M Corp.) - Ward No.140"
        },
        {
            "urban_body_code": 250299,
            "id": 17363,
            "text": "Kolkata (M Corp.) - Ward No.141"
        },
        {
            "urban_body_code": 250299,
            "id": 9999344,
            "text": "Kolkata (M Corp.) - Ward No.142"
        },
        {
            "urban_body_code": 250299,
            "id": 9999345,
            "text": "Kolkata (M Corp.) - Ward No.143"
        },
        {
            "urban_body_code": 250299,
            "id": 9999346,
            "text": "Kolkata (M Corp.) - Ward No.144"
        },
        {
            "urban_body_code": 250300,
            "id": 17751,
            "text": "Maheshtala (M) - Ward No.1"
        },
        {
            "urban_body_code": 250300,
            "id": 17752,
            "text": "Maheshtala (M) - Ward No.2"
        },
        {
            "urban_body_code": 250300,
            "id": 17753,
            "text": "Maheshtala (M) - Ward No.3"
        },
        {
            "urban_body_code": 250300,
            "id": 17754,
            "text": "Maheshtala (M) - Ward No.4"
        },
        {
            "urban_body_code": 250300,
            "id": 17744,
            "text": "Maheshtala (M) - Ward No.5"
        },
        {
            "urban_body_code": 250300,
            "id": 17745,
            "text": "Maheshtala (M) - Ward No.6"
        },
        {
            "urban_body_code": 250300,
            "id": 17746,
            "text": "Maheshtala (M) - Ward No.7"
        },
        {
            "urban_body_code": 250300,
            "id": 17747,
            "text": "Maheshtala (M) - Ward No.8"
        },
        {
            "urban_body_code": 250300,
            "id": 17748,
            "text": "Maheshtala (M) - Ward No.9"
        },
        {
            "urban_body_code": 250300,
            "id": 17749,
            "text": "Maheshtala (M) - Ward No.10"
        },
        {
            "urban_body_code": 250300,
            "id": 17750,
            "text": "Maheshtala (M) - Ward No.11"
        },
        {
            "urban_body_code": 250300,
            "id": 17755,
            "text": "Maheshtala (M) - Ward No.12"
        },
        {
            "urban_body_code": 250300,
            "id": 17756,
            "text": "Maheshtala (M) - Ward No.13"
        },
        {
            "urban_body_code": 250300,
            "id": 17757,
            "text": "Maheshtala (M) - Ward No.14"
        },
        {
            "urban_body_code": 250300,
            "id": 17758,
            "text": "Maheshtala (M) - Ward No.15"
        },
        {
            "urban_body_code": 250300,
            "id": 17759,
            "text": "Maheshtala (M) - Ward No.16"
        },
        {
            "urban_body_code": 250300,
            "id": 17760,
            "text": "Maheshtala (M) - Ward No.17"
        },
        {
            "urban_body_code": 250300,
            "id": 17761,
            "text": "Maheshtala (M) - Ward No.18"
        },
        {
            "urban_body_code": 250300,
            "id": 17762,
            "text": "Maheshtala (M) - Ward No.19"
        },
        {
            "urban_body_code": 250300,
            "id": 17763,
            "text": "Maheshtala (M) - Ward No.20"
        },
        {
            "urban_body_code": 250300,
            "id": 17764,
            "text": "Maheshtala (M) - Ward No.21"
        },
        {
            "urban_body_code": 250300,
            "id": 17765,
            "text": "Maheshtala (M) - Ward No.22"
        },
        {
            "urban_body_code": 250300,
            "id": 17766,
            "text": "Maheshtala (M) - Ward No.23"
        },
        {
            "urban_body_code": 250300,
            "id": 17767,
            "text": "Maheshtala (M) - Ward No.24"
        },
        {
            "urban_body_code": 250300,
            "id": 17768,
            "text": "Maheshtala (M) - Ward No.25"
        },
        {
            "urban_body_code": 250300,
            "id": 17769,
            "text": "Maheshtala (M) - Ward No.26"
        },
        {
            "urban_body_code": 250300,
            "id": 17770,
            "text": "Maheshtala (M) - Ward No.27"
        },
        {
            "urban_body_code": 250300,
            "id": 17771,
            "text": "Maheshtala (M) - Ward No.28"
        },
        {
            "urban_body_code": 250300,
            "id": 17772,
            "text": "Maheshtala (M) - Ward No.29"
        },
        {
            "urban_body_code": 250300,
            "id": 17773,
            "text": "Maheshtala (M) - Ward No.30"
        },
        {
            "urban_body_code": 250300,
            "id": 17774,
            "text": "Maheshtala (M) - Ward No.31"
        },
        {
            "urban_body_code": 250300,
            "id": 17775,
            "text": "Maheshtala (M) - Ward No.32"
        },
        {
            "urban_body_code": 250300,
            "id": 17776,
            "text": "Maheshtala (M) - Ward No.33"
        },
        {
            "urban_body_code": 250300,
            "id": 17777,
            "text": "Maheshtala (M) - Ward No.34"
        },
        {
            "urban_body_code": 250300,
            "id": 17778,
            "text": "Maheshtala (M) - Ward No.35"
        },
        {
            "urban_body_code": 250300,
            "id": 18161,
            "text": "Joka (OG) - Ward No.142"
        },
        {
            "urban_body_code": 250301,
            "id": 17779,
            "text": "Budge Budge (M) - Ward No.1"
        },
        {
            "urban_body_code": 250301,
            "id": 17780,
            "text": "Budge Budge (M) - Ward No.2"
        },
        {
            "urban_body_code": 250301,
            "id": 17781,
            "text": "Budge Budge (M) - Ward No.3"
        },
        {
            "urban_body_code": 250301,
            "id": 17782,
            "text": "Budge Budge (M) - Ward No.4"
        },
        {
            "urban_body_code": 250301,
            "id": 17783,
            "text": "Budge Budge (M) - Ward No.5"
        },
        {
            "urban_body_code": 250301,
            "id": 17784,
            "text": "Budge Budge (M) - Ward No.6"
        },
        {
            "urban_body_code": 250301,
            "id": 17785,
            "text": "Budge Budge (M) - Ward No.7"
        },
        {
            "urban_body_code": 250301,
            "id": 17786,
            "text": "Budge Budge (M) - Ward No.8"
        },
        {
            "urban_body_code": 250301,
            "id": 17787,
            "text": "Budge Budge (M) - Ward No.9"
        },
        {
            "urban_body_code": 250301,
            "id": 17788,
            "text": "Budge Budge (M) - Ward No.10"
        },
        {
            "urban_body_code": 250301,
            "id": 17789,
            "text": "Budge Budge (M) - Ward No.11"
        },
        {
            "urban_body_code": 250301,
            "id": 17790,
            "text": "Budge Budge (M) - Ward No.12"
        },
        {
            "urban_body_code": 250301,
            "id": 17791,
            "text": "Budge Budge (M) - Ward No.13"
        },
        {
            "urban_body_code": 250301,
            "id": 17792,
            "text": "Budge Budge (M) - Ward No.14"
        },
        {
            "urban_body_code": 250301,
            "id": 17793,
            "text": "Budge Budge (M) - Ward No.15"
        },
        {
            "urban_body_code": 250301,
            "id": 17794,
            "text": "Budge Budge (M) - Ward No.16"
        },
        {
            "urban_body_code": 250301,
            "id": 17795,
            "text": "Budge Budge (M) - Ward No.17"
        },
        {
            "urban_body_code": 250301,
            "id": 17796,
            "text": "Budge Budge (M) - Ward No.18"
        },
        {
            "urban_body_code": 250301,
            "id": 17797,
            "text": "Budge Budge (M) - Ward No.19"
        },
        {
            "urban_body_code": 250301,
            "id": 17798,
            "text": "Budge Budge (M) - Ward No.20"
        },
        {
            "urban_body_code": 250301,
            "id": 18165,
            "text": "Nischintapur (OG) - Ward No.21"
        },
        {
            "urban_body_code": 250302,
            "id": 17799,
            "text": "Pujali (M) - Ward No.1"
        },
        {
            "urban_body_code": 250302,
            "id": 17800,
            "text": "Pujali (M) - Ward No.2"
        },
        {
            "urban_body_code": 250302,
            "id": 17801,
            "text": "Pujali (M) - Ward No.3"
        },
        {
            "urban_body_code": 250302,
            "id": 17802,
            "text": "Pujali (M) - Ward No.4"
        },
        {
            "urban_body_code": 250302,
            "id": 17803,
            "text": "Pujali (M) - Ward No.5"
        },
        {
            "urban_body_code": 250302,
            "id": 17804,
            "text": "Pujali (M) - Ward No.6"
        },
        {
            "urban_body_code": 250302,
            "id": 17805,
            "text": "Pujali (M) - Ward No.7"
        },
        {
            "urban_body_code": 250302,
            "id": 17806,
            "text": "Pujali (M) - Ward No.8"
        },
        {
            "urban_body_code": 250302,
            "id": 17807,
            "text": "Pujali (M) - Ward No.9"
        },
        {
            "urban_body_code": 250302,
            "id": 17808,
            "text": "Pujali (M) - Ward No.10"
        },
        {
            "urban_body_code": 250302,
            "id": 17809,
            "text": "Pujali (M) - Ward No.11"
        },
        {
            "urban_body_code": 250302,
            "id": 17810,
            "text": "Pujali (M) - Ward No.12"
        },
        {
            "urban_body_code": 250302,
            "id": 17811,
            "text": "Pujali (M) - Ward No.13"
        },
        {
            "urban_body_code": 250302,
            "id": 17812,
            "text": "Pujali (M) - Ward No.14"
        },
        {
            "urban_body_code": 250302,
            "id": 17813,
            "text": "Pujali (M) - Ward No.15"
        },
        {
            "urban_body_code": 250302,
            "id": 9999368,
            "text": "Pujali (M) - Ward No.16"
        },
        {
            "urban_body_code": 250303,
            "id": 17814,
            "text": "Rajpur Sonarpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250303,
            "id": 17815,
            "text": "Rajpur Sonarpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250303,
            "id": 17816,
            "text": "Rajpur Sonarpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250303,
            "id": 17817,
            "text": "Rajpur Sonarpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250303,
            "id": 17818,
            "text": "Rajpur Sonarpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250303,
            "id": 17819,
            "text": "Rajpur Sonarpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250303,
            "id": 17820,
            "text": "Rajpur Sonarpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250303,
            "id": 17821,
            "text": "Rajpur Sonarpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250303,
            "id": 17822,
            "text": "Rajpur Sonarpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250303,
            "id": 17823,
            "text": "Rajpur Sonarpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250303,
            "id": 17824,
            "text": "Rajpur Sonarpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250303,
            "id": 17825,
            "text": "Rajpur Sonarpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250303,
            "id": 17826,
            "text": "Rajpur Sonarpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250303,
            "id": 17827,
            "text": "Rajpur Sonarpur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250303,
            "id": 17828,
            "text": "Rajpur Sonarpur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250303,
            "id": 17829,
            "text": "Rajpur Sonarpur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250303,
            "id": 17830,
            "text": "Rajpur Sonarpur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250303,
            "id": 17831,
            "text": "Rajpur Sonarpur (M) - Ward No.18"
        },
        {
            "urban_body_code": 250303,
            "id": 17832,
            "text": "Rajpur Sonarpur (M) - Ward No.19"
        },
        {
            "urban_body_code": 250303,
            "id": 17833,
            "text": "Rajpur Sonarpur (M) - Ward No.20"
        },
        {
            "urban_body_code": 250303,
            "id": 17834,
            "text": "Rajpur Sonarpur (M) - Ward No.21"
        },
        {
            "urban_body_code": 250303,
            "id": 17835,
            "text": "Rajpur Sonarpur (M) - Ward No.22"
        },
        {
            "urban_body_code": 250303,
            "id": 18119,
            "text": "Rajpur Sonarpur (M) - Ward No.23"
        },
        {
            "urban_body_code": 250303,
            "id": 18120,
            "text": "Rajpur Sonarpur (M) - Ward No.24"
        },
        {
            "urban_body_code": 250303,
            "id": 18121,
            "text": "Rajpur Sonarpur (M) - Ward No.25"
        },
        {
            "urban_body_code": 250303,
            "id": 18122,
            "text": "Rajpur Sonarpur (M) - Ward No.26"
        },
        {
            "urban_body_code": 250303,
            "id": 18123,
            "text": "Rajpur Sonarpur (M) - Ward No.27"
        },
        {
            "urban_body_code": 250303,
            "id": 18124,
            "text": "Rajpur Sonarpur (M) - Ward No.28"
        },
        {
            "urban_body_code": 250303,
            "id": 18125,
            "text": "Rajpur Sonarpur (M) - Ward No.29"
        },
        {
            "urban_body_code": 250303,
            "id": 18126,
            "text": "Rajpur Sonarpur (M) - Ward No.30"
        },
        {
            "urban_body_code": 250303,
            "id": 18127,
            "text": "Rajpur Sonarpur (M) - Ward No.31"
        },
        {
            "urban_body_code": 250303,
            "id": 18128,
            "text": "Rajpur Sonarpur (M) - Ward No.32"
        },
        {
            "urban_body_code": 250303,
            "id": 18129,
            "text": "Rajpur Sonarpur (M) - Ward No.33"
        },
        {
            "urban_body_code": 250303,
            "id": 9999371,
            "text": "Rajpur Sonarpur (M) - Ward No.34"
        },
        {
            "urban_body_code": 250303,
            "id": 9999405,
            "text": "Rajpur Sonarpur (M) - Ward No.34"
        },
        {
            "urban_body_code": 250303,
            "id": 9999372,
            "text": "Rajpur Sonarpur (M) - Ward No.35"
        },
        {
            "urban_body_code": 250303,
            "id": 9999406,
            "text": "Rajpur Sonarpur (M) - Ward No.35"
        },
        {
            "urban_body_code": 250304,
            "id": 18130,
            "text": "Baruipur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250304,
            "id": 18131,
            "text": "Baruipur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250304,
            "id": 18132,
            "text": "Baruipur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250304,
            "id": 18133,
            "text": "Baruipur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250304,
            "id": 18134,
            "text": "Baruipur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250304,
            "id": 18135,
            "text": "Baruipur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250304,
            "id": 18136,
            "text": "Baruipur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250304,
            "id": 18137,
            "text": "Baruipur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250304,
            "id": 18138,
            "text": "Baruipur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250304,
            "id": 18139,
            "text": "Baruipur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250304,
            "id": 18140,
            "text": "Baruipur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250304,
            "id": 18141,
            "text": "Baruipur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250304,
            "id": 18142,
            "text": "Baruipur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250304,
            "id": 18143,
            "text": "Baruipur (M) - Ward No.14"
        },
        {
            "urban_body_code": 250304,
            "id": 18144,
            "text": "Baruipur (M) - Ward No.15"
        },
        {
            "urban_body_code": 250304,
            "id": 18145,
            "text": "Baruipur (M) - Ward No.16"
        },
        {
            "urban_body_code": 250304,
            "id": 18146,
            "text": "Baruipur (M) - Ward No.17"
        },
        {
            "urban_body_code": 250305,
            "id": 69277,
            "text": "Diamond Harbour (M) - Ward No.1"
        },
        {
            "urban_body_code": 250305,
            "id": 69278,
            "text": "Diamond Harbour (M) - Ward No.2"
        },
        {
            "urban_body_code": 250305,
            "id": 69279,
            "text": "Diamond Harbour (M) - Ward No.3"
        },
        {
            "urban_body_code": 250305,
            "id": 69280,
            "text": "Diamond Harbour (M) - Ward No.4"
        },
        {
            "urban_body_code": 250305,
            "id": 69281,
            "text": "Diamond Harbour (M) - Ward No.5"
        },
        {
            "urban_body_code": 250305,
            "id": 69282,
            "text": "Diamond Harbour (M) - Ward No.6"
        },
        {
            "urban_body_code": 250305,
            "id": 69283,
            "text": "Diamond Harbour (M) - Ward No.7"
        },
        {
            "urban_body_code": 250305,
            "id": 69284,
            "text": "Diamond Harbour (M) - Ward No.8"
        },
        {
            "urban_body_code": 250305,
            "id": 69285,
            "text": "Diamond Harbour (M) - Ward No.9"
        },
        {
            "urban_body_code": 250305,
            "id": 69286,
            "text": "Diamond Harbour (M) - Ward No.10"
        },
        {
            "urban_body_code": 250305,
            "id": 69287,
            "text": "Diamond Harbour (M) - Ward No.11"
        },
        {
            "urban_body_code": 250305,
            "id": 69288,
            "text": "Diamond Harbour (M) - Ward No.12"
        },
        {
            "urban_body_code": 250305,
            "id": 69289,
            "text": "Diamond Harbour (M) - Ward No.13"
        },
        {
            "urban_body_code": 250305,
            "id": 69290,
            "text": "Diamond Harbour (M) - Ward No.14"
        },
        {
            "urban_body_code": 250305,
            "id": 69291,
            "text": "Diamond Harbour (M) - Ward No.15"
        },
        {
            "urban_body_code": 250305,
            "id": 69292,
            "text": "Diamond Harbour (M) - Ward No.16"
        },
        {
            "urban_body_code": 250306,
            "id": 18147,
            "text": "Jaynagar Mazilpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 250306,
            "id": 18148,
            "text": "Jaynagar Mazilpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 250306,
            "id": 18149,
            "text": "Jaynagar Mazilpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 250306,
            "id": 18150,
            "text": "Jaynagar Mazilpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 250306,
            "id": 18151,
            "text": "Jaynagar Mazilpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 250306,
            "id": 18152,
            "text": "Jaynagar Mazilpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 250306,
            "id": 18153,
            "text": "Jaynagar Mazilpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 250306,
            "id": 18154,
            "text": "Jaynagar Mazilpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 250306,
            "id": 18155,
            "text": "Jaynagar Mazilpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 250306,
            "id": 18156,
            "text": "Jaynagar Mazilpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 250306,
            "id": 18157,
            "text": "Jaynagar Mazilpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 250306,
            "id": 18158,
            "text": "Jaynagar Mazilpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 250306,
            "id": 18159,
            "text": "Jaynagar Mazilpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 250306,
            "id": 18160,
            "text": "Jaynagar Mazilpur (M) - Ward No.14"
        },
        {
            "urban_body_code": 253229,
            "id": 977,
            "text": "Panskura (M) - Ward No.1"
        },
        {
            "urban_body_code": 253229,
            "id": 7500,
            "text": "Panskura (M) - Ward No.2"
        },
        {
            "urban_body_code": 253229,
            "id": 7501,
            "text": "Panskura (M) - Ward No.3"
        },
        {
            "urban_body_code": 253229,
            "id": 7502,
            "text": "Panskura (M) - Ward No.4"
        },
        {
            "urban_body_code": 253229,
            "id": 7503,
            "text": "Panskura (M) - Ward No.5"
        },
        {
            "urban_body_code": 253229,
            "id": 7504,
            "text": "Panskura (M) - Ward No.6"
        },
        {
            "urban_body_code": 253229,
            "id": 7505,
            "text": "Panskura (M) - Ward No.7"
        },
        {
            "urban_body_code": 253229,
            "id": 7506,
            "text": "Panskura (M) - Ward No.8"
        },
        {
            "urban_body_code": 253229,
            "id": 7507,
            "text": "Panskura (M) - Ward No.9"
        },
        {
            "urban_body_code": 253229,
            "id": 7508,
            "text": "Panskura (M) - Ward No.10"
        },
        {
            "urban_body_code": 253229,
            "id": 7509,
            "text": "Panskura (M) - Ward No.11"
        },
        {
            "urban_body_code": 253229,
            "id": 7510,
            "text": "Panskura (M) - Ward No.12"
        },
        {
            "urban_body_code": 253229,
            "id": 7511,
            "text": "Panskura (M) - Ward No.13"
        },
        {
            "urban_body_code": 253229,
            "id": 7512,
            "text": "Panskura (M) - Ward No.14"
        },
        {
            "urban_body_code": 253229,
            "id": 7513,
            "text": "Panskura (M) - Ward No.15"
        },
        {
            "urban_body_code": 253229,
            "id": 7514,
            "text": "Panskura (M) - Ward No.16"
        },
        {
            "urban_body_code": 253229,
            "id": 7515,
            "text": "Panskura (M) - Ward No.17"
        },
        {
            "urban_body_code": 253229,
            "id": 9999367,
            "text": "Panskura (M) - Ward No.18"
        },
        {
            "urban_body_code": 253250,
            "id": 54369,
            "text": "Nalhati (M) - Ward No.1"
        },
        {
            "urban_body_code": 253250,
            "id": 54370,
            "text": "Nalhati (M) - Ward No.2"
        },
        {
            "urban_body_code": 253250,
            "id": 54371,
            "text": "Nalhati (M) - Ward No.3"
        },
        {
            "urban_body_code": 253250,
            "id": 54372,
            "text": "Nalhati (M) - Ward No.4"
        },
        {
            "urban_body_code": 253250,
            "id": 54373,
            "text": "Nalhati (M) - Ward No.5"
        },
        {
            "urban_body_code": 253250,
            "id": 54374,
            "text": "Nalhati (M) - Ward No.6"
        },
        {
            "urban_body_code": 253250,
            "id": 54375,
            "text": "Nalhati (M) - Ward No.7"
        },
        {
            "urban_body_code": 253250,
            "id": 54376,
            "text": "Nalhati (M) - Ward No.8"
        },
        {
            "urban_body_code": 253250,
            "id": 54377,
            "text": "Nalhati (M) - Ward No.9"
        },
        {
            "urban_body_code": 253250,
            "id": 54378,
            "text": "Nalhati (M) - Ward No.10"
        },
        {
            "urban_body_code": 253250,
            "id": 54379,
            "text": "Nalhati (M) - Ward No.11"
        },
        {
            "urban_body_code": 253250,
            "id": 54380,
            "text": "Nalhati (M) - Ward No.12"
        },
        {
            "urban_body_code": 253250,
            "id": 54381,
            "text": "Nalhati (M) - Ward No.13"
        },
        {
            "urban_body_code": 253250,
            "id": 54382,
            "text": "Nalhati (M) - Ward No.14"
        },
        {
            "urban_body_code": 253250,
            "id": 54383,
            "text": "Nalhati (M) - Ward No.15"
        },
        {
            "urban_body_code": 253250,
            "id": 54384,
            "text": "Nalhati (M) - Ward No.16"
        },
        {
            "urban_body_code": 253251,
            "id": 69294,
            "text": "NKDA (M) - Ward No.1"
        },
        {
            "urban_body_code": 253252,
            "id": 69295,
            "text": "Falakata (M) - Ward No.1"
        },
        {
            "urban_body_code": 253252,
            "id": 69296,
            "text": "Falakata (M) - Ward No.2"
        },
        {
            "urban_body_code": 253252,
            "id": 69297,
            "text": "Falakata (M) - Ward No.3"
        },
        {
            "urban_body_code": 253252,
            "id": 69298,
            "text": "Falakata (M) - Ward No.4"
        },
        {
            "urban_body_code": 253252,
            "id": 69299,
            "text": "Falakata (M) - Ward No.5"
        },
        {
            "urban_body_code": 253252,
            "id": 69300,
            "text": "Falakata (M) - Ward No.6"
        },
        {
            "urban_body_code": 253252,
            "id": 69301,
            "text": "Falakata (M) - Ward No.7"
        },
        {
            "urban_body_code": 253252,
            "id": 69302,
            "text": "Falakata (M) - Ward No.8"
        },
        {
            "urban_body_code": 253252,
            "id": 69303,
            "text": "Falakata (M) - Ward No.9"
        },
        {
            "urban_body_code": 253252,
            "id": 69304,
            "text": "Falakata (M) - Ward No.10"
        },
        {
            "urban_body_code": 253252,
            "id": 69305,
            "text": "Falakata (M) - Ward No.11"
        },
        {
            "urban_body_code": 253252,
            "id": 69306,
            "text": "Falakata (M) - Ward No.12"
        },
        {
            "urban_body_code": 253252,
            "id": 69307,
            "text": "Falakata (M) - Ward No.13"
        },
        {
            "urban_body_code": 253252,
            "id": 69308,
            "text": "Falakata (M) - Ward No.14"
        },
        {
            "urban_body_code": 253252,
            "id": 69309,
            "text": "Falakata (M) - Ward No.15"
        },
        {
            "urban_body_code": 253252,
            "id": 69310,
            "text": "Falakata (M) - Ward No.16"
        },
        {
            "urban_body_code": 253252,
            "id": 69311,
            "text": "Falakata (M) - Ward No.17"
        },
        {
            "urban_body_code": 253252,
            "id": 69312,
            "text": "Falakata (M) - Ward No.18"
        },
        {
            "urban_body_code": 273006,
            "id": 9999314,
            "text": "Haringhata (M) - Ward No.1"
        },
        {
            "urban_body_code": 273006,
            "id": 9999315,
            "text": "Haringhata (M) - Ward No.2"
        },
        {
            "urban_body_code": 273006,
            "id": 9999316,
            "text": "Haringhata (M) - Ward No.3"
        },
        {
            "urban_body_code": 273006,
            "id": 9999317,
            "text": "Haringhata (M) - Ward No.4"
        },
        {
            "urban_body_code": 273006,
            "id": 9999318,
            "text": "Haringhata (M) - Ward No.5"
        },
        {
            "urban_body_code": 273006,
            "id": 9999319,
            "text": "Haringhata (M) - Ward No.6"
        },
        {
            "urban_body_code": 273006,
            "id": 9999320,
            "text": "Haringhata (M) - Ward No.7"
        },
        {
            "urban_body_code": 273006,
            "id": 9999321,
            "text": "Haringhata (M) - Ward No.8"
        },
        {
            "urban_body_code": 273006,
            "id": 9999322,
            "text": "Haringhata (M) - Ward No.9"
        },
        {
            "urban_body_code": 273006,
            "id": 9999323,
            "text": "Haringhata (M) - Ward No.10"
        },
        {
            "urban_body_code": 273006,
            "id": 9999324,
            "text": "Haringhata (M) - Ward No.11"
        },
        {
            "urban_body_code": 273006,
            "id": 9999325,
            "text": "Haringhata (M) - Ward No.12"
        },
        {
            "urban_body_code": 273006,
            "id": 9999326,
            "text": "Haringhata (M) - Ward No.13"
        },
        {
            "urban_body_code": 273006,
            "id": 9999327,
            "text": "Haringhata (M) - Ward No.14"
        },
        {
            "urban_body_code": 273006,
            "id": 9999328,
            "text": "Haringhata (M) - Ward No.15"
        },
        {
            "urban_body_code": 273006,
            "id": 9999329,
            "text": "Haringhata (M) - Ward No.16"
        },
        {
            "urban_body_code": 273006,
            "id": 9999330,
            "text": "Haringhata (M) - Ward No.17"
        },
        {
            "urban_body_code": 273007,
            "id": 9999266,
            "text": "Domkal (M) - Ward No.1"
        },
        {
            "urban_body_code": 273007,
            "id": 9999267,
            "text": "Domkal (M) - Ward No.2"
        },
        {
            "urban_body_code": 273007,
            "id": 9999268,
            "text": "Domkal (M) - Ward No.3"
        },
        {
            "urban_body_code": 273007,
            "id": 9999269,
            "text": "Domkal (M) - Ward No.4"
        },
        {
            "urban_body_code": 273007,
            "id": 9999270,
            "text": "Domkal (M) - Ward No.5"
        },
        {
            "urban_body_code": 273007,
            "id": 9999271,
            "text": "Domkal (M) - Ward No.6"
        },
        {
            "urban_body_code": 273007,
            "id": 9999272,
            "text": "Domkal (M) - Ward No.7"
        },
        {
            "urban_body_code": 273007,
            "id": 9999273,
            "text": "Domkal (M) - Ward No.8"
        },
        {
            "urban_body_code": 273007,
            "id": 9999274,
            "text": "Domkal (M) - Ward No.9"
        },
        {
            "urban_body_code": 273007,
            "id": 9999275,
            "text": "Domkal (M) - Ward No.10"
        },
        {
            "urban_body_code": 273007,
            "id": 9999276,
            "text": "Domkal (M) - Ward No.11"
        },
        {
            "urban_body_code": 273007,
            "id": 9999277,
            "text": "Domkal (M) - Ward No.12"
        },
        {
            "urban_body_code": 273007,
            "id": 9999278,
            "text": "Domkal (M) - Ward No.13"
        },
        {
            "urban_body_code": 273007,
            "id": 9999279,
            "text": "Domkal (M) - Ward No.14"
        },
        {
            "urban_body_code": 273007,
            "id": 9999280,
            "text": "Domkal (M) - Ward No.15"
        },
        {
            "urban_body_code": 273007,
            "id": 9999281,
            "text": "Domkal (M) - Ward No.16"
        },
        {
            "urban_body_code": 273007,
            "id": 9999282,
            "text": "Domkal (M) - Ward No.17"
        },
        {
            "urban_body_code": 273007,
            "id": 9999283,
            "text": "Domkal (M) - Ward No.18"
        },
        {
            "urban_body_code": 273007,
            "id": 9999284,
            "text": "Domkal (M) - Ward No.19"
        },
        {
            "urban_body_code": 273007,
            "id": 9999285,
            "text": "Domkal (M) - Ward No.20"
        },
        {
            "urban_body_code": 273007,
            "id": 9999286,
            "text": "Domkal (M) - Ward No.21"
        },
        {
            "urban_body_code": 277279,
            "id": 69293,
            "text": "Barrackpore Cantonment Board (M) - Ward No.1"
        },
        {
            "urban_body_code": 289244,
            "id": 9999195,
            "text": "Buniadpur (M) - Ward No.1"
        },
        {
            "urban_body_code": 289244,
            "id": 9999196,
            "text": "Buniadpur (M) - Ward No.2"
        },
        {
            "urban_body_code": 289244,
            "id": 9999197,
            "text": "Buniadpur (M) - Ward No.3"
        },
        {
            "urban_body_code": 289244,
            "id": 9999198,
            "text": "Buniadpur (M) - Ward No.4"
        },
        {
            "urban_body_code": 289244,
            "id": 9999199,
            "text": "Buniadpur (M) - Ward No.5"
        },
        {
            "urban_body_code": 289244,
            "id": 9999200,
            "text": "Buniadpur (M) - Ward No.6"
        },
        {
            "urban_body_code": 289244,
            "id": 9999201,
            "text": "Buniadpur (M) - Ward No.7"
        },
        {
            "urban_body_code": 289244,
            "id": 9999202,
            "text": "Buniadpur (M) - Ward No.8"
        },
        {
            "urban_body_code": 289244,
            "id": 9999203,
            "text": "Buniadpur (M) - Ward No.9"
        },
        {
            "urban_body_code": 289244,
            "id": 9999204,
            "text": "Buniadpur (M) - Ward No.10"
        },
        {
            "urban_body_code": 289244,
            "id": 9999205,
            "text": "Buniadpur (M) - Ward No.11"
        },
        {
            "urban_body_code": 289244,
            "id": 9999206,
            "text": "Buniadpur (M) - Ward No.12"
        },
        {
            "urban_body_code": 289244,
            "id": 9999207,
            "text": "Buniadpur (M) - Ward No.13"
        },
        {
            "urban_body_code": 289244,
            "id": 9999208,
            "text": "Buniadpur (M) - Ward No.14"
        },
        {
            "urban_body_code": 999991,
            "id": 66445,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.31"
        },
        {
            "urban_body_code": 999991,
            "id": 66446,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.32"
        },
        {
            "urban_body_code": 999991,
            "id": 66447,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.33"
        },
        {
            "urban_body_code": 999991,
            "id": 66448,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.34"
        },
        {
            "urban_body_code": 999991,
            "id": 66449,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.35"
        },
        {
            "urban_body_code": 999991,
            "id": 66450,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.36"
        },
        {
            "urban_body_code": 999991,
            "id": 66451,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.37"
        },
        {
            "urban_body_code": 999991,
            "id": 66452,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.38"
        },
        {
            "urban_body_code": 999991,
            "id": 66453,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.39"
        },
        {
            "urban_body_code": 999991,
            "id": 66454,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.40"
        },
        {
            "urban_body_code": 999991,
            "id": 66455,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.41"
        },
        {
            "urban_body_code": 999991,
            "id": 66456,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.42"
        },
        {
            "urban_body_code": 999991,
            "id": 66457,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.43"
        },
        {
            "urban_body_code": 999991,
            "id": 66458,
            "text": "Siliguri (M Corp.) (Part) JPG - Ward No.44"
        },
        {
            "urban_body_code": 999992,
            "id": 9999228,
            "text": "Dankuni (M) - Ward No.1"
        },
        {
            "urban_body_code": 999992,
            "id": 9999229,
            "text": "Dankuni (M) - Ward No.2"
        },
        {
            "urban_body_code": 999992,
            "id": 9999230,
            "text": "Dankuni (M) - Ward No.3"
        },
        {
            "urban_body_code": 999992,
            "id": 9999231,
            "text": "Dankuni (M) - Ward No.4"
        },
        {
            "urban_body_code": 999992,
            "id": 9999232,
            "text": "Dankuni (M) - Ward No.5"
        },
        {
            "urban_body_code": 999992,
            "id": 9999233,
            "text": "Dankuni (M) - Ward No.6"
        },
        {
            "urban_body_code": 999992,
            "id": 9999234,
            "text": "Dankuni (M) - Ward No.7"
        },
        {
            "urban_body_code": 999992,
            "id": 9999235,
            "text": "Dankuni (M) - Ward No.8"
        },
        {
            "urban_body_code": 999992,
            "id": 9999236,
            "text": "Dankuni (M) - Ward No.9"
        },
        {
            "urban_body_code": 999992,
            "id": 9999237,
            "text": "Dankuni (M) - Ward No.10"
        },
        {
            "urban_body_code": 999992,
            "id": 9999238,
            "text": "Dankuni (M) - Ward No.11"
        },
        {
            "urban_body_code": 999992,
            "id": 9999239,
            "text": "Dankuni (M) - Ward No.12"
        },
        {
            "urban_body_code": 999992,
            "id": 9999240,
            "text": "Dankuni (M) - Ward No.13"
        },
        {
            "urban_body_code": 999992,
            "id": 9999241,
            "text": "Dankuni (M) - Ward No.14"
        },
        {
            "urban_body_code": 999992,
            "id": 9999242,
            "text": "Dankuni (M) - Ward No.15"
        },
        {
            "urban_body_code": 999992,
            "id": 9999243,
            "text": "Dankuni (M) - Ward No.16"
        },
        {
            "urban_body_code": 999992,
            "id": 9999244,
            "text": "Dankuni (M) - Ward No.17"
        },
        {
            "urban_body_code": 999992,
            "id": 9999245,
            "text": "Dankuni (M) - Ward No.18"
        },
        {
            "urban_body_code": 999992,
            "id": 9999246,
            "text": "Dankuni (M) - Ward No.19"
        },
        {
            "urban_body_code": 999992,
            "id": 9999247,
            "text": "Dankuni (M) - Ward No.20"
        },
        {
            "urban_body_code": 999992,
            "id": 9999248,
            "text": "Dankuni (M) - Ward No.21"
        },
        {
            "urban_body_code": 999994,
            "id": 9999417,
            "text": "Mainaguri (M) - Ward No.1"
        },
        {
            "urban_body_code": 999994,
            "id": 9999418,
            "text": "Mainaguri (M) - Ward No.2"
        },
        {
            "urban_body_code": 999994,
            "id": 9999419,
            "text": "Mainaguri (M) - Ward No.3"
        },
        {
            "urban_body_code": 999994,
            "id": 9999420,
            "text": "Mainaguri (M) - Ward No.4"
        },
        {
            "urban_body_code": 999994,
            "id": 9999421,
            "text": "Mainaguri (M) - Ward No.5"
        },
        {
            "urban_body_code": 999994,
            "id": 9999422,
            "text": "Mainaguri (M) - Ward No.6"
        },
        {
            "urban_body_code": 999994,
            "id": 9999423,
            "text": "Mainaguri (M) - Ward No.7"
        },
        {
            "urban_body_code": 999994,
            "id": 9999424,
            "text": "Mainaguri (M) - Ward No.8"
        },
        {
            "urban_body_code": 999994,
            "id": 9999425,
            "text": "Mainaguri (M) - Ward No.9"
        },
        {
            "urban_body_code": 999994,
            "id": 9999426,
            "text": "Mainaguri (M) - Ward No.10"
        },
        {
            "urban_body_code": 999994,
            "id": 9999427,
            "text": "Mainaguri (M) - Ward No.11"
        },
        {
            "urban_body_code": 999994,
            "id": 9999428,
            "text": "Mainaguri (M) - Ward No.12"
        },
        {
            "urban_body_code": 999994,
            "id": 9999429,
            "text": "Mainaguri (M) - Ward No.13"
        },
        {
            "urban_body_code": 999994,
            "id": 9999430,
            "text": "Mainaguri (M) - Ward No.14"
        },
        {
            "urban_body_code": 999994,
            "id": 9999431,
            "text": "Mainaguri (M) - Ward No.15"
        },
        {
            "urban_body_code": 999994,
            "id": 9999432,
            "text": "Mainaguri (M) - Ward No.16"
        },
        {
            "urban_body_code": 999994,
            "id": 9999433,
            "text": "Mainaguri (M) - Ward No.17"
        }
    ];


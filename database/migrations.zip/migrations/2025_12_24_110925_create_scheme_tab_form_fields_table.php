<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('scheme_tab_form_fields', function (Blueprint $table) {
            $table->id();
            $table->integer('tab_field_id')->references('id')->on('scheme_tab_basefields')->onDelete('cascade');
            ;
            $table->integer('scheme_id');
            $table->string('level_name', 100)->nullable();
            $table->string('field_name', 100);
            $table->string('field_id', 50);
            $table->string('field_type', 50);
            $table->jsonb('options')->nullable();
            $table->boolean('is_common')->default(false);
            $table->string('db_column')->nullable();
            $table->integer('is_mandatory')->nullable()->default(0);
            $table->integer('tab_code');
            $table->string('validation_rule', 255)->nullable();
            $table->string('regex', 255)->nullable();
            $table->bigInteger('confirm_of')->nullable();
            $table->string('dependent_on', 50)->nullable();
            $table->jsonb('dependent_on_values')->nullable();
            $table->string('field_class', 100)->nullable();
            $table->boolean('is_multiple')->default(false);
            $table->integer('field_position');
            $table->boolean('is_active')->default(true);
            $table->integer('section_level_id')->nullable();
            $table->integer('section_level_type')->nullable();
            $table->smallInteger('is_readonly')->nullable()->default(0);
            $table->timestamps();
            $table->foreign('tab_code')->references('tab_code')->on('master_tabs')->onDelete('cascade');
            $table->unique(['tab_code', 'scheme_id', 'tab_field_id', 'field_name', 'level_name']);
            $table->index(['tab_code', 'scheme_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('scheme_tab_form_fields');
    }
};
